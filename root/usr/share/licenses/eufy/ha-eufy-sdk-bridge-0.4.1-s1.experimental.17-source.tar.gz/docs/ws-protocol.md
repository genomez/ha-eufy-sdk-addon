# ha-eufy-sdk-bridge — WebSocket protocol

Modified for genomez S1 experimental source preview, 2026-10-16.

The bridge exposes control, state, auth and events over one WebSocket, and video/snapshots over sibling
HTTP endpoints. This is the reference for what a frontend (the HACS integration, a web UI, anything)
sends and receives.

- **Endpoint:** `ws://<host>:3000/ws`
- **Schema version:** `1` (sent in `hello`/`ready`; bumped on any breaking change so an old client fails loudly)
- **Encoding:** JSON text frames.

## Message shapes

**Request** (client → bridge): a `cmd` plus a caller-chosen `id` used to match the reply.

```json
{ "id": 1, "cmd": "<command>", "...": "command args" }
```

**Response** (bridge → client): echoes `id`, with `ok`.

```json
{ "id": 1, "ok": true,  "...": "result fields" }
{ "id": 1, "ok": false, "error": "reason" }
```

**Event** (bridge → client, unsolicited): no `id`, carries an `event` name.

```json
{ "event": "<name>", "...": "payload" }
```

---

## Commands

### Recordings browse, version 1

This additive capability keeps global schema version 1. This build defaults
`RECORDINGS_ENABLED` on (truthy: `1`, `true`, `yes`, `on`); `RECORDINGS_ROOT`
defaults to `/data/recordings`. Missing SDK read methods advertise `enabled:false`.
Startup, camera-list browsing, cache-only requests and detection pushes never
initiate recording reads. The bridge network remains a trusted control network;
the existing host HTTP/command policy hooks also apply to these routes.

```ts
// Additional hello member:
recordings: {
  version: 1; browseOnly: boolean; playback: boolean; enabled: boolean; scopeId: string | null;
  timezone: string; stationWindow: number; pageSize: 100; coverBudget: 100;
}

// Requests (no cursor, grant, serial, path, selector or URL fields):
{ id, cmd: "recordings.cameras" }
{ id, cmd: "recordings.catalog", cameraId,
  refresh: "cache_only" | "if_due", focusEventId?: string }
{ id, cmd: "recordings.cover", cameraId, eventId,
  browseId: string | null, mode: "cache_only" | "request_if_admitted" }

// Every successful command:
{ id, ok: true, recordings: CameraList | Catalog | Cover }
// Every recordings failure:
{ id, ok: false, code, error: "Recordings unavailable" }
```

IDs use `s_`, `c_`, `e_` followed by 22 base64url characters. Browse IDs are
22-character random base64url tokens held only in memory. Unknown request fields
are rejected. RPC IDs are safe integers or 1–128 letters, digits, `_`, `-`.
Failure codes are `recordings_disabled`, `recordings_unsupported`,
`recordings_invalid`, `recordings_not_found`, `recordings_scope_invalid`,
`recordings_store_unavailable`.

```ts
type CameraList = {
  version: 1;
  scopeId: string;
  cameras: { cameraId: string; name: string; scopeId: string }[];
};
type Catalog = {
  version: 1;
  scopeId: string;
  cameraId: string;
  playbackSupported?: boolean;
  revision: string;
  events: RecordingEvent[];
  truncated: boolean;
  historyIncomplete: true;
  stationWindow: number;
  disclosure: string;
  lastSuccessfulQueryAtMs: number | null;
  lastAttemptAtMs: number | null;
  dirty: boolean;
  refresh: {
    state: "idle" | "scheduled" | "deferred" | "rate_limited" | "failed";
    reason:
      | "none"
      | "busy"
      | "playback"
      | "renewal"
      | "refresh_hold"
      | "offline"
      | "scope_invalid"
      | "rate_limited"
      | "timeout"
      | "invalid_reply"
      | "store_unavailable";
    retryAfterMs: number | null;
  };
  browseId: string | null;
  browseExpiresAtMs: number | null;
  coverEligibleEventIds: string[];
};
type RecordingEvent = {
  eventId: string;
  cameraId: string;
  startedAtMs: number | null;
  endedAtMs: number | null;
  startedAtUtc: string | null;
  startedAtLocal: string | null;
  sourceStartLocal: string | null;
  timezone: string;
  timeStatus: "valid" | "unknown_format" | "ambiguous" | "invalid";
  durationSeconds: number | null;
  durationBasis: "end_minus_start" | "unknown";
  eventType: { code: number | null; label: string };
  detectType: { code: number | null; label: string };
  firstObservedAtMs: number;
  lastObservedAtMs: number;
  stationPresence: "seen_in_latest_window" | "not_in_latest_window";
  coverState: "not_requested" | "pending" | "cached" | "unavailable" | "evicted";
  coverRevision: string | null;
  playable: boolean;
};
type Cover = {
  version: 1;
  cameraId: string;
  eventId: string;
  state: "ready" | "pending" | "deferred" | "unavailable" | "evicted";
  retryAfterMs: number | null;
  bytes?: number;
  sha256?: string;
  coverRevision?: string; // ready only
};
```

Catalog responses contain at most 100 newest entries, or the single requested focus event;
there is no public cursor. Bounded internal station continuation is described below.
The additive version-1 `playbackSupported` field reports whether this enrolled camera's
model is enabled by the current playback model policy, including live policy changes.
It is independent of row count, selectors and the global playback switch; `true` is
not a guarantee of playable media. Excluded cameras still receive no catalog.
Clients may use `false` for a non-playable camera-folder information item and `true`
with zero rows for an empty-folder item. Older bridges omit this field: clients must
then keep their existing behavior without adding either item. Information items must
not initiate requests, expose thumbnails or change existing IDs and signing rules.
Known times precede unknown times.
`if_due` returns cached data promptly, records a camera/socket interest for 60 s,
and requests at most one station-wide refresh per 60 s, including failed exchanges.
Transient SDK deferrals (`observing`, `busy`, `quiet_period`, `renewal_due`,
`reply_capacity`, `owner_unhealthy`) release that reservation. A shared cycle allows
at most two automatic retries per 60 s, with one retry timer; repeated browsing
cannot add retries. Retry hints are honored (bounded to 1–300 s); without a hint,
the first retry waits 5 s and the second 30 s. Interest must still be active,
unless the cycle belongs to the enabled background schedule.
An unhinted `observing` deferral waits 61 s, beyond the 60 s browse intent;
with background scheduling disabled, a fresh browse is needed after observation.
At most 100 uncached
event IDs share one camera budget per 60 s across clients and detail browsing.
Cached covers need no interest or connected owner. Uncached covers require an
eligible event plus the matching socket's current browse ID. The station has one
read in flight, at most 32 unsent unique cover demands, unchanged runtime cover
pacing and a 5-minute event failure cache. Metadata has no additional bridge
post-cover wait; the SDK retains its 2 s read quiet period. Table continuations
retain their separate 5 s completion gap.
Ordinary foreground requests preempt feature work.

`RECORDINGS_BACKGROUND` defaults to `true`; `false` disables background catalogs
and cover prefetch without disabling browsing or its bounded catalog retries.
The background schedule starts 60 seconds after enrollment, with a live-configurable
interval (milliseconds), subject to the shared 60-second latest-query
admission gate and all SDK gates. It skips unhealthy sessions and pauses during
live view, playback or an unresolved playback safety hold. It never acquires a
session. Background continuation requires a consistent full page of the requested
count, distinct normalized rows with valid start times, all absent from the prior
successful latest-window checkpoint. The checkpoint is process-local and resets
on scope change or restart; startup without a checkpoint cannot trigger overflow.
A background burst stops at a known row with authenticated playback authority,
a short page, cursor exhaustion, invalid page or failure.
It also stops after 50 total pages (latest plus 49 older pages), recording
`stoppedReason: "runaway_guard"`: a station that keeps returning fresh-looking
pages would query forever. The four-extra-page and 60-second cycle stop rules
are removed for background bursts; retention filtering/storage caps still apply
but do not terminate background paging. Existing 5-second completion gaps,
preemption, live kill switch, overlap checks and the `pagingStatus` latch remain.
A scheduled latest refresh does not supersede a running background burst.

`RECORDINGS_BACKGROUND_PAGING` defaults to `true`; `false` is a hard disable for
background overflow continuation, leaving latest refreshes and browse paging
unchanged. Environment changes require restart. With the environment enabled,
`background-paging.json` in the recordings root provides a live switch:
`{"version":1,"enabled":false}` disables it and `{"version":1,"enabled":true}`
enables it. The file is re-read at every page admission, without restart; an
already dispatched read may finish. Missing files use the enabled default;
malformed, oversized, linked or unreadable files disable paging. Replace the
small regular file atomically when changing it. Re-enabling permits future
overflow cycles, without resuming a stopped cycle or clearing the unsupported latch.

The playback model allowlist has a separate live file,
`<RECORDINGS_ROOT>/playback-models.json`: `{"version":1,"models":["T8425","T8171"]}`.
It replaces the list at each catalog request and new playback admission without
background refresh or restart. Models are trimmed, uppercased and deduplicated,
and must match `^T\d{4}[A-Z0-9]*$`; `[]` disables all models. The built-in list is
T8425, T8426, T8170, T8171, T8214, T8416, T8134. Precedence is valid file, startup `RECORDINGS_PLAYBACK_MODELS`,
then built-in default. Missing files use the fallback. Malformed JSON, unknown
versions/fields, invalid entries, linked, changing or unreadable files reject
the entire file and use the fallback, with `rejection` in policy readback.
Replace a regular file atomically. Existing jobs may finish; a removed model
cannot admit a new job. The file has no timer, expiry or new limits.
The test RPC retains its existing `{enabled, models, minutes}` semantics (30-minute
default, maximum 240); it overrides the file while active.
See the [README](../README.md) for the complete live model policy.

After latest or deeper merges, uncached covers with a validated selector and a
known start within the last 24 hours are eligible for background prefetch, newest
first. Future and unknown starts are excluded. Background reads are serialized
with browsing and paging, yield to browse cover demands, and start no faster than
one per 15 s; all existing SDK, renewal and aggregate cover limits still apply.
Unavailable covers wait five minutes. Three failures stop background attempts for
that event; the count survives merges and restart. Deferrals do not count as
failures. The cover cache allows 2,000 files while retaining the 128 MiB byte cap
and existing row retention limits. Diagnostics and cache-only requests never
create browse interest or start a station read themselves.

```ts
{ event: "recordings.changed", version: 1, scopeId,
  cameraId: string | null, revision: string,
  reason: "catalog" | "cover" | "eviction" | "disabled" }
```

Notifications coalesce within a one-second window, with `cameraId:null` when
several cameras change. They never include catalog rows or image data.

`GET /recordings/v1/covers/<cameraId>/<eventId>` is cache-only, including when
Eufy is offline. It requires no transfer header and never initiates any SDK work.
It runs after the service HTTP policy wrapper and before Eufy session readiness.
Invalid IDs, scope, missing or invalid bytes return generic 404; query strings
are refused. Other methods return 405 (`Allow: GET`); more than four active
deliveries return 429 (`Retry-After: 1`). Valid JPEG responses have:

```text
Content-Type: image/jpeg
Content-Length: <validated length>
Cache-Control: private, no-store
X-Content-Type-Options: nosniff
X-Eufy-Image-Sha256: <digest>
X-Eufy-Event-Time: <event UTC time, omitted when unknown>
```

There are no redirects, CORS permissions, range handling or snapshot fallback.
Home Assistant must supply its own authenticated thumbnail proxy. Covers use
immutable `<eventId>.<sha256>.jpg` filenames so a failed manifest replacement
cannot publish an orphan or overwrite an earlier verified cover. Metadata has a
non-sliding 7-day TTL, 2,000-row total / 400-row camera caps. Covers expire with
their parent or after 7 days, capped at 2,000 files / 128 MiB; eviction trims to
90% of both cover caps. Atomic scratch is capped at two files / 8 MiB, with a
64 MiB free-space floor. All new directories/files request 0700/0600 modes.

#### SDK pairing seam

`src/recordings-adapter.mjs` is the isolated SDK compatibility boundary. It
requires `getRecordingAccountNamespace(identityKey)`,
`readRecordingCatalog(scope, {signal,timeoutMs})` and
`readRecordingCover(scope, selector, {signal,timeoutMs})`. Scope remains private:
`{stationSn,cameraSns: Set<string>,accountNamespace,identityKey: Buffer(32)}`.
The namespace comes from the SDK's cache-only getter, including its canonical
account identity. No raw account identity is read or persisted by the bridge.
Inventory comes from ordinary device-list publication, with exactly five
T842x/T84Ax children under the sole T9000, excluding the named safe device.
Ambiguous topology disables new reads while preserving safely bound cache for
the same account.

Scope/camera HMAC domains match `recordings.scope.v1` and
`recordings.camera.v1`; selectors match `recordings.selector.v1`, including the
account namespace before source, camera, station, path and receipt time. The
package exports neither the binding helper nor its selector verifier, so the
adapter checks those tuples locally; the SDK independently verifies every fetch.
The bridge verifies each returned scope/camera/event ID against its local binding.
SDK normalization owns station-local parsing and DST handling using the host IANA
`TZ` (or the station compatibility fallback). Capability and event `timezone` fields
report the zone used; retained events preserve their original conversion zone. Unknown type labels
remain fixed numeric fallbacks and numeric duration fields remain unqualified.

Service construction shares the installed SDK policy
`{enabled,stationBinding,allowedCameras}` with the adapter. Enrollment updates
that same object without discovery or owner acquisition. Timeout values are
integer milliseconds from 1 through 8000, and the bridge deadline aborts the SDK
signal. SDK-only refusals map into the existing public finite reason vocabulary.

The store retains private HMAC path fingerprints across catalog windows,
selector replacement and restart, including `coverPathKey` from rows whose SDK
selector was suppressed for shared-path ambiguity. Distinct event identities
sharing a fingerprint lose uncached selectors permanently for their retained
lifetimes; existing validated cached bytes remain usable. Fingerprints are
bounded to 64 per event; overflow conservatively disables new uncached covers
for the bound store scope. No path fingerprint appears in a public DTO or log.

The paired dependency is the local recordings SDK artifact at `b7c30da`, with
its tarball SHA-256 in `eventPlaybackProbeSdkSha256`. Probe gates hash the installed
JavaScript bundle; both `server.mjs` and `bin/event-playback-probe-control.mjs`
therefore consume the separate `eventPlaybackProbeSdkRuntimeSha256` pin. Existing
playback grants must match the new bundle and bridge files. Historical table,
thumbnail and storage probe pins are unchanged and refuse a mismatched bundle.
Optional SDK idle/preemption events remain hooks;
the current facade relies on its own arbitration and abort behavior. A deferred
cover without an idle notification expires without polling. Full pairing
receipts and remaining acceptance limits are in
[`recordings-pairing-validation.md`](recordings-pairing-validation.md).

#### Local implementation validation (2026-11-05)

Synthetic fixture version: `recordings-synthetic-v1`. Interpreter: Node
`v24.15.0`, Windows. The focused run blocks socket/process creation and replaces
the account SDK with its existing test tripwire:

```text
node --test --import ./test/fixtures/no-socket-guard.mjs --import ./test/fixtures/proof-loader.mjs test/recordings-store.test.mjs test/recordings-policy.test.mjs test/recordings-api.test.mjs test/recordings-privacy.test.mjs
62 tests: 61 passed, 0 failed, 1 skipped

npm test
666 tests: 638 passed, 0 failed, 28 skipped
```

The added skip is POSIX permission-mode verification on Windows; deployment
filesystem permissions still need qualification. The full suite was repeated
after final-review interest-expiry and notification-coalescer fixes (the earlier
run had 664 tests, 636 passed, 0 failed, 28 skipped). Prettier was applied only to
changed files. These receipts cover local synthetic bridge behavior; final SDK
dependency pairing, installed enrollment policy, transport arbitration/logging,
HA delivery, filesystem ACLs and live station acceptance remain separate gates.

### `auth.status`

Ask what the login needs right now.

```jsonc
// →
{ "id": 1, "cmd": "auth.status" }
// ←
{ "id": 1, "ok": true, "auth": { "state": "ok" } }
```

`auth` is one of:

| state             | extra fields                                        | meaning                                                                                                                                                                                                                                                 |
| ----------------- | --------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ok`              | —                                                   | logged in; device commands work                                                                                                                                                                                                                         |
| `require_2fa`     | `method`                                            | a 2FA code was sent; submit it                                                                                                                                                                                                                          |
| `require_captcha` | `image` (`data:image/png;base64,…`), `retry` (bool) | solve the captcha image                                                                                                                                                                                                                                 |
| `pending`         | —                                                   | no challenge yet / retrying                                                                                                                                                                                                                             |
| `reauth`          | —                                                   | the cloud session was kicked/expired **after** startup (another login on the account, or a token timeout); the bridge is re-logging in automatically. It becomes `ok` on success, or `require_2fa` if a fresh code is needed — drive `auth.submit` then |

The bridge pushes an unsolicited `auth` event (same fields as `auth.status`'s `auth` object) whenever this
state changes, so a frontend re-renders the challenge without polling. A single active session per account
means a login elsewhere (e.g. opening the phone app) bumps the bridge into `reauth`; it recovers on its own
unless the account then demands a 2FA code.

### `auth.submit`

Submit a 2FA code **or** a captcha answer. The pending id/token is held inside the bridge.

```jsonc
// 2FA:
{ "id": 2, "cmd": "auth.submit", "code": "123456" }
// captcha:
{ "id": 2, "cmd": "auth.submit", "captcha": "AB3D" }
// ←  (the new auth state after the attempt)
{ "id": 2, "ok": true, "auth": { "state": "ok" } }
// missing both →
{ "id": 2, "ok": false, "error": "auth.submit needs { code } (2FA) or { captcha } (captcha answer)" }
```

### `auth.retrigger`

Request a fresh challenge (new captcha image / new 2FA code).

```jsonc
// →
{ "id": 3, "cmd": "auth.retrigger" }
// ←
{ "id": 3, "ok": true, "auth": { "state": "require_captcha", "image": "data:image/png;base64,…", "retry": false } }
```

### `devices.list`

Every device the account exposes. _(Requires `auth.state == "ok"`.)_

```jsonc
// →
{ "id": 4, "cmd": "devices.list" }
// ←
{
  "id": 4, "ok": true,
  "devices": [
    {
      "sn": "EXAMPLE-CAM-0001",
      "name": "Living Room Camera",
      "model": "T8410",
      "modelName": "Indoor Cam Pan & Tilt",
      "codec": "camera",
      "capabilities": ["video","snapshot","motion","camera","rtsp","battery","light","ptz","audio","info"],
      "state": { "battery": 74, "motion": false, "light": true, "statusLed": true },
      "stream": "/stream/EXAMPLE-CAM-0001",
      "power": "wired"
    },
    { "sn": "EXAMPLE-SENSOR-0002", "name": "Entry Sensor", "model": "T8900",
      "modelName": "Entry Sensor", "codec": "sensor",
      "capabilities": ["contact","battery","info"],
      "state": { "contact": true, "battery": 88 } }
  ]
}
```

- `name` is the owner's device name (from `device_name`); it falls back to `modelName` when the device is unnamed.
- `model` is the T-code (e.g. `T8410`); `modelName` is the product display name (e.g. `Indoor Cam Pan & Tilt`).
- `state` is a flat `{ property: value }` map of the device's **current** values; reading it schedules a background refresh, and semantic events (below) push changes between reads.
- `stream` is present only on devices with live video (cameras/doorbells).
- `streaming` (cameras/doorbells only) is `true` while a live P2P feed is actually open right now — the
  same signal the `streamState` event carries, so a frontend can seed a "Streaming" sensor from the list.
- `power` (cameras/doorbells only) is `"battery"` or `"wired"`, using the SDK's live-media power
  classification. Mains-only models can still report the `battery` capability or a sentinel level;
  a zero, missing or suppressed level does not override this field. Solar charging still means battery
  hardware. `state.powerSource` and `state.powerSourceInfo` retain their charge-input/settings meanings.
- `canReboot` is `true` on HomeBase/station devices, which accept `device.reboot`.
- A device that failed to resolve appears as `{ "sn": "…", "error": "…" }`.

### `device.state`

The same shape as one `devices.list` entry, for a single device (identity + capabilities + live `state`). _(Requires auth.)_

```jsonc
// →
{ "id": 5, "cmd": "device.state", "sn": "EXAMPLE-CAM-0001" }
// ←
{ "id": 5, "ok": true, "device": { "sn": "…", "name": "…", "codec": "camera", "capabilities": ["…"], "state": { "battery": 74, … }, "stream": "/stream/…" } }
```

### `device.properties`

The device's **property manifest** — one entry per property, with enough metadata for a frontend to
build the right entity without knowing eufy wire ids. Static per device; fetch once at setup.
_(Requires auth.)_

```jsonc
// →
{ "id": 9, "cmd": "device.properties", "sn": "EXAMPLE-CAM-0001" }
// ←
{
  "id": 9, "ok": true, "sn": "EXAMPLE-CAM-0001",
  "properties": [
    { "name": "battery",   "type": "number", "unit": "%",   "kind": "percent", "writable": false },
    { "name": "statusLed", "type": "bool",                                       "writable": true  },
    { "name": "motion",    "type": "bool",                                       "writable": false },
    { "name": "workingMode","type": "enum",  "writable": true,
      "enumValues": { "0": "Optimal battery life", "1": "Optimal surveillance", "2": "Custom" } }
  ]
}
```

Map an entry to an entity: `writable` + `bool` → **switch**, `enum` → **select** (`enumValues` = raw→label),
`number` → **number** (`unit`/`kind` for display), everything else → **sensor**. Pair with the live value
from `state` (same `name`).

### `device.set`

Write a property (maps to the SDK's `setProperty`). The valid `name`s are the writable properties a
device's capabilities expose (e.g. `statusLed`, `nightVision`, guard-mode `mode`, …). _(Requires auth.)_

```jsonc
// →
{ "id": 6, "cmd": "device.set", "sn": "EXAMPLE-CAM-0001", "name": "statusLed", "value": true }
// ←
{ "id": 6, "ok": true }
// unsupported property / device →
{ "id": 6, "ok": false, "error": "device … does not support 'statusLed'" }
```

### `device.action`

Invoke a capability **action** — a typed method that is not a scalar property, so `device.set` cannot
reach it. `{ sn, action, args? }`, where `args` is the positional argument list. Only methods a
capability surface exposes are reachable; today those surfaces are `smart_light`, `camera`, `lock` and
`siren`. _(Requires auth.)_

```jsonc
// sound the alarm for 10 s — a HomeBase, or a camera attached to one
{ "id": 9, "cmd": "device.action", "sn": "EXAMPLE-CAM-0001", "action": "trigger", "args": [10] }
// ←
{ "id": 9, "ok": true, "result": null }
// stop it before the duration runs out
{ "id": 10, "cmd": "device.action", "sn": "EXAMPLE-CAM-0001", "action": "stop" }
// no surface on this device carries the verb →
{ "id": 11, "ok": false, "error": "no action 'trigger' on EXAMPLE-CAM-0002" }
```

The siren verbs install only where the SDK has evidence for a wire: a HomeBase reporting hub-alarm
params, a camera attached to one that reports the EAS slot, or a standalone siren (`stop` only, plus
its own `test`). A device that has them lists `"siren"` among its `devices.list` capabilities — the
duration is validated by the SDK, which rejects anything that is not a positive whole number of
seconds.

### `device.reboot`

Reboot a **HomeBase / station** (maps to the SDK's `reboot`). Only devices with `canReboot: true` accept
it; the SDK throws for a non-hub serial. The hub drops offline for a minute or two, then rejoins.
_(Requires auth.)_

```jsonc
// →
{ "id": 7, "cmd": "device.reboot", "sn": "EXAMPLE-STATION-0003" }
// ←
{ "id": 7, "ok": true }
// non-hub serial →
{ "id": 7, "ok": false, "error": "…" }
```

### `event.refresh`

Force an immediate **"Last event" image** refresh for a device — pull the newest event cover from the
HomeBase now and (if a genuinely newer image landed) broadcast `eventImageUpdated`. Backs a manual
"Refresh Last Event" control; useful when the automatic on-detection refresh raced the HomeBase writing
the crop. _(Requires auth.)_

```jsonc
// →  { "id": 8, "cmd": "event.refresh", "sn": "EXAMPLE-CAM-0001" }
// ←  { "id": 8, "ok": true, "changed": true }   // changed=false when no newer image is available yet
```

### `config.get` / `config.set`

Read or change the **cloud poll interval** (`pollMs`, milliseconds) at runtime — how often the bridge
re-reads device state from the cloud. `0` disables polling. Unset at startup → the SDK default
(600000 = 10 min); the `EUFY_POLL_MS` env var sets the startup value. _(Requires auth.)_

```jsonc
// →  { "id": 9, "cmd": "config.get" }
// ←  { "id": 9, "ok": true, "pollMs": 600000 }

// →  { "id": 10, "cmd": "config.set", "pollMs": 120000 }   // poll every 2 min
// ←  { "id": 10, "ok": true, "pollMs": 120000 }
// invalid →
{ "id": 10, "ok": false, "error": "pollMs must be a non-negative number (ms)" }
```

Faster polling means fresher state but more cloud traffic; the cloud itself only refreshes these
values on the order of minutes, so intervals below ~1 min mostly add load without adding freshness.

When recordings is available, `config.get` also returns
`recordings.playbackModelPolicy`: `{version, models, source, rejection, revision}`.
`source` is `file`, `env`, or `default`; `rejection` describes an
ignored live file, including during a test override. The same current policy is
included in recordings capability, `recordings.diagnostics`, and the `recordings`
section of `/diagnostics`. Reads do not require a restart or background refresh.

### `stream.start`

Returns the URLs for a camera's live video. **Does not open the camera** — connecting to the URL is
what starts it; disconnecting stops it. _(Requires auth.)_

```jsonc
// →
{ "id": 7, "cmd": "stream.start", "sn": "EXAMPLE-CAM-0001" }
// ←
{
  "id": 7, "ok": true,
  "path": "/stream/EXAMPLE-CAM-0001",
  "http": "http://127.0.0.1:3000/stream/EXAMPLE-CAM-0001",
  "rtsp": "rtsp://127.0.0.1:8554/EXAMPLE-CAM-0001"
}
```

### `stream.stop`

Advisory only — the media connection closing is the real "stop". _(Requires auth.)_

```jsonc
// →  { "id": 8, "cmd": "stream.stop", "sn": "…" }
// ←  { "id": 8, "ok": true }
```

### Anker Solix (`solix.*`)

Optional — present only when the bridge has `SOLIX_EMAIL` / `SOLIX_PASSWORD` set. Solix is a **separate
Anker account** on a separate backend, so these commands do **not** require the eufy `auth.state == "ok"`
and are independent of the eufy device commands above.

#### `solix.status`

```jsonc
// →  { "id": 9, "cmd": "solix.status" }
// ←  { "id": 9, "ok": true, "solix": { "enabled": true, "state": "ready", "deviceCount": 1 } }
```

`state`: `disabled` | `connecting` | `2fa` | `ready` | `error`. `enabled` is `false` when `SOLIX_*` is unset.

#### `solix.devices`

The account's Solix devices (empty until `state == "ready"`). _(Not gated by eufy auth.)_

```jsonc
// →  { "id": 10, "cmd": "solix.devices" }
// ←  { "id": 10, "ok": true, "devices": [ {
//       "source": "solix", "sn": "…", "productCode": "AE1X0", "name": "Smart Meter Gen 2",
//       "category": "Accessory",
//       "capabilities": ["identity", "firmware", "connectivity", "energyMeter"],
//       "firmware": "V1.0.0.9", "online": true, "ssid": "Xman24", "rssi": -35,
//       "values": { "gridVoltage": 237.1 } } ] }
```

#### `solix.submitCode`

Complete a pending Solix 2FA (only when `state == "2fa"`). The code is never logged.

```jsonc
// →  { "id": 11, "cmd": "solix.submitCode", "code": "123456" }
// ←  { "id": 11, "ok": true, "solix": { "enabled": true, "state": "ready", "deviceCount": 1 } }
```

### Errors

- Unknown command → `{ "id": n, "ok": false, "error": "unknown cmd: …" }`
- A device command before auth → `{ "id": n, "ok": false, "error": "not authenticated — query auth.status and complete 2FA/captcha first" }`
- Malformed frame → `{ "ok": false, "error": "bad json" }` (no `id`)

---

## Events (unsolicited)

### Recordings capability changes

`hello.recordings` remains the initial optional v1 recordings advertisement.
After enrollment, scope replacement, scope invalidation or disablement, the bridge
broadcasts `{ "event": "recordings.capability", "recordings": { ... } }` to
connected clients. `recordings` has exactly the same fields as `hello.recordings`:
`version`, `browseOnly`, `playback`, `enabled`, `scopeId`, `timezone`, `stationWindow`,
`pageSize`, and `coverBudget`. Disabled advertisements may have a null `scopeId`.
Clients replace their advertisement, retire old scope interests/covers, and update
media source availability without reconnecting. Every reconnect `hello` replaces
the advertisement too; absent or unsupported capabilities disable browsing.
Older clients may ignore this additive event. Existing `recordings.changed`
catalog/cover notifications are unchanged. Capability events initiate no reads.

SDK-deferred cover demands retry within their original 60-second browse interest,
using a supplied `retryAfterMs` or a short backoff. Each retry passes normal
single-flight, five-second completion gap, six-attempt/minute and SDK station
admission checks. Expiry, preemption, scope teardown and shutdown cancel retries.
The cache-only cover HTTP route omits `X-Eufy-Event-Time` unless it is strict ISO
UTC (`YYYY-MM-DDTHH:mm:ss[.sss]Z`); corrupt persisted metadata is never echoed.

### Lifecycle

| event   | payload                                                       | when                               |
| ------- | ------------------------------------------------------------- | ---------------------------------- |
| `hello` | `{ schemaVersion, auth: { state, … }, webrtcRelay: boolean }` | on connect                         |
| `auth`  | `{ state, image?, method?, retry? }`                          | auth state changed                 |
| `ready` | `{ schemaVersion }`                                           | login complete + devices/go2rtc up |

```json
{ "event": "hello", "schemaVersion": 1, "auth": { "state": "ok" }, "webrtcRelay": false }
{ "event": "auth", "state": "require_2fa", "method": "email" }
{ "event": "ready", "schemaVersion": 1 }
```

### Device events (forwarded from the SDK, broadcast to all clients)

Each carries the SDK's event payload (typically `deviceSn` / `stationSn` plus event-specific fields).

```json
{ "event": "motion", "deviceSn": "EXAMPLE-CAM…", "stationSn": "EXAMPLE-HB…" }
{ "event": "contactState", "deviceSn": "EXAMPLE-SENSOR…", "open": true }
{ "event": "batteryLevel", "deviceSn": "EXAMPLE-CAM…", "to": "74" }
{ "event": "doorbellPress", "deviceSn": "EXAMPLE-DOORBELL…" }
```

Full set: `motion`, `personDetected`, `strangerDetected`, `doorbellPress`, `petDetection`,
`packageDelivered`, `packageTaken`, `packageStranded`, `soundDetected`, `cryingDetected`,
`vehicleDetected`, `dogDetected`, `armingModeChanged`, `alarm`, `lockState`, `contactState`,
`batteryLevel`, `batteryAlert`, `ptzNotify`, `smartLightState`.

### Anker Solix events

Present only when Solix is configured (`SOLIX_*`).

| event          | payload                             | when                                                     |
| -------------- | ----------------------------------- | -------------------------------------------------------- |
| `solixAuth`    | `{ state, method?, error? }`        | Solix login state changed (incl. `state: "2fa"`)         |
| `solixReady`   | `{ devices: [...] }`                | Solix devices discovered (same shape as `solix.devices`) |
| `solixReading` | `{ deviceSn, productCode, values }` | a live telemetry frame                                   |

```json
{ "event": "solixReading", "deviceSn": "…", "productCode": "AE1X0", "values": { "gridVoltage": 237.1 } }
```

Plus a stream-lifecycle event (not a device push):

```json
{ "event": "streamState", "deviceSn": "EXAMPLE-CAM…", "active": true }
```

Fired when a camera's live P2P feed opens (`active: true`) or is torn down / idle-suspended
(`active: false`). The device summary also carries the current value as a `streaming` boolean.

---

## Sibling HTTP endpoints

| method + path        | returns                                                                                           |
| -------------------- | ------------------------------------------------------------------------------------------------- |
| `GET /healthz`       | `{ ok, schemaVersion, auth: { state }, streaming: [sn,…] }` — always available (even before auth) |
| `GET /snapshot/<sn>` | a JPEG still (`image/jpeg`). _Requires auth._                                                     |
| `GET /stream/<sn>`   | live Annex-B H.264/H.265 (`application/octet-stream`) — what go2rtc pulls. _Requires auth._       |

`/healthz` also reports `lastActivitySec`, the age of the last observed device activity. Quiet devices
can leave it high while polling succeeds; it is not a poll-stall indicator and there is no `stalled` field.

go2rtc (bundled) turns `/stream/<sn>` into RTSP / WebRTC / MSE / HLS, so the frontend never speaks the
raw video protocol.

---

## Not yet exposed

- Capability **action** verbs beyond the surfaces `device.action` routes today (PTZ move, talkback).
- Guard / station security mode (arm home/away/disarm).
- Per-device event subscription/filtering (events broadcast to all clients).
- Audio / recording / timelapse.

### Recordings follow-up: station child cameras, deeper reads and diagnostics

Recordings v1 retains all existing RPC/HTTP routes, fields, reason vocabulary and
100-event response bound. Enrollment uses the existing inventory's camera/video
classification and unambiguous station/channel ownership beneath the single
T9000. It includes wired, battery and doorbell cameras, excludes other stations
and non-camera devices. `RECORDINGS_SKIP_CAMERAS` optionally excludes names
using trimmed, case-insensitive matching. An omitted or rejected value skips nothing. Scope/camera HMAC inputs are unchanged when the camera set grows.

Update the add-on and integration together, then restart Home Assistant after the add-on is running, so removed controls are cleaned up. An older, incompatible integration can show recordings unavailable. The 3o integration at `63d2048` accepts exactly five
cameras and rejects an expanded roster. Its roster parser raises a recordings
error, which media browsing translates into "Recordings unavailable"; it does
not disconnect the shared bridge connection or change other bridge features.
Integration `f7b7f4e` also accepts a five-camera roster from a 3o-style bridge,
so use a matching integration and bridge. Update the add-on and integration together, then restart Home Assistant after the add-on is running, so removed controls are cleaned up.

A latest-catalog query defaults to 50 station-wide rows and retains the existing
60-second admission spacing. `catalogQueryCount` changes the per-query count.
Foreground browse continuation keeps its 60-second interest, four-extra-page,
retention and cursor rules. Background bursts use the stop rules above. Every
page independently arbitrates with controls/live view and keeps the five-second
completion gap. Empty deeper replies, repeated/overlapping IDs,
duplicate events, invalid envelopes/time evidence or newer time bounds latch
`pagingStatus` to `unsupported_stopped`. Three consecutive deeper timeout or
invalid-reply exchange failures also latch it; successful deeper pages reset
that failure count. Preemption, deferrals and other failures abandon the burst
without clearing or setting the latch. `working` is evidence of page progress,
not firmware qualification.

`recordings.set_pacing` updates process-local recording pacing and catalog settings through the
same command-policy filter and enrollment guards as other recordings commands:

```json
{ "id": 1, "cmd": "recordings.set_pacing", "prefetchGap": 2000, "coverGap": 2000, "coverRate": 0, "coverQuiet": 0 }
```

All fields are optional partial updates. Defaults are `prefetchGap: 3000`,
`coverGap: 500`, `coverRate: 20`, `coverQuiet: 500`,
`backgroundCatalogInterval: 60000`, `catalogQueryCount: 50`. Gap/quiet values are finite
nonnegative milliseconds; rate is a nonnegative safe integer. Rate 0 or null
means no minute cap. Unknown fields, invalid numbers, empty updates and reset
combined with pacing fields are rejected. `{ "id": 2, "cmd": "recordings.set_pacing",
"reset": true }` restores defaults. Replies use `{id, ok: true, recordings:
{pacing: {prefetchGap, coverGap, coverRate, coverQuiet, backgroundCatalogInterval, catalogQueryCount}, catalogSettings, setAtMs}}`. Restart also
restores defaults; attempt history is not cleared by a change.

For the ramp, set both gaps to 15000, 5000, 2000, then 0, with rate 0 and quiet 0.
The prefetch gap measures starts; the cover gap measures time since completion.
Zero quiet affects cover-to-cover only. Fixed foreground/catalog quiet,
serialized reads, playback/live priority, owner health/observation, renewal,
scope, reply capacity, queue and folder budgets remain in force.

`recordings.background` diagnostics include `pacing`, `pacingSetAtMs`, and
`coverReads: {maxBuckets: 16, samplesPerBucket: 512, buckets: [...]}`. Each pacing
change starts an interval with `{pacing, setAtMs, count, sampleCount, minMs,
medianMs, p95Ms, maxMs, failures: {reason: count}}`. The last 16 intervals survive
in memory only. Count and finite-reason failures include all completed API
attempts (including deferrals); latency statistics use the last 512 durations in
that interval, excluding disk persistence and queue wait. Durations are measured
with the monotonic clock; empty statistics are null. In-flight attempts remain
attributed to the interval in which they started. No row identities, serials or
URLs are retained in these measurements. Diagnostics reads do not issue requests.

Optional `recordings.diagnostics` takes no arguments (besides `id` and `cmd`) and
returns the usual `{id, ok, recordings}` envelope. This is a cache-only read and
uses the existing host command policy. `/diagnostics` also includes `recordings`:

- `rowsKeptPerCamera`: `{name, rows}` entries using trimmed display names;
- `rejected`: cumulative process counts for `not_in_scope`, `bad_record_id`,
  `bad_start_time`, `other`; `identity_conflict`: cumulative conflict count;
- `timeStatus`: retained-row counts for `valid`, `unknown_format`, `ambiguous`, `invalid`;
- `pagingStatus`: `unverified`, `working` or `unsupported_stopped`; `lastPageCount`;
- `lastCatalogTime`: last successful catalog receipt time in epoch milliseconds or null;
- `lastCatalogAttempt`: the last admitted latest-catalog read, or null. Contains only
  `atMs`, `finishedAtMs`, `outcome` and a sanitized finite `reason`. While running,
  `outcome` is `pending` and `finishedAtMs` is null; completed outcomes are `ok`,
  `deferred`, `unavailable` or `failed`. Later rate-limited, busy, offline or invalid-scope
  browse decisions do not replace it. This summary is process-local and resets on restart;
- Internal `lastCatalogAttempt.reason` preserves this finite vocabulary: `none`,
  `busy`, `playback`, `renewal`, `refresh_hold`, `offline`, `scope_invalid`,
  `rate_limited`, `timeout`, `invalid_reply`, `store_unavailable`, `disabled`,
  `invalid_options`, `owner_unavailable`, `owner_changed`, `owner_unhealthy`,
  `observing`, `quiet_period`, `renewal_due`, `selector_invalid`,
  `selector_reserved`, `reply_capacity`, `aborted`, `send_refused`.
  Unknown values sanitize to `busy`. **Catalog `refresh.reason` is unchanged**:
  new internal reasons map to the original public vocabulary above (`renewal_due`
  to `renewal`; disabled/missing/changed owners to `offline`; invalid options or
  selectors to `invalid_reply`; other new codes to `busy`). No HA catalog schema
  update is needed;
- `background`: `{enabled, lastCatalogAtMs, nextCatalogAtMs, catalogRuns, ok,
deferred, failed, coverPrefetch: {queued, fetched, failed, skippedPlayback,
lastAtMs}, retries}`. Times are epoch milliseconds or null. `catalogRuns` and
  outcomes count admitted background attempts, including retries; cadence skips
  do not count as reads. `retries` counts automatic catalog retry opportunities
  from either source. `queued` counts eligible uncached prefetch rows, including
  negative waits. All counters are process-local; background diagnostics contain
  no identifiers, paths or row data;
- `background.paging`: `{enabled, runs, pages, stopReasons, lastTrigger, stoppedReason?}`.
  `runs` counts admitted overflow cycles; `pages` counts deeper adapter calls,
  including SDK deferrals, not confirmed wire sends. `stopReasons` is a detached
  map of counts keyed by fixed enums: `known_row`, `short_page`, `cursor_end`,
  `runaway_guard`, `disabled`,
  `unsupported_stopped`, `preempted`, `superseded`, `store_unavailable`,
  `invalid_latest`, or the finite internal SDK reasons above. `lastTrigger` is
  `none`, `no_checkpoint`, `not_overflow`, `overflow`, `disabled` or
  `unsupported_stopped`. These are process-local aggregates with no row data;
- `coverCache`: `{files, bytes, pending}`;
- `unknownStartTimeShapes`: at most 32 `{shape, count}` entries. At most 32 code
  points from each raw start token are masked: numbers become `9`, letters become
  `a`, date separators remain, and all remaining characters become `?`.

No serials, raw record IDs, selectors, paths, account identities or raw time tokens
are included. Display names are the sole new human labels in diagnostics. Private
SDK paging evidence is never forwarded to WS, HTTP or HA. HA projects this schema
again and keeps opaque folder links under `recordings.folders` in its diagnostics.
Event titles omit type labels; camera folder titles use only the trimmed name,
with incomplete-history and cache status in an information child.

`recordings.test_reread` is a test-only load generator for pacing ramps. `{ "cmd": "recordings.test_reread", "enabled": true, "minutes": 15 }` makes background prefetch re-read already cached covers (least recently re-read first, after any uncached rows) at the current pacing, without replacing or penalizing the cached files. Reads are recorded in the current `coverReads` bucket. It is process-local, off at start-up, and switches itself off after `minutes` (default 60, greater than zero and at most 1440, with finite wall-clock and monotonic deadlines); `enabled: false` stops it at once. Diagnostics report `recordings.background.testReread` as `{ active, untilMs, reads, failed }`.

## Save-first recording clips (3p)

Playback is strictly on demand. `RECORDINGS_PLAYBACK` defaults to true and accepts
`0`, `false`, or another non-truthy value to disable playback. The hello and
`recordings.capability` objects add `playback: boolean`; `browseOnly` is its inverse.
Missing SDK `pullRecordingClip` support advertises playback false. Integrations
must use this capability to hide playback when disabled. Existing catalog rows
without private playback authority become playable after a successful catalog
refresh. Catalog `playable` describes exact-event authority; capability remains
the feature-level gate. There is no clip prefetch or permanent-copy/Keep action.

All three commands use the existing recordings command policy, scope guards,
strict field validation and opaque camera/event identifiers. No serial, record
number, station path, grant, URL, or raw selector is accepted from a client.

```ts
{ id, cmd: "recordings.clip_prepare", cameraId, eventId }
{ id, cmd: "recordings.clip_status", cameraId, eventId }
{ id, cmd: "recordings.clip_cancel", cameraId, eventId }

// Success: clip is direct, and mirrored in the existing recordings envelope.
{ id, ok: true, clip: Clip, recordings: { clip: Clip } }

type Clip = {
  state: "idle" | "queued" | "pulling" | "converting" | "ready" |
         "failed" | "refused" | "cancelled";
  reason: "none" | "live_view" | "busy" | "owner_unavailable" | "not_found" |
          "too_long" | "storage" | "convert_failed" | "station_error" |
          "cleanup_uncertain" | "disabled";
  progress: { pulledMs: number; expectedMs: number };
  durationMs: number | null;
  bytes: number;
  expiresAtMs: number | null;
};
```

Malformed fields, invalid IDs and scope failures retain the existing
`{id, ok:false, code, error:"Recordings unavailable"}` envelope. Unknown event
preparation returns `refused/not_found`; status before any prepare is `idle/none`.
Duration and expiry are null until known; bytes describe the ready MP4 only.
Progress uses monotonic video-arrival elapsed time, bounded by catalog duration.
Status polling does not extend expiry.
Transient playback admission gates retry every three seconds for up to 150 seconds,
including session renewal and the replacement owner's observation window. Permanent
gates refuse immediately. This wait precedes each admitted capture's fresh SDK
deadline; preparation returns immediately and status remains queued while waiting.
An exactly correlated no-stream refusal before acknowledgement or ingress reports
`failed/not_found` after confirmed quiet cessation, while retaining reconnect
protection. Uncertain refusal or cleanup evidence reports `failed/cleanup_uncertain`.
`disabled` means playback is disabled, the SDK lacks playback support, or the
clip worker has stopped. A marker-storage failure before any start is dispatched
returns `failed/storage` without retaining the SDK's in-memory live-view latch.

One event has one in-memory job. Repeated prepare during queued/pulling/converting
or ready reuses that job and never opens another stream. An explicit prepare
following failed/refused/cancelled retries the same event job; it is not an
automatic retry. There is one worker and at most eight waiting jobs, in FIFO
order. Expired/evicted clips return to idle. A live start cancels queued jobs and
an active pull, awaits mandatory same-owner release/cessation, then admits live.
An uncertain release blocks handoff and the SDK latch continues to deny live.
New prepares during active live acquisition/viewing return `refused/live_view`.
Conversion can finish alongside live; it uses at most two encoding threads.

Each state change uses the existing notify event, with only opaque identifiers:

```ts
{ event: "recordings.changed", version: 1, scopeId,
  cameraId, eventId, revision, reason: "clip" }
```

The bridge spools Annex-B H.265 to a restricted, randomly named temporary file.
The SDK authenticates a private catalog selector for the exact record, camera,
start and expected duration, without another newest-record query. Catalog and
cover/prefetch reads pause while the worker runs. Optional SDK state refreshes
remain deferred for the full duration-bound capture, including cleanup.

The capture budget is catalog duration plus 15 seconds; another 16 seconds is
reserved for invocation/cleanup. Existing owner observation, current-owner,
renewal headroom, pause/stop, five-second cessation and durable latch checks
remain enforced. No start means no unresolved latch. A clip that cannot fit on
the current owner is refused rather than reconnecting or extending its renewal.
Capture ends at the station EOF or the budget; **only EOF plus confirmed release,
clean ingress and a random-access first video frame can produce ready**. A cutoff
without EOF returns `too_long` and deletes the partial file. This is intentionally
stricter than publishing duration-capped material as a complete clip.
Streaming ingress admits 8 MiB and 8192 native messages per rounded-up capture
second (minimum 16 MiB and 32768 messages, maximum 2 GiB of native bytes).
Concurrent reassembly retains the existing eight-frame/16-MiB bounds; the
short diagnostic probe retains its separate 4-MiB/16384-message cutoff.

FFmpeg runs with an argument array and no shell. It decodes HEVC, encodes H.264
with libx264/veryfast, uses yuv420p, reduces width only above 1920 (or by one pixel
for an odd width), and finalizes a faststart MP4. Audio is **not included** because
the station audio frames do not yet identify a qualified codec/configuration.
Frames are spread uniformly over the validated catalog duration, independent of
network delivery cadence. PTCS frame IDs use a millisecond clock in the portal's
packetizer, but the station's playback clock semantics are unqualified and the
SDK video callback carries bytes only. Catalog timing therefore avoids treating
burst transfer time as media duration; original variable-frame-rate fidelity
remains unqualified. Conversion has a deadline of six times catalog duration
with a two-minute floor (capped at the platform timer maximum). Timeout or
cancellation sends SIGTERM, escalating to SIGKILL after five seconds. The worker
waits for process close before cleaning files or resuming background reads;
timeout reports `convert_failed`. Conversion errors and output-size cutoffs
never publish a clip.

`GET /recordings/v1/clips/<cameraId>/<eventId>.mp4` uses the identical host HTTP
policy boundary as covers. It never starts a station operation and works offline
for ready clips. It returns 404 unless ready and playback is enabled. Only GET is
accepted (405 otherwise); malformed paths and query strings return 404. It sends
`video/mp4`, `Accept-Ranges: bytes`, `Cache-Control: private, no-store` and
`X-Content-Type-Options: nosniff`. Single closed, open-ended and suffix byte ranges
return 206 with Content-Range/Content-Length; invalid, multiple or unsatisfiable
ranges return 416 and `Content-Range: bytes */<size>`. Full requests return 200.
The existing global four-delivery HTTP limit applies to covers and clips together.

Temporary files live under `/data/recordings/clips/` (or `RECORDINGS_ROOT/clips`).
Cancel, failure and shutdown delete temporary files. Startup removes owned orphan
clip files; unexpected files/symlinks fail storage closed. A two-GiB aggregate cap
includes input, conversion output and ready files, with oldest-access-first
eviction. Conversion reserves headroom and bounds FFmpeg output size. Active
HTTP readers pin files; cancellation defers their unlink until the last reader
closes. Unpinned ready files expire 60 minutes after their last GET access/read
completion; a 30-second sweep enforces expiry. No station file is ever deleted.
The durable `/data/recordings/playback-safety.json` latch is outside disposable
storage, survives restart and is honored even when playback/browsing is disabled.

`recordings.diagnostics` adds `clips`, containing current `states` and `reasons`
counts for every finite enum, `lastJob: {pullMs, convertMs, bytes, audioIncluded}`
(or null before a completed job), and `audioIncluded:false`. This added object
contains no IDs, serials, URLs or vendor error text. Existing diagnostics remain.

Offline qualification uses synthetic frames and a fake conversion runner, plus
real loopback HTTP range tests. Full-event EOF/first-last coverage, timing,
Android and desktop decoding/seeking, live preemption, natural owner renewal and
host CPU/storage behavior still require an authorized live acceptance test.

Progressive HLS is an optional companion protocol described in
[recordings-progressive.md](recordings-progressive.md). When enabled, capability
adds `progressivePlayback: true` and `progressivePlayableMs` (effective integer
1000-6000, default 3000). Diagnostics add bounded `clips.history` and
`clips.progressive` session counters, fixed end reasons and the latest twenty
job time-to-playable summary. Public MP4 state/reason enums are unchanged.

### Live catalog interval and row count

Use the existing authorized WS command, with milliseconds for the interval:

```json
{ "id": 1, "cmd": "recordings.set_pacing", "backgroundCatalogInterval": 60000, "catalogQueryCount": 50 }
```

Either setting can be changed alone; `{"id":2,"cmd":"recordings.set_pacing","reset":true}`
restores all pacing defaults, including 60000 ms and 50 rows. Settings are held in
process memory and reset on restart, matching existing cover pacing. No control
file, expiry or new timer is added. An interval change immediately cancels and
rearms the existing background timer from the change time. Intervals must be finite
numbers >=1000 ms, with no upper policy cap. Long waits reuse the same timer
in Node-representable chunks; this does not shorten the configured interval. Existing station/latest-read admission
gates remain unchanged, so polling faster does not bypass them.

`catalogQueryCount` is an integer 1..87381, derived from the SDK's existing 256 KiB
`EVENT_TABLE_BYTE_CAP` (`src/transport/rtc/event-table-candidate.ts`): even an array
of n empty objects needs 3n+1 bytes. This packet-derived ceiling is not a station
capacity claim; actual rows and envelope consume more of that same byte budget.
Counts of 50 and 100 can be tested without restarting. Short successful replies
merge valid rows. A larger count returning fewer rows, malformed data or an error
falls back on the next query to the last full successful count (initially 20).
Admission deferrals do not establish station rejection. No automatic retry or
immediate re-query is added. An in-flight query keeps its original requested count.

`config.get.recordings.catalogSettings`, recordings capability and
`recordings.diagnostics.catalogSettings` (also `/diagnostics.recordings`) expose
`backgroundCatalogInterval: {value, source}` and
`catalogQueryCount: {value, source, configuredValue, lastGoodCount}`. Source is
`default`, `live`, or (count only) `fallback`. `lastQuery` is null or
`{requestedCount, returnedCount, status, reason}`; failed reads have null returned
count. Values contain no station identifiers. `stationWindow` and the catalog
disclosure reflect the effective count for the next query. The retired
`recordings.test_playback_models` command returns the normal unknown-command error;
use `<RECORDINGS_ROOT>/playback-models.json`, e.g.
`{"version":1,"models":["T8425","T8171"]}`, for live playback eligibility.

The 50-row built-in default requires Home Assistant integration revision
`9c77c22` or later. Revision `cd068ae` rejects station windows other than 20.

## Shadow state evidence (version 1)

An SDK with evidence support advertises `stateEvidence: {version: 1, mode: "shadow"}` in `hello` and `ready`. The WebSocket schema remains 1. Existing state values, observations, command receipts and safety inputs retain their existing meaning.

Device summaries add `stateEvidence[property]`. Legacy `propertyChanged` and `propertiesObserved` events may carry optional evidence when supplied by the SDK. Shadow processing runs after all legacy handling for a frame; current SDK ingress events omit those optional fields and publish the evidence separately afterward. `propertyEvidenceChanged` carries `{deviceSn, property, evidence}` for quality changes, including equal-value samples. These records are detached SDK decisions, validated and forwarded without getter substitution or receive-time restamping. Unavailable original receipt times are `null`, never a new snapshot timestamp. Local receive sequence and session renewal do not establish device sample order. Current information-read associations remain temporal-only and do not establish OFF proof.

The cache-only diagnostics snapshot exposes `stateEvidence` with bounded totals/reason counts, saturating anonymous `failures` (SDK shadow work) and `forwardingFailures` (bridge shadow event projection/send), command-level `offCommands`, `offCommandsWithProof`, `offCommandsWithoutProof`, sample-level `offAfterCommand`, `offProofEligible`, `offUnresolved`, and at most 32 recent decisions. Command counts include dispatches with no subsequent OFF sample. Counts describe the current runtime and are not persisted. Recent rows contain a stable, salted per-run numeric target index and finite property/source/decision fields; they contain no target identity or state value. Retention is capped at 2,048 parameter slots and 256 session watermarks; eviction is counted and affects evidence only. Legacy SDKs omit the capability and additive event/snapshot fields, and diagnostics reports null evidence support.

## Guard report outcomes (additive schema 1)

When supported by the SDK, `hello` and `ready` include
`guardConfirmation: {version: 1, maxAttempts: 1, enabledRetry: false}`.
SDKs with lifecycle advertisements also include
`guardRuntime: {version: 1, runtimeGeneration: "<opaque UUID>"}` in hello/ready.
Every SDK guard-owner replacement emits an additive `guardRuntime` event with
those two fields before the replacement's first receipt. This includes watchdog
disconnect and successful auth recovery even when boot is already ready. A
consumer retires the previous receipt scope only from this advertisement, never
from an arbitrary different-runtime receipt, and fences in-flight ACK/recovery
results across scope changes. Older SDKs omit the advertisement and keep the
existing capability/receipt contract.
There is one SDK owner per station/property, with a 55-second monotonic overall
budget and a 20-second report window starting at dispatch completion. No layer
resends a guard command automatically.

`device.set` for `armingMode` accepts optional `intentGeneration`, an opaque
caller token of 1–64 ASCII letters, digits, underscores or hyphens. Callers should
use globally unique tokens per deliberate intent. Repeated tokens join the original
operation (including a retained terminal receipt); reusing a token for a different
mode is rejected. Pending requests without a token for the same mode join. A new
deliberate mode supersedes its predecessor and serializes behind unavoidable active
transport work. SDK callers and fluent arming setters share this owner.

The ACK RPC reply adds `guardConfirmation`, with `version`, opaque
`runtimeGeneration` and `handle`, increasing runtime-local `generation`, `deviceSn`,
raw numeric `requestedMode`, `outcome`, finite `reason`, actual `attempts` (0 or 1),
and nullable wall-clock `outcomeAtMs`. It ordinarily returns `pending`; a terminal
outcome can race the ACK. Transport ACK is not a mode report. Dispatch rejection
returns an RPC error with code `guard_dispatch_rejected`.

`guardConfirmation` events carry those same fields, independently of normal state
updates. Outcomes are:

- `pending`: `waiting_dispatch` or `waiting_report`, nonterminal.
- `reported`: `reported_after_command`; requested parameter 1224 arrived after
  dispatch in the current runtime/session and observation window. This means
  **reported after command**, temporal-only evidence. It is never confirmation,
  proof of command application, or producer-ordered evidence.
- `contradicted`: `different_mode_reported`, terminal on a different requested-mode
  report. `currentMode` never settles a requested guard mode.
- `not_reported`: `window_expired`, `budget_expired`, `ack_missing`,
  `transport_uncertain`, `cancelled`, `superseded`, `session_changed`,
  `runtime_closed`, or `dispatch_rejected`. Pre-existing matching state cannot
  settle this intent. Reports after a terminal result cannot rewrite its receipt.

`guard.confirmation.get` takes `handle` and returns `{guardConfirmation: receipt}`
or `{guardConfirmation: null}` when unavailable. It is read-only and never replays
commands. Retention is current-runtime only, at most 32 terminal receipts for ten
monotonic minutes, plus bounded active operations. Runtime replacement makes old
handles unavailable. Socket reconnect leaves the SDK owner running so clients can
recover a missed outcome through this method. Diagnostics expose outcome counts
and pending count only, without serials, handles, modes or caller tokens.

## Cloud inventory evidence (additive schema 1)

`devices.list` preserves its `devices` array and adds `inventoryEvidence` when the
SDK supports atomic roster evidence. Each summary also gains row
`inventoryEvidence: {quality: "fresh"|"retained", lastSuccessfulObservationMs}`.
The top-level evidence contains `version: 1`, `generation`, `completedAtMs`,
`quality: "complete"|"partial"|"retained"`, `attempted`/`failed` query counts,
`lastCompleteSuccessMs`, and `rows` keyed only by serials in that returned array.
These fields are captured with the exact roster before asynchronous descriptions.
A successful query refreshes only returned rows. Retained rows keep their original
successful observation time. Complete successful absence uses normal removal;
partial absence preserves topology. Inventory quality says nothing about property
truth. The existing operation timing label `fresh_sdk` is not cloud freshness.
Unknown versions, invalid fields or missing metadata mean unknown quality.

`bridge.diagnostics.inventoryErrors` adds bounded sanitized inventory failures:
`origin: "device_registry"`, `operation: "house_list"|"device_list"`, finite
`kind: "http"|"vendor"|"timeout"|"dns"|"connect"|"tls"|"decode"|"unknown"`,
nullable int32 `vendorCode`, nullable HTTP 100–599 `httpStatus`, and local `atMs`.
The SDK retains 32 samples, saturating total/eviction and kind/operation/status-class
counts, first/last failure, and last complete success. These failures use
`inventory_<kind>` in the existing SDK error history instead of `other`, with the
sanitized row alongside it. No exception message, body, stack, URL, identifier,
header or arbitrary error key is projected into these diagnostics. Authentication
expiration retains its existing explicit error path. No retry, timeout or login
policy changes are introduced. Legacy SDKs omit inventory/guard capability fields;
legacy clients can ignore these additive schema-1 fields.

Inventory shape diagnostics are additive within schema 1. Optional decode sample
`shape` is limited to `envelope_null`, `envelope_primitive`, `envelope_array`, or
`field_not_array`. Null/undefined envelopes, primitive envelopes, nonempty top-level
arrays, and present list fields other than arrays or null remain decode failures
and retain missing prior inventory. Empty objects remain complete empty lists.
Null lists, missing list fields on envelopes with other keys, empty top-level
arrays, non-object rows, and rows lacking a valid identity are tolerated without
errors or partial evidence. Valid house siblings are still queried. Diagnostics
add per-operation saturating `toleratedShapes` counters with only `field_null`,
`field_missing_with_keys`, `envelope_empty_array`, `row_not_object`, and
`row_missing_serial` (`house_list` uses the last label for missing house identity).
Each occurrence increments its counter, including every skipped row. Counts are
cumulative for the recorder lifetime; tolerated shapes do not increment error
counts or failure times. Bridge projections strip unknown shapes and operations,
invalid counts, and all raw values, keys, serials and IDs. Older summaries may omit
`toleratedShapes`; older samples may omit `shape`.

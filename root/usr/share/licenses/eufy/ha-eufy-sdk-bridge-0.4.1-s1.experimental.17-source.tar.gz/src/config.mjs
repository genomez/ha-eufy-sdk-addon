/** Modified for genomez S1 experimental source preview, 2026-10-16. */
import { pilotLog } from "./pilot-log.mjs";
import { createLoggingControl } from "./logging-control.mjs";
import { playbackModelDefaults } from "./recordings-playback-models.mjs";
// Environment → the immutable config + constants the whole bridge reads. Side-effect free (no mkdir,
// no process.exit) so it can be imported from tests; server.mjs owns the startup guards.
import path from "node:path";

export const SCHEMA_VERSION = 1; // bump on any breaking protocol change so an old frontend fails loudly

const truthy = (v) => /^(1|true|yes|on)$/i.test(String(v ?? ""));
/** A positive whole number from an env value, else undefined (so the caller's default applies). */
const positiveInt = (v) => {
  const n = Number(v);
  return v != null && v !== "" && Number.isSafeInteger(n) && n > 0 ? n : undefined;
};

/** Invalid or absent host zones retain the station timestamp compatibility default. */
export function recordingTimeZone(value) {
  if (typeof value !== "string" || !value || /^[+-]/.test(value)) return "America/Chicago";
  try {
    return new Intl.DateTimeFormat("en", { timeZone: value }).resolvedOptions().timeZone;
  } catch {
    return "America/Chicago";
  }
}

/** Parse the entire JSON option atomically; never retain rejected camera names. */
export function recordingSkipCameras(value) {
  const base = { names: [], source: "default", rejection: null };
  if (value == null) return base;
  try {
    const names = JSON.parse(value);
    if (!Array.isArray(names) || !names.every((name) => typeof name === "string" && name.trim()))
      throw new Error("invalid");
    return { names: [...new Set(names.map((name) => name.trim().toLowerCase()))], source: "env", rejection: null };
  } catch {
    return { ...base, rejection: "skip_cameras" };
  }
}

/** The SDK event names broadcast to every connected WS client. */
export const FORWARDED_EVENTS = [
  "propertyChanged",
  "motion",
  "personDetected",
  "strangerDetected",
  "doorbellPress",
  "petDetection",
  "packageDelivered",
  "packageTaken",
  "packageStranded",
  "soundDetected",
  "cryingDetected",
  "vehicleDetected",
  "dogDetected",
  "armingModeChanged",
  "alarm",
  "lockState",
  "contactState",
  "batteryLevel",
  "batteryAlert",
  "ptzNotify",
  "smartLightState",
];

// The "something happened" pushes (not battery/arming/state changes) — these keep a camera's live
// feed warm and reset the battery rtspStream idle clock (see stream-idle.mjs).
export const DETECTION_EVENTS = new Set([
  "motion",
  "personDetected",
  "strangerDetected",
  "petDetection",
  "vehicleDetected",
  "dogDetected",
  "doorbellPress",
  "packageDelivered",
  "packageTaken",
  "packageStranded",
  "soundDetected",
  "cryingDetected",
]);

export const PUSH_STALL_MS = 5 * 60_000; // push down (or never up) this long ⇒ events are dead ⇒ recover
export const SUSPEND_RELEASE_MS = 30_000; // no /stream pull this long while suspended ⇒ nobody's watching
export const STREAM_FAIL_BACKOFF_MAX_MS = 5 * 60_000; // cap on the exponential backoff after failed opens

/**
 * Parse startup defaults. Stable bridge loggers consult process-local runtime overrides.
 * BRIDGE_DEBUG_P2P is currently inert: the SDK has no bridge-provided logger sink.
 */
export function loadConfig(env = process.env) {
  const playbackModels = playbackModelDefaults(env);
  const skipCameras = recordingSkipCameras(env.RECORDINGS_SKIP_CAMERAS);
  const rawOfferWait = env.EUFY_RTC_OFFER_WAIT_MS;
  const offerWaitMs = typeof rawOfferWait === "string" && /^\d+$/.test(rawOfferWait) ? Number(rawOfferWait) : NaN;
  const rtcOfferWaitMs = Number.isSafeInteger(offerWaitMs) && offerWaitMs <= 2_147_483_647 ? offerWaitMs : undefined;
  const cfg = {
    email: env.EUFY_EMAIL,
    password: env.EUFY_PASSWORD,
    country: env.EUFY_COUNTRY || "GB",
    host: env.BRIDGE_HOST || "0.0.0.0",
    port: Number(env.BRIDGE_PORT || 3000),
    // Presentation-only UTC timestamps on allowlisted pilot JSON records; off by default.
    logTimestamps: truthy(env.LOG_TIMESTAMPS),
    session: env.EUFY_SESSION || "./data/.eufy-session.json",
    // Distinct per-install device identity. Unset → the SDK derives one from the account email, which is
    // STABLE but IDENTICAL for every client on the account — so a second client (a second bridge, or the
    // phone app under some conditions) presents the same identity and the two displace each other's
    // session / split push delivery. Set a unique value per bridge when you run more than one on an account.
    openudid: env.BRIDGE_OPENUDID || undefined,
    go2rtcConfig: env.GO2RTC_CONFIG || "./go2rtc.yaml",
    // Toggle for the bundled go2rtc process. Useful when running go2rtc as a separate container/service
    // instead of the one bundled here. Default ON to match existing behavior; set GO2RTC_ENABLE=0 to skip
    // spawning it.
    go2rtcEnable: env.GO2RTC_ENABLE == null ? true : truthy(env.GO2RTC_ENABLE),
    // Native WebRTC relay is opt-in; only the exact environment value "1" enables it.
    webrtcRelay: env.BRIDGE_WEBRTC_RELAY === "1",
    // T9000 (HomeBase Professional) control channel: the mega shard the RTC signalling signs on when the
    // SDK cannot derive it (e.g. `ie-pr`), and the ICE policy (`relay` default; never host-only).
    rtcShard: env.BRIDGE_RTC_SHARD || undefined,
    recordingTimeZone: recordingTimeZone(env.TZ),
    rtcIcePolicy: env.BRIDGE_RTC_ICE_POLICY || undefined,
    rtcOfferWaitMs,
    rtcOfferWaitRejected: rawOfferWait != null && rtcOfferWaitMs === undefined,
    rtcSessionRefreshMs: env.BRIDGE_RTC_SESSION_REFRESH_MS ? Number(env.BRIDGE_RTC_SESSION_REFRESH_MS) : 270_000,
    rtcCommandKeepaliveMs: env.BRIDGE_RTC_COMMAND_KEEPALIVE_MS
      ? Number(env.BRIDGE_RTC_COMMAND_KEEPALIVE_MS)
      : undefined,
    rtcStateRefreshMs: env.BRIDGE_RTC_STATE_REFRESH_MS ? Number(env.BRIDGE_RTC_STATE_REFRESH_MS) : undefined,
    // Separate default-off admission policy; entity/view reads never enable collection.
    storageTelemetry: env.BRIDGE_S1_STORAGE_TELEMETRY === "1",
    recordings: {
      enabled: env.RECORDINGS_ENABLED == null ? true : truthy(env.RECORDINGS_ENABLED),
      playback: env.RECORDINGS_PLAYBACK == null ? true : truthy(env.RECORDINGS_PLAYBACK),
      progressivePlayableMs:
        typeof env.RECORDINGS_PROGRESSIVE_PLAYABLE_MS === "string" &&
        /^(?:[1-5][0-9]{3}|6000)$/.test(env.RECORDINGS_PROGRESSIVE_PLAYABLE_MS)
          ? Number(env.RECORDINGS_PROGRESSIVE_PLAYABLE_MS)
          : 3000,
      progressiveFps: env.RECORDINGS_PROGRESSIVE_FPS === "off" ? null : 15,
      skipCameras: skipCameras.names,
      skipCamerasSource: skipCameras.source,
      skipCamerasRejection: skipCameras.rejection,
      playbackModelsSource: playbackModels.source,
      playbackModels: playbackModels.models,
      playbackModelsRejection: playbackModels.rejection,
      background: env.RECORDINGS_BACKGROUND == null ? true : truthy(env.RECORDINGS_BACKGROUND),
      backgroundPaging: env.RECORDINGS_BACKGROUND_PAGING == null ? true : truthy(env.RECORDINGS_BACKGROUND_PAGING),
      root: env.RECORDINGS_ROOT || "/data/recordings",
    },
    selfHost: env.BRIDGE_SELF_HOST || "127.0.0.1",
    // Cloud poll interval (ms). Unset → the SDK default (600000 = 10 min). Changeable live via the
    // config.set WS command. 0 disables polling.
    pollMs: env.EUFY_POLL_MS ? Number(env.EUFY_POLL_MS) : undefined,
    // Auto-off a battery camera's live stream after this many ms with no detection event. It bleeds power
    // while its P2P live session is up, and go2rtc holds /stream open as long as anything consumes it —
    // so keep its feed only while detections are recent. Mains feeds stay up. Default 5 min; 0 disables.
    streamIdleMs: env.STREAM_IDLE_MS != null ? Number(env.STREAM_IDLE_MS) : 300_000,
    // Battery-saver: a BATTERY camera left with the device's native `rtspStream` publish ON encodes
    // continuously and drains, even when nobody consumes it. If a battery device has rtspStream=true and
    // has been idle this long, turn rtspStream OFF on the device. Default 5 min; 0 disables.
    rtspIdleOffMs: env.RTSP_IDLE_OFF_MS != null ? Number(env.RTSP_IDLE_OFF_MS) : 300_000,
    // Battery-saver: when a /stream open FAILS (P2P connect timeout, no p2p_did, connection closed), go2rtc's
    // ffmpeg source keeps retrying into /stream every ~30s — and each retry opens a fresh P2P session,
    // waking the camera radio for nothing on a camera that can't connect. After a failure, refuse reopening
    // for this base window (doubling per consecutive failure, capped at STREAM_FAIL_BACKOFF_MAX_MS) so a
    // hammering consumer gets a fast 503 instead of a radio wake. Cleared on a successful open or a
    // detection. Default 30s (≈ one ffmpeg retry cycle); 0 disables.
    streamFailBackoffMs: env.STREAM_FAIL_BACKOFF_MS != null ? Number(env.STREAM_FAIL_BACKOFF_MS) : 30_000,
    // A live snapshot burst wakes a battery camera's radio for EVERY caller — and HA fetches a still per
    // camera whenever a dashboard renders or the HomeKit tiles refresh. On an account whose pushes carry
    // no thumbnail, `snapshotStored()` is always empty, so the burst is the only path and every tile costs
    // a wake (and a ~10-20s stall, past HA's 10s still timeout). Set SNAPSHOT_LIVE=0 to skip the burst and
    // answer from the retained/persisted thumbnail only. Default on — unchanged behaviour.
    // "auto" (default): wake the camera for a still only when it is MAINS-POWERED. A mains camera
    // answers a live burst for free; a battery one pays a radio wake for every fetch, and a host fetches
    // stills on a timer (HA re-pulls each camera tile), so the cost is continuous. `1` forces the burst
    // everywhere, `0` never — both remain available for hosts that want the old behaviour.
    snapshotLive: env.SNAPSHOT_LIVE == null || env.SNAPSHOT_LIVE === "auto" ? "auto" : truthy(env.SNAPSHOT_LIVE),
    // How long a BATTERY camera may stream continuously, handed to the SDK when /stream opens the session.
    // The SDK bounds a battery stream to a budget (default 45s) plus a 10s grace, then stops it unless the
    // caller extends it — and a Readable, which is what /stream consumes, has no way to extend. So every
    // watched battery stream ended after ~55s, and the consumer's reconnect woke the camera again. Unset
    // keeps the SDK default. Mains cameras ignore it, and closing the last viewer still ends the session
    // at once. Positive whole ms; anything else → default.
    streamBatteryBudgetMs: positiveInt(env.STREAM_BATTERY_BUDGET_MS),
    // Currently inert: true passes undefined, and the packaged SDK defaults to no prewarm events.
    prewarm: truthy(env.BRIDGE_PREWARM),
    // Optional Anker Solix support — a SEPARATE Anker account (its own login + device backend), enabled
    // only when both SOLIX_EMAIL and SOLIX_PASSWORD are set. Independent of the eufy client; its own
    // persisted session file. Country falls back to the eufy country.
    solix:
      env.SOLIX_EMAIL && env.SOLIX_PASSWORD
        ? {
            email: env.SOLIX_EMAIL,
            password: env.SOLIX_PASSWORD,
            country: env.SOLIX_COUNTRY || env.EUFY_COUNTRY || "GB",
            session: env.SOLIX_SESSION || "./data/.solix-session.json",
            // Cadence of the scene backstop poll — the slow authed read that fills the gap fields
            // (battery temperature + a SOC cross-check) the MQTT push doesn't carry. Deliberately slow:
            // Anker throttles frequent reads, and realtime already comes from the push. Default 90s.
            scenePollMs: Number(env.SOLIX_SCENE_POLL_MS) || 90_000,
            // Login self-heal backoff: after a failed login the bridge retries on an escalating delay
            // (doubling from base, capped at max) rather than tight-looping — Anker throttles frequent
            // logins ("too frequent") and can escalate to a captcha. Base 15 min (past the throttle
            // window), cap 1 h. Raise if you still see throttling; there is rarely a reason to lower.
            retryBaseMs: Number(env.SOLIX_RETRY_BASE_MS) || 15 * 60 * 1000,
            retryMaxMs: Number(env.SOLIX_RETRY_MAX_MS) || 60 * 60 * 1000,
          }
        : undefined,
  };
  // Where the FCM push registration (token + seen-ids) is persisted, beside the session file. Without a
  // pushStore the SDK falls back to MemoryFcmStore and re-registers a fresh token on every restart —
  // wasted work, and it's what makes a same-identity collision bite rather than self-correct (issue #30).
  cfg.pushSession = path.join(path.dirname(cfg.session), ".eufy-fcm.json");

  const DEBUG = truthy(env.BRIDGE_DEBUG);
  const DEBUG_P2P = truthy(env.BRIDGE_DEBUG_P2P);
  const EVENT_LOG = env.BRIDGE_EVENT_LOG == null ? true : truthy(env.BRIDGE_EVENT_LOG);
  const logging = createLoggingControl({ debug: DEBUG, event_log: EVENT_LOG });
  const dbg = (...a) => {
    if (logging.effective("debug")) pilotLog("config_1");
  };

  // Event log — a NARROW, always-on-by-default trace of just the realtime-event path: a push/semantic
  // event arriving, how many frontend (WS) clients it was broadcast to, and each "Last event" image
  // fetch. This is NOT the BRIDGE_DEBUG firehose — it fires only on real events, so it's quiet on an idle
  // system and is what a "why isn't Last event updating" report needs. Set BRIDGE_EVENT_LOG=0 to silence.
  const eventLog = (...a) => {
    if (logging.effective("event_log")) pilotLog("config_2");
  };

  return {
    cfg,
    logging,
    SCHEMA_VERSION,
    DEBUG,
    DEBUG_P2P,
    dbg,
    EVENT_LOG,
    eventLog,
    eventImageDir: path.dirname(cfg.session), // last-event thumbnails live beside the session file
    FORWARDED_EVENTS,
    DETECTION_EVENTS,
    PUSH_STALL_MS,
    SUSPEND_RELEASE_MS,
    STREAM_FAIL_BACKOFF_MAX_MS,
  };
}

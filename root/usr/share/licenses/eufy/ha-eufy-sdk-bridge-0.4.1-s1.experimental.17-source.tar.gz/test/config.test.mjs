/** Modified for genomez S1 experimental source preview, 2026-10-14. */
import { test } from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import { loadConfig } from "../src/config.mjs";

test("recording timestamps use valid host IANA TZ and otherwise Chicago", () => {
  for (const [TZ, expected] of [
    ["America/New_York", "America/New_York"],
    ["UTC", "UTC"],
    ["invalid/zone", "America/Chicago"],
    [undefined, "America/Chicago"],
    ["+05:00", "America/Chicago"],
  ])
    assert.equal(loadConfig({ TZ }).cfg.recordingTimeZone, expected);
});

const base = { EUFY_EMAIL: "x@y.z", EUFY_PASSWORD: "pw" };

test("native WebRTC relay is OFF by default", () => {
  assert.equal(loadConfig(base).cfg.webrtcRelay, false);
});

test("BRIDGE_WEBRTC_RELAY enables only the exact string 1", () => {
  assert.equal(loadConfig({ ...base, BRIDGE_WEBRTC_RELAY: "1" }).cfg.webrtcRelay, true);
  for (const value of ["", "0", "true", "yes", "on", "TRUE", " 1", "1 ", "01", 1, true, null]) {
    assert.equal(loadConfig({ ...base, BRIDGE_WEBRTC_RELAY: value }).cfg.webrtcRelay, false);
  }
});

test("event pre-warm is OFF by default", () => {
  assert.equal(loadConfig(base).cfg.prewarm, false); // → client passes prewarmEvents: []
});

test("BRIDGE_PREWARM=1 preserves the inert request flag (SDK defaults to no events)", () => {
  assert.equal(loadConfig({ ...base, BRIDGE_PREWARM: "1" }).cfg.prewarm, true);
  assert.equal(loadConfig({ ...base, BRIDGE_PREWARM: "true" }).cfg.prewarm, true);
  assert.equal(loadConfig({ ...base, BRIDGE_PREWARM: "0" }).cfg.prewarm, false);
});

test("FCM push store path is derived beside the session file", () => {
  assert.equal(loadConfig(base).cfg.pushSession, path.join("data", ".eufy-fcm.json")); // default session ./data/.eufy-session.json
  assert.equal(
    loadConfig({ ...base, EUFY_SESSION: "/app/data/.eufy-session.json" }).cfg.pushSession,
    path.join("/app/data", ".eufy-fcm.json"),
  );
});

test("SOLIX_SCENE_POLL_MS: default 90s, and a custom value is honoured", () => {
  const solixEnv = { ...base, SOLIX_EMAIL: "s@a.z", SOLIX_PASSWORD: "sp" };
  assert.equal(loadConfig(solixEnv).cfg.solix.scenePollMs, 90_000); // default
  assert.equal(loadConfig({ ...solixEnv, SOLIX_SCENE_POLL_MS: "30000" }).cfg.solix.scenePollMs, 30_000);
  // A non-numeric / empty value falls back to the default rather than NaN.
  assert.equal(loadConfig({ ...solixEnv, SOLIX_SCENE_POLL_MS: "" }).cfg.solix.scenePollMs, 90_000);
});

test("SOLIX_RETRY_BASE_MS / SOLIX_RETRY_MAX_MS: defaults and custom values", () => {
  const solixEnv = { ...base, SOLIX_EMAIL: "s@a.z", SOLIX_PASSWORD: "sp" };
  const def = loadConfig(solixEnv).cfg.solix;
  assert.equal(def.retryBaseMs, 15 * 60 * 1000); // 15 min
  assert.equal(def.retryMaxMs, 60 * 60 * 1000); // 1 h
  const custom = loadConfig({ ...solixEnv, SOLIX_RETRY_BASE_MS: "60000", SOLIX_RETRY_MAX_MS: "300000" }).cfg.solix;
  assert.equal(custom.retryBaseMs, 60_000);
  assert.equal(custom.retryMaxMs, 300_000);
});

test("openudid is undefined by default and taken from BRIDGE_OPENUDID when set", () => {
  assert.equal(loadConfig(base).cfg.openudid, undefined); // → SDK derives from email
  assert.equal(loadConfig({ ...base, BRIDGE_OPENUDID: "abcd1234abcd1234" }).cfg.openudid, "abcd1234abcd1234");
  assert.equal(loadConfig({ ...base, BRIDGE_OPENUDID: "" }).cfg.openudid, undefined); // empty → default
});

test("RTC command keepalive defaults off and parses like the session refresh interval", () => {
  assert.equal(loadConfig(base).cfg.rtcCommandKeepaliveMs, undefined);
  for (const value of ["", "29000", "0", "-1", "1.5", "invalid"]) {
    const { cfg } = loadConfig({ ...base, BRIDGE_RTC_COMMAND_KEEPALIVE_MS: value });
    assert.equal(cfg.rtcCommandKeepaliveMs, value ? Number(value) : undefined);
  }
  assert.equal(loadConfig({ ...base, BRIDGE_RTC_COMMAND_KEEPALIVE_MS: "29000" }).cfg.rtcCommandKeepaliveMs, 29_000);
});

test("RTC session renewal runs at 270 seconds without an environment override", () => {
  assert.equal(loadConfig({}).cfg.rtcSessionRefreshMs, 270_000);
  assert.equal(loadConfig({ ...base, BRIDGE_RTC_SESSION_REFRESH_MS: "300000" }).cfg.rtcSessionRefreshMs, 300_000);
  assert.equal(loadConfig({ ...base, BRIDGE_RTC_SESSION_REFRESH_MS: "0" }).cfg.rtcSessionRefreshMs, 0);
});

test("SDK offer wait leaves unset or invalid overrides to the SDK and accepts zero", () => {
  const read = (value) => loadConfig({ ...base, EUFY_RTC_OFFER_WAIT_MS: value }).cfg;
  assert.equal(read(undefined).rtcOfferWaitMs, undefined);
  assert.equal(read(undefined).rtcOfferWaitRejected, false);
  for (const value of ["", " ", "-1", "1.5", "1e3", "2147483648", "invalid"]) {
    assert.equal(read(value).rtcOfferWaitMs, undefined);
    assert.equal(read(value).rtcOfferWaitRejected, true);
  }
  for (const value of ["0", "2500", "2147483647"]) {
    assert.equal(read(value).rtcOfferWaitMs, Number(value));
    assert.equal(read(value).rtcOfferWaitRejected, false);
  }
});

test("progressive playable threshold accepts only integer milliseconds in range", () => {
  for (const value of [undefined, "", "999", "6001", "1e3", "1000.0", " 1000", "NaN", "-1000"])
    assert.equal(
      loadConfig({ ...base, RECORDINGS_PROGRESSIVE_PLAYABLE_MS: value }).cfg.recordings.progressivePlayableMs,
      3000,
    );
  for (const value of ["1000", "2500", "6000"])
    assert.equal(
      loadConfig({ ...base, RECORDINGS_PROGRESSIVE_PLAYABLE_MS: value }).cfg.recordings.progressivePlayableMs,
      Number(value),
    );
});

test("quick-start playback defaults on and explicit off disables it", () => {
  for (const value of [undefined, "15", "", "invalid"])
    assert.equal(loadConfig({ RECORDINGS_PROGRESSIVE_FPS: value }).cfg.recordings.progressiveFps, 15);
  assert.equal(loadConfig({ RECORDINGS_PROGRESSIVE_FPS: "off" }).cfg.recordings.progressiveFps, null);
  assert.equal(loadConfig({}).cfg.recordings.progressivePlayableMs, 3000);
});

test("skip cameras JSON preserves commas, normalizes and deduplicates atomically", () => {
  const cfg = loadConfig({ RECORDINGS_SKIP_CAMERAS: '[" Camera, East ", "CAMERA, EAST", "Camera West"]' }).cfg
    .recordings;
  assert.deepEqual(cfg.skipCameras, ["camera, east", "camera west"]);
  assert.equal(cfg.skipCamerasSource, "env");
  assert.equal(cfg.skipCamerasRejection, null);
  assert.deepEqual(loadConfig({}).cfg.recordings.skipCameras, []);
  assert.deepEqual(loadConfig({ RECORDINGS_SKIP_CAMERAS: "[]" }).cfg.recordings.skipCameras, []);
  for (const raw of [
    "",
    "{",
    "null",
    "{}",
    '"Camera"',
    '["Camera",null]',
    '["Camera",1]',
    '["Camera",""]',
    '["Camera"," "]',
  ]) {
    const rejected = loadConfig({ RECORDINGS_SKIP_CAMERAS: raw }).cfg.recordings;
    assert.deepEqual(rejected.skipCameras, []);
    assert.equal(rejected.skipCamerasRejection, "skip_cameras");
    assert.equal(rejected.skipCamerasSource, "default");
  }
});

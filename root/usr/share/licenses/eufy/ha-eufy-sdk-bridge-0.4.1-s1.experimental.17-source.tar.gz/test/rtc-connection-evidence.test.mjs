import { test } from "node:test";
import assert from "node:assert/strict";
import { rtcConnectionEvidence, cloudPollEvidence, ownCloudPollEvidence } from "../src/rtc-connection-evidence.mjs";
import { createDiagnostics } from "../src/diagnostics.mjs";
import { createState } from "../src/state.mjs";

const sample = () => ({
  version: 1,
  incarnation: 1,
  epoch: 2,
  activeCap: 64,
  terminalCap: 32,
  eventCap: 32,
  activeCount: 1,
  activeEvicted: 0,
  terminalEvicted: 3,
  active: [
    {
      epoch: 2,
      generation: 1,
      role: "candidate",
      startedAtMs: 12,
      endedAtMs: null,
      outcome: "opening",
      retirement: null,
      closeOrigin: null,
      stages: {
        events: [{ stage: "sign", status: "started", atMs: 12 }],
        evicted: 0,
        lastFailure: { stage: "signaling_auth", status: "failed", atMs: 13 },
      },
    },
  ],
  terminal: [
    {
      epoch: 1,
      generation: 1,
      role: "current",
      startedAtMs: null,
      endedAtMs: 10,
      outcome: "connect_timeout",
      retirement: "router_reset",
      closeOrigin: "signaling_closed",
      stages: null,
    },
  ],
});
const cloud = () => ({ enabled: true, intervalMs: 60_000, scheduledAtMs: 100, nextDueAtMs: 60_100, inFlight: false });
function snapshot(eufy) {
  return createDiagnostics({ eufy, state: createState() }).diagnostics(false);
}

function failureHistory() {
  const recent = Array.from({ length: 32 }, (_, i) => ({
    ...sample().terminal[0],
    generation: i + 1,
    role: "candidate",
    connectFailureCategory: null,
    connectLastStage: "ice_checking",
    signalingBoundary: null,
    failureSequence: i + 2,
    renewal: { originalSessionGeneration: 1, attemptOrdinal: 1, failureSequence: 1 },
    renewalLink: "linked",
    stages: {
      events: Array.from({ length: 64 }, () => ({ stage: "signaling_auth", status: "observed", atMs: 5 })),
      evicted: 2,
      lastFailure: null,
    },
  }));
  return {
    cap: 32, eventCap: 64, retainedCount: 32, totalRecorded: 33, evicted: 1, oldestFailureSequence: 2,
    lastEviction: { failureSequence: 1, endedAtMs: 10, evictedAtMs: 15 },
    recent,
  };
}

test("projects bounded failed history and both sides of a renewal link", () => {
  const raw = { ...sample(), failed: failureHistory() };
  const row = {
    outcome: "failed", candidateSessionGeneration: 1, candidateConnectionEpoch: 1,
    candidateConnectionFailureSequence: 2, candidateConnected: false, informationVerified: false,
  };
  const retention = {
    version: 1, ownerIncarnation: 1, ownerEpoch: 1, failedCompletions: 1, cancelledCompletions: 0,
    evictedFailures: 0, recentFailures: [{ ...row, sequence: 1 }],
  };
  const result = snapshot({
    getRtcConnectionDiagnostics: () => raw,
    getRtcSessionRefreshDiagnostics: () => ({ lastAttempt: row, lastFailure: row, recent: [row], failureRetention: retention }),
  });
  assert.deepEqual(result.rtcConnections, raw);
  result.rtcConnections.failed.recent[0].renewal.attemptOrdinal = 2;
  assert.equal(raw.failed.recent[0].renewal.attemptOrdinal, 1);
  for (const entry of [
    result.rtcRenewals.lastFailure,
    result.rtcRenewals.lastAttempt,
    result.rtcRenewals.recent[0],
    result.rtcRenewals.failureRetention.recentFailures[0],
  ]) {
    assert.equal(entry.candidateConnectionEpoch, 1);
    assert.equal(entry.candidateConnectionFailureSequence, 2);
  }
  assert.equal(result.rtcRenewals.failureRetention.recentFailures[0].sequence, 1);
});

test("preserves active and terminal evidence when failed history is malformed", () => {
  const valid = sample();
  for (const contaminate of [
    (failed) => { failed.recent.push(failed.recent[0]); },
    (failed) => { failed.recent[0].stages.events.push(failed.recent[0].stages.events[0]); },
    (failed) => { failed.recent[0].stages.events.pop(); },
    (failed) => { failed.recent[0].outcome = "connected"; },
    (failed) => { failed.recent[0].failureSequence = Number.MAX_SAFE_INTEGER + 1; },
    (failed) => { failed.recent[0].renewal.failureSequence = -1; },
    (failed) => { failed.recent[0].renewalLink = "not_renewal"; },
    (failed) => { failed.oldestFailureSequence = 1; },
    (failed) => { failed.evicted = 2; },
    (failed) => { failed.lastEviction.unknown = "CANARY"; },
    (failed) => { failed.recent[0].renewal.unknown = "CANARY"; },
    (failed) => { failed.recent[0].stages.events[0].unknown = "CANARY"; },
    (failed) => { failed.unknown = "CANARY"; },
  ]) {
    const failed = failureHistory();
    contaminate(failed);
    const raw = { ...valid, failed };
    assert.deepEqual(rtcConnectionEvidence(raw), { ...valid, failed: null });
    assert.deepEqual(snapshot({ getRtcConnectionDiagnostics: () => raw }).rtcConnections, {
      ...valid,
      failed: null,
    });
  }
});

test("ignores unsafe renewal link fields without reading accessors", () => {
  let accessorRead = false;
  const raw = {
    get candidateConnectionEpoch() { accessorRead = true; return 2; },
    outcome: "failed", candidateSessionGeneration: 1, candidateConnectionFailureSequence: Number.MAX_SAFE_INTEGER + 1,
    unexpected: "CANARY",
  };
  const { rtcRenewals } = snapshot({
    getRtcSessionRefreshDiagnostics: () => ({ lastFailure: raw, lastAttempt: {
      candidateSessionGeneration: 1, candidateConnectionEpoch: 0, candidateConnectionFailureSequence: 0,
    } }),
  });
  assert.equal(accessorRead, false);
  assert.equal(rtcRenewals.lastFailure.candidateConnectionEpoch, null);
  assert.equal(rtcRenewals.lastFailure.candidateConnectionFailureSequence, null);
  assert.equal(rtcRenewals.lastFailure.unexpected, undefined);
  assert.equal(rtcRenewals.lastAttempt.candidateConnectionEpoch, 0);
  assert.equal(rtcRenewals.lastAttempt.candidateConnectionFailureSequence, null);
});

test("projects renewal refresh retries and their finite client outcome", () => {
  const result = snapshot({
    getStateRefreshDiagnostics: () => ({
      renewalRetries: 2,
      attempts: 3,
      successes: 2,
      failures: 1,
      operations: [{ outcome: "superseded_by_renewal", phase: "transport", failure: null, private: "CANARY" }],
    }),
  }).stateRefresh;
  assert.equal(result.renewalRetries, 2);
  assert.deepEqual([result.attempts, result.successes, result.failures], [3, 2, 1]);
  assert.equal(result.operations[0].outcome, "superseded_by_renewal");
  assert.equal(result.operations[0].private, undefined);
});

test("SDK getter is read once; projection is detached and missing or throwing APIs stay null", () => {
  const raw = sample();
  const cp = cloud();
  let rtc = 0;
  let refresh = 0;
  const eufy = {
    getRtcConnectionDiagnostics() {
      rtc++;
      return raw;
    },
    getStateRefreshDiagnostics() {
      refresh++;
      return { cloudPoll: cp };
    },
  };
  const result = snapshot(eufy);
  assert.equal(rtc, 1);
  assert.equal(refresh, 1);
  assert.deepEqual(result.rtcConnections, raw);
  assert.deepEqual(result.stateRefresh.cloudPoll, cp);
  raw.active[0].stages.events[0].stage = "private";
  cp.intervalMs = 1;
  assert.equal(result.rtcConnections.active[0].stages.events[0].stage, "sign");
  assert.equal(result.stateRefresh.cloudPoll.intervalMs, 60_000);
  result.rtcConnections.terminal[0].generation = 999;
  assert.equal(raw.terminal[0].generation, 1);
  for (const getRtcConnectionDiagnostics of [
    undefined,
    3,
    () => {
      throw new Error("private");
    },
  ])
    assert.equal(snapshot({ getRtcConnectionDiagnostics }).rtcConnections, null);
  assert.equal(snapshot({ getStateRefreshDiagnostics: () => ({}) }).stateRefresh.cloudPoll, null);
});

test("fixed schema accepts every published finite enum, null evidence, and exact caps", () => {
  const raw = sample();
  for (const stage of [
    "sign",
    "signaling_transport",
    "signaling_auth",
    "call",
    "grant",
    "peer_init",
    "offer",
    "answer",
    "command_channel",
    "signaling",
    "peer",
    "call_retry",
  ])
    for (const status of ["started", "succeeded", "failed", "observed"]) {
      raw.active[0].stages.events[0] = { stage, status, atMs: null };
      assert.ok(rtcConnectionEvidence(raw));
    }
  for (const outcome of ["opening", "connected", "connect_failed", "connect_timeout", "closed_before_open"])
    for (const retirement of [null, "closed", "retired", "router_reset"])
      for (const closeOrigin of [
        null,
        "local",
        "signaling_closed",
        "remote_hangup",
        "command_channel_closed",
        "peer_failed",
        "peer_closed",
      ]) {
        Object.assign(raw.active[0], { outcome, retirement, closeOrigin });
        assert.ok(rtcConnectionEvidence(raw));
      }
  raw.active[0].stages.events = Array.from({ length: 32 }, () => ({ stage: "peer", status: "observed", atMs: 0 }));
  raw.active = Array.from({ length: 64 }, () => structuredClone(raw.active[0]));
  raw.activeCount = 80;
  raw.terminal = Array.from({ length: 32 }, () => structuredClone(raw.terminal[0]));
  assert.ok(rtcConnectionEvidence(raw));
});

test("strict projection rejects malformed, oversized, extra, inherited and accessor data without traversing payloads", () => {
  let getterReads = 0;
  const bad = [
    undefined,
    null,
    0,
    "private",
    [],
    Promise.resolve({}),
    Object.create(sample()),
    ...[
      "version",
      "incarnation",
      "epoch",
      "activeCap",
      "terminalCap",
      "eventCap",
      "activeCount",
      "activeEvicted",
      "terminalEvicted",
    ].flatMap((key) =>
      [-1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, "1", {}, null].map((v) => ({ ...sample(), [key]: v })),
    ),
  ];
  const changes = [
    (r) => {
      delete r.epoch;
    },
    (r) => {
      r[Symbol("private")] = 1;
    },
    (r) => {
      Object.defineProperty(r, "private", { value: "private" });
    },
    (r) => {
      Object.defineProperty(r, "epoch", {
        get() {
          getterReads++;
          return 1;
        },
      });
    },
    (r) => {
      r.active = new Array(1_000_000);
    },
    (r) => {
      r.terminal = Array(33).fill(r.terminal[0]);
    },
    (r) => {
      r.active = new Array(1);
    },
    (r) => {
      r.active.extra = "private";
    },
    (r) => {
      Object.defineProperty(r.active, "0", {
        get() {
          getterReads++;
          return {};
        },
      });
    },
    (r) => {
      r.activeCount = 0;
    },
    (r) => {
      r.active[0].generation = 0;
    },
    (r) => {
      r.active[0].role = "private";
    },
    (r) => {
      r.active[0].outcome = "private";
    },
    (r) => {
      r.active[0].retirement = "private";
    },
    (r) => {
      r.active[0].closeOrigin = "private";
    },
    (r) => {
      r.active[0].startedAtMs = -1;
    },
    (r) => {
      r.active[0].stages.events = Array(33).fill({});
    },
    (r) => {
      r.active[0].stages.private = "private";
    },
    (r) => {
      r.active[0].stages.events[0].stage = "private";
    },
    (r) => {
      r.active[0].stages.events[0].status = "private";
    },
    (r) => {
      r.active[0].stages.events[0].atMs = Infinity;
    },
    (r) => {
      r.active[0].stages.lastFailure.private = "private";
    },
    (r) => {
      r.active[0].stages.lastFailure = undefined;
    },
    (r) => {
      r.active[0].stages = new Date();
    },
    (r) => {
      r.active[0].private = {
        toJSON() {
          throw new Error("must not serialize");
        },
      };
    },
    (r) => {
      r.terminal[0].stages = {
        events: [],
        evicted: 0,
        lastFailure: { stage: "sign", status: "failed", atMs: 0, token: "private" },
      };
    },
  ];
  for (const change of changes) {
    const r = sample();
    change(r);
    bad.push(r);
  }
  const revoked = Proxy.revocable({}, {});
  revoked.revoke();
  bad.push(revoked.proxy);
  bad.push(
    new Proxy(
      {},
      {
        ownKeys() {
          throw new Error("private");
        },
      },
    ),
  );
  for (const value of bad) assert.equal(rtcConnectionEvidence(value), null);
  assert.equal(getterReads, 0);
});

test("cloud poll projection is exact, bounded, accessor-safe and independently detached", () => {
  assert.deepEqual(cloudPollEvidence(cloud()), cloud());
  const empty = { enabled: false, intervalMs: null, scheduledAtMs: null, nextDueAtMs: null, inFlight: false };
  assert.deepEqual(cloudPollEvidence(empty), empty);
  for (const value of [
    undefined,
    null,
    [],
    Object.create(cloud()),
    { ...cloud(), private: 1 },
    { ...cloud(), enabled: 1 },
    { ...cloud(), inFlight: null },
    { ...cloud(), intervalMs: Infinity },
    { ...cloud(), nextDueAtMs: -1 },
  ])
    assert.equal(cloudPollEvidence(value), null);
  const raw = {};
  Object.defineProperty(raw, "cloudPoll", {
    get() {
      throw new Error("must not read");
    },
  });
  assert.equal(ownCloudPollEvidence(raw), null);
  const cp = cloud();
  Object.defineProperty(cp, "enabled", {
    get() {
      throw new Error("must not read");
    },
  });
  assert.equal(cloudPollEvidence(cp), null);
});

const retryFields = (raw) => {
  const { nextRetryAtMs, retryAttempt, retryReason } = snapshot({ getStateRefreshDiagnostics: () => raw }).stateRefresh;
  return { nextRetryAtMs, retryAttempt, retryReason };
};
const retry = () => ({ nextRetryAtMs: 60_100, retryAttempt: 2, retryReason: "failure_backoff" });
const unknownRetry = () => ({ nextRetryAtMs: null, retryAttempt: null, retryReason: null });

test("state refresh retry fields stay flat, detached and preserve existing diagnostics", () => {
  const raw = { ...retry(), active: true, attempts: 3, cloudPoll: cloud() };
  let reads = 0;
  const result = snapshot({
    getStateRefreshDiagnostics() {
      reads++;
      return raw;
    },
  }).stateRefresh;
  assert.equal(reads, 1);
  for (const [key, value] of Object.entries(retry())) assert.equal(result[key], value);
  assert.equal(result.active, true);
  assert.equal(result.attempts, 3);
  assert.deepEqual(result.cloudPoll, cloud());
  Object.assign(raw, { nextRetryAtMs: 70_100, retryAttempt: 3, retryReason: "session_recovery" });
  for (const [key, value] of Object.entries(retry())) assert.equal(result[key], value);
  Object.assign(result, { nextRetryAtMs: 80_100, retryAttempt: 4, retryReason: null });
  assert.equal(raw.nextRetryAtMs, 70_100);
  assert.equal(raw.retryAttempt, 3);
  assert.equal(raw.retryReason, "session_recovery");
});

test("state refresh retry projection handles missing APIs, null state and unknown fields", () => {
  assert.equal(snapshot({}).stateRefresh, null);
  for (const raw of [undefined, null])
    assert.equal(snapshot({ getStateRefreshDiagnostics: () => raw }).stateRefresh, null);
  for (const raw of [{}, unknownRetry(), { nextRetryAtMs: undefined, retryAttempt: undefined, retryReason: undefined }])
    assert.deepEqual(retryFields(raw), unknownRetry());
  for (const key of Object.keys(retry())) {
    const raw = retry();
    delete raw[key];
    assert.deepEqual(retryFields(raw), { ...retry(), [key]: null });
  }
});

test("state refresh retry projection accepts safe boundaries and supported reasons", () => {
  for (const nextRetryAtMs of [1, Number.MAX_SAFE_INTEGER])
    for (const retryAttempt of [0, 1, Number.MAX_SAFE_INTEGER])
      for (const retryReason of ["failure_backoff", "session_recovery", "station_work", null]) {
        const raw = { nextRetryAtMs, retryAttempt, retryReason };
        assert.deepEqual(retryFields(raw), raw);
      }
});

test("state refresh retry projection rejects invalid values independently without coercion", () => {
  const invalidNumbers = [
    undefined,
    null,
    -1,
    1.5,
    NaN,
    Infinity,
    -Infinity,
    Number.MAX_SAFE_INTEGER + 1,
    "1",
    "0",
    true,
    false,
    1n,
    Symbol("invalid"),
    [],
    {
      valueOf() {
        throw new Error("must not coerce");
      },
    },
  ];
  for (const key of ["nextRetryAtMs", "retryAttempt"])
    for (const value of [...invalidNumbers, ...(key === "nextRetryAtMs" ? [0, -0] : [])])
      assert.deepEqual(retryFields({ ...retry(), [key]: value }), { ...retry(), [key]: null });
  for (const retryReason of [...invalidNumbers, 0, "", "unknown", "FAILURE_BACKOFF", new String("failure_backoff")])
    assert.deepEqual(retryFields({ ...retry(), retryReason }), { ...retry(), retryReason: null });
});

test("state refresh retry projection reads only own data descriptors without invoking accessors", () => {
  let getterReads = 0;
  for (const [key, value] of Object.entries(retry())) {
    const inherited = Object.create({ [key]: value });
    Object.assign(inherited, retry());
    delete inherited[key];
    assert.deepEqual(retryFields(inherited), { ...retry(), [key]: null });
    for (const descriptor of [
      {
        get() {
          getterReads++;
          return value;
        },
      },
      {
        get() {
          getterReads++;
          throw new Error("must not read");
        },
      },
      { set(_) {} },
    ]) {
      const raw = retry();
      Object.defineProperty(raw, key, descriptor);
      assert.deepEqual(retryFields(raw), { ...retry(), [key]: null });
    }
    const inheritedGetter = Object.create(
      Object.defineProperty({}, key, {
        get() {
          getterReads++;
          return value;
        },
      }),
    );
    for (const [other, otherValue] of Object.entries(retry())) if (other !== key) inheritedGetter[other] = otherValue;
    assert.deepEqual(retryFields(inheritedGetter), { ...retry(), [key]: null });
    const nonenumerable = retry();
    Object.defineProperty(nonenumerable, key, { value, enumerable: false });
    assert.deepEqual(retryFields(nonenumerable), retry());
  }
  assert.equal(getterReads, 0);
});

test("state refresh retry projection contains descriptor failures to the affected field", () => {
  for (const key of Object.keys(retry())) {
    const raw = new Proxy(retry(), {
      getOwnPropertyDescriptor(target, property) {
        if (property === key) throw new Error("unavailable descriptor");
        return Reflect.getOwnPropertyDescriptor(target, property);
      },
    });
    assert.deepEqual(retryFields(raw), { ...retry(), [key]: null });
  }
});
import { EventEmitter } from "node:events";
import { RtcCommandRouter, RtcSession } from "@mega-yfue/eufy-sdk";

async function assertInstalledSdkDeadlines(t, offerWaitMs) {
  const deadline = offerWaitMs === 0 ? "connection" : "offer";
  let now = 0;
  t.mock.method(performance, "now", () => now);
  t.mock.timers.enable({ apis: ["setTimeout", "Date"], now: 100000 });
  const signals = [],
    natives = [],
    realSessions = [];
  const flush = async () => {
    for (let i = 0; i < 30; i++) await Promise.resolve();
  };
  class Signaling extends EventEmitter {
    isOpen = true;
    async fetchSign() {}
    async connect() {
      this.emit("message", { action: 1, code: 200 });
    }
    sendCall() {}
    sendHangup() {}
    close() {
      this.isOpen = false;
    }
    sendInfoCandidate() {}
  }
  const native = () => {
    const callbacks = {};
    const pc = {
      callbacks,
      close() {},
      onLocalDescription(cb) {
        callbacks.description = cb;
      },
      onLocalCandidate(cb) {
        callbacks.candidate = cb;
      },
      onGatheringStateChange(cb) {
        callbacks.gathering = cb;
      },
      onStateChange(cb) {
        callbacks.connection = cb;
      },
      onIceStateChange(cb) {
        callbacks.ice = cb;
      },
      onDataChannel(cb) {
        callbacks.channel = cb;
      },
      getSelectedCandidatePair: () => ({ local: { type: "host" }, remote: { type: "relay" } }),
    };
    natives.push(pc);
    return pc;
  };
  const deps = {
    identity: () => ({ authToken: "offline-token", userId: "offline-user" }),
    shard: () => "offline",
    accountName: () => "offline",
    findDevice: () => ({ sn: "offline-station", model: "T9000", deviceClass: "homebase" }),
    icePolicy: "all",
    connectTimeoutMs: 12000,
    offerWaitMs,
    createSession(opts) {
      const session = new RtcSession({
        ...opts,
        createSignaling() {
          const s = new Signaling();
          signals.push(s);
          return s;
        },
        peer: { ...opts.peer, createPeer: native },
      });
      realSessions.push(session);
      return session;
    },
  };
  const router = new RtcCommandRouter(deps);
  t.after(() => router.close());
  const pending = router.sessionFor("offline-station").catch((error) => error);
  await flush();
  signals[0].emit("message", {
    dataType: "scall",
    data: JSON.stringify({
      status: 100,
      turn: { turn_addr: "offline.invalid", turn_port: 3478, turn_user: "fixture", turn_password: "fixture" },
    }),
  });
  await flush();
  natives[0].callbacks.ice("checking");
  natives[0].callbacks.connection("connecting");
  natives[0].callbacks.candidate("candidate:1 1 udp 1 192.0.2.1 1 typ host");
  signals[0].emit("message", { dataType: "info", data: JSON.stringify({ candidate: "synthetic-candidate" }) });
  await flush();
  deps.connectTimeoutMs = 20000;
  now = deadline === "offer" ? 3000 : 12000;
  t.mock.timers.tick(now);
  await flush();
  const first = router.getConnectionDiagnostics();
  assert.equal(first.active.length, 1);
  assert.equal(first.active[0].stages.establishment.policy, "relay");
  assert.equal(first.terminal[0].stages.establishment.policy, "all");
  const expectedDeadline =
    deadline === "offer"
      ? { kind: "offer", atMs: now, waitMs: 3000, remoteCandidatesReceived: true }
      : { kind: "connection", atMs: now };
  assert.deepEqual(first.terminal[0].stages.establishment.deadlines, [expectedDeadline]);
  assert.equal(first.failed.recent[0].outcome, deadline === "offer" ? "offer_timeout" : "connect_timeout");
  assert.ok(first.terminal[0].stages.establishment.transitions.length >= 2);
  assert.deepEqual(rtcConnectionEvidence(first), first);
  // A candidate's grant timeout preserves grant_timeout: a current relay is instead
  // synchronously dropped by the router's error listener. Use the actual router
  // candidate-creation seam to exercise this path without opening a native socket.
  const candidate = router.createStationSession("offline-station", "offline-user", deps.identity(), true, "relay");
  const candidateDone = candidate.ready.catch((error) => error);
  await flush();
  signals[2].emit("message", { dataType: "info", data: JSON.stringify({ sdp: "v=0\r\n" }) });
  await flush();
  now += 15000;
  t.mock.timers.tick(15000);
  await flush();
  assert.ok((await candidateDone) instanceof Error);
  const second = router.getConnectionDiagnostics();
  assert.equal(second.active.length, 1);
  const timedOut = second.terminal.find((row) => row.closeOrigin === "grant_timeout");
  assert.ok(timedOut);
  assert.deepEqual(timedOut.stages.establishment.deadlines, [{ kind: "turn_grant", atMs: 15000 }]);
  assert.equal(timedOut.stages.lastFailure.stage, "grant");
  assert.deepEqual(rtcConnectionEvidence(second), second);
  assert.ok(realSessions.every((session) => session instanceof RtcSession));
  router.close();
  await pending;
}

for (const offerWaitMs of [0, undefined]) {
  const deadline = offerWaitMs === 0 ? "connection" : "offer";
  test(`installed SDK projects the ${deadline} deadline beside relay recovery and grant timeout`, (t) =>
    assertInstalledSdkDeadlines(t, offerWaitMs),
  );
}

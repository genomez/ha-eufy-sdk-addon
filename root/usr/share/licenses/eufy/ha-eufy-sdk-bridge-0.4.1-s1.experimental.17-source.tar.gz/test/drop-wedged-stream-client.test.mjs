/** Modified for genomez S1 experimental source preview, 2026-10-17. */
// A stream client whose P2P session died must not be reused. streams.mjs caches one client per camera
// and never expires it, so a wedged session turns into a permanent "P2P unreachable" for that camera —
// observed for hours while the eufy app held a live view of the SAME camera, and cured only by a bridge
// restart (which empties the cache). The route must therefore drop the client whenever an open fails.
import { test } from "node:test";
import assert from "node:assert/strict";

import { loadConfig } from "../src/config.mjs";
import { createState } from "../src/state.mjs";
import { dropStreamClient } from "../streams.mjs";

process.env.BRIDGE_STREAM_CONSUMER_LOG_MS = "0"; // no real HTTP at :1984 from the consumer probe
const { createHttpHandler } = await import("../src/http-routes.mjs");

/** A handler whose stream client always fails to open, recording the drops the route asks for. */
function setup() {
  const config = loadConfig({ EUFY_EMAIL: "x@y.z", EUFY_PASSWORD: "pw" });
  const state = createState();
  state.flags.ready = true;
  const dropped = [];
  let openAttempts = 0;
  const ctx = {
    ...config,
    state,
    resolveMediaTopology: async () => ({ onT9000: false }),
    eufy: {
      getDevices: async () => [
        { sn: "CAM1", stationSn: "BASE1" },
        { sn: "BASE1", model: "T8010" },
      ],
    },
    eventLog: () => {},
    broadcast: () => {},
    noteStreamOpened: () => {},
    noteStreamFailure: () => {},
    streamBackoffMs: () => 0,
    dropStreamClient: (sn) => void dropped.push(sn),
    streamClientFor: async () => ({
      getDevice: async () => ({
        camera: () => ({
          openReadable: async () => {
            openAttempts += 1;
            throw new Error("P2P connect timeout");
          },
        }),
      }),
    }),
  };
  return { handler: createHttpHandler(ctx), dropped, openAttempts: () => openAttempts };
}

async function pull(handler) {
  const out = { chunks: [] };
  const res = {
    writeHead(code) {
      out.code = code;
    },
    write(c) {
      out.chunks.push(Buffer.from(c));
      return true;
    },
    end(body) {
      if (body) out.chunks.push(Buffer.from(body));
    },
    on() {},
    once() {},
    emit() {},
    removeListener() {},
    off() {},
    destroy() {},
  };
  await handler({ url: "/stream/CAM1", headers: { host: "localhost" }, on() {} }, res);
  return out;
}

test("a failed open drops the cached client instead of keeping it", async () => {
  const { handler, dropped, openAttempts } = setup();
  const out = await pull(handler);
  assert.equal(out.code, 502);
  assert.equal(openAttempts(), 1);
  assert.deepEqual(dropped, ["CAM1"]); // the next attempt must start from a fresh session
});

test("dropStreamClient is harmless for a camera that has no client", () => {
  assert.equal(dropStreamClient("NEVER-OPENED"), false);
});

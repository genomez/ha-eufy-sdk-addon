/** Modified for genomez S1 experimental source preview, 2026-10-16. */
import { LIGHT, LIGHT_CMD, type LightActions } from "../light.js";
import { unobservableMembers } from "../members.js";
import { buildCommand } from "../index.js";
import { bind } from "./bind.js";
import type { CommandContext } from "../types.js";
import { commandObservation, type Command } from "../../../core/contracts.js";
import { Device } from "../../device.js";
import { DeviceType } from "../../device-types.js";

describe("light switch scalar reports", () => {
  it("re-projects retained reported evidence when parent identity arrives or changes", () => {
    const dev = Device.fromRecord("T8000P0000000000", {
      model: "T8425",
      deviceType: 47,
      parentSn: "T9000P0000000000",
      params: { 1400: "0" },
    });
    const manifest = () => dev.properties.find((spec) => spec.name === "light")?.boundedStateWrites;
    expect(manifest()).toBeUndefined();
    dev.setStationContext({ stationModel: "T9000" });
    expect(manifest()).toBe(true);
    dev.reresolve({ name: "Synthetic floodlight" });
    expect(manifest()).toBe(true);
    expect(dev.getProperty("light")?.value).toBe(false);
    dev.setStationContext({ stationModel: "T8030" });
    expect(manifest()).toBeUndefined();
    expect(dev.getPropertySpecs().find((spec) => spec.name === "light")?.boundedStateWrites).toBeUndefined();
    dev.setStationContext({ stationDeviceType: undefined, stationModel: undefined });
    expect(manifest()).toBeUndefined();
  });

  it.each([true, false])("advertises bounded state writes only with verified station coverage (%s)", (supported) => {
    const dev = Device.fromRecord("T8000P0000000000", {
      model: "T8425",
      deviceType: 47,
      category: "eufy_security",
      params: { 1400: "0" },
    });
    dev.bindActions(
      {
        channel: 1,
        codec: "camera",
        deviceType: 47,
        paramIds: new Set([1400]),
        stationModel: supported ? "T9000" : "T8030",
      },
      { dispatch: async () => undefined },
    );
    expect(dev.getPropertySpecs().find((spec) => spec.name === "light")?.boundedStateWrites).toBe(
      supported ? true : undefined,
    );
  });

  function device(value: string | number | boolean) {
    const dev = Device.fromRecord("T8000P0000000000", {
      model: "T8425",
      deviceType: 47,
      category: "eufy_security",
      params: { [LIGHT_CMD.FLOODLIGHT_SWITCH]: String(value) },
    });
    dev.applyParams({ [LIGHT_CMD.FLOODLIGHT_SWITCH]: value });
    dev.bindActions(
      { channel: 0, codec: "camera", deviceType: 47, paramIds: new Set([LIGHT_CMD.FLOODLIGHT_SWITCH]) },
      { dispatch: async () => undefined },
    );
    return dev;
  }

  it.each([
    true,
    1,
    "1",
    "true",
    " TRUE ",
    Buffer.from("1").toString("base64"),
    Buffer.from("true").toString("base64"),
    Buffer.from("1\0").toString("base64"),
  ])("reads true from a qualified scalar %s", (value) => {
    expect(device(value).light?.()?.isOn).toBe(true);
  });

  it.each([
    false,
    0,
    "0",
    "false",
    " FALSE ",
    Buffer.from("0").toString("base64"),
    Buffer.from("false").toString("base64"),
    Buffer.from("0\0").toString("base64"),
  ])("reads false from a qualified scalar %s", (value) => {
    expect(device(value).light?.()?.isOn).toBe(false);
  });

  it.each([
    "",
    "unknown",
    "2",
    "!!!!",
    "MB==",
    "MA",
    "/w==",
    '{"value":0}',
    Buffer.from('{"value":0}').toString("base64"),
  ])("preserves an unqualified scalar without reporting false: %s", (value) => {
    const dev = device(value);
    expect(dev.getProperty("light")?.value).toBe(value);
    expect(dev.light?.()?.isOn).toBeUndefined();
  });
});

/**
 * Resolve an intent the way a device does. A control's write lives on the control, so the barrel — not
 * the module's own `buildCommand` — is where the property path resolves; pinning the capability keeps
 * the answer this module's alone.
 */
const intent = (action: string, value: boolean | number | string, c: CommandContext): Command | undefined =>
  buildCommand(action, value, { ...c, capabilities: new Set(["light"]) });

// Default ctx = an int-string-switch device (e.g. T8442 IndoorOutdoor). jsonCtx = a JSON-switch
// family (deviceType 47 = FloodlightCam T8425).
// Default ctx = an int-string family (deviceType 46 = IndoorOutdoor T8442). jsonCtx = JSON family
// (47 = FloodlightCam T8425). unknownCtx = a spotlight model not in either wire-format table.
const ctx = (channel = 0): CommandContext => ({
  channel,
  codec: "camera",
  deviceType: 46,
  paramIds: new Set<number>(),
});
const jsonCtx = (channel = 0): CommandContext => ({
  channel,
  codec: "camera",
  deviceType: 47,
  paramIds: new Set<number>(),
});
const unknownCtx = (channel = 0): CommandContext => ({
  channel,
  codec: "camera",
  deviceType: 99999,
  paramIds: new Set<number>(),
});

describe("light capability module", () => {
  it("declares the capability + schema", () => {
    expect(LIGHT.capability).toBe("light");
    // `colorTemp` is absent: write-only, with no read measured. The master switch's own read evidence is
    // in the describe below.
    expect(LIGHT.properties.map((p) => p.name)).toEqual(["light", "brightness", "spotlightEnabled"]);
  });

  it("detects only from real SPOTLIGHT params (NOT 1045 status LED)", () => {
    // 1045 (status LED, on every camera) must NOT be here — that's `camera`, not `light`.
    expect(LIGHT.detection?.detect?.({ params: { 1045: "1" } }, "camera")).toBe(false);
    for (const param of [1400, 1401, 1403, 6080, 6082, 1413]) {
      expect(LIGHT.detection?.detect?.({ params: { [param]: "0" } }, "camera")).toBe(true);
    }
    const re = LIGHT.detection!.modelHints![0];
    expect(re.test("Floodlight Cam")).toBe(true);
    expect(re.test("Wired Doorbell")).toBe(false);
  });

  it.each(["T8170", "T8425", "T8426"])("keeps light capability for spotlight model %s", (model) => {
    const dev = Device.fromRecord("T8000P0000000000", {
      model,
      params: { 1400: "0", 1401: "50", 1403: "1" },
    });
    expect(dev.capabilities).toContain("light");
    expect(dev.properties.map((property) => property.name)).toEqual(
      expect.arrayContaining(["light", "brightness", "spotlightEnabled"]),
    );
  });

  it.each([
    ["T8425", DeviceType.FLOODLIGHT_CAMERA_8425, "json"],
    ["T8426", DeviceType.FLOODLIGHT_CAMERA_8426, "json"],
    ["T8170", DeviceType.OUTDOOR_PT_CAMERA, "int-string"],
  ] as const)("preserves resolved %s light on/off commands", async (model, deviceType, wire) => {
    const dev = Device.fromRecord("T8000P0000000000", {
      model,
      deviceType,
      params: { 1400: "0", 1401: "50", 1403: "1" },
    });
    const sent: Command[] = [];
    dev.bindActions(
      { channel: 3, codec: "camera", model, deviceType, paramIds: new Set([1400, 1401, 1403]) },
      { dispatch: async (command) => void sent.push(command) },
    );
    expect(dev.capabilities).toContain("light");
    const light = dev.light!()!;
    await light.on();
    await light.off();
    expect(sent).toEqual(
      [1, 0].map((value) =>
        wire === "json"
          ? { kind: "set-json", param: 1400, data: { time: 0, type: 2, value }, channel: 3 }
          : { kind: "set-param", param: 1400, form: "int-string", value, channel: 3 },
      ),
    );
  });

  it("excludes T8171 despite reported spotlight parameters", () => {
    const dev = Device.fromRecord("T8000P0000000000", {
      model: "T8171",
      deviceType: DeviceType.SOLO_CAMERA_E30,
      params: { 1400: "0", 1401: "50", 1403: "1" },
    });
    expect(dev.capabilities).not.toContain("light");
    for (const name of ["light", "brightness", "spotlightEnabled"]) {
      expect(dev.properties.map((property) => property.name)).not.toContain(name);
    }
    for (const param of [1400, 1401, 1403, 6080, 6082, 1413]) {
      expect(LIGHT.detection?.detect?.({ model: "T8171", params: { [param]: "0" } }, "camera")).toBe(false);
    }
  });

  it("preserves spotlight name hints without parameter evidence", () => {
    const dev = Device.fromRecord("T8000P0000000000", { model: "T8425", name: "Floodlight Cam" });
    expect(dev.capabilities).toContain("light");
  });

  describe("buildCommand — variant resolution", () => {
    it("refuses the removed type 88 spotlight switch wire", () => {
      expect(() => intent("light", true, { ...ctx(), deviceType: DeviceType.SOLO_CAMERA_E30 })).toThrow(
        /light: unknown spotlight switch wire format/,
      );
    });

    it.each([44, 45, 46, 48, 8, 9, 14, 15, 19, 23])("keeps int-string switch wire for type %i", (deviceType) => {
      expect(intent("light", true, { ...ctx(2), deviceType })).toMatchObject({
        kind: "set-param",
        param: LIGHT_CMD.FLOODLIGHT_SWITCH,
        form: "int-string",
        value: 1,
        channel: 2,
      });
    });
    it.each([
      [47, true],
      [87, true],
      [19, false],
      [31, false],
      [46, false],
    ])("late-effect read eligibility for device type %i is %s", (deviceType, eligible) => {
      const command = intent("light", true, {
        ...jsonCtx(3),
        deviceType: deviceType as number,
        paramIds: new Set([1400]),
      })!;
      expect(commandObservation(command)?.lateEffectReadback).toBe(eligible);
    });
    it("on/off on a JSON-switch family (T8425) → set-json floodlight switch", () => {
      expect(intent("on", true, jsonCtx(3))).toEqual({
        kind: "set-json",
        param: LIGHT_CMD.FLOODLIGHT_SWITCH,
        data: { time: 0, type: 2, value: 1 },
        channel: 3,
      });
      expect((intent("off", false, jsonCtx()) as Extract<Command, { kind: "set-json" }>).data).toEqual({
        time: 0,
        type: 2,
        value: 0,
      });
    });

    it.each([true, false])("T8426 emits the explicit JSON switch intent for %s", (on) => {
      const context = { ...jsonCtx(4), deviceType: 87, paramIds: new Set([1400]) };
      const command = intent("light", on, context)!;
      expect(command).toEqual({
        kind: "set-json",
        param: LIGHT_CMD.FLOODLIGHT_SWITCH,
        data: { time: 0, type: 2, value: on ? 1 : 0 },
        channel: 4,
      });
      expect(commandObservation(command)).toMatchObject({
        event: "lightChanged",
        property: "light",
        param: 1400,
        expected: on ? 1 : 0,
        observed: on,
      });
    });

    it("T8426 aliases use the same JSON intent without changing the channel", async () => {
      const { acts, sent } = bind<LightActions>("light", { ...jsonCtx(6), deviceType: 87, paramIds: new Set([1400]) });
      await acts.on();
      await acts.off();
      expect(sent).toEqual([
        { kind: "set-json", param: 1400, data: { time: 0, type: 2, value: 1 }, channel: 6 },
        { kind: "set-json", param: 1400, data: { time: 0, type: 2, value: 0 }, channel: 6 },
      ]);
      expect(sent.every((command) => commandObservation(command)?.event === "lightChanged")).toBe(true);
    });

    it("on/off on an int-string family (T8442/default) → set-param pinned to int-string (1400)", () => {
      expect(intent("on", true, ctx(2))).toEqual({
        kind: "set-param",
        param: LIGHT_CMD.FLOODLIGHT_SWITCH,
        value: 1,
        form: "int-string",
        channel: 2,
      });
      expect(intent("off", false, ctx())).toMatchObject({
        kind: "set-param",
        form: "int-string",
        value: 0,
      });
    });

    it("brightness/colorTemp/enabled → set-param pinned to direct-binary with the right param", () => {
      expect(intent("brightness", 50, ctx())).toEqual({
        kind: "set-param",
        param: LIGHT_CMD.SPOTLIGHT_BRIGHTNESS,
        value: 50,
        form: "direct-binary",
        channel: 0,
      });
      expect(intent("colorTemp", 80, ctx())).toMatchObject({
        kind: "set-param",
        param: LIGHT_CMD.SPOTLIGHT_COLOR_TEMP,
        form: "direct-binary",
        value: 80,
      });
      expect(intent("spotlightEnabled", true, ctx())).toMatchObject({
        kind: "set-param",
        param: LIGHT_CMD.SPOTLIGHT_ENABLE,
        form: "direct-binary",
        value: 1,
      });
    });

    it("rejects a brightness outside 1..100 and a color-temp outside 0..100 rather than clamping", () => {
      expect(() => intent("brightness", 0, ctx())).toThrow(
        /brightness: 0 is not a valid value \(must be in 1\.\.100\)/,
      );
      expect(() => intent("brightness", 250, ctx())).toThrow(
        /brightness: 250 is not a valid value \(must be in 1\.\.100\)/,
      );
      expect(() => intent("colorTemp", -10, ctx())).toThrow(
        /colorTemp: -10 is not a valid value \(must be in 0\.\.100\)/,
      );
      expect(() => intent("colorTemp", 999, ctx())).toThrow(
        /colorTemp: 999 is not a valid value \(must be in 0\.\.100\)/,
      );
      expect(intent("brightness", 1, ctx())).toMatchObject({ value: 1 });
      expect(intent("colorTemp", 0, ctx())).toMatchObject({ value: 0 });
    });

    it("autoSpotlight is NOT a bare bool property or a buildCommand action (composite/write-only footgun)", () => {
      // A plain toggle would re-send hardcoded defaults and clobber the user's config, so it's ONLY the
      // explicit setAutoSpotlight(on, opts) setter — buildCommand/setProperty must not accept it.
      expect(LIGHT.properties.map((p) => p.name)).not.toContain("autoSpotlight");
      expect(intent("autoSpotlight", true, jsonCtx(3))).toBeUndefined();
    });

    it("returns undefined for an unknown action", () => {
      expect(intent("totally_unknown", 1, ctx())).toBeUndefined();
    });

    it("on/off on a model NOT in either wire-format table → throws the model as the reason (don't guess)", () => {
      // A spotlight was detected but this deviceType's switch wire format is unknown → refuse
      // rather than silently send the wrong format (the silent-no-op bug). The refusal names the
      // MODEL, which a generated "not a valid value" over a boolean could never say.
      expect(() => intent("on", true, unknownCtx())).toThrow(/light: unknown spotlight switch wire format/);
      expect(() => intent("light", false, unknownCtx())).toThrow(/light: unknown spotlight switch wire format/);
    });

    it("the on()/off() verbs reject rather than throwing synchronously on such a model", async () => {
      const { acts, sent } = bind<LightActions>("light", unknownCtx());
      await expect(acts.on()).rejects.toThrow(/light: unknown spotlight switch wire format/);
      await expect(acts.off()).rejects.toThrow(/light: unknown spotlight switch wire format/);
      await expect(acts.set(true)).rejects.toThrow(/light: unknown spotlight switch wire format/);
      expect(sent).toEqual([]);
    });
  });

  describe("actions → dispatch the resolved Command through the sink", () => {
    it("on() dispatches the resolved switch command; the derived setBrightness → direct-binary", async () => {
      const { acts, sent } = bind<LightActions>("light", ctx(2)); // int-string family
      await acts.on();
      await acts.setBrightness!(40);
      expect(sent[0]).toMatchObject({
        kind: "set-param",
        param: LIGHT_CMD.FLOODLIGHT_SWITCH,
        form: "int-string",
        channel: 2,
      });
      expect(sent[1]).toMatchObject({
        kind: "set-param",
        param: LIGHT_CMD.SPOTLIGHT_BRIGHTNESS,
        form: "direct-binary",
        value: 40,
      });
    });

    it("setAutoSpotlight(on) sends the 1422 composite; opts override the carried brightness/time/mode", async () => {
      const sent: Command[] = [];
      const acts = LIGHT.actions!({
        ctx: jsonCtx(3),
        sink: { dispatch: async (c) => void sent.push(c) },
        read: () => undefined,
      });
      await acts.setAutoSpotlight!(true); // no opts → captured defaults
      expect(sent[0]).toMatchObject({
        kind: "set-payload",
        cmd: LIGHT_CMD.MOTION_ACTIVATE_LIGHT, // 1422
        channel: 3,
        mValue3: 0,
        payload: { enable: 1, brightness: 50, time: 30, mode: 1 },
      });
      await acts.setAutoSpotlight!(false, { brightness: 80, time: 120 }); // caller preserves config
      expect((sent[1] as Extract<Command, { kind: "set-payload" }>).payload).toMatchObject({
        enable: 0,
        brightness: 80,
        time: 120,
      });
    });
  });
});

/**
 * The spotlight MASTER switch is reported, so it is a read as well as a write.
 *
 * The read is what earns it a schema entry, a getter, and an announcement when its value moves. Measured
 * on a T8170: the cloud device list carries param 1403 and its value tracks the vendor app's "spotlight"
 * setting in both directions, `1 -> 0` when the setting is switched off and `0 -> 1` when it is switched
 * back on. `pollChanges` only reports a param whose PREVIOUS value differed, so the id was already in the
 * snapshot rather than newly appearing. The SDK's own param dictionary agrees, naming 1403
 * `floodlightTotalSwitch` (`app:FLOODLIGHT_TOTAL_SWITCH`) and listing the T8170 among its models.
 *
 * Distinct from `isOn` (1400), which is the momentary lighting and is bound to whichever client is
 * streaming — the vendor app lights the lamp for a live view and drops it on quitting. The master switch
 * is the SETTING a user changes and expects to stay changed, which is why it is the one a host has to be
 * told about.
 */
describe("the spotlight master switch is a read, not write-only", () => {
  const reporting = (): CommandContext => ({
    channel: 0,
    codec: "camera",
    deviceType: 46,
    paramIds: new Set([LIGHT_CMD.SPOTLIGHT_ENABLE]),
  });

  it("publishes a property for it, so a device reporting it can be read and announced", () => {
    const spec = LIGHT.properties.find((p) => p.name === "spotlightEnabled");
    expect(spec).toMatchObject({ paramType: LIGHT_CMD.SPOTLIGHT_ENABLE, type: "bool", kind: "boolean" });
    expect(spec!.writable).toBe(true);
  });

  it("installs a getter on a device that reported it, reading the polarity measured live", () => {
    const { acts } = bind<LightActions>("light", reporting(), {
      read: (name) => (name === "spotlightEnabled" ? { value: true } : undefined),
    });
    expect(acts.spotlightEnabled).toBe(true);
  });

  it("keeps its setter under the name the key would not derive", () => {
    const { acts } = bind<LightActions>("light", reporting());
    expect(typeof acts.setEnabled).toBe("function");
  });

  /**
   * `unobservableMembers` is a STATEMENT to a caller — "this is accepted and never reported back" — so
   * leaving it there would publish the very claim the measurement disproves.
   */
  it("no longer claims the device never reports it back", () => {
    const { acts } = bind<LightActions>("light", reporting());
    expect(unobservableMembers(acts as object)).not.toContain("spotlightEnabled");
  });
});

import { GuardConfirmationOwner, type GuardOperation } from "./guard-confirmation.js";
import { guardModeRequest } from "../model/capabilities/arming.js";
import { StateEvidenceOwner, type EvidenceIngress } from "./state-evidence.js";
import type { StateEvidence } from "../core/state-evidence.js";
/** Modified for genomez S1 experimental source preview, 2026-10-17. */
/**
 * eufy-sdk — one client for every eufy device class.
 *
 * Cloud APIs:  the eufy v6 cloud (+ legacy, planned)
 * Realtime:    secure MQTT (appliances)  +  P2P (cameras/HomeBases)
 *
 *   const eufy = new EufyMega({ email, password, region: "eu-pr" });
 *   await eufy.login(); // → LoginResult; on success the SDK auto-starts realtime (push/MQTT/wired P2P)
 *   eufy.on("motion", (e) => console.log(e.deviceSn)); // typed semantic events — flowing already
 *   const dev = await eufy.getDevice((await eufy.getDevices())[0].sn);
 *   await dev.camera?.()?.snapshotStored?.();
 *
 * Connectivity is SDK-managed: the host calls no `connect*`. P2P to a battery camera is opened only
 * when a command/stream/doorbell-ring needs it and closed when idle, so the camera can sleep.
 */
import { EventEmitter } from "node:events";
import { performance } from "node:perf_hooks";
import { MegaHttpClient, LoginStatus, SessionExpiredError, type LoginResult } from "../transport/http/mega-client.js";
import { SecureMqtt, isNotAuthorized, type SecureMqttCredentials } from "../transport/mqtt/secure-mqtt.js";
import { mqttAppName, mqttScopeFor, type MqttScope } from "../transport/mqtt/topics.js";
import { buildAppShapedClientId, mqttUuidFrom } from "../transport/mqtt/app-client-id.js";
import { parseStateInfoSignal } from "../transport/mqtt/availability.js";
import { parseDpMessage, parseAiotDpReport } from "../transport/mqtt/dp-codec.js";
import { parseBizMapFrame } from "../transport/mqtt/biz-stream.js";
import type { BizMapFrame } from "../transport/mqtt/biz-stream.js";
import { decodeMapFrame } from "./map-channels.js";
import { VacuumMapStore } from "../model/index.js";
import { type P2PSession, type P2PFrame } from "../transport/p2p/p2p-session.js";
import { P2PCommandRouter } from "../transport/p2p/command-router.js";
import {
  consumeRetiredInformationRead,
  consumeRenewalInformationRead,
  isRenewalInformationRead,
  markRenewalInformationRead,
} from "../transport/rtc/retired-information-read.js";
import { RtcCommandRouter } from "../transport/rtc/command-router.js";
import type { RecentPersonCropOptions, RecentPersonCropResult } from "../transport/rtc/recent-person-crops.js";
import type { StationPersonRosterOptions, StationPersonRosterResult } from "../transport/rtc/station-person-roster.js";
import {
  recordingAccountNamespace,
  type RecordingReadScope,
  type RecordingReadOptions,
  type RecordingPacing,
  type InternalCoverSelector,
  type InternalPlaybackSelector,
  type CatalogReadResult,
  type CoverReadResult,
} from "../transport/rtc/recordings.js";
import { commandOutcome, RtcCommandRejection } from "../transport/rtc/command-diagnostics.js";
import { RtcLateEffectReconciler } from "./rtc-late-effect.js";
import { RtcLateContraryObserver, type RtcReportIdentity } from "./rtc-late-contrary.js";
export type { LateContraryEffect, LateContraryConfirmation } from "./rtc-late-contrary.js";
import { CommandIntentRegistry, type CommandIntent } from "./command-intents.js";
import { CameraHealthIngress } from "./camera-health-ingress.js";
import { CommandHealthGate, type CommandHealthToken } from "./command-health.js";
export {
  COMMAND_FAST_REFUSAL_MAX_MS,
  COMMAND_FAST_REFUSAL_WINDOW_MS,
  COMMAND_FAST_REFUSAL_THRESHOLD,
  COMMAND_DEGRADED_COOLDOWN_MS,
} from "./command-health.js";
export type { CameraHealth, CameraHealthEvent } from "./camera-health.js";
export type { CommandHealthEvent } from "./command-health.js";
import type { PortalResponse } from "../transport/rtc/portal-packet.js";
import { stationOf } from "../transport/p2p/station-channels.js";
import {
  rtcCommandConfirmed,
  rtcCommandReadbackRequested,
  rtcReportParameters,
  rtcStateParameters,
} from "./rtc-state.js";
import { inspectRtcPushSignal } from "./rtc-push.js";
import { EventRoutingRecorder, type EventRoutingDiagnostics } from "./event-routing-diagnostics.js";
export type { EventRoutingDiagnostics } from "./event-routing-diagnostics.js";
import { RtcObservationRecorder, type RtcObservationDiagnostics } from "./rtc-observation-diagnostics.js";
import {
  PropertyPreparationRecorder,
  type PropertyPreparationObservation,
  type PropertyPreparationDiagnostics,
} from "./property-preparation-diagnostics.js";
export type {
  PropertyPreparationDiagnostics,
  PropertyPreparationEvidence,
  PropertyPreparationPhase,
} from "./property-preparation-diagnostics.js";
export type { RtcObservationDiagnostics } from "./rtc-observation-diagnostics.js";
import {
  emptyStateRefreshEvidence,
  stateRefreshFailure,
  type StateRefreshDiagnostics,
  type StateRefreshFailure,
  type StateRefreshTrigger,
  type StateRefreshSweepEvidence,
  type StateRefreshOperationEvidence,
} from "./state-refresh-diagnostics.js";
export type { StateRefreshDiagnostics, StateRefreshFailure } from "./state-refresh-diagnostics.js";
import { jpegGeometry } from "../transport/p2p/media.js";
import type { PowerTier } from "../transport/p2p/session-manager.js";
import { MqttCommandRouter } from "../transport/mqtt/command-router.js";
import { TuyaCommandRouter } from "../transport/tuya/command-router.js";
import { TuyaDpRouter, parseTuyaDpReport } from "../transport/tuya/dp-codec.js";
import { rawDpCodec } from "../transport/raw-dp.js";
import { resolveLightEffect as resolveLightEffectHttp } from "../transport/http/light-catalog.js";
import {
  buildCommand as buildCapabilityCommand,
  decodeEvent as decodeCapabilityEvent,
  STATE_EVENT_FIELDS,
  decodeState as decodeCapabilityState,
  buildRealtimeInit,
  hasRealtimeReads,
  needsRealtimeInit,
  hasProvidedAction,
  cameraPowerTier,
} from "../model/capabilities/index.js";
import type { DeviceEventMap } from "../model/capabilities/index.js";
import type { CommandContext } from "../model/capabilities/types.js";
import { CapabilityNotSupportedError } from "../model/capabilities/types.js";
import { type DpCatalog, EMPTY_DP_CATALOG, parseDpCatalog } from "../model/capabilities/dp-catalog.js";
import { type CleanRecordPage, EMPTY_CLEAN_RECORD_PAGE, parseCleanRecords } from "../model/clean-records.js";
import {
  commandObservation,
  LiveSnapshotUnavailableError,
  StateConvergenceError,
  type Command,
  type CommandObservation,
  type CommandExecutionContext,
  type CommandReceipt,
  type CommandSink,
  type Ff09SettingsReader,
  type MediaProvider,
  type TuyaDpInbound,
} from "../core/contracts.js";
import { noopLogger } from "../core/logger.js";
import { PushLifecycleRecorder, type PushLifecycleDiagnostics } from "../transport/push/lifecycle-diagnostics.js";
export type { PushLifecycleDiagnostics } from "../transport/push/lifecycle-diagnostics.js";
import { PushClient } from "../transport/push/push-client.js";
import { FcmRegistrar } from "../transport/push/fcm.js";
import { MemoryFcmStore } from "../transport/push/store.js";
import { ThumbnailDiagnostics } from "../transport/thumbnail-diagnostics.js";
import { StoredImageCache } from "../transport/stored-image-cache.js";
import type { PushEvent, RawPushMessage } from "../transport/push/types.js";
import { type AvailabilityObservation, type EufyDevice, type RealtimeTransport } from "../core/types.js";
import { Timer, structuralEqual } from "../core/util.js";
import {
  Device,
  resolveDevice,
  detectionName,
  type Capability,
  type DeviceInspection,
  type RawParams,
} from "../model/index.js";
import { isHomeBase } from "../model/device-family.js";
import { namespaceForCodec } from "../model/param-namespace.js";
import { DeviceRegistry, type DeviceRecord, type ParamChange } from "./device-registry.js";
import type {
  SdkErrorOrigin,
  EufyMegaOptions,
  EufyMegaEvent,
  EufyMegaEventMap,
  DeviceState,
  RealtimePlaneReadiness,
  RealtimeReadiness,
  WaitForRealtimeOptions,
  PropertyExecutionOptions,
} from "./types.js";

export type {
  SdkErrorOrigin,
  SdkErrorContext,
  EufyMegaOptions,
  EufyMegaEvent,
  EufyMegaEventMap,
  AnyDeviceEvent,
  DeviceState,
  RealtimePlaneReadiness,
  RealtimeReadiness,
  WaitForRealtimeOptions,
  PropertyExecutionOptions,
} from "./types.js";

/** Private read-binding topology retained without changing the shared command contract. */
type ReadContext = CommandContext & { stationSerial?: string };

/** Invocation ownership carried through the bound sink without changing capability setters. */
interface PropertyInvocation {
  guard?: GuardOperation;
  preparation?: PropertyPreparationObservation;
  ordinal: number;
  execution?: CommandExecutionContext;
  intent?: CommandIntent;
  receipt?: CommandReceipt;
  receiptRequested?: boolean;
  transportAttempted?: boolean;
  health?: CommandHealthToken;
}

/** Detached context from one retained roster snapshot; missing records remain cache-unknown. */
export interface CachedDeviceContext {
  readonly targetCached: boolean;
  readonly parentCached: boolean;
  readonly targetDeviceType?: number;
  readonly parentDeviceType?: number;
  readonly topology: "attached" | "self-or-unknown";
  readonly parentLink: "consistent" | "conflict" | "unknown";
  readonly rtcDevice: boolean;
  readonly rtcMedia: boolean;
}

/** Numeric family facts must be explicit positive safe integers in the retained record. */
function cachedDeviceType(device: EufyDevice | undefined): number | undefined {
  const value = (device?.raw as Record<string, unknown> | undefined)?.device_type;
  return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : undefined;
}

type SemanticEventRefresh = Pick<CommandObservation, "param" | "property" | "resetStandaloneSession" | "timeoutMs"> & {
  expected?: CommandObservation["expected"];
  observed?: CommandObservation["observed"];
};

/**
 * Read a non-empty string field off a raw device record, tolerating the app's `deviceParams` nesting
 * (the v6 app resolves e.g. firmware as `record.deviceParams?.main_sw_version ?? record.main_sw_version`).
 * Returns `undefined` for a missing or empty value, so a blank firmware never surfaces as `""`.
 */
function recordString(raw: Record<string, unknown>, key: string): string | undefined {
  const nested = (raw.deviceParams as Record<string, unknown> | undefined)?.[key];
  const v = typeof nested === "string" && nested ? nested : raw[key];
  return typeof v === "string" && v ? v : undefined;
}

/** Cache ownership is independent of an ordinary RTC session replacement. Never serialize token. */
export interface StorageTelemetryOwner {
  readonly token: object;
  readonly model: "T9000";
  readonly firmware: "4.4.0.4" | "4.4.1.4";
}

/**
 * Extract the Tuya device id from a `eufy_home_tuya` device's raw cloud record.
 * The cloud `get_devs_list` response embeds the Tuya id under one of several field names
 * (naming varied across firmware generations). Returns the first non-empty string found.
 */
function tuyaDevIdFrom(raw: Record<string, unknown>): string | undefined {
  for (const field of ["tuya_uuid", "tuya_virtual_id", "tuya_device_id", "virtualId"]) {
    const v = recordString(raw, field);
    if (v) return v;
  }
  return undefined;
}

/**
 * Default cloud-param poll interval (10 min) — paced to the cloud's own refresh rate rather than to a
 * host's refresh appetite. Rationale and the measurements behind the number are on
 * {@link EufyMegaOptions.pollMs}, the knob that overrides it (`0` disables the loop).
 */
const DEFAULT_POLL_MS = 600_000;

/**
 * Power tiers a speculative pre-warm may open a station on, when the caller states none. Both, because
 * the opt-in that turns pre-warm on at all is {@link EufyMegaOptions.prewarmEvents}: a caller who listed
 * an event asked for its session, and silently skipping the only tier a pre-warm can actually open would
 * make that opt-in do nothing. {@link EufyMegaOptions.prewarmTiers} narrows it.
 */
const DEFAULT_PREWARM_TIERS: readonly PowerTier[] = ["wired", "battery"];

/**
 * How long a write waits for the session recycle it asked for before letting go of the wait.
 *
 * A recycle that nothing is holding completes in the time one session teardown takes, so this bound is
 * never reached in the ordinary case. It exists for the case where a viewer is attached: the recycle
 * then waits for that viewer to detach, which may be minutes or never, and the wait is what a following
 * write to the same member queues behind. Letting go does not cancel the recycle.
 */
const SESSION_RECYCLE_WAIT_MS = 5_000;

interface StateRefreshResult {
  refreshed: boolean;
  retiredSession: boolean;
}

const STATE_REFRESH_PLAYBACK_DEFER_MS = 5_000;
const STATE_REFRESH_PLAYBACK_DEFERRALS = 12;

interface RealtimeGeneration {
  readonly epoch: number;
  readonly readiness: MutableRealtimeReadiness;
  readonly promise: Promise<RealtimeReadiness>;
  readonly resolve: (readiness: RealtimeReadiness) => void;
  readonly abort: AbortController;
  result?: RealtimeReadiness;
  superseded?: RealtimeReadiness;
  settled: boolean;
  stateRefreshFailures?: number;
  stateRefreshDeferrals?: { retryAttempt: number; count: number };
  /** Consecutive scheduled reads held back by an active stored-playback capture. */
  stateRefreshPlaybackDeferrals?: number;
}

class RealtimeStartupSupersededError extends Error {}

/**
 * The convergence window closed while waiting on a dependency, rather than the dependency failing.
 *
 * Distinguishing the two is what lets {@link EufyMega.refreshEventState} answer a write that was never applied
 * with the member it was waiting for: without it the last poll's own deadline escapes first, and the caller is
 * told only that something timed out somewhere.
 */
class RefreshWindowClosedError extends Error {}

interface MutableRealtimePlaneReadiness {
  required: number;
  ready: number;
  failed: number;
  pending: number;
}

interface MutableRealtimeReadiness {
  state: RealtimeReadiness["state"];
  push: MutableRealtimePlaneReadiness;
  mqtt: MutableRealtimePlaneReadiness;
  wiredP2p: MutableRealtimePlaneReadiness;
}

function createPlaneReadiness(required = 0): MutableRealtimePlaneReadiness {
  return { required, ready: 0, failed: 0, pending: required };
}

function readinessSnapshot(
  readiness: RealtimeReadiness | MutableRealtimeReadiness,
  state = readiness.state,
): RealtimeReadiness {
  return Object.freeze({
    state,
    push: Object.freeze({ ...readiness.push }),
    mqtt: Object.freeze({ ...readiness.mqtt }),
    wiredP2p: Object.freeze({ ...readiness.wiredP2p }),
  });
}

// Typed EventEmitter surface: declaration-merge strongly-typed on/once/off/emit onto the class so
// `eufy.on("motion", e => …)` autocompletes the name and types the payload, while the runtime is
// still the untyped node EventEmitter. Only these overloads are visible to consumers.
export interface EufyMega {
  on<E extends EufyMegaEvent>(event: E, listener: (...args: EufyMegaEventMap[E]) => void): this;
  once<E extends EufyMegaEvent>(event: E, listener: (...args: EufyMegaEventMap[E]) => void): this;
  off<E extends EufyMegaEvent>(event: E, listener: (...args: EufyMegaEventMap[E]) => void): this;
  emit<E extends EufyMegaEvent>(event: E, ...args: EufyMegaEventMap[E]): boolean;
}

/**
 * The package entry point — one client per Anker eufy account. Handles the {@link login} state machine
 * (captcha/2FA/persistence), resolves the account's devices ({@link getDevices}/{@link getDevice}
 * → capability-driven {@link Device}s), **auto-manages** the realtime channels (FCM push + secure MQTT
 * start on login; P2P opens on demand per station and idle-detaches battery cameras), and fans every
 * transport's traffic into one typed semantic event stream (`eufy.on("motion", …)`). Construct it with
 * an {@link EufyMegaOptions} (email/password + optional session/push stores), then drive `login()` to
 * completion — no `connect*` call needed (set `autoRealtime:false` to opt out). Call {@link disconnect}
 * to tear the realtime channels down.
 */
export class EufyMega extends EventEmitter {
  private readonly opts: EufyMegaOptions;
  private readonly mega: MegaHttpClient;
  /**
   * The installed secure-MQTT transports, one per credential scope.
   *
   * There is more than one because `get_user_mqtt_info` issues a DIFFERENT certificate per `app-name`
   * and the broker's policy grants each line's topic space to its own cert — a `eufy_life` light's
   * topics are silently denied to the default credential. A device's
   * scope is a pure function of its record, so the set of live connections follows the roster with no
   * extra state to keep in sync, and a scope with no devices is never connected.
   */
  private readonly transports = new Map<MqttScope, RealtimeTransport>();
  /** Shared in-flight/settled `startMqtt()` promise PER SCOPE — so realtime bring-up and an on-demand
   * publish await the SAME fully-connected transport instead of racing (and never open two). */
  private readonly mqttReady = new Map<MqttScope, Promise<void>>();
  /** Device list/record/capability resolution + the frame→caps cache. */
  private readonly registry: DeviceRegistry;
  private pushClient?: PushClient;
  private readonly pushLifecycle = new PushLifecycleRecorder();
  /** Push-fed passive image store; absent when the caller disables acquisition. */
  private readonly storedImages?: StoredImageCache;
  private readonly thumbnailEvidence = new ThumbnailDiagnostics();
  /** Account whose retained images are currently held. */
  private storedImageAccount?: string;
  /**
   * Which bring-up generation is current. Bumped by every {@link disconnect}, so an in-flight
   * {@link ensureRealtime} can tell on completion whether it is still the live one.
   *
   * The bring-up is fire-and-forget, so a caller that disconnects while it is still running would
   * otherwise leave behind whatever opened after teardown had already passed. A single "closing" flag
   * is not enough: `disconnect()` followed by `login()` clears it, and the stale bring-up then finishes,
   * sees nothing amiss, and overwrites the live channels with its own — stranding the sockets it was
   * meant to release. Comparing generations makes each bring-up responsible for exactly its own epoch.
   */
  private realtimeEpoch = 0;
  private inventoryScopeKey?: string;
  private inventoryScope: Readonly<{ epoch: number }> = Object.freeze({ epoch: 0 });
  private storageTelemetryOwners = new Map<string, { fields: readonly unknown[]; owner: StorageTelemetryOwner }>();
  private readonly firmwareVersions = new Map<string, string | undefined>();
  private storageTelemetryReads = new Map<string, Set<AbortController>>();
  /** Shared startup state for the current epoch; caller timeouts never replace or cancel it. */
  private realtimeGeneration?: RealtimeGeneration;
  /**
   * Devices already handed to a caller, so a realtime report refreshes the object they are holding
   * rather than only the registry. Weak so a caller dropping a `Device` still lets it be collected —
   * this map must never be what keeps one alive.
   */
  private readonly liveDevices = new Map<string, WeakRef<Device>>();
  /** Every returned model's parent projection, including older references for the same serial. */
  private readonly stationContextDevices = new Set<WeakRef<Device>>();
  /** Serialized state-transition transactions keyed by device and reflected member. */
  private readonly stateTransitions = new Map<string, Promise<unknown>>();
  /** Local writes already awaiting the same semantic transition, counted per reflected member. */
  private readonly commandRefreshes = new Map<string, { epoch: number; count: number }>();
  /**
   * The param ids each bound device's read getters were built from — the evidence the gate saw at bind
   * time. Compared against an incoming report to notice when one carries an id the getters do not cover
   * yet, which is the signal to rebuild them (see {@link rebindReads}).
   */
  private readonly boundParamIds = new Map<string, ReadonlySet<number>>();
  /** Cloud presence and report/write-observation precedence are evidence IDs, never retained raw values. */
  private readonly cloudParamIds = new WeakMap<Device, ReadonlySet<number>>();
  private readonly guardReads = new WeakMap<GuardOperation, Promise<void>>();
  private readonly guardReconnects = new WeakSet<GuardOperation>();
  private guardConfirmation = new GuardConfirmationOwner(
    (receipt) => this.emit("guardConfirmation", receipt),
    (op) => void this.refreshGuardState(op, "confirmation"),
  );
  private guardScope = "";
  private guardOwner(): GuardConfirmationOwner {
    const scope = JSON.stringify([this.realtimeEpoch, this.mega.auth?.userId ?? null]);
    if (scope !== this.guardScope) {
      this.guardScope = scope;
      this.guardConfirmation.close();
      this.guardConfirmation = new GuardConfirmationOwner(
        (receipt) => this.emit("guardConfirmation", receipt),
        (op) => void this.refreshGuardState(op, "confirmation"),
      );
      this.emit("guardRuntime", { version: 1, runtimeGeneration: this.guardConfirmation.runtimeGeneration });
    }
    return this.guardConfirmation;
  }

  /** A replacement session can report within the original send-relative window without another write. */
  private refreshPendingGuardState(station: string): void {
    for (const op of this.guardOwner().pendingStation(station)) {
      if (!op.sessionChanged || !this.guardOwner().current(op)) continue;
      void this.refreshGuardState(op);
    }
  }

  /** Coalesced session recovery and one confirming read share the original report deadline. */
  private refreshGuardState(op: GuardOperation, afterCurrent?: "confirmation" | "recovery"): Promise<void> {
    const previous = this.guardReads.get(op);
    if (previous)
      return afterCurrent
        ? previous.then(() => {
            if (
              afterCurrent === "recovery" ||
              (op.lastObservedMode !== undefined && op.lastObservedMode !== op.receipt.requestedMode)
            )
              return this.refreshGuardState(op, afterCurrent);
          })
        : previous;
    const completion = Promise.withResolvers<void>();
    const read = completion.promise
      .catch(() => {})
      .finally(() => {
        if (this.guardReads.get(op) === read) this.guardReads.delete(op);
      });
    this.guardReads.set(op, read);
    const start = async () => {
      if (!this.guardOwner().current(op)) return;
      const now = performance.now();
      const timeoutMs = Math.floor(Math.min(15_000, op.deadline - now, op.dispatchAt! + 20_000 - now));
      if (timeoutMs <= 0) return;
      if (afterCurrent === "confirmation") {
        const result = await this.rtc.refreshInformation(op.station, { timeoutMs });
        if (!this.guardOwner().current(op) || !this.rtc.informationResultCurrent(op.station, result)) return;
        const raw = rtcStateParameters(op.station, result.frame, this.registry).get(op.receipt.deviceSn)?.[op.param];
        if (typeof raw === "string" && /^[0-9]+$/.test(raw) && guardModeRequest(raw))
          op.confirmationReadMode = Number(raw);
      } else await this.refreshDeviceState(op.receipt.deviceSn, { timeoutMs });
    };
    const started = afterCurrent === "confirmation" ? start() : Promise.resolve().then(start);
    void started.then(completion.resolve, completion.reject);
    return read;
  }

  /** One automatic reconnect read per pending attempt; failed reconnects cannot loop or renew the window. */
  private recoverPendingGuardState(station: string): void {
    for (const op of this.guardOwner().pendingStation(station)) {
      if (this.guardReconnects.has(op)) continue;
      this.guardReconnects.add(op);
      void this.refreshGuardState(op, "recovery");
    }
  }

  /** Authoritative current guard runtime; replacement is advertised before its first receipt. */
  getGuardConfirmationScope(): { version: 1; runtimeGeneration: string } {
    return { version: 1, runtimeGeneration: this.guardOwner().runtimeGeneration };
  }
  private shadowEvidence = new StateEvidenceOwner();
  private shadowEvidenceScope = "";
  private shadowFailures = 0;

  /** Shadow provenance is scoped separately from inventory revisions and contains no account identity. */
  private evidenceOwner(): StateEvidenceOwner {
    const scope = JSON.stringify([this.realtimeEpoch, this.mega.auth?.userId ?? null]);
    if (scope !== this.shadowEvidenceScope) {
      this.shadowEvidenceScope = scope;
      this.shadowEvidence = new StateEvidenceOwner();
      this.shadowFailures = 0;
    }
    return this.shadowEvidence;
  }

  /** Detached cached evidence; never reads the network or refreshes a model. */
  getStateEvidence(sn: string): Record<string, StateEvidence> {
    const dev = this.liveDevices.get(sn)?.deref();
    return dev ? (this.runShadow(() => this.projectStateEvidence(dev)) ?? {}) : {};
  }

  /** Opaque current runtime for evidence scope validation. */
  getStateEvidenceScope(): { runtimeGeneration: string } {
    return { runtimeGeneration: this.evidenceOwner().runtimeGeneration };
  }

  /** Privacy-safe bounded shadow counters and decisions for offline comparison. */
  getStateEvidenceDiagnostics() {
    const owner = this.evidenceOwner();
    return { ...owner.diagnostics(), failures: this.shadowFailures };
  }

  /** Shadow failures retain only a saturating count, never exception text or target identity. */
  private runShadow<T>(work: () => T): T | undefined {
    try {
      return work();
    } catch {
      this.shadowFailures = Math.min(Number.MAX_SAFE_INTEGER, this.shadowFailures + 1);
      return undefined;
    }
  }

  /** Execute only after the enclosing legacy work, without awaits, timers or retries. */
  private finishShadow(work: readonly (() => void)[]): void {
    for (const task of work) this.runShadow(task);
  }

  private projectStateEvidence(device: Device, params?: RawParams): Record<string, StateEvidence> {
    const owner = this.evidenceOwner();
    return Object.fromEntries(
      (device.observedPropertyParameters?.(params) ?? []).flatMap(({ property, paramType, value }) => {
        const evidence = owner.project(device.sn, paramType, property, value);
        return evidence ? [[property, evidence]] : [];
      }),
    );
  }

  private recordStateEvidence(sn: string, params: RawParams, ingress: EvidenceIngress, onlyMissing = false): void {
    if (typeof sn !== "string" || !sn) return;
    const owner = this.evidenceOwner();
    for (const [id, value] of Object.entries(params))
      if (!onlyMissing || !owner.matches(sn, Number(id), String(value)))
        owner.record(
          sn,
          Number(id),
          String(value),
          ["legacy_unknown", "snapshot", "cloud_poll"].includes(ingress.source)
            ? (owner.cachedIngress(sn, Number(id), String(value)) ?? ingress)
            : ingress,
        );
  }

  private shadowDispatched(sn: string, cmd: Command, sentAtMonotonicMs: number): void {
    this.runShadow(() => {
      const observation = commandObservation(cmd);
      if (observation)
        this.evidenceOwner().dispatched(
          sn,
          observation.param,
          observation.expected,
          sentAtMonotonicMs,
          observation.property,
          this.rtc.getSessionScope(sn),
        );
    });
  }

  private readonly realtimeParamIds = new WeakMap<Device, Map<number, number>>();
  /** Scoped report revisions survive model replacement without retaining parameter values. */
  private readonly deviceParamRevisions = new Map<string, Map<number, number>>();
  private deviceParamRevisionScope?: string;
  private realtimeReportRevision = 0;
  /** A cached reconciliation supersedes the context of an older asynchronous read adoption. */
  private readonly polledReads = new WeakMap<Device, symbol>();
  private readonly readContexts = new WeakMap<Device, ReadContext>();
  /** Per-SKU DP catalog cache — keyed on model/T-code, fetched lazily via `get_product_data_point`. */
  private readonly dpCatalogCache = new Map<string, DpCatalog>();
  /** Semantic event names that speculatively pre-warm P2P (resolved once from the options; empty = off). */
  private readonly prewarmEvents: ReadonlySet<string>;
  /** Station power tiers a pre-warm may open (resolved once from the options). */
  private readonly prewarmTiers: ReadonlySet<PowerTier>;
  /** Transport-side owner of the P2P sessions + all wire senders. */
  private readonly p2p: P2PCommandRouter;
  private readonly rtc: RtcCommandRouter;
  /** Transport-side owner of the secure-MQTT ff09 lock/garage command path (sibling of {@link p2p}). */
  private readonly mqtt: MqttCommandRouter;
  /** Transport-side owner of the legacy Tuya REST command path for non-AIoT vacuums (G-series). */
  private readonly tuya: TuyaCommandRouter;

  private readonly tuyaDpRouter: TuyaDpRouter;
  /**
   * Last state value announced per `deviceSn:event`, for the edge-trigger in {@link isRepeatState}.
   * Realtime-only: the poll path deliberately bypasses it so an unchanged state is still re-asserted.
   */
  private readonly lastStateAnnounced = new Map<string, unknown>();
  /** Latest authoritative availability observation per device; no heuristic path writes this map. */
  private readonly availabilityObservations = new Map<string, AvailabilityObservation>();
  /**
   * One map per clean-line device, assembled from the pieces its `biz/…/res` frames carry.
   *
   * Created on the first frame that decodes rather than per device: a store for a robot that has never
   * sent a map would answer `undefined` to everything, so allocating one buys nothing.
   */
  private readonly mapStores = new Map<string, VacuumMapStore>();
  /** Re-armed after each cloud-param poll; cancelled by {@link disconnect}. */
  private readonly pollTimer = new Timer();
  private cloudPollSchedule?: { epoch: number; scheduledAtMs: number | null; nextDueAtMs: number | null };
  private cloudPollInFlight = 0;
  /** Optional station-state schedule, independent of the cloud polling timer. */
  private readonly stateRefreshTimer = new Timer();
  private readonly commandIntents = new CommandIntentRegistry();
  private readonly propertyPreparations = new Set<AbortController>();
  private readonly cameraHealthIngress: CameraHealthIngress;
  private readonly commandHealth = new CommandHealthGate((event) => {
    if (event.status === "command_degraded") this.lateEffects.suppressAutomatic(event.device, event.property);
    this.emit("commandHealth", event);
  });
  private readonly lateEffects = new RtcLateEffectReconciler({
    intents: this.commandIntents,
    canRead: (station) => this.automaticInformationAllowed() && this.rtc.informationRefreshReady(station, true),
    read: (station, signal, timeoutMs, options) => this.readLateEffect(station, signal, timeoutMs, options),
    retry: async (request) => {
      const property = commandObservation(request.command)?.property;
      const parent = property === undefined ? undefined : this.commandHealthParents.get(request.intent);
      const health = parent ? this.commandHealth.child(parent) : undefined;
      if (parent && !health) return { status: "cancelled_before_send", sendAttempted: false };
      try {
        return await this.rtc.dispatchCommandWithReceipt(request.device, request.command, {
          execution: {
            profile: "bounded-state-v1",
            bornAtMs: request.originalSentAtMonotonicMs,
            sendByMs: request.sendByMonotonicMs,
            totalByMs: request.totalByMonotonicMs,
            wallExpiresAtMs: request.wallExpiresAtMs,
            wallOffsetMs: request.wallOffsetMs,
            clockUncertaintyMs: request.clockUncertaintyMs,
            signal: health ? AbortSignal.any([request.signal, health.controller.signal]) : request.signal,
            replacementKey: request.intent.replacementKey,
            intent: request.intent.ordinal,
            isCurrent: request.isCurrent,
            origin: "retry",
            parentAttempt: request.parentAttempt,
            preparationWaitMs: 0,
            authorizingRead: request.authorizingRead,
            originalSentAtMonotonicMs: request.originalSentAtMonotonicMs,
            readStartedAgeMs: request.readStartedAgeMs,
            readFinishedAgeMs: request.readFinishedAgeMs,
          },
          onSent: () => {
            if (health) health.sent = true;
            request.onSent();
          },
          onResponse: (receipt) => this.commandHealth.response(health, receipt),
        });
      } finally {
        this.commandHealth.release(health);
      }
    },
    event: (event) => this.emit("rtcLateEffect", event),
    recoverySettled: (device, intent) => this.lateContrary.recoverySettled(device, intent),
  });
  private readonly commandHealthParents = new WeakMap<CommandIntent, CommandHealthToken>();
  private readonly lateContrary = new RtcLateContraryObserver({
    intents: this.commandIntents,
    canRead: (station, resumeSession) =>
      this.automaticInformationAllowed() && (resumeSession || this.rtc.informationRefreshReady(station, true)),
    read: (station, signal, timeoutMs, options) => this.readLateEffect(station, signal, timeoutMs, options),
    recoveryBusy: (device, intent) => this.lateEffects.recoveryBusy(device, intent),
    event: (event) => this.emit("lateContraryEffect", event),
  });
  private readonly reportRefreshes = new Map<
    string,
    {
      timer?: ReturnType<typeof setTimeout>;
      promise?: ReturnType<EufyMega["refreshDeviceState"]>;
    }
  >();
  /** One station-state sweep shared by startup and polling within a realtime generation. */
  private stateRefreshSweep?: {
    epoch: number;
    promise: Promise<StateRefreshResult>;
    evidence: StateRefreshSweepEvidence;
  };
  /** Successful observations and finite failures in the current realtime generation. */
  private stateRefreshEvidence = emptyStateRefreshEvidence();
  /** Current timer ownership and bounded retry evidence. */
  private stateRefreshSchedule?: {
    generation: RealtimeGeneration;
    nextRetryAtMs: number | null;
    reason: StateRefreshDiagnostics["retryReason"];
  };
  /** Teardown invalidates unfinished scheduled work even when the realtime epoch is retained. */
  private stateRefreshLifecycle = 0;
  private eventRoutingRecorder = new EventRoutingRecorder();
  private rtcObservationRecorder = new RtcObservationRecorder();
  private readonly propertyPreparationRecorder = new PropertyPreparationRecorder();
  /** Active post-command information reads, cancelled when the realtime epoch ends. */
  private readonly observationReads = new Set<AbortController>();

  constructor(opts: EufyMegaOptions) {
    super();
    const stateRefreshMs = opts.rtc?.stateRefreshMs ?? 0;
    if (
      !Number.isSafeInteger(stateRefreshMs) ||
      (stateRefreshMs !== 0 && (stateRefreshMs < 30_000 || stateRefreshMs > 600_000))
    )
      throw new RangeError(
        "RTC state refresh interval must be zero or an integer between 30000 and 600000 milliseconds",
      );
    this.opts = opts;
    this.prewarmEvents = new Set(opts.prewarmEvents ?? []);
    this.prewarmTiers = new Set(opts.prewarmTiers ?? DEFAULT_PREWARM_TIERS);
    this.mega = new MegaHttpClient(opts);
    if (opts.storedSnapshotCache !== false) {
      this.storedImages = new StoredImageCache(
        async (url, deviceKey) => {
          const devices = this.registry.list();
          const device = devices.find((entry) => entry.sn === deviceKey);
          const stationKey = device?.stationSn || device?.sn;
          const p2pDid = devices.find((entry) => entry.sn === stationKey)?.p2pDid;
          return this.mega.downloadImage(url, p2pDid);
        },
        opts.logger ?? noopLogger,
        Date.now,
        (error) => error instanceof SessionExpiredError,
        this.thumbnailEvidence,
      );
    }
    this.registry = new DeviceRegistry({
      mega: this.mega,
      accountIdentity: () => this.mega.auth?.userId,
      onRoster: () => {
        this.reconcileStationContexts();
        this.cameraHealthIngress?.roster(this.registry.list());
        this.reconcileFirmwareVersions();
      },
      onCloudEvidence: (sn, params, times, receivedAtMs) =>
        this.runShadow(() => this.evidenceOwner().captureCloud(sn, params, times, receivedAtMs)),
      onCloudParams: (sn, params) => this.cameraHealthIngress?.params(sn, params, "cloud_params"),
      onError: (e, inventoryError) => this.reportError(e, "device_registry", inventoryError),
      logger: opts.logger,
    });
    this.cameraHealthIngress = new CameraHealthIngress(opts.email, this.registry, (event) => {
      try {
        this.emit("cameraHealth", event);
      } catch {}
    });
    this.p2p = new P2PCommandRouter({
      mega: this.mega,
      logger: opts.logger,
      ffmpegLogLevel: opts.ffmpegLogLevel,
      ffmpegPath: opts.ffmpegPath,
      poweredFor: (parentSn) => this.stationPower(parentSn),
      sessionIdle: { batteryIdleMs: opts.p2pIdleMs },
      localAddresses: opts.localAddresses,
      noBroadcast: opts.noBroadcast,
      listDevices: () => this.registry.list(),
      ensureDevices: async () => {
        await this.registry.getDevices();
        this.reconcileStorageTelemetryOwners();
      },
      onConnect: (sn) => {
        this.cameraHealthIngress.parent(sn, "connected", "p2p");
        this.emit("p2pConnect", sn);
      },
      onClose: (sn) => {
        this.guardOwner().closeStation(sn);
        this.cameraHealthIngress.parent(sn, "disconnected", "p2p");
        this.emit("p2pClose", sn);
      },
      observeLiveMedia: (sn) => this.cameraHealthIngress.live(sn),
      observeCommand: (sn) => this.cameraHealthIngress.command(sn),
      onError: (e) => this.reportError(e, "p2p"),
      onLevel2Ready: (sn, cipherId) => this.emit("p2pLevel2Ready", { stationSn: sn, cipherId }),
      onFrame: (stationSn, f) => this.onP2PFrame(stationSn, f),
    });
    this.rtc = new RtcCommandRouter({
      recordings: opts.rtc?.recordings,
      recordingsAllowed: (scope) => this.recordingsAllowed(scope),
      recordingsTopology: () => this.getInventoryScope(),
      identity: () => this.mega.rtcIdentity(),
      shard: () => this.mega.rtcShard,
      country: opts.countryCode,
      accountName: () => this.mega.accountName,
      findDevice: (sn) => this.registry.list().find((d) => d.sn === sn),
      logger: opts.logger,
      icePolicy: opts.rtc?.icePolicy,
      icePolicyAtSessionCreation: opts.rtc?.icePolicyAtSessionCreation,
      ackTimeoutMs: opts.rtc?.ackTimeoutMs,
      commandAckTimeoutMs: opts.rtc?.commandAckTimeoutMs,
      commandTimeoutMs: opts.rtc?.commandTimeoutMs,
      connectTimeoutMs: opts.rtc?.connectTimeoutMs,
      idleCloseMs: opts.rtc?.idleCloseMs,
      sessionRefreshMs: opts.rtc?.sessionRefreshMs,
      recordingTimeZone: opts.rtc?.recordingTimeZone,
      commandKeepaliveMs: opts.rtc?.commandKeepaliveMs,
      maxCallRetries: opts.rtc?.maxCallRetries,
      onFrame: (stationSn, frame, identity) => this.onRtcFrame(stationSn, frame, identity),
      observeCommand: (sn) => this.cameraHealthIngress.command(sn),
      onTransport: (sn, state) => this.cameraHealthIngress.parent(sn, state, "rtc"),
      observeLiveMedia: (sn) => this.cameraHealthIngress.live(sn),
      onSessionReplaced: (stationSn) => {
        this.lateContrary.closeStation(stationSn);
        this.guardOwner().closeStation(stationSn);
        this.refreshPendingGuardState(stationSn);
      },
      onSessionConnected: (stationSn) => this.refreshPendingGuardState(stationSn),
      onSessionClosed: (stationSn) => {
        this.guardOwner().closeStation(stationSn);
        this.lateContrary.closeStation(stationSn);
        this.lateEffects.closeStation(stationSn);
        this.recoverPendingGuardState(stationSn);
      },
      requestsCommandReadback: (stationSn, deviceSn, command, frame) =>
        rtcCommandReadbackRequested(stationSn, deviceSn, command, frame, this.registry),
      confirmsCommand: (stationSn, deviceSn, command, frame) =>
        rtcCommandConfirmed(stationSn, deviceSn, command, frame, this.registry),
      ffmpegPath: opts.ffmpegPath,
      ffmpegLogLevel: opts.ffmpegLogLevel,
      onError: (e) => this.reportError(e, "rtc_session"),
    });
    this.commandIntents.subscribe((_previous, current) => {
      if (current) this.rtc.preemptRecordingReads(current.station);
    });
    this.mqtt = new MqttCommandRouter({
      mega: this.mega,
      logger: opts.logger,
      listDevices: () => this.registry.list(),
      ensureDevices: async () => {
        await this.registry.getDevices();
        this.reconcileStorageTelemetryOwners();
      },
      onCommandAck: (info) => this.emit("commandAck", info as EufyMegaEventMap["commandAck"][0]),
      onError: (e) => this.reportError(e, "mqtt"),
      // The `a2` account id an `eufy_life` DP frame embeds — the owning member's `admin_user_id`,
      // falling back to the logged-in account's user id (the confirmed script path does the same).
      resolveAccountId: (dev) => {
        const member = ((dev.raw ?? {}) as Record<string, unknown>).member as Record<string, unknown> | undefined;
        const adminId = member?.admin_user_id;
        if (typeof adminId === "string" && adminId) return adminId;
        return this.mega.auth?.userId ?? "";
      },
      // Fetch + parse a gallery effect from the HTTP catalogue into the serializable spec. The catalogue
      // lives in the http layer (transport/http/light-catalog); the mqtt router owns the frame bytes.
      resolvePreset: (presetId) => resolveLightEffectHttp(this.mega, presetId),
      /**
       * Publish over the persistent transport for THIS device's credential scope — one connection per
       * product line carrying both legs, as the app does. CONFIRMED live (2026-07-28) that the
       * `eufy_life` credential grants the command leg as well as the reports.
       *
       * Uses an already-installed transport directly rather than awaiting the bring-up memo, because
       * the path is re-entrant: bringing a scope up subscribes its devices and sends their
       * realtime-init commands, which publish back through here on that same scope. Awaiting the memo
       * would have that publish wait on the bring-up waiting on it. The transport is installed before
       * subscribing begins and publishing needs no subscription, so the direct path is safe.
       */
      publishSecure: async (dev, topic, body) => {
        const scope = mqttScopeFor(dev);
        if (!this.transports.has(scope)) await this.ensureMqttStarted(scope);
        const transport = this.transports.get(scope);
        if (!transport) throw new Error(`secure-MQTT transport not connected for scope "${scope}"`);
        await transport.publish(topic, body, { qos: 1 });
      },
    });
    this.tuya = new TuyaCommandRouter({ allowUnverified: this.opts.tuyaAllowUnverified });
    this.tuyaDpRouter = new TuyaDpRouter();
    this.tuyaDpRouter.setListener(this.makeTuyaDpInbound());
  }

  /**
   * Builds the inbound listener that converts ThingClips DP maps to realtime capability state.
   * DP values arrive as booleans, numbers, or strings; they are normalised to the string form
   * the param store uses, then applied through the standard realtime-report path.
   */
  private makeTuyaDpInbound(): TuyaDpInbound {
    return {
      onDps: (sn, dps) => {
        const dpParams: Record<number, string> = {};
        for (const [id, value] of Object.entries(dps)) {
          dpParams[Number(id)] = typeof value === "boolean" ? (value ? "1" : "0") : String(value);
        }
        if (!Object.keys(dpParams).length) return;
        const caps = this.capsForEvent(sn);
        const signal = { source: "mqtt" as const, deviceSn: sn, topic: "", raw: {}, dpParams };
        this.applyRealtimeReport(sn, decodeCapabilityState(signal, caps));
      },
    };
  }

  /**
   * Reports what became of a command already acknowledged to its caller.
   *
   * A write whose declared observation never converged is not a fault of this client, so it does not reach
   * the generic error bus: it is the answer to a question `dispatch` deliberately does not wait for, and it
   * gets its own channel for exactly the reason `commandAck` has one. Anything else that goes wrong after
   * the acknowledgement is a genuine fault and is reported as one.
   */
  private reportUnacknowledged(e: unknown): void {
    if (e instanceof StateConvergenceError) {
      this.emit("commandUnconfirmed", {
        sn: e.sn,
        property: e.property,
        param: e.param,
        expected: e.expected,
        observed: e.observed,
        timeoutMs: e.timeoutMs,
      });
      return;
    }
    this.reportError(e, "command_execution");
  }

  /**
   * Route an internal error to the host, without being able to kill it.
   *
   * A {@link SessionExpiredError} — a kicked/expired token, the transport having already cleared the
   * session — is emitted as the dedicated `sessionExpired` event; it is NOT also sent to `error`. Every
   * other error goes to `error`.
   *
   * Either way it falls back to a logged warning when nothing listens, because `error` on an
   * `EventEmitter` THROWS when it has no listener, and most of these failures reach us from a
   * fire-and-forget path (a transport callback, an un-awaited re-bind) where that throw would land as an
   * unhandled rejection and abort the process.
   *
   * Only reported-error paths reach here — an error thrown straight out of a direct call is the caller's
   * to handle.
   */
  private reportError(
    e: unknown,
    origin: SdkErrorOrigin,
    inventoryError?: import("./inventory-evidence.js").InventoryError,
  ): void {
    const err = e instanceof Error ? e : new Error(String(e));
    if (err instanceof SessionExpiredError) {
      if (this.listenerCount("sessionExpired")) this.emit("sessionExpired", err);
      else this.opts.logger?.warn?.(`[eufy] ${err.message}`);
      return;
    }
    if (this.listenerCount("error")) this.emit("error", err, { origin, ...(inventoryError ? { inventoryError } : {}) });
    else this.opts.logger?.warn?.(`[eufy] ${err.message}`);
  }

  /**
   * The single entry point that installs the persistent secure-MQTT transport for one credential
   * scope — used by BOTH the auto-realtime bring-up ({@link ensureRealtime}) and an on-demand light-DP
   * publish (the router's `publishSecure`, wired in the constructor). Memoised per scope on
   * {@link mqttReady} so the two can't race into two connections: whoever calls first starts it, the
   * other awaits the same promise. Resolves only once {@link startMqtt} has `connect()`-ed, the
   * transport is installed, and every device on that scope is subscribed — so a publish that awaits it
   * always hits a live, subscribed client (never the silent no-op of firing into an unconnected
   * transport). Epoch-guarded: if a {@link disconnect} lands mid bring-up, the freshly-connected
   * transport is torn down instead of stranded. On failure the memo is cleared so a later call retries
   * — but only if it is still THIS attempt's memo: a `disconnect()` clears the map and a later call can
   * install a second bring-up, so an abandoned attempt that rejects afterwards must not wipe its
   * successor (that would let two `connect()`s run concurrently and strand whichever installed first,
   * still subscribed and double-emitting).
   */
  private ensureMqttStarted(scope: MqttScope, epoch = this.realtimeEpoch): Promise<void> {
    const existing = this.mqttReady.get(scope);
    if (existing) return existing;
    const attempt: Promise<void> = (async () => {
      const mqtt = await this.startMqtt(scope);
      if (epoch !== this.realtimeEpoch) {
        await mqtt.disconnect();
        return;
      }
      this.transports.set(scope, mqtt);
      await this.subscribeMqttDevices(scope, mqtt);
    })().catch((e) => {
      if (this.mqttReady.get(scope) === attempt) this.mqttReady.delete(scope);
      throw e;
    });
    this.mqttReady.set(scope, attempt);
    return attempt;
  }

  /**
   * Give a realtime-only device a bounded chance to report before its actions are bound.
   *
   * The typed read getters are evidence-gated on the ids a device has reported, resolved once at bind
   * time. A device whose state exists ONLY on its realtime wire therefore has no readable state at all
   * if it is resolved before its first report. Waiting here is the cheap path: the returned `Device`
   * already carries its reads, so a caller never has to watch for them appearing.
   *
   * It is a head start, not the mechanism — {@link rebindReads} installs reads that arrive later, which
   * is what covers a device too slow (or too idle) to answer inside the window. A docked robot is
   * exactly that.
   *
   * Skipped entirely for a device with a pollable cloud record, for an already-reporting device, and
   * when realtime is off — so the common path adds nothing. Resolving on timeout leaves a silent device
   * read-less rather than failing the lookup.
   */
  private async awaitFirstRealtimeState(sn: string): Promise<void> {
    if (this.opts.autoRealtime === false || this.realtimeGeneration?.epoch !== this.realtimeEpoch) return;
    if (this.registry.hasRealtimeState(sn)) return;
    const timeoutMs = this.opts.stateSnapshotMs ?? 4000;
    if (timeoutMs <= 0) return;
    if (!this.registry.list().length) await this.getDevices();
    const dev = this.registry.list().find((d) => d.sn === sn);
    if (!dev || dev.realtime !== "smqtt") return;
    const caps = this.registry.capabilitiesForDevice(sn);
    if (!caps || !hasRealtimeReads(caps)) return;
    try {
      await this.ensureMqttStarted(mqttScopeFor(dev));
    } catch {
      return;
    }
    await this.registry.awaitRealtimeState(sn, timeoutMs);
  }

  /**
   * Feed one map-stream frame to the device's map, and announce it if anything changed.
   *
   * Silent about a frame it cannot use. Most of them are: channels nothing reads yet, and fragments of
   * a split message. Neither is a fault, and logging either would log on every frame of every clean.
   */
  private applyMapFrame(deviceSn: string, frame: BizMapFrame): void {
    const piece = decodeMapFrame(frame, rawDpCodec);
    if (!piece) return;

    let store = this.mapStores.get(deviceSn);
    if (!store) {
      store = new VacuumMapStore();
      this.mapStores.set(deviceSn, store);
    }
    // The device repeats its map while it cleans. Announcing an unchanged one on every repeat would
    // wake every listener for nothing, so the store's own answer decides.
    if (store.apply(piece)) this.emit("map", { deviceSn, map: store.snapshot });
  }

  private applyRealtimeReport(sn: string | undefined, states: readonly { params: Record<number, string> }[]): void {
    if (!states.length) return;
    this.applyRealtimeState(sn, Object.assign({}, ...states.map((s) => s.params)));
  }

  /**
   * Land state a capability recovered from a realtime signal: into the registry (so the next
   * {@link getDevice} sees it) AND into any `Device` already handed out (so a caller holding one sees
   * the new value without re-fetching). Announces every property whose value moved, then `deviceState`.
   *
   * Both writes matter: the registry alone would leave an existing `Device` stale until its freshness
   * window expired, and that refresh re-reads the CLOUD record — which for a realtime-only line does
   * not carry this state at all.
   *
   * This is three of the four inbound paths the security line has, and the ONLY one the clean and life
   * lines have — a robot's cloud record carries none of its data points — so it is what brings those
   * lines into scope for a property announcement at all. The announcement is edge-triggered for free:
   * {@link Device.applyParams} names only the properties whose value actually moved, so a device
   * re-reporting the same state is silent with no dedupe table to keep.
   *
   * The reported ids are recorded as evidence BEFORE the re-bind is fired, not after it lands. One
   * report fans out to one call per capability that decoded it, and the re-bind is a cloud round-trip:
   * advancing the set here is what stops the second call from firing a duplicate, and what stops a
   * failed re-bind from re-triggering on every subsequent report.
   */
  private applyRealtimeState(
    sn: string | undefined,
    params: Record<number, string>,
    rssiSource: "hub_report" | "realtime_overlay" = "realtime_overlay",
    receivedAtMs?: number,
    evidenceIngress?: EvidenceIngress,
    deferredShadow?: (() => void)[],
  ): void {
    if (!sn) return;
    const shadow = deferredShadow ?? [];
    const ingress = evidenceIngress ?? { source: "legacy_unknown", receivedAtMs: receivedAtMs ?? Date.now() };
    shadow.push(() => this.recordStateEvidence(sn, params, ingress));
    this.cameraHealthIngress.recordRssiSuppression(sn, params, rssiSource);
    const known = this.boundParamIds.get(sn);
    const reported = Object.keys(params).map(Number);
    const widens = known ? reported.some((id) => !known.has(id)) : false;
    if (widens && known) this.boundParamIds.set(sn, new Set([...known, ...reported]));
    if (receivedAtMs === undefined) this.registry.applyRealtimeParams(sn, params);
    else this.registry.applyRealtimeParams(sn, params, receivedAtMs);
    const revisions = this.deviceRevisions(sn);
    const revision = ++this.realtimeReportRevision;
    for (const id of reported) revisions.set(id, revision);
    const device = this.liveDeviceToAnnounce(sn);
    if (device) {
      const realtime = this.realtimeParamIds.get(device) ?? new Map<number, number>();
      for (const id of reported) realtime.set(id, revision);
      this.realtimeParamIds.set(device, realtime);
      this.applyAndAnnounce(device, params, "recorded", shadow);
    }
    this.emit("deviceState", this.deviceState(sn));
    if (widens) void this.rebindReads(sn);
    if (!deferredShadow) this.finishShadow(shadow);
  }

  /** Parameter revision ownership is per device within the current account and connection lifecycle. */
  private deviceRevisions(sn: string): Map<number, number> {
    const scope = JSON.stringify([this.realtimeEpoch, this.mega.auth?.userId ?? null]);
    if (scope !== this.deviceParamRevisionScope) {
      this.deviceParamRevisions.clear();
      this.deviceParamRevisionScope = scope;
    }
    let revisions = this.deviceParamRevisions.get(sn);
    if (!revisions) this.deviceParamRevisions.set(sn, (revisions = new Map()));
    return revisions;
  }

  /** Apply qualified RTC information and dispatch scoped notifications through the model event path. */
  private onRtcFrame(stationSn: string, frame: PortalResponse, identity?: RtcReportIdentity): void {
    const shadow: (() => void)[] = [];
    this.handleRtcFrame(stationSn, frame, identity, shadow);
    this.finishShadow(shadow);
  }

  private handleRtcFrame(
    stationSn: string,
    frame: PortalResponse,
    identity: RtcReportIdentity | undefined,
    shadow: (() => void)[],
  ): void {
    const observedAtMs = Date.now();
    if (rtcReportParameters(stationSn, frame, this.registry).size) this.scheduleReportRefresh(stationSn);
    for (const [sn, params] of rtcStateParameters(stationSn, frame, this.registry)) {
      this.cameraHealthIngress.params(sn, params, "hub_report");
      this.applyRealtimeState(
        sn,
        params,
        "hub_report",
        this.rtc.informationFrameReceivedAtMs(frame),
        {
          source: identity?.readGeneration === undefined ? "rtc_push" : "rtc_readback",
          receivedAtMs: this.rtc.informationFrameReceivedAtMs(frame) ?? observedAtMs,
          station: stationSn,
          sessionGeneration: identity?.sessionGeneration,
          receiveSequence: identity?.sequence,
          receivedAtMonotonicMs: identity?.receivedAtMonotonicMs,
          readGeneration: identity?.readGeneration,
          readIssuedAtMonotonicMs: identity?.readIssuedAtMonotonicMs,
        },
        shadow,
      );
      this.guardOwner().observe(stationSn, sn, params, identity?.sessionGeneration, identity?.receivedAtMonotonicMs);
      this.lateEffects.observe(sn, params);
      if (identity) this.lateContrary.observe(sn, params, identity);
      const device = this.liveDevices.get(sn)?.deref();
      const properties = Object.fromEntries(
        (device?.observedProperties(params) ?? []).flatMap(({ property, value }) =>
          value === undefined ? [] : [[property, value]],
        ),
      );
      if (Object.keys(properties).length) {
        const context = this.rtc.getCommandTarget(sn);
        if (context)
          this.rtcObservationRecorder.record({
            attempt: context.latestCommandAttempt,
            target: context.target,
            observedAtMs,
            properties: Object.keys(properties).length,
          });
        this.emit("propertiesObserved", {
          deviceSn: sn,
          source: "rtc",
          observedAtMs,
          properties,
        });
      }
    }
    const inspected = inspectRtcPushSignal(stationSn, frame, this.registry);
    const signal = inspected.signal;
    if (!signal) {
      this.eventRoutingRecorder.record("rtc", inspected.decision, inspected.model, inspected.payload, [], frame.cmd);
      return;
    }
    this.cameraHealthIngress.push(signal.deviceSn, signal.stationSn, signal.payload, signal.eventType);
    const outputs = decodeCapabilityEvent(signal, this.capsForEvent(signal.deviceSn));
    this.eventRoutingRecorder.record(
      "rtc",
      outputs.length ? "mapped" : "unmapped",
      inspected.model,
      signal.payload,
      outputs,
      frame.cmd,
    );
    for (const out of outputs) this.emitSemantic(out.event, out.payload, { edge: true, refresh: out.refresh });
  }

  /** Presence-only, bounded push-routing evidence; reading it performs no connection or query. */
  getEventRoutingDiagnostics(): EventRoutingDiagnostics {
    return this.eventRoutingRecorder.diagnostics();
  }

  /** Bounded push connection lifecycle observations; performs no connection or query. */
  getPushLifecycleDiagnostics(): PushLifecycleDiagnostics {
    return this.pushLifecycle.diagnostics();
  }

  /** Passive, finite thumbnail pipeline counters for the current cache lifecycle. */
  getThumbnailDiagnostics(): {
    enabled: boolean;
    counters: Record<string, number>;
    downloadFailures: ReturnType<ThumbnailDiagnostics["failures"]>;
  } {
    return {
      enabled: this.storedImages !== undefined,
      counters: this.thumbnailEvidence.diagnostics(),
      downloadFailures: this.thumbnailEvidence.failures(),
    };
  }

  /** Passive profile/ownership lookup; it never fetches a roster or acquires a session. */
  getStorageTelemetryOwner(sn: string): StorageTelemetryOwner | undefined {
    const device = this.registry.list().find((candidate) => candidate.sn === sn);
    const identity = this.mega.rtcIdentity();
    const raw = (device?.raw ?? {}) as Record<string, unknown>;
    const firmware = recordString(raw, "main_sw_version");
    const admin = (raw.member as { admin_user_id?: unknown } | undefined)?.admin_user_id;
    if (
      !device ||
      !identity ||
      !identity.authToken ||
      !identity.userId ||
      device.model !== "T9000" ||
      device.deviceClass !== "homebase" ||
      !RtcCommandRouter.claimsDevice(device) ||
      (firmware !== "4.4.0.4" && firmware !== "4.4.1.4") ||
      (admin !== undefined && (typeof admin !== "string" || !admin.trim() || Buffer.byteLength(admin) > 128))
    ) {
      this.invalidateStorageTelemetryOwner(sn);
      return undefined;
    }
    const fields = [
      this.realtimeEpoch,
      identity.authToken,
      identity.userId,
      identity.accountUserId,
      identity.gtoken,
      device.sn,
      device.model,
      device.stationSn,
      device.deviceClass,
      device.api,
      device.realtime,
      admin,
      recordString(raw, "main_sw_version"),
    ];
    const current = this.storageTelemetryOwners.get(sn);
    if (current && fields.every((field, index) => Object.is(field, current.fields[index]))) return current.owner;
    this.invalidateStorageTelemetryOwner(sn);
    const token = Object.freeze({
      toJSON() {
        throw new Error("Storage telemetry owner token is not serializable");
      },
    });
    const owner: StorageTelemetryOwner = Object.freeze({ token, model: "T9000", firmware });
    this.storageTelemetryOwners.set(sn, { fields, owner });
    return owner;
  }

  private invalidateStorageTelemetryOwner(sn: string): void {
    this.storageTelemetryOwners.delete(sn);
    for (const controller of this.storageTelemetryReads.get(sn) ?? [])
      controller.abort(new Error("Storage telemetry ownership changed"));
  }

  private reconcileStorageTelemetryOwners(): void {
    for (const sn of [...this.storageTelemetryOwners.keys()]) this.getStorageTelemetryOwner(sn);
  }

  /** One bounded observation on an existing owner; no login, acquisition, retry or polling. */
  async readStorageTelemetry(sn: string, opts: { signal?: AbortSignal; timeoutMs?: number } = {}) {
    opts.signal?.throwIfAborted();
    const owner = this.getStorageTelemetryOwner(sn);
    if (!owner) throw new Error("Storage telemetry requires an existing T9000 owner on firmware 4.4.0.4 or 4.4.1.4");
    const controller = new AbortController();
    const signal = opts.signal ? AbortSignal.any([opts.signal, controller.signal]) : controller.signal;
    const reads = this.storageTelemetryReads.get(sn) ?? new Set<AbortController>();
    reads.add(controller);
    this.storageTelemetryReads.set(sn, reads);
    try {
      const result = await this.rtc.readStorageCandidate(sn, {
        signal,
        timeoutMs: opts.timeoutMs,
        ownerMatches: () => this.getStorageTelemetryOwner(sn)?.token === owner.token,
      });
      signal.throwIfAborted();
      if (this.getStorageTelemetryOwner(sn)?.token !== owner.token)
        throw new Error("Storage telemetry ownership changed");
      return result;
    } finally {
      reads.delete(controller);
      if (!reads.size && this.storageTelemetryReads.get(sn) === reads) this.storageTelemetryReads.delete(sn);
    }
  }

  /** Cache-only opaque namespace; no identity is returned when no authenticated account is installed. */
  getRecordingAccountNamespace(identityKey: Uint8Array): string | null {
    if (identityKey?.length !== 32) return null;
    const identity = this.mega.rtcIdentity();
    const account = identity?.accountUserId ?? identity?.userId;
    return account ? recordingAccountNamespace(identityKey, account) : null;
  }

  /** Update process-local cover pacing without clearing admission history; null restores defaults. */
  setRecordingPacing(pacing: Partial<RecordingPacing> | null = null): RecordingPacing {
    return this.rtc.setRecordingPacing(pacing);
  }

  /** Production browse read on the existing healthy idle owner, with no discovery or acquisition. */
  async readRecordingCatalog(scope: RecordingReadScope, opts: RecordingReadOptions = {}): Promise<CatalogReadResult> {
    try {
      if (!this.opts.rtc?.recordings?.enabled) return { status: "unavailable", reason: "disabled" };
      if (scope.identityKey?.length !== 32) return { status: "unavailable", reason: "store_unavailable" };
      if (!this.recordingsAllowed(scope)) return { status: "deferred", reason: "scope_invalid" };
      const generation = this.realtimeGeneration!;
      const signal = opts.signal ? AbortSignal.any([opts.signal, generation.abort.signal]) : generation.abort.signal;
      return await this.rtc.readRecordingCatalog(scope, { ...opts, signal });
    } catch {
      return { status: "unavailable", reason: "scope_invalid" };
    }
  }

  /** Fetch exactly one internally sealed observed selector, without a table or live-image fallback. */
  async readRecordingCover(
    scope: RecordingReadScope,
    selector: InternalCoverSelector,
    opts: RecordingReadOptions = {},
  ): Promise<CoverReadResult> {
    try {
      if (!this.opts.rtc?.recordings?.enabled) return { status: "unavailable", reason: "disabled" };
      if (scope.identityKey?.length !== 32) return { status: "unavailable", reason: "store_unavailable" };
      if (!this.recordingsAllowed(scope)) return { status: "deferred", reason: "scope_invalid" };
      const generation = this.realtimeGeneration!;
      const signal = opts.signal ? AbortSignal.any([opts.signal, generation.abort.signal]) : generation.abort.signal;
      return await this.rtc.readRecordingCover(scope, selector, { ...opts, signal });
    } catch {
      return { status: "unavailable", reason: "scope_invalid" };
    }
  }

  /** Pull one authenticated catalog event on the current owner, delivering Annex-B video only. */
  async pullRecordingClip(
    scope: RecordingReadScope,
    selector: InternalPlaybackSelector,
    opts: {
      signal?: AbortSignal;
      video: (data: Buffer, timing?: { nativeTimestamp: number }) => void;
      file?: (data: Buffer) => void;
      beforeDispatch?: () => void;
      mediaReady?: (receipt: import("../transport/rtc/event-playback-candidate.js").PlaybackReceipt) => void;
      experiment?: import("../transport/rtc/playback-telemetry.js").PlaybackExperiment;
      transferSpeed?: 1 | 2;
      /** Process monotonic origin for caller pipeline telemetry, independent of protocol deadlines. */
      timelineOriginMs?: number;
    },
  ) {
    const admissionGateName = this.recordingsAdmission(scope);
    if (admissionGateName)
      throw Object.assign(new Error("Playback unavailable"), {
        reason: "owner_unavailable",
        admissionGateName,
        captureOutcome: "not_admitted",
      });
    const generation = this.realtimeGeneration!;
    const signal = opts.signal ? AbortSignal.any([opts.signal, generation.abort.signal]) : generation.abort.signal;
    return this.rtc.readEventPlaybackCandidate(scope.stationSn, {
      enabled: true,
      beforeDispatch: opts.beforeDispatch,
      signal,
      cameras: scope.cameraSns,
      excluded: new Set(),
      fresh: () => this.recordingsAllowed(scope, true),
      clip: {
        scope,
        selector,
        video: opts.video,
        file: opts.file,
        mediaReady: opts.mediaReady,
        experiment: opts.experiment,
        transferSpeed: opts.transferSpeed,
        timelineOriginMs: opts.timelineOriginMs,
      },
    });
  }

  /** Lifecycle, correction and exact enrolled topology gate, evaluated without network activity. */
  private recordingsAllowed(scope: RecordingReadScope, pulling = false): boolean {
    return this.recordingsAdmission(scope, pulling) === undefined;
  }

  /** Stable refusal reason without transport activity or selector disclosure. */
  private recordingsAdmission(
    scope: RecordingReadScope,
    pulling = false,
  ): "disabled" | "scope_invalid" | "recordings_unavailable" | "realtime_disabled" | "inventory_conflict" | undefined {
    const policy = this.opts.rtc?.recordings;
    if (!policy?.enabled) return "disabled";
    if (this.getRecordingAccountNamespace(scope.identityKey) !== scope.accountNamespace) return "scope_invalid";
    if (this.opts.autoRealtime === false) return "realtime_disabled";
    if (this.registry.conflicts().length) return "inventory_conflict";
    if (
      !this.automaticInformationAllowed() ||
      (!pulling && (this.stateRefreshSweep || this.reportRefreshes.has(scope.stationSn))) ||
      this.lateEffects.has(scope.stationSn) ||
      this.commandRefreshes.size ||
      this.stateTransitions.size ||
      this.propertyPreparations.size
    )
      return "recordings_unavailable";
    const allowed = new Set(policy.allowedCameras);
    if (
      scope.stationSn !== policy.stationBinding ||
      allowed.size < 1 ||
      scope.cameraSns.size !== allowed.size ||
      [...scope.cameraSns].some((sn) => !allowed.has(sn))
    )
      return "scope_invalid";
    for (const sn of allowed) {
      const device = this.registry.list().find((entry) => entry.sn === sn);
      const channel = (device?.raw as { device_channel?: unknown } | undefined)?.device_channel;
      if (
        !device ||
        device.stationSn !== scope.stationSn ||
        resolveDevice({
          model: device.model,
          deviceType: cachedDeviceType(device),
          category: device.category,
          params: device.params ?? {},
        }).codec !== "camera" ||
        typeof channel !== "number" ||
        this.registry.serialForFrame(scope.stationSn, channel) !== sn
      )
        return "scope_invalid";
    }
    return undefined;
  }

  /** Background reads share the current realtime generation's authentication and failure holds. */
  private automaticInformationAllowed(): boolean {
    const generation = this.realtimeGeneration;
    return (
      this.opts.autoRealtime !== false &&
      !!generation &&
      generation.epoch === this.realtimeEpoch &&
      !generation.abort.signal.aborted &&
      (generation.stateRefreshFailures ?? 0) === 0
    );
  }

  /** Qualified late reads retain their actual wire-start and session ownership. */
  private async readLateEffect(
    station: string,
    signal: AbortSignal,
    timeoutMs: number,
    options?: { notBeforeMonotonicMs?: number; priority: "late-check" },
  ): Promise<unknown> {
    const generation = this.realtimeGeneration;
    if (!generation || !this.automaticInformationAllowed()) return;
    const combined = AbortSignal.any([signal, generation.abort.signal]);
    const result = await this.rtc.refreshInformation(station, { signal: combined, timeoutMs, ...options });
    if (generation !== this.realtimeGeneration || combined.aborted) return;
    return { ...result, deviceParams: Object.fromEntries(rtcStateParameters(station, result.frame, this.registry)) };
  }

  /** Debounce reports; an active late-effect intent permits one bounded deferral onto the station queue. */
  private scheduleReportRefresh(stationSn: string, deferred = false): void {
    this.rtc.preemptRecordingReads(stationSn);
    const generation = this.realtimeGeneration;
    if (
      this.opts.autoRealtime === false ||
      !generation ||
      generation.epoch !== this.realtimeEpoch ||
      generation.abort.signal.aborted ||
      (generation.stateRefreshFailures ?? 0) > 0 ||
      ((this.stateRefreshSweep || !this.rtc.informationRefreshReady(stationSn)) &&
        !(this.lateEffects.has(stationSn) && this.rtc.informationRefreshReady(stationSn, true)))
    )
      return;
    const pending = this.reportRefreshes.get(stationSn);
    if (pending?.promise) return;
    if (pending?.timer) clearTimeout(pending.timer);
    const entry: { timer?: ReturnType<typeof setTimeout>; promise?: ReturnType<EufyMega["refreshDeviceState"]> } = {};
    this.reportRefreshes.set(stationSn, entry);
    let held = 0;
    const fire = () => {
      entry.timer = undefined;
      // A read queued during stored playback aborts the capture; hold it (bounded), never drop it.
      if (
        (this.rtc.playbackFullClipActive() || held < STATE_REFRESH_PLAYBACK_DEFERRALS) &&
        generation.epoch === this.realtimeEpoch &&
        !generation.abort.signal.aborted &&
        this.rtc.playbackActive()
      ) {
        held++;
        entry.timer = setTimeout(fire, STATE_REFRESH_PLAYBACK_DEFER_MS);
        entry.timer.unref?.();
        return;
      }
      if (
        generation.epoch !== this.realtimeEpoch ||
        generation.abort.signal.aborted ||
        (generation.stateRefreshFailures ?? 0) > 0 ||
        ((this.stateRefreshSweep || !this.rtc.informationRefreshReady(stationSn)) &&
          !(deferred && this.lateEffects.has(stationSn) && this.rtc.informationRefreshReady(stationSn, true)))
      ) {
        if (this.reportRefreshes.get(stationSn) === entry) this.reportRefreshes.delete(stationSn);
        if (
          !deferred &&
          this.lateEffects.has(stationSn) &&
          this.automaticInformationAllowed() &&
          this.rtc.informationRefreshReady(stationSn, true)
        )
          this.scheduleReportRefresh(stationSn, true);
        return;
      }
      if (this.stateRefreshSweep) {
        if (this.reportRefreshes.get(stationSn) === entry) this.reportRefreshes.delete(stationSn);
        return;
      }
      entry.promise = this.refreshAutomaticState(stationSn, generation);
      void entry.promise
        .catch((error) => {
          if (generation.epoch === this.realtimeEpoch && !generation.abort.signal.aborted) {
            generation.stateRefreshFailures = (generation.stateRefreshFailures ?? 0) + 1;
            this.scheduleStateRefresh(generation);
            this.reportError(error, "state_refresh");
          }
        })
        .finally(() => {
          if (this.reportRefreshes.get(stationSn) === entry) this.reportRefreshes.delete(stationSn);
        });
    };
    entry.timer = setTimeout(fire, 1_500);
    entry.timer.unref?.();
  }

  /** Automatic joiners share one renewal retry and one deadline covering renewal waits and both reads. */
  private async refreshAutomaticState(
    station: string,
    generation: RealtimeGeneration,
  ): ReturnType<EufyMega["refreshDeviceState"]> {
    const deadline = Date.now() + 15_000;
    const { epoch, abort } = generation;
    try {
      return await this.refreshDeviceState(station, {
        signal: abort.signal,
        timeoutMs: deadline - Date.now(),
        waitForRenewal: true,
      });
    } catch (error) {
      const remaining = deadline - Date.now();
      if (
        epoch !== this.realtimeEpoch ||
        abort.signal.aborted ||
        remaining < 1 ||
        !consumeRenewalInformationRead(error)
      )
        throw error;
      this.stateRefreshEvidence.renewalRetries++;
      return this.refreshDeviceState(station, {
        signal: abort.signal,
        timeoutMs: remaining,
        waitForRenewal: true,
      });
    }
  }

  /**
   * Request current state from a known T9000 station or an attached device's station. The reply updates
   * all qualified devices it names. Counts describe accepted parameter reports, including unchanged
   * values; property changes are announced only when a value changes. Notification correlation is
   * temporal, not proof that the report was caused by this request. No polling is started.
   */
  async refreshDeviceState(
    sn: string,
    opts: { signal?: AbortSignal; timeoutMs?: number; waitForRenewal?: boolean } = {},
  ): Promise<{ notificationCorrelation: "temporal-only"; devicesUpdated: number; parametersUpdated: number }> {
    const epoch = this.realtimeEpoch;
    const startedAtMs = Date.now();
    let phase: StateRefreshOperationEvidence["phase"] = "validation";
    let completed = false;
    let superseded = false;
    let failure: StateRefreshFailure | null = null;
    try {
      opts.signal?.throwIfAborted();
      if (!this.registry.list().length) await this.getDevices();
      opts.signal?.throwIfAborted();
      if (epoch !== this.realtimeEpoch) throw new Error("State refresh was interrupted");
      const devices = this.registry.list();
      const device = devices.find((candidate) => candidate.sn === sn);
      const station = device && devices.find((candidate) => candidate.sn === stationOf(device));
      if (!station || !RtcCommandRouter.claimsDevice(station))
        throw new Error("State refresh is unavailable for this device");
      phase = "transport";
      const result = await this.rtc.refreshInformation(station.sn, opts);
      if (
        epoch !== this.realtimeEpoch ||
        opts.signal?.aborted ||
        !this.rtc.informationResultCurrent(station.sn, result)
      ) {
        const error = new Error("State refresh was interrupted");
        if (
          epoch === this.realtimeEpoch &&
          !opts.signal?.aborted &&
          this.rtc.informationResultSupersededByRenewal(station.sn, result)
        )
          markRenewalInformationRead(error);
        throw error;
      }
      phase = "processing";
      const updates = rtcStateParameters(station.sn, result.frame, this.registry);
      const receivedAtMs = result.informationReceivedAtMs;
      if (receivedAtMs !== undefined)
        for (const [deviceSn, params] of updates) {
          if (Object.keys(params).length && this.registry.markSeen(deviceSn, receivedAtMs))
            this.emit("deviceState", this.deviceState(deviceSn));
        }
      completed = true;
      return {
        notificationCorrelation: result.notificationCorrelation,
        devicesUpdated: updates.size,
        parametersUpdated: [...updates.values()].reduce((count, params) => count + Object.keys(params).length, 0),
      };
    } catch (error) {
      superseded = isRenewalInformationRead(error);
      failure = stateRefreshFailure(error);
      throw error;
    } finally {
      if (epoch === this.realtimeEpoch) {
        const evidence: StateRefreshOperationEvidence = {
          startedAtMs,
          finishedAtMs: Date.now(),
          phase,
          outcome: completed ? "success" : superseded ? "superseded_by_renewal" : "failed",
          failure: superseded ? null : failure,
        };
        this.stateRefreshEvidence.operations.push(evidence);
        if (this.stateRefreshEvidence.operations.length > 20) this.stateRefreshEvidence.operations.shift();
        if (!completed && !superseded) this.stateRefreshEvidence.lastOperationFailure = { ...evidence };
      }
    }
  }

  /**
   * Re-install a bound device's read getters after a report widened the evidence.
   *
   * The getters are built ONCE, and only for params the device had already reported — so a line whose
   * state arrives only over realtime binds with NO getters at all and would never grow them, no matter
   * how much state landed afterwards. A robot vacuum is exactly that: its cloud record carries none of
   * its data points, so the first report is what makes the reads exist.
   *
   * Re-binding is how the capability-gain path handles the same problem, and it is idempotent — the
   * getters read live state through a closure over `getProperty`, so rebuilding them keeps every value
   * a caller can already see. Only widening triggers it, so a device reporting the same ids repeatedly
   * rebinds once.
   *
   * `deviceState` is re-emitted once the getters exist. The report that creates them is announced before
   * they are installed, so the same event fires again when the reads are actually there, which is what
   * makes "re-read on `deviceState`" true on the first report rather than only from the second.
   * `bindActions` replaces the action objects, so the live ones are reached through the accessor
   * (`dev.vacuumClean()`) and never through a bag cached earlier.
   *
   * The evidence set is widened, never replaced: the ids come back through the cloud record, and a
   * record that omits a realtime-only id would otherwise un-know it and re-trigger on the next report.
   */
  private async rebindReads(sn: string): Promise<void> {
    const dev = this.liveDevices.get(sn)?.deref();
    if (!dev) return;
    const epoch = this.realtimeEpoch;
    const polled = this.polledReads.get(dev);
    const namespace = namespaceForCodec(dev.codec);
    const revisions = new Map(this.realtimeParamIds.get(dev));
    try {
      const rec = await this.registry.record(sn);
      const ctx = await this.commandContext(sn, rec);
      if (epoch !== this.realtimeEpoch) return;
      const superseded = this.polledReads.get(dev) !== polled;
      if (!superseded) dev.reresolve(rec);
      const latest = this.readContexts.get(dev);
      const compatible =
        namespace === namespaceForCodec(dev.codec) &&
        latest?.model === rec.model &&
        latest?.category === rec.category &&
        latest?.deviceType === rec.deviceType &&
        (latest?.stationSerial || sn) === (rec.parentSn || sn);
      if (superseded && latest && compatible) {
        dev.reresolve({ ...rec, name: latest.name, parentSn: latest.stationSerial ?? "" });
        this.boundParamIds.set(sn, new Set([...(this.boundParamIds.get(sn) ?? []), ...ctx.paramIds]));
      }
      if (rec.dpParams && (!superseded || compatible)) {
        const params: RawParams = {};
        for (const [key, value] of Object.entries(rec.dpParams)) {
          const id = Number(key);
          if ((!superseded || revisions.has(id)) && revisions.get(id) === this.realtimeParamIds.get(dev)?.get(id))
            params[id] = value;
        }
        if (Object.keys(params).length) this.applyAndAnnounce(dev, params);
      }
      if (superseded) {
        this.emit("deviceState", this.deviceState(sn));
        return;
      }
      dev.bindActions(
        ctx,
        this.commandSinkFor(sn),
        this.mediaProviderFor(sn),
        this.ff09SettingsReaderFor(sn, ctx),
        rawDpCodec,
      );
      this.readContexts.set(dev, ctx);
      this.boundParamIds.set(sn, new Set([...(this.boundParamIds.get(sn) ?? []), ...ctx.paramIds]));
      this.emit("deviceState", this.deviceState(sn));
    } catch (e) {
      this.reportError(e, "state_refresh");
    }
  }

  /** The distinct credential scopes the current MQTT roster needs — no devices on a scope, no connection. */
  private mqttScopesInUse(): MqttScope[] {
    return [...new Set(this.getMqttDevices().map(mqttScopeFor))];
  }

  /**
   * Emit a semantic capability event whose name is only known at runtime (`decodeCapabilityEvent`
   * returns a plain-string `event` + `payload`). The typed `emit` overload requires a literal event
   * key, so this is the ONE place that bridges the dynamic name to the typed surface — every
   * `emit:` string in a capability module is a member of {@link DeviceEventMap}, so the cast is
   * sound. Keeping it here means the four dispatch loops stay a single call, not a scattered cast.
   *
   * `edge` asks for a state-carrying event to be suppressed when it only repeats what was last
   * announced. The state is noted either way: the poll re-announces an unchanged value on purpose,
   * and must still update what is known, or the next realtime signal carrying that same value would
   * read as a change and be announced a second time.
   */
  private emitSemantic(
    event: string,
    payload: Record<string, unknown>,
    opts: {
      edge?: boolean;
      refresh?: SemanticEventRefresh;
    } = {},
  ): void {
    const refresh = opts.refresh;
    const deviceSn = payload.deviceSn;
    if (refresh && typeof deviceSn === "string") {
      const key = this.eventRefreshKey(deviceSn, refresh);
      const commandOwner = this.commandRefreshes.get(key);
      if (commandOwner?.epoch === this.realtimeEpoch && commandOwner.count > 0) return;
      const device = this.liveDevices.get(deviceSn)?.deref();
      if (device) {
        const emission = this.enqueueStateTransition(key, () => this.refreshEventState(deviceSn, refresh))
          .then(async (refreshed) => {
            if (!refreshed) return;
            this.emitSemantic(event, payload, { edge: opts.edge });
          })
          .catch((error) => this.reportError(error, "state_refresh"));
        void emission;
        return;
      }
    }
    const repeat = this.noteState(event, payload);
    if (opts.edge && repeat) return;
    const emit = this.emit as (e: string, p: unknown) => boolean;
    emit.call(this, event, payload); // the named listener (eufy.on("motion", …))
    emit.call(this, "event", { ...payload, eventName: event }); // the catch-all (eufy.on("event", …)); avoids colliding with payload.name
  }

  /**
   * Await one capability-declared reflected param before publishing its valueless transition event.
   *
   * The state already on hand is consulted BEFORE fetching, but only where the observation carries a concrete
   * value to compare against: a device that reports the written param on its own session lands it through
   * {@link applyRealtimeState} within seconds, and polling the account device list to learn what the device has
   * already said costs a dozen requests to reach the same answer. Without an expectation, "converged" means
   * only "differs from what was read before", which state already on hand can satisfy spuriously — and the
   * caller that has no expectation is the push path, where the signal itself is the news that a re-read is owed.
   *
   * An expected value on an RTC device requests at most one bounded information report before the cloud
   * fallback. It shares the station session, sends no write, and is cancelled when the epoch ends.
   *
   * The cloud half is asked for through {@link DeviceRegistry.refreshedList}, never by fetching the account
   * list outright. The fetch is account-wide — one house list plus one device list per house — so a param that
   * never converges would otherwise spend a whole burst of those every iteration of this loop, and concurrent
   * transitions would multiply it by however many are in flight. The registry's reuse window and its
   * single in-flight fetch collapse all of that to one list per window, shared across every waiter. The loop
   * still turns on its own cadence: each pass re-reads what is known, so a value the device volunteers over
   * its own session settles the wait between two cloud reads rather than after them.
   */
  private refreshEventState(sn: string, refresh: SemanticEventRefresh, requireRead = false): Promise<boolean> {
    const epoch = this.realtimeEpoch;
    return (async (): Promise<boolean> => {
      if (epoch !== this.realtimeEpoch) return false;
      const initialDevice = this.liveDevices.get(sn)?.deref();
      const before = initialDevice?.getProperty(refresh.property)?.value;
      const rawBefore = this.registry.knownParam(sn, refresh.param);
      const deadline = Date.now() + refresh.timeoutMs;
      /**
       * Whether the state already on hand satisfies the observation, applying it to the live device when it
       * does. Reads what is already known and fetches nothing, so a param the DEVICE volunteered over its own
       * session settles the write for free.
       */
      const settled = (): boolean => {
        const device = this.liveDevices.get(sn)?.deref();
        const rawValue = this.registry.knownParam(sn, refresh.param);
        const converged =
          refresh.expected === undefined
            ? device
              ? String(rawValue) !== String(before)
              : rawValue !== rawBefore
            : String(rawValue) === String(refresh.expected);
        if (!converged) return false;
        if (rawValue === undefined) return false;
        const revision = ++this.realtimeReportRevision;
        this.deviceRevisions(sn).set(refresh.param, revision);
        if (!device) return true;
        const revisions = this.realtimeParamIds.get(device) ?? new Map<number, number>();
        revisions.set(refresh.param, revision);
        this.realtimeParamIds.set(device, revisions);
        this.applyAndAnnounce(device, { [refresh.param]: rawValue }, "cached");
        return this.matchesObservation(device.getProperty(refresh.property)?.value, refresh, before);
      };
      if (!requireRead && refresh.expected !== undefined && settled()) return true;
      if (refresh.expected !== undefined && this.rtcDevice(sn) && Date.now() < deadline) {
        const abort = new AbortController();
        this.observationReads.add(abort);
        try {
          await this.refreshDeviceState(sn, {
            signal: abort.signal,
            timeoutMs: Math.min(15_000, deadline - Date.now()),
          });
        } catch {
          if (epoch !== this.realtimeEpoch) return false;
        } finally {
          this.observationReads.delete(abort);
        }
        if (epoch !== this.realtimeEpoch) return false;
        if (settled()) return true;
      }
      while (Date.now() < deadline) {
        if (epoch !== this.realtimeEpoch) return false;
        const remaining = deadline - Date.now();
        try {
          await this.beforeDeadline(this.registry.refreshedList(sn), remaining);
        } catch (error) {
          if (!(error instanceof RefreshWindowClosedError)) throw error;
          break;
        }
        if (epoch !== this.realtimeEpoch) return false;
        if (settled()) return true;
        const delay = Math.min(500, deadline - Date.now());
        if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay));
        if (epoch !== this.realtimeEpoch) return false;
        if (refresh.expected !== undefined && settled()) return true;
      }
      if (epoch !== this.realtimeEpoch) return false;
      throw new StateConvergenceError({
        sn,
        property: refresh.property,
        param: refresh.param,
        expected: refresh.expected,
        observed: this.registry.knownParam(sn, refresh.param),
        timeoutMs: refresh.timeoutMs,
      });
    })();
  }

  /** Serialize one complete state-transition transaction behind its keyed predecessor. */
  private enqueueStateTransition<T>(key: string, operation: () => Promise<T>): Promise<T> {
    const predecessor = this.stateTransitions.get(key);
    const current = (async (): Promise<T> => {
      if (predecessor) {
        try {
          await predecessor;
        } catch {}
      }
      return operation();
    })();
    const tracked = current.finally(() => {
      if (this.stateTransitions.get(key) === tracked) this.stateTransitions.delete(key);
    });
    this.stateTransitions.set(key, tracked);
    return tracked;
  }

  /**
   * Recycle a standalone device's P2P session after a write that needs one, waiting only
   * {@link SESSION_RECYCLE_WAIT_MS} for it.
   *
   * The recycle itself waits for every viewer to detach, so that a write does not drop a live stream.
   * That wait is unbounded by design — a viewer may watch indefinitely — and it happens INSIDE the keyed
   * transaction, so the next write to the same member queues behind it. Racing it decouples the two: the
   * losing recycle stays pending and still runs when the station falls idle, it just stops gating an
   * unrelated write.
   *
   * A failure reported before the bound propagates; one arriving after it survives only as the session
   * manager's own log, since by then nothing is waiting to receive it.
   */
  private recycleStandaloneSession(sn: string): Promise<void> {
    const releaseWrite = new Promise<void>((resolve) => void setTimeout(resolve, SESSION_RECYCLE_WAIT_MS).unref?.());
    return Promise.race([
      this.p2p.resetStandaloneSession(sn),
      releaseWrite.then(() =>
        this.opts.logger?.debug(
          `[session ${sn}] recycle still waiting on an attached viewer — releasing the write that asked for it`,
        ),
      ),
    ]);
  }

  /**
   * Whether the DECODED property now reads what the write asked for.
   *
   * Compared against {@link CommandObservation.observed} where the property's decode is not the identity, and
   * against the raw expectation only where the two coincide. A disable-bit param reports `0` for a property
   * that reads `true`, so comparing the decoded value against the raw expectation would reject a write that
   * had landed — the value converged and the transition event never fired.
   */
  private matchesObservation(
    value: unknown,
    refresh: SemanticEventRefresh & { expected?: boolean | number | string; observed?: boolean | number | string },
    before: unknown,
  ): boolean {
    const want = refresh.observed ?? refresh.expected;
    return want === undefined ? value !== before : String(value) === String(want);
  }

  private eventRefreshKey(sn: string, refresh: Pick<CommandObservation, "param">): string {
    return `${sn}:${refresh.param}`;
  }

  /** Limit waiting on an unabortable dependency operation to the remaining semantic-event refresh window. */
  private beforeDeadline<T>(operation: Promise<T>, timeoutMs: number): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const timeout = setTimeout(
        () => reject(new RefreshWindowClosedError("refresh window closed")),
        Math.max(0, timeoutMs),
      );
      operation.then(
        (value) => {
          clearTimeout(timeout);
          resolve(value);
        },
        (error) => {
          clearTimeout(timeout);
          reject(error);
        },
      );
    });
  }

  /**
   * Fan one inbound P2P frame out: raw escape hatch, device state, then semantic events.
   *
   * The frame is decoded against the capabilities of the device it came FROM, resolved from the
   * `(station, channel)` pair — a shared command id (1700 serves pan-tilt, spotlight and privacy)
   * would otherwise let an unrelated module's parser fabricate an event. The decode is a model
   * concern kept on this side of the boundary, so the router never imports model.
   *
   * Frame events carry the station, which cannot say WHICH attached device reported when a station
   * fans same-kind sensors out by channel, so the resolved serial is folded in; a payload's own
   * fields still win on conflict.
   *
   * Params the station volunteered land as device state first. They arrive in the cloud record's own
   * `param_type → value` shape, so no capability has to claim an id it does not own, and the reads
   * they back stop waiting for the next cloud poll. A capability decode follows for the frames that
   * report a bare value rather than that array, which the generic unwrap cannot recognise. Semantic
   * events are edge-triggered: the same change also arrives as a push seconds later, and is announced
   * once.
   */
  private onP2PFrame(stationSn: string, f: P2PFrame): void {
    this.emit("p2p", f);
    const caps = this.registry.capabilitiesForFrame(stationSn, f.channel);
    const deviceSn = this.registry.serialForFrame(stationSn, f.channel);
    const signal = { source: "p2p-frame" as const, ...f };
    if (f.params) {
      if (deviceSn)
        this.cameraHealthIngress.params(deviceSn, f.params, stationSn === deviceSn ? undefined : "hub_report");
      if (deviceSn) this.guardOwner().observe(stationSn, deviceSn, f.params);
      this.applyRealtimeState(deviceSn, f.params, stationSn === deviceSn ? "realtime_overlay" : "hub_report");
    }
    this.applyRealtimeReport(deviceSn, decodeCapabilityState(signal, caps));
    for (const ev of decodeCapabilityEvent(signal, caps))
      this.emitSemantic(ev.event, deviceSn ? { deviceSn, ...ev.payload } : ev.payload, {
        edge: true,
        refresh: ev.refresh,
      });
  }

  /**
   * Record the state this signal reports, and say whether it merely repeats the last one announced.
   *
   * One physical change reaches the SDK on several transports — an entry sensor's contact arrives as
   * a station notify ~2 s before the identical FCM push — and is announced once. The comparison is
   * edge-triggered on the field a capability declared
   * ({@link CapabilityModule.stateEvents}) rather than time-windowed: a genuine open→close→open burst
   * differs from the last value at every step and passes intact, where any window wide enough to
   * cover the transport spread would have swallowed the second open.
   *
   * Returns `false` — never a repeat — in the three cases where suppressing would lose information:
   * an event no module declared as state-carrying (a pulse: motion, a doorbell press, whose
   * consecutive occurrences are all real), a signal carrying no value for the field (it says nothing
   * about the state, so it can neither duplicate nor overwrite it), and one that can't be attributed
   * to a device (announcing twice beats suppressing a different device's change).
   */
  private noteState(event: string, payload: Record<string, unknown>): boolean {
    const field = STATE_EVENT_FIELDS[event];
    if (!field) return false;
    const value = payload[field];
    if (value === undefined) return false;
    const sn = typeof payload["deviceSn"] === "string" ? payload["deviceSn"] : undefined;
    if (!sn) return false;
    const key = `${sn}:${event}`;
    if (this.lastStateAnnounced.get(key) === value) return true;
    this.lastStateAnnounced.set(key, value);
    return false;
  }

  /**
   * Begin (or resume) login. Returns a `LoginResult` — switch on `status`:
   *  - `ok` → authenticated (`result.session`).
   *  - `captcha` → show `result.image`, then {@link solveCaptcha}(answer).
   *  - `2fa` → a code was sent; {@link submitVerifyCode}(code).
   *
   * A restored session resolves straight to `ok`. No exceptions for the expected captcha/2FA flow.
   *
   * @example
   * ```ts
   * const res = await eufy.login();
   * if (res.status === "captcha") await eufy.solveCaptcha(await promptUser(res.image));
   * else if (res.status === "2fa") await eufy.submitVerifyCode(await promptUser());
   * ```
   */
  async login(opts: { messageType?: number } = {}): Promise<LoginResult> {
    return this.afterLogin(await this.mega.login(opts));
  }

  /** Continue a `{status:"captcha"}` login with the solved answer. See {@link login}. */
  async solveCaptcha(answer: string, opts: { messageType?: number } = {}): Promise<LoginResult> {
    return this.afterLogin(await this.mega.solveCaptcha(answer, opts));
  }

  /** Continue a `{status:"2fa"}` login with the verify code that was sent. See {@link login}. */
  async submitVerifyCode(code: string): Promise<LoginResult> {
    return this.afterLogin(await this.mega.submitVerifyCode(code));
  }

  /**
   * On a successful login, kick off auto-realtime (unless `autoRealtime:false`). Fire-and-forget so
   * `login()` returns as soon as the session is ready — realtime channels come up in the background and
   * surface failures via `error`. Idempotent through the retained generation promise.
   */
  private afterLogin(result: LoginResult): LoginResult {
    if (result.status === LoginStatus.Ok) {
      if (this.storedImageAccount && this.storedImageAccount !== result.session.userId) this.storedImages?.clear();
      this.storedImages?.clearLifecycleErrors();
      this.storedImageAccount = result.session.userId;
      const auth = this.mega.auth;
      if (auth?.userId) this.tuya.bind(auth.userId, this.mega.regionShard, this.opts.countryCode);
      if (this.opts.autoRealtime !== false) void this.ensureRealtime();
    }
    return result;
  }

  /**
   * Wait for the auto-managed realtime startup begun by the current successful {@link login}.
   *
   * A caller-specific timeout does not cancel startup. Calls made before successful login reject with
   * `login() first`; clients configured with `autoRealtime:false` resolve as `disabled` without opening
   * a transport.
   */
  async waitForRealtime(options: WaitForRealtimeOptions = {}): Promise<RealtimeReadiness> {
    if (!this.loggedIn) throw new Error("login() first");
    if (this.opts.autoRealtime === false) {
      return {
        state: "disabled",
        push: createPlaneReadiness(),
        mqtt: createPlaneReadiness(),
        wiredP2p: createPlaneReadiness(),
      };
    }
    const generation = this.realtimeGeneration;
    if (!generation) throw new Error("login() first");
    if (generation.epoch !== this.realtimeEpoch) {
      return generation.superseded ?? readinessSnapshot(generation.readiness, "superseded");
    }
    if (options.timeoutMs === undefined) return generation.promise;
    const timeoutMs = Math.max(0, options.timeoutMs);
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve(readinessSnapshot(generation.readiness, "timed-out")), timeoutMs);
      timer.unref?.();
      void generation.promise.then((result) => {
        clearTimeout(timer);
        resolve(result);
      });
    });
  }

  /** Raw mega HTTP client, for endpoints not yet wrapped. */
  get api(): MegaHttpClient {
    return this.mega;
  }

  /**
   * Fetch the per-user secure-MQTT credentials for realtime appliance control. Pass `appName` to
   * request a specific capability scope on the current session without re-logging in — security
   * devices (locks/garage) need the `eufy_security` scope, which the default scope can't reach.
   */
  getUserMqttInfo(appName?: string): Promise<SecureMqttCredentials> {
    // The returned credential's publish scope is set by `app-name`; `eufy_security` yields a distinct
    // security-scoped credential that the default scope's credential can't substitute for.
    return this.mega.getUserMqttInfo(appName);
  }

  /**
   * A {@link CommandSink} bound to one device serial. This is the one place a device's commands fan out
   * to whichever transport it actually has — so capability modules and `getDevice` callers never need to
   * know which, and this facade names no capability and builds no wire bytes itself. The `ff09-*` kinds
   * ride ONE shared frame over BOTH P2P and secure-MQTT, so they're routed by the device's topology
   * (`p2p_did` present → P2P, else MQTT); the chosen router re-resolves its own routing tail. Every
   * other kind is P2P.
   */
  private commandSinkFor(sn: string, invocation?: PropertyInvocation): CommandSink {
    return {
      dispatch: async (cmd: Command) => {
        const current: PropertyInvocation = invocation ?? { ordinal: this.commandIntents.allocate() };
        if (current.guard && !this.guardOwner().current(current.guard)) return;

        const target = this.rtcDevice(sn);
        if (
          target?.stationSn &&
          target.stationSn !== sn &&
          "channel" in cmd &&
          this.registry.serialForFrame(target.stationSn, cmd.channel) !== sn
        )
          throw new Error("RTC command requires an unambiguous attached-device channel");
        const observation = commandObservation(cmd);
        if (!current.guard && observation?.temporalReport && typeof observation.expected === "number") {
          const guard = this.guardOwner().begin(sn, target?.stationSn || sn, observation.param, observation.expected);
          await this.guardOwner().run(guard, async () => {
            try {
              await this.commandSinkFor(sn, { ...current, guard, receiptRequested: true }).dispatch(cmd);
            } catch (error) {
              this.guardOwner().finish(guard, "not_reported", "transport_uncertain");
              throw error;
            }
          });
          return;
        }
        current.intent ??= this.commandIntents.acceptValidated(
          target?.stationSn || sn,
          sn,
          current.ordinal,
          observation?.replaceableState ? `${sn}:${observation.property}` : undefined,
          current.execution !== undefined,
        );
        if (!current.intent) {
          current.receipt = current.execution
            ? this.rtc.recordUnsentReceipt("superseded_before_send", current.execution)
            : Object.freeze({
                status: "superseded_before_send",
                sendAttempted: false,
                effect: "unconfirmed",
                intent: current.ordinal,
              });
          if (!current.receiptRequested) throw new Error("command superseded before send");
          return;
        }
        if (target && observation?.replaceableState && observation.lateEffectReadback) {
          current.health = this.commandHealth.bind(
            sn,
            observation.property,
            current.ordinal,
            current.execution?.automatic === true || current.execution?.origin === "correction",
          );
          if (!current.health) {
            current.receipt = current.execution
              ? this.rtc.recordUnsentReceipt("queue_full", current.execution)
              : { status: "queue_full", sendAttempted: false, effect: "unconfirmed" };
            if (!current.receiptRequested) throw new Error("command health capacity exhausted");
            return;
          }
          this.commandHealthParents.set(current.intent, current.health);
        }
        if (current.execution)
          current.execution = {
            ...current.execution,
            intent: current.ordinal,
            replacementKey: current.intent.replacementKey,
            isCurrent: () => this.commandIntents.isPropertyCurrent(current.intent!),
            signal: current.health?.automatic
              ? current.execution.signal
                ? AbortSignal.any([current.execution.signal, current.health.controller.signal])
                : current.health.controller.signal
              : current.execution.signal,
          };
        if (observation?.passiveReadback) {
          const route = this.commandRouteFor(sn, cmd, current);
          if (route.passiveReadback) {
            try {
              await route.dispatch(Date.now() + this.rtc.commandTimeoutMs);
            } finally {
              this.commandHealth.release(current.health);
            }
            return;
          }
        }
        if (!observation) {
          await this.routeCommand(sn, cmd, undefined, current);
          return;
        }
        const deadlineAtMs = this.rtcDevice(sn) ? Date.now() + this.rtc.commandTimeoutMs : undefined;
        const key = this.eventRefreshKey(sn, observation);
        const epoch = this.realtimeEpoch;
        const owner = this.commandRefreshes.get(key);
        const currentOwner = owner?.epoch === epoch ? owner : { epoch, count: 0 };
        currentOwner.count += 1;
        this.commandRefreshes.set(key, currentOwner);
        let acknowledge!: () => void;
        let reject!: (error: unknown) => void;
        let acknowledged = false;
        const acknowledgement = new Promise<void>((resolve, rejectPromise) => {
          acknowledge = () => {
            acknowledged = true;
            resolve();
          };
          reject = rejectPromise;
        });
        let released = false;
        const release = (): void => {
          if (released) return;
          released = true;
          if (this.commandRefreshes.get(key) === currentOwner) {
            currentOwner.count -= 1;
            if (currentOwner.count === 0) this.commandRefreshes.delete(key);
          }
        };
        let expired = false;
        const queueTimer =
          deadlineAtMs === undefined
            ? undefined
            : setTimeout(
                () => {
                  expired = true;
                  reject(new Error("RTC command timed out before send"));
                  release();
                },
                Math.max(0, deadlineAtMs - Date.now()),
              );
        const transaction = this.enqueueStateTransition(key, async () => {
          clearTimeout(queueTimer);
          try {
            if (expired || (deadlineAtMs !== undefined && Date.now() >= deadlineAtMs))
              throw new Error("RTC command timed out before send");
            if (epoch !== this.realtimeEpoch) throw new Error("observed command superseded by disconnect");
            if (current.guard && !this.guardOwner().current(current.guard)) {
              acknowledge();
              return;
            }
            if (current.guard && !this.rtcDevice(sn)) this.guardOwner().sent(current.guard);
            await this.routeCommand(
              sn,
              cmd,
              current.guard
                ? Math.min(
                    deadlineAtMs ?? Infinity,
                    Date.now() + Math.max(0, Math.floor(current.guard.deadline - performance.now())),
                  )
                : deadlineAtMs,
              current,
            );
            if (current.guard) {
              const receipt = current.receipt;
              if (receipt?.sendAttempted) this.guardOwner().sent(current.guard);
              if (!receipt || receipt.status === "acknowledged")
                this.guardOwner().dispatched(current.guard, receipt?.sessionGeneration);
              else {
                this.guardOwner().finish(
                  current.guard,
                  "not_reported",
                  receipt.status === "rejected" ? "dispatch_rejected" : "ack_missing",
                );
                if (receipt.status === "rejected")
                  throw Object.assign(new Error("guard dispatch rejected"), { code: "guard_dispatch_rejected" });
              }
            }
            acknowledge();
            const refreshed = await this.refreshEventState(sn, observation, current.guard !== undefined);
            if (!refreshed || epoch !== this.realtimeEpoch) return;
            this.emitSemantic(observation.event, { deviceSn: sn });
            if (observation.resetStandaloneSession && !this.rtcDevice(sn)) await this.recycleStandaloneSession(sn);
          } catch (error) {
            if (!acknowledged) reject(error);
            else this.reportUnacknowledged(error);
          } finally {
            release();
          }
        });
        void transaction.catch((error) => {
          if (!acknowledged) reject(error);
          else this.reportUnacknowledged(error);
          release();
        });
        return acknowledgement;
      },
    };
  }

  /**
   * Combine explicit P2P media with the optional passive push-thumbnail provider.
   *
   * The retained still also becomes the answer for a live still that could not be captured. One session
   * serves one camera at a time and a live view outranks a tile — a still does not open a connection of its
   * own — so a still asked for while a sibling is being watched is refused at the transport. Answering the retained bytes answers the read rather than
   * failing it, marked {@link MediaProvider.snapshotLive} `retained` so the caller knows they are not
   * current. With nothing retained the refusal stands.
   */
  private mediaProviderFor(sn: string): MediaProvider {
    // A camera on a T9000 has no P2P live; its video rides the station's control channel.
    const target = this.registry.list().find((d) => d.sn === sn);
    const media =
      target &&
      RtcCommandRouter.claimsMedia(target, (stationSn) => this.registry.list().find((d) => d.sn === stationSn))
        ? this.rtc.mediaProviderFor(sn)
        : this.p2p.mediaProviderFor(sn);
    const cache = this.storedImages;
    if (!cache) return media;
    const retainedStill = () => {
      if (!this.mega.loggedIn) return Promise.reject(new Error("login() first"));
      return cache.snapshotStored(sn);
    };
    return {
      ...media,
      snapshotStored: retainedStill,
      snapshotLive: async (opts) => {
        try {
          return await media.snapshotLive(opts);
        } catch (error) {
          if (!(error instanceof LiveSnapshotUnavailableError)) throw error;
          const retained = (await retainedStill().catch(() => undefined))?.jpeg;
          const geometry = retained && jpegGeometry(retained);
          if (!retained || !geometry) throw error;
          (this.opts.logger ?? noopLogger).debug(
            `[media] a live still was unavailable (${error.reason}) — answering the retained one instead`,
          );
          return { jpeg: retained, ...geometry, retained: true };
        }
      },
    };
  }

  /**
   * Choose the transport stack for one command — the routing half of {@link commandSinkFor}.
   *
   * The `ff09-*` kinds share ONE frame that rides either transport, so each stack is asked whether it
   * drives this device (`claimsDevice`) rather than inferring from the kind. `registry.require` throws
   * on an unloaded serial, so a routing decision never silently falls through to the wrong transport.
   * The `eufy_life` DP writes (smart lights) are secure-MQTT-only. `aiot-dp` routes to either the
   * Anker AIoT MQTT stack or the legacy Tuya REST router depending on the device's category
   * (`eufy_home_tuya` → Tuya, everything else → MQTT). The capability layer emits a single `aiot-dp`
   * kind and stays transport-agnostic; only the facade sees both sides and decides here. Everything
   * else is RTC for a supported station and its attached devices, or P2P for other stations.
   */
  private routeCommand(
    sn: string,
    cmd: Command,
    deadlineAtMs?: number,
    invocation?: PropertyInvocation,
  ): Promise<void> {
    return this.commandRouteFor(sn, cmd, invocation).dispatch(deadlineAtMs);
  }

  /** Resolve the command's selected transport and its independent state-report policy. */
  private commandRouteFor(
    sn: string,
    cmd: Command,
    invocation?: PropertyInvocation,
  ): { dispatch: (deadlineAtMs?: number) => Promise<void>; passiveReadback?: boolean } {
    if (cmd.kind === "ff09-actuate" || cmd.kind === "ff09-autolock" || cmd.kind === "ff09-setting-toggle") {
      const dev = this.registry.require(sn);
      if (P2PCommandRouter.claimsDevice(dev))
        return {
          dispatch: () => {
            invocation?.preparation?.finish("transport_handoff");
            return this.p2p.dispatchCommand(sn, cmd);
          },
        };
      if (MqttCommandRouter.claimsDevice(dev))
        return {
          dispatch: () => {
            invocation?.preparation?.finish("transport_handoff");
            return this.mqtt.dispatchCommand(sn, cmd);
          },
        };
      throw new Error(`no transport stack claims device ${sn} for a ${cmd.kind} command`);
    }
    if (cmd.kind === "mqtt-dp" || cmd.kind === "mqtt-dp-preset" || cmd.kind === "mqtt-dp-color") {
      return {
        dispatch: () => {
          invocation?.preparation?.finish("transport_handoff");
          return this.mqtt.dispatchCommand(sn, cmd);
        },
      };
    }
    if (cmd.kind === "aiot-dp") {
      const dev = this.registry.require(sn);
      return dev.category === "eufy_home_tuya"
        ? {
            dispatch: () => {
              invocation?.preparation?.finish("transport_handoff");
              return this.tuya.dispatchCommand(sn, cmd);
            },
          }
        : {
            dispatch: () => {
              invocation?.preparation?.finish("transport_handoff");
              return this.mqtt.dispatchCommand(sn, cmd);
            },
          };
    }
    const target = this.rtcDevice(sn);
    if (target) {
      return {
        passiveReadback: true,
        dispatch: async (deadlineAtMs) => {
          if (
            target.stationSn &&
            target.stationSn !== sn &&
            this.registry.serialForFrame(target.stationSn, cmd.channel) !== sn
          )
            return Promise.reject(new Error("RTC command requires an unambiguous attached-device channel"));
          const intent =
            target.stationSn && target.stationSn !== sn
              ? this.lateEffects.begin(target.stationSn, sn, cmd, {
                  intent: invocation?.intent,
                  ...(invocation?.execution &&
                  invocation.execution.origin !== "correction" &&
                  this.commandHealth.status(sn, commandObservation(cmd)!.property).status !== "command_degraded"
                    ? {
                        retry: {
                          totalByMonotonicMs: invocation.execution.totalByMs,
                          signal: invocation.execution.signal,
                          wallExpiresAtMs: invocation.execution.wallExpiresAtMs,
                          wallOffsetMs: invocation.execution.wallOffsetMs,
                          clockUncertaintyMs: invocation.execution.clockUncertaintyMs,
                        },
                      }
                    : {}),
                })
              : undefined;
          const contraryWatch =
            invocation?.execution && invocation.intent && target.stationSn
              ? this.lateContrary.begin(
                  target.stationSn,
                  sn,
                  cmd,
                  invocation.intent,
                  invocation.execution.origin !== "correction",
                )
              : undefined;
          try {
            invocation?.preparation?.finish("transport_handoff");
            if (invocation?.receiptRequested) {
              invocation.transportAttempted = true;
              const receipt = await this.rtc.dispatchCommandWithReceipt(sn, cmd, {
                ...(invocation.execution
                  ? { execution: invocation.execution }
                  : {
                      deadlineAtMs,
                      ...(invocation.intent
                        ? {
                            intent: {
                              replacementKey: invocation.intent.replacementKey,
                              isCurrent: () =>
                                this.commandIntents.isPropertyCurrent(invocation.intent!) &&
                                (!invocation.guard || this.guardOwner().current(invocation.guard)),
                            },
                          }
                        : {}),
                    }),
                onSent: (sentAt: number) => {
                  const sentAtMonotonicMs = performance.now();
                  if (invocation.guard) this.guardOwner().sent(invocation.guard);
                  if (invocation.health) invocation.health.sent = true;
                  if (intent) this.lateEffects.sent(intent, sentAt);
                  this.shadowDispatched(sn, cmd, sentAtMonotonicMs);
                },
                onResponse: (receipt) => this.commandHealth.response(invocation.health, receipt),
              });
              if (intent && receipt.sentAtMonotonicMs !== undefined && receipt.sessionGeneration !== undefined)
                this.lateEffects.sent(intent, {
                  sentAtMs: receipt.sentAtMs ?? Date.now(),
                  sentAtMonotonicMs: receipt.sentAtMonotonicMs,
                  sessionGeneration: receipt.sessionGeneration,
                });
              if (intent?.retry) intent.retry.parentAttempt = receipt.attempt;
              const pending =
                receipt.status === "rejected" &&
                receipt.rejectionCode === -108 &&
                this.lateEffects.finish(intent, true, true);
              if (!pending)
                this.lateEffects.finish(
                  intent,
                  ["ack_timeout", "expired_after_send", "rejected"].includes(receipt.status),
                );
              invocation.receipt = Object.freeze({
                ...receipt,
                ...(invocation.health
                  ? { commandHealth: this.commandHealth.status(sn, commandObservation(cmd)!.property) }
                  : {}),
                ...(pending ? { status: "pending_accepted" as const } : {}),
                ...(invocation.intent && !this.commandIntents.isPropertyCurrent(invocation.intent)
                  ? { superseded: true }
                  : {}),
              });
              this.lateContrary.finish(contraryWatch, invocation.receipt);
              return;
            }
            await this.rtc.dispatchCommand(sn, cmd, {
              deadlineAtMs,
              ...(invocation?.intent
                ? {
                    intent: {
                      replacementKey: invocation.intent.replacementKey,
                      isCurrent: () =>
                        this.commandIntents.isPropertyCurrent(invocation.intent!) &&
                        (!invocation.guard || this.guardOwner().current(invocation.guard)),
                    },
                  }
                : {}),
              ...(commandObservation(cmd) || invocation?.health || intent
                ? {
                    onSent: (sentAt: number) => {
                      const sentAtMonotonicMs = performance.now();
                      if (invocation?.health) invocation.health.sent = true;
                      if (intent) this.lateEffects.sent(intent, sentAt);
                      this.shadowDispatched(sn, cmd, sentAtMonotonicMs);
                    },
                  }
                : {}),
              ...(invocation?.health
                ? { onResponse: (receipt: CommandReceipt) => this.commandHealth.response(invocation.health, receipt) }
                : {}),
            });
            this.lateEffects.finish(intent, false);
          } catch (error) {
            this.lateContrary.finish(contraryWatch, { status: "not_sent", sendAttempted: false, effect: "unknown" });
            if (
              error instanceof RtcCommandRejection &&
              error.code === -108 &&
              this.lateEffects.finish(intent, true, true)
            ) {
              if (invocation?.receiptRequested)
                invocation.receipt = Object.freeze({
                  status: "pending_accepted",
                  sendAttempted: true,
                  effect: "unconfirmed",
                  intent: invocation.ordinal,
                });
              return;
            }
            this.lateEffects.finish(
              intent,
              ["ack_timeout", "expired_after_send", "rejected"].includes(commandOutcome(error)),
            );
            throw error;
          }
        },
      };
    }
    return {
      dispatch: () => {
        invocation?.preparation?.finish("transport_handoff");
        return this.p2p.dispatchCommand(sn, cmd);
      },
    };
  }

  /** Resolve a cached device sharing a supported RTC station's control channel. */
  private rtcDevice(sn: string): EufyDevice | undefined {
    const devices = this.registry.list();
    const target = devices.find((device) => device.sn === sn);
    if (!target) return undefined;
    const claims = this.cachedRtcClaims(target, devices);
    return claims.rtcDevice || claims.rtcMedia ? target : undefined;
  }

  /** Existing RTC route predicates evaluated against the same retained roster snapshot. */
  private cachedRtcClaims(
    target: EufyDevice,
    devices: readonly EufyDevice[],
  ): Pick<CachedDeviceContext, "rtcDevice" | "rtcMedia"> {
    return {
      rtcDevice: RtcCommandRouter.claimsDevice(target),
      rtcMedia: RtcCommandRouter.claimsMedia(target, (stationSn) => devices.find((device) => device.sn === stationSn)),
    };
  }

  /**
   * Compare a held model's parent link with one cached roster snapshot, without fetching or allocating
   * command history. Default-self is self-or-unknown. Family and route facts are separate retained
   * observations; a conflicting link does not select either relation as current.
   */
  getCachedDeviceContext(device: Pick<Device, "sn" | "stationSn">): CachedDeviceContext {
    const devices = this.registry.list();
    const target = devices.find((entry) => entry.sn === device.sn);
    const parentSn = target?.stationSn ?? target?.sn;
    const parent = target && parentSn !== target.sn ? devices.find((entry) => entry.sn === parentSn) : undefined;
    const targetDeviceType = cachedDeviceType(target);
    const parentDeviceType = cachedDeviceType(parent);
    return {
      targetCached: target !== undefined,
      parentCached: parent !== undefined,
      ...(targetDeviceType !== undefined ? { targetDeviceType } : {}),
      ...(parentDeviceType !== undefined ? { parentDeviceType } : {}),
      topology: target
        ? parentSn !== target.sn
          ? "attached"
          : "self-or-unknown"
        : device.stationSn !== device.sn
          ? "attached"
          : "self-or-unknown",
      parentLink: target ? (parentSn === device.stationSn ? "consistent" : "conflict") : "unknown",
      ...(target ? this.cachedRtcClaims(target, devices) : { rtcDevice: false, rtcMedia: false }),
    };
  }

  /**
   * Cache-only topology generation. Parameter updates and row order do not change its identity;
   * account, connection lifecycle, parent/channel/family changes and duplicate conflicts do.
   * The epoch identifies the connection lifecycle independently of a roster refresh. No inventory
   * or media work starts here, and this value does not hold a feed or station-session lease.
   */
  getInventoryScope(): Readonly<{ epoch: number }> {
    const rows = this.registry.list().map((dev) => {
      const raw = dev.raw as Record<string, unknown> | undefined;
      return JSON.stringify([
        dev.sn,
        dev.stationSn ?? null,
        dev.model ?? null,
        dev.category ?? null,
        raw?.device_type ?? null,
        raw?.device_channel ?? null,
      ]);
    });
    const key = JSON.stringify([
      this.realtimeEpoch,
      this.mega.auth?.userId ?? null,
      rows.sort(),
      this.registry.conflicts(),
    ]);
    if (key !== this.inventoryScopeKey) {
      this.inventoryScopeKey = key;
      this.inventoryScope = Object.freeze({ epoch: this.realtimeEpoch });
    }
    return this.inventoryScope;
  }

  /** Cache-only conflicting serials for admission validation; not a diagnostics payload. */
  getInventoryConflicts(): readonly string[] {
    return this.registry.conflicts();
  }

  /**
   * List + classify devices across all houses (mega API). Each device is tagged with its API backend
   * + realtime transport. Camera/HomeBase records still appear here for inventory; driving them is
   * P2P. Delegates to `DeviceRegistry` (the house-scoped merge/dedupe lives there).
   *
   * Side-effect: registers `eufy_home_tuya` devices with the Tuya command router so
   * the command dispatcher can resolve a eufy SN → Tuya devId without a separate lookup.
   * The Tuya id is extracted from the device's raw cloud record (`tuya_uuid`, `tuya_virtual_id`,
   * `tuya_device_id`, or `virtualId` fields — whichever is non-empty).
   *
   * A partial cloud outage still resolves, with the devices that answered plus the ones already known — but a
   * session the cloud has rejected REJECTS, with {@link SessionExpiredError}. An empty list would be
   * indistinguishable from an account with no devices.
   */
  async getDevices(): Promise<EufyDevice[]> {
    const devices = await this.registry.getDevices();
    this.reconcileStorageTelemetryOwners();
    for (const dev of devices) {
      if (dev.category !== "eufy_home_tuya") continue;
      const raw = (dev.raw ?? {}) as Record<string, unknown>;
      const devId = tuyaDevIdFrom(raw);
      if (devId) this.tuya.registerDevice(dev.sn, devId);
    }
    return devices;
  }

  /** Devices that this client drives over MQTT (transport ≠ p2p). */
  getMqttDevices(): EufyDevice[] {
    return this.registry.mqttDevices();
  }

  /**
   * One page of a robot vacuum's **cleaning history**, in whatever order the cloud returns it —
   * newest first in practice, but that is the gateway's contract and the SDK does not re-sort.
   *
   * `pageSize` is how many records to return and `page` is 1-based; page through until the returned
   * `total` is reached. Answers an empty page rather than throwing when the account has no history for
   * the device or the response cannot be read.
   *
   * Each record carries a `downloadUrl` for the run's binary detail blob (map and per-run statistics).
   * The SDK hands that URL over rather than fetching it — the host is unconfirmed and the blob's format
   * is not evidenced yet.
   */
  async getCleanRecords(deviceSn: string, pageSize = 20, page = 1): Promise<CleanRecordPage> {
    try {
      return parseCleanRecords(await this.mega.getCleanRecords(deviceSn, pageSize, page));
    } catch (err) {
      this.opts.logger?.debug?.(`[clean] record list failed: ${(err as Error).message}`);
      return EMPTY_CLEAN_RECORD_PAGE;
    }
  }

  /**
   * Inspect one device by serial: resolve its codec/capabilities, cross-reference every reported
   * `param_type` against the param dictionary, and emit a paste-ready `registry.ts` row plus
   * dictionary snippets for anything unknown. Loads the device list if needed; prefers
   * the live `get_device_param_list` for freshest params, falling back to the device-list params.
   */
  async inspectDevice(sn: string): Promise<DeviceInspection> {
    return this.registry.inspectDevice(sn);
  }

  /**
   * The device's LIVE, authoritative `rtsp://` URL — host, path, and the credentials it is
   * enforcing right now — or `undefined` when none is pushed within the read window.
   *
   * A thin public door onto the P2P transport (which stays internal otherwise): opens the
   * station's session on demand, so a viewer adopting a tile can call this directly without one
   * already existing. It writes only the publish switch and the test-stream provoke, never the
   * credentials, so a stream a NAS/NVR already consumes keeps its own pair.
   *
   * This is the CANONICAL way to fetch the URL: it provokes and returns it. The `rtsp` capability's
   * `url` member surfaces the SAME value as inbound state for code that already holds a `dev.rtsp()`
   * and reacts to `propertyChanged` — not a second way to fetch it.
   *
   * Every failure — no route, no account id, level-2 not ready, no push before the deadline — collapses
   * to `undefined`. The distinction the caller might want (terminal "no RTSP" vs a transient "session
   * not warm yet") is not drawn here yet; a caller that retries on `undefined` recovers from the
   * transient case. The read window is a fixed 12 s — long enough for a cold HomeBase to wake and
   * answer, and about the ceiling a UI adopting a tile will wait — deliberately not caller-tunable.
   */
  async reportedRtspUrl(sn: string): Promise<string | undefined> {
    return this.p2p.readReportedRtspUrl(sn);
  }

  /**
   * Build a live {@link Device} model object for one serial: the resolved codec/capabilities with
   * its current param values applied (named via the param dictionary; unknown ids kept as
   * `unknown_<pt>`). This is the device primitive — `dev.getProperties()`, `dev.has(cap)`, etc.
   * Prefers fresh `get_device_param_list`, falls back to the device-list params.
   * Under auto-realtime the returned Device is wired with a read-through freshness cache (see
   * {@link Device.setFreshnessPolicy}), so repeat reads are served from cache instead of re-fetching,
   * and realtime updates keep values fresh.
   *
   * That refresh ANNOUNCES what it lands, like the other two inbound paths. Under frequent reads it
   * fires every `cacheTtlMs` where the poll fires every ten minutes, so it is where most fresh cloud values
   * arrive — and each announcing path is edge-triggered on the same live state, so whichever sees a change
   * first announces it and the others stay silent. Its timing says only when a caller happened to read; the
   * value is the news. It applies what the device volunteered over realtime on top of the cloud half, which
   * the registry keeps apart, so it can neither revert nor announce a revert of a report already landed.
   * Nothing awaits that refresh, so its failure is reported like the other background paths' — a dead
   * token as `sessionExpired`, anything else as `error` — and the read keeps its last-known value.
   *
   * The `Device` returned is held WEAKLY: it is what the inbound paths announce against, so a caller that
   * wants property changes for a serial keeps its own reference. Dropping it stops the announcements, not
   * the device.
   *
   * @example
   * ```ts
   * const dev = await eufy.getDevice(sn);
   * if (dev.has("camera")) await dev.camera?.()?.snapshotStored?.();
   * console.log(dev.getProperty("battery"));
   * ```
   */
  async getDevice(sn: string): Promise<Device> {
    const epoch = this.realtimeEpoch;
    const account = this.mega.auth?.userId;
    const current = () => epoch === this.realtimeEpoch && account === this.mega.auth?.userId;
    await this.awaitFirstRealtimeState(sn);
    if (!current()) throw new Error("Device construction superseded by account or runtime change");
    const revisions = new Map(this.deviceRevisions(sn));
    const rec = await this.registry.record(sn);
    if (!current()) throw new Error("Device construction superseded by account or runtime change");
    const context = await this.commandContext(sn, rec);
    if (!current()) throw new Error("Device construction superseded by account or runtime change");
    const advanced: RawParams = {};
    const latestRevisions = this.deviceRevisions(sn);
    for (const [id, revision] of latestRevisions) {
      if (revisions.get(id) === revision) continue;
      const value = this.registry.knownParam(sn, id);
      if (value === undefined) throw new Error("Device construction superseded by unavailable parameter");
      advanced[id] = value;
    }
    const reconciled = { ...rec, dpParams: { ...rec.dpParams, ...advanced } };
    const dev = Device.fromRecord(sn, reconciled, this.opts.logger);
    dev.applyParams(reconciled.dpParams);
    const cloudParams = this.registry.list().find((record) => record.sn === sn)?.params ?? rec.params;
    this.cloudParamIds.set(dev, new Set(Object.keys(cloudParams ?? {}).map(Number)));
    this.realtimeParamIds.set(
      dev,
      new Map(Object.keys(reconciled.dpParams).map((id) => [Number(id), latestRevisions.get(Number(id)) ?? 0])),
    );
    const ctx = { ...context, paramIds: new Set([...context.paramIds, ...Object.keys(advanced).map(Number)]) };
    dev.setStationContext(ctx);
    dev.bindActions(
      ctx,
      this.commandSinkFor(sn),
      this.mediaProviderFor(sn),
      this.ff09SettingsReaderFor(sn, ctx),
      rawDpCodec,
    );
    this.readContexts.set(dev, ctx);
    this.boundParamIds.set(sn, ctx.paramIds);
    if (this.opts.autoRealtime !== false) {
      dev.setFreshnessPolicy({
        staleAfterMs: this.opts.cacheTtlMs ?? 15_000,
        refresh: async () => {
          try {
            const epoch = this.realtimeEpoch;
            // A poll may supersede a useful per-device result without changing this value.
            // Retry once from the new baseline; never adopt the rejected snapshot itself.
            for (let attempt = 0; attempt < 2; attempt++) {
              const polled = this.polledReads.get(dev);
              const revisions = new Map(this.realtimeParamIds.get(dev));
              const fresh = await this.registry.record(sn);
              if (epoch !== this.realtimeEpoch) return;
              if (polled !== this.polledReads.get(dev)) continue;
              const params: RawParams = {};
              for (const [key, value] of Object.entries({ ...fresh.params, ...fresh.dpParams })) {
                const id = Number(key);
                if (revisions.get(id) === this.realtimeParamIds.get(dev)?.get(id)) params[id] = value;
              }
              this.applyAndAnnounce(dev, params);
              return;
            }
          } catch (e) {
            this.reportError(e, "state_refresh");
          }
        },
      });
    }
    const held = new WeakRef(dev);
    this.liveDevices.set(sn, held);
    this.stationContextDevices.add(held);
    this.runShadow(() => {
      this.recordStateEvidence(
        sn,
        { ...rec.params, ...reconciled.dpParams },
        { source: "snapshot", receivedAtMs: null },
        true,
      );
      this.projectStateEvidence(dev, { ...rec.params, ...reconciled.dpParams });
    });
    return dev;
  }

  /**
   * The {@link Ff09SettingsReader} behind `dev.lock()?.getAutoLockState()` — picks P2P vs MQTT the same
   * way {@link commandSinkFor} does for writes, so `lock.ts` never has to know which transport this
   * device has. `undefined` when `ctx.adminUserId` is missing (not a lock-family device — mirrors
   * `CommandContext.adminUserId`'s own doc: "present on lock-family devices, absent elsewhere").
   *
   * It earns its own boundary because `GET_SETTINGS` is a request/reply query that neither
   * `CommandSink` (write-only) nor `MediaProvider.p2pQuery` (P2P-only, no decrypt) fits. Named for the
   * frame family rather than the capability, so this facade stays capability-neutral like the layers
   * below it — see `CapabilityModule.actions`'s doc before adding another.
   */
  private ff09SettingsReaderFor(sn: string, ctx: CommandContext): Ff09SettingsReader | undefined {
    if (!ctx.adminUserId) return undefined;
    const adminUserId = ctx.adminUserId;
    const deviceSn = ctx.serial ?? "";
    return {
      getAutoLockState: () =>
        ctx.hasP2p
          ? this.p2p.getAutoLockState(sn, { adminUserId, deviceSn })
          : this.mqtt.getAutoLockState(sn, { adminUserId, deviceSn }),
    };
  }

  /**
   * Auto-realtime bring-up — the SDK owns connectivity so the host calls no `connect*`. Runs once per
   * session after a successful login (unless `autoRealtime:false`). Starts the **always-on, battery-safe**
   * channels — FCM push (account-wide events) + secure MQTT (iff appliances present) — and eagerly warms
   * P2P **only for wired stations** (HomeBases / mains cameras, which don't drain). Battery cameras are
   * left detached: their P2P opens on demand (command / stream, or an opted-in event pre-warm) and
   * idle-detaches. All channels start concurrently; a single failure surfaces via `error` without
   * aborting the rest.
   */
  private ensureRealtime(): Promise<RealtimeReadiness> {
    return this.ensureRealtimeGeneration().promise;
  }

  /** Create or join the one transport bring-up owned by the current realtime epoch. */
  private ensureRealtimeGeneration(): RealtimeGeneration {
    if (this.realtimeGeneration?.epoch === this.realtimeEpoch) return this.realtimeGeneration;
    const epoch = this.realtimeEpoch;
    let resolve!: (readiness: RealtimeReadiness) => void;
    const promise = new Promise<RealtimeReadiness>((done) => (resolve = done));
    const generation: RealtimeGeneration = {
      epoch,
      readiness: {
        state: "ready",
        push: createPlaneReadiness(1),
        mqtt: createPlaneReadiness(),
        wiredP2p: createPlaneReadiness(),
      },
      promise,
      resolve,
      abort: new AbortController(),
      settled: false,
    };
    this.realtimeGeneration = generation;
    void this.startRealtimeGeneration(generation);
    return generation;
  }

  /** Start all selected transports concurrently and settle their owning generation once. */
  private async startRealtimeGeneration(generation: RealtimeGeneration): Promise<void> {
    const { epoch, readiness } = generation;
    try {
      if (!this.registry.list().length) await this.getDevices();
      if (epoch !== this.realtimeEpoch) return this.settleRealtimeGeneration(generation, "superseded");
      const scopes = this.mqttScopesInUse();
      readiness.mqtt = createPlaneReadiness(scopes.length);
      let push: PushClient | undefined;
      let startupFailed = false;
      const pushStart = this.startPush(generation.abort.signal).then(
        (client) => {
          push = client;
          readiness.push.ready++;
          readiness.push.pending--;
        },
        (error) => {
          if (error instanceof RealtimeStartupSupersededError) return;
          readiness.push.failed++;
          readiness.push.pending--;
          this.reportError(error, "push_connection");
        },
      );
      const mqttStarts = scopes.map((scope) =>
        this.ensureMqttStarted(scope, epoch).then(
          () => {
            readiness.mqtt.ready++;
            readiness.mqtt.pending--;
          },
          (error) => {
            readiness.mqtt.failed++;
            readiness.mqtt.pending--;
            this.reportError(error, "mqtt");
          },
        ),
      );
      const wiredStart = this.warmWiredP2P(readiness.wiredP2p, generation.abort.signal).then(
        (result) => {
          readiness.wiredP2p = result;
        },
        (error) => {
          this.reportError(error, "p2p");
          readiness.wiredP2p.pending = 0;
          startupFailed = true;
        },
      );
      const stateStart = this.refreshRealtimeStates(generation, "startup").then((refreshed) => {
        if (!refreshed.refreshed) startupFailed = true;
      });
      await Promise.all([pushStart, ...mqttStarts, wiredStart, stateStart]);
      if (epoch !== this.realtimeEpoch) {
        push?.close();
        return this.settleRealtimeGeneration(generation, "superseded");
      }
      this.pushClient = push;
      this.schedulePoll();
      const failures = readiness.push.failed + readiness.mqtt.failed + readiness.wiredP2p.failed;
      this.settleRealtimeGeneration(generation, failures || startupFailed ? "partial" : "ready");
      this.scheduleStateRefresh(generation);
    } catch (e) {
      this.reportError(e, "realtime_startup");
      readiness.push.failed += readiness.push.pending;
      readiness.push.pending = 0;
      this.settleRealtimeGeneration(generation, epoch === this.realtimeEpoch ? "partial" : "superseded");
    }
  }

  /** Resolve a generation with an immutable count snapshot; later transport completions are ignored. */
  private settleRealtimeGeneration(generation: RealtimeGeneration, state: RealtimeReadiness["state"]): void {
    if (generation.settled) return;
    generation.settled = true;
    generation.readiness.state = state;
    generation.result = readinessSnapshot(generation.readiness);
    generation.resolve(generation.result);
  }

  /**
   * Snapshot of startup, scheduled and cloud-poll station sweeps; does not perform a read.
   * A success requires accepted parameters from every targeted station, including unchanged values.
   * It does not establish the age or completeness of any individual property. Empty or partial
   * responses cannot advance the successful-sweep timestamp. Evidence resets on disconnect.
   */
  getStateRefreshDiagnostics(): StateRefreshDiagnostics {
    const generation = this.realtimeGeneration;
    const active = generation?.epoch === this.realtimeEpoch && !generation.abort.signal.aborted;
    const retryAttempt = active ? Math.max(0, (generation.stateRefreshFailures ?? 0) - 2) : 0;
    const schedule = this.stateRefreshSchedule;
    return {
      ...this.stateRefreshEvidence,
      cloudPoll: this.getCloudPollDiagnostics(),
      recent: this.stateRefreshEvidence.recent.map((entry) => ({ ...entry })),
      operations: this.stateRefreshEvidence.operations.map((entry) => ({ ...entry })),
      lastOperationFailure: this.stateRefreshEvidence.lastOperationFailure
        ? { ...this.stateRefreshEvidence.lastOperationFailure }
        : null,
      schedules: this.stateRefreshEvidence.schedules.map((entry) => ({ ...entry })),
      active,
      inFlight: this.stateRefreshSweep?.epoch === this.realtimeEpoch,
      scheduledPaused:
        active &&
        (generation?.stateRefreshFailures ?? 0) >= 3 &&
        !this.stateRefreshTimer.pending &&
        this.stateRefreshSweep?.epoch !== this.realtimeEpoch,
      nextRetryAtMs:
        retryAttempt > 0 && this.stateRefreshTimer.pending && schedule && schedule.generation === generation
          ? schedule.nextRetryAtMs
          : null,
      retryAttempt,
      retryReason: retryAttempt > 0 && schedule && schedule.generation === generation ? schedule.reason : null,
      intervalMs: this.opts.rtc?.stateRefreshMs ?? 0,
      targetStations: new Set(
        this.registry
          .list()
          .filter(RtcCommandRouter.claimsDevice)
          .map((device) => device.sn),
      ).size,
    };
  }

  /** Passive actual connection stages and bounded terminal evidence across realtime resets. */
  getRtcConnectionDiagnostics() {
    return this.rtc.getConnectionDiagnostics();
  }

  /** Passive counters for bounded station-session replacement attempts. */
  getRtcSessionRefreshDiagnostics() {
    return this.rtc.getSessionRefreshDiagnostics();
  }

  /** Passive command-session keepalive counters without connection identifiers. */
  getRtcKeepaliveDiagnostics() {
    return this.rtc.getKeepaliveDiagnostics();
  }

  /** Passive bounded control-operation observations. */
  getRtcCommandDiagnostics() {
    return {
      ...this.rtc.getCommandDiagnostics(),
      lateEffect: this.lateEffects.diagnostics(),
      lateContrary: this.lateContrary.diagnostics(),
      commandHealth: this.commandHealth.diagnostics(),
    };
  }

  /** Passive bounded information-exchange observations. */
  getRtcReadDiagnostics() {
    return this.rtc.getReadDiagnostics();
  }

  /** Newest sanitized crop metadata from an existing idle station session; no acquisition or retry. */
  readRecentPersonCrops(stationSn: string, options: RecentPersonCropOptions = {}): Promise<RecentPersonCropResult> {
    return this.rtc.readRecentPersonCrops(stationSn, options);
  }

  /** Sanitized person roster from an existing idle station session; no acquisition or retry. */
  readStationPersonRoster(
    stationSn: string,
    options: StationPersonRosterOptions = {},
  ): Promise<StationPersonRosterResult> {
    return this.rtc.readStationPersonRoster(stationSn, options);
  }

  /** Passive target association for an already attempted command; does not allocate an association. */
  getRtcObservationContext(sn: string) {
    return this.rtc.getCommandTarget(sn);
  }

  /** Passive report counts and original arrival times; reports are not command acknowledgements. */
  getRtcObservationDiagnostics(): RtcObservationDiagnostics {
    return { lifecycle: this.realtimeEpoch, ...this.rtcObservationRecorder.diagnostics() };
  }

  /**
   * Refresh each supported station once, sharing its response with all attached devices. The current
   * generation owns cancellation; a failed station does not prevent another station from reporting.
   * Concurrent startup and poll requests join the same sweep instead of queueing duplicate reads.
   */
  private refreshRealtimeStates(
    generation: RealtimeGeneration,
    trigger: StateRefreshTrigger,
  ): Promise<StateRefreshResult> {
    this.rtc.preemptRecordingReads();
    const { epoch, abort } = generation;
    if (this.opts.autoRealtime === false || epoch !== this.realtimeEpoch || abort.signal.aborted)
      return Promise.resolve({ refreshed: true, retiredSession: false });
    if (this.stateRefreshSweep?.epoch === epoch) {
      const key =
        trigger === "startup" ? "startupJoins" : trigger === "scheduled" ? "scheduledJoins" : "cloudPollJoins";
      this.stateRefreshSweep.evidence[key]++;
      return this.stateRefreshSweep.promise;
    }
    generation.stateRefreshDeferrals = undefined;
    generation.stateRefreshPlaybackDeferrals = undefined;
    const evidence: StateRefreshSweepEvidence = {
      startedAtMs: Date.now(),
      finishedAtMs: 0,
      trigger,
      startupJoins: 0,
      scheduledJoins: 0,
      cloudPollJoins: 0,
      outcome: "failed",
      failure: null,
      parameters: 0,
    };
    const sweep = {
      epoch,
      promise: Promise.resolve({ refreshed: true, retiredSession: false }),
      evidence,
    };
    sweep.promise = Promise.resolve()
      .then(async () => {
        let refreshed = true;
        let retiredSession = false;
        let qualified = true;
        let failure: StateRefreshFailure | null = null;
        let parameters = 0;
        const stations = new Set(
          this.registry
            .list()
            .filter(RtcCommandRouter.claimsDevice)
            .map((device) => device.sn),
        );
        if (epoch !== this.realtimeEpoch || abort.signal.aborted) return { refreshed: false, retiredSession: false };
        if (stations.size) {
          this.stateRefreshEvidence.attempts++;
          this.stateRefreshEvidence.lastAttemptMs = Date.now();
        }
        for (const station of stations) {
          if (epoch !== this.realtimeEpoch || abort.signal.aborted) return { refreshed: false, retiredSession: false };
          try {
            const result = await (this.reportRefreshes.get(station)?.promise ??
              this.refreshAutomaticState(station, generation));
            if (epoch !== this.realtimeEpoch || abort.signal.aborted)
              return { refreshed: false, retiredSession: false };
            parameters += result.parametersUpdated;
            if (result.parametersUpdated === 0) {
              refreshed = false;
              qualified = false;
              failure ??= "empty_response";
            }
          } catch (error) {
            if (epoch !== this.realtimeEpoch || abort.signal.aborted)
              return { refreshed: false, retiredSession: false };
            refreshed = false;
            qualified = false;
            failure = stateRefreshFailure(error);
            retiredSession = consumeRetiredInformationRead(error) && stations.size === 1;
            this.reportError(error, "state_refresh");
          }
        }
        if (stations.size && epoch === this.realtimeEpoch && !abort.signal.aborted) {
          Object.assign(evidence, {
            finishedAtMs: Date.now(),
            outcome: qualified ? "success" : "failed",
            failure,
            parameters,
          });
          this.stateRefreshEvidence.recent.push({ ...evidence });
          if (this.stateRefreshEvidence.recent.length > 20) this.stateRefreshEvidence.recent.shift();
          this.stateRefreshEvidence.lastResponseParameters = parameters;
          if (qualified) {
            this.stateRefreshEvidence.successes++;
            this.stateRefreshEvidence.lastSuccessMs = Date.now();
          } else {
            this.stateRefreshEvidence.failures++;
            this.stateRefreshEvidence.lastFailureMs = Date.now();
            this.stateRefreshEvidence.lastFailureKind = failure ?? "other";
          }
        }
        return { refreshed, retiredSession };
      })
      .finally(() => {
        if (this.stateRefreshSweep === sweep) this.stateRefreshSweep = undefined;
      });
    this.stateRefreshSweep = sweep;
    return sweep.promise;
  }

  /**
   * Schedule one optional station-state sweep after the previous work completes. The generation owns
   * cancellation and the existing sweep coalesces overlapping cloud/startup requests. Failures delay
   * the next attempt exponentially. After three failures, retries start at thirty seconds and double
   * to five minutes, with up to one second of positive jitter below the cap. The configured interval
   * is always the minimum wait, including after a proven session retirement. Successful reads reset
   * the cadence. No property command or login is replayed here.
   */
  private scheduleStateRefresh(
    generation: RealtimeGeneration,
    reset = false,
    retiredSession = false,
    reason: StateRefreshDiagnostics["retryReason"] = "failure_backoff",
  ): void {
    const interval = this.opts.rtc?.stateRefreshMs ?? 0;
    if (
      interval === 0 ||
      this.opts.autoRealtime === false ||
      generation.epoch !== this.realtimeEpoch ||
      generation.abort.signal.aborted
    )
      return;
    if (reset) {
      generation.stateRefreshFailures = 0;
      generation.stateRefreshDeferrals = undefined;
    }
    const failures = generation.stateRefreshFailures ?? 0;
    const delayMs =
      failures >= 3
        ? Math.max(
            interval,
            Math.min(30_000 * 2 ** Math.min(failures - 3, 4) + Math.floor(Math.random() * 1_001), 300_000),
          )
        : failures === 1 && retiredSession
          ? interval
          : Math.min(interval * 2 ** failures, 600_000);
    const scheduledAtMs = Date.now();
    this.stateRefreshEvidence.schedules.push({
      scheduledAtMs,
      delayMs,
      consecutiveFailures: failures,
      reset,
    });
    if (this.stateRefreshEvidence.schedules.length > 20) this.stateRefreshEvidence.schedules.shift();
    const due = scheduledAtMs + delayMs;
    const schedule = {
      generation,
      nextRetryAtMs:
        Number.isSafeInteger(scheduledAtMs) && scheduledAtMs >= 0 && Number.isSafeInteger(due) ? due : null,
      reason: failures >= 3 ? reason : null,
    };
    this.stateRefreshSchedule = schedule;
    this.stateRefreshTimer.arm(delayMs, () => {
      if (this.stateRefreshSchedule === schedule) void this.runScheduledStateRefresh(generation);
    });
  }

  /**
   * Join an existing sweep before considering protection holds. Recovery retries yield to unfinished
   * renewal and active or queued station work without changing failure evidence. Each retry ordinal
   * allows two consecutive work deferrals or four while renewal is unfinished, sharing one count
   * across both reasons. The next opportunity submits the read to the normal station queue.
   * Aggregate work counters conservatively protect all stations; acquisition and cooldowns stay
   * router-owned. A real sweep, cadence reset or teardown clears the deferral count.
   * Complete the read before rearming; teardown and obsolete epochs cannot restart the timer.
   */
  private async runScheduledStateRefresh(generation: RealtimeGeneration): Promise<void> {
    if (generation.epoch !== this.realtimeEpoch || generation.abort.signal.aborted) return;
    const schedule = this.stateRefreshSchedule;
    const lifecycle = this.stateRefreshLifecycle;
    // Station work queued during a stored-playback capture aborts it, so the scheduled read waits for
    // the bounded capture to finish: 5 s steps, at most 60 s, without counting a failure.
    if (this.stateRefreshSweep?.epoch !== generation.epoch && this.rtc.playbackActive()) {
      const held = generation.stateRefreshPlaybackDeferrals ?? 0;
      if (this.rtc.playbackFullClipActive() || held < STATE_REFRESH_PLAYBACK_DEFERRALS) {
        generation.stateRefreshPlaybackDeferrals = held + 1;
        if (schedule?.nextRetryAtMs != null) schedule.nextRetryAtMs = Date.now() + STATE_REFRESH_PLAYBACK_DEFER_MS;
        this.stateRefreshTimer.arm(STATE_REFRESH_PLAYBACK_DEFER_MS, () => {
          if (this.stateRefreshSchedule === schedule && this.stateRefreshLifecycle === lifecycle)
            void this.runScheduledStateRefresh(generation);
        });
        return;
      }
    }
    const failuresAtStart = generation.stateRefreshFailures ?? 0;
    if (failuresAtStart >= 3 && this.stateRefreshSweep?.epoch !== generation.epoch) {
      const renewal = this.rtc.getSessionRefreshDiagnostics();
      const work = this.rtc.getCommandDiagnostics().schedulerTotals;
      const reason =
        renewal.attempts > renewal.successes + renewal.failures
          ? "session_recovery"
          : work.active > 0 || work.queued > 0
            ? "station_work"
            : null;
      const retryAttempt = failuresAtStart - 2;
      const deferrals =
        generation.stateRefreshDeferrals?.retryAttempt === retryAttempt ? generation.stateRefreshDeferrals.count : 0;
      const limit = reason === "session_recovery" ? 4 : 2;
      if (reason && deferrals < limit) {
        generation.stateRefreshDeferrals = { retryAttempt, count: deferrals + 1 };
        this.scheduleStateRefresh(generation, false, false, reason);
        return;
      }
    }
    let result: StateRefreshResult = { refreshed: false, retiredSession: false };
    try {
      result = await this.refreshRealtimeStates(generation, "scheduled");
    } catch (error) {
      this.reportError(error, "state_refresh");
    } finally {
      if (
        generation.epoch === this.realtimeEpoch &&
        !generation.abort.signal.aborted &&
        this.stateRefreshLifecycle === lifecycle &&
        (this.stateRefreshSchedule === schedule || result.refreshed)
      ) {
        generation.stateRefreshFailures = result.refreshed
          ? 0
          : Math.max(failuresAtStart + 1, generation.stateRefreshFailures ?? 0);
        this.scheduleStateRefresh(generation, false, result.retiredSession);
      }
    }
  }

  /**
   * Arm the next cloud-param poll. Re-arms from the END of each run rather than on a fixed interval,
   * so a slow list fetch can never stack overlapping polls, and re-arms in `finally` so a failed poll
   * (a transient cloud error) doesn't silently kill the loop for the session's remaining life.
   *
   * Disabled by `pollMs: 0`, and never started when `autoRealtime:false` — a host that opted out of
   * SDK-managed connectivity gets no background traffic. Also declines to re-arm once the bring-up
   * that armed it has been superseded, so a poll that fires as the client shuts down can't resurrect
   * the loop after teardown.
   */
  private schedulePoll(epoch = this.realtimeEpoch): void {
    const every = this.opts.pollMs ?? DEFAULT_POLL_MS;
    if (every <= 0 || epoch !== this.realtimeEpoch) return;
    this.pollTimer.arm(every, () => {
      this.cloudPollSchedule = undefined;
      void this.pollOnce(epoch).finally(() => this.schedulePoll(epoch));
    });
    try {
      const now = Date.now();
      const validTime = Number.isSafeInteger(now) && now >= 0;
      const due = now + every;
      this.cloudPollSchedule = {
        epoch,
        scheduledAtMs: validTime ? now : null,
        nextDueAtMs:
          validTime && Number.isSafeInteger(every) && every > 0 && every <= 2_147_483_647 && Number.isSafeInteger(due)
            ? due
            : null,
      };
    } catch {
      this.cloudPollSchedule = undefined;
    }
  }

  /** Detached scheduling evidence; stale epochs cannot supply due times or in-flight state. */
  private getCloudPollDiagnostics() {
    const configured = this.opts.pollMs ?? DEFAULT_POLL_MS;
    const intervalMs = Number.isSafeInteger(configured) && configured >= 0 ? configured : null;
    const pending = this.pollTimer.pending && this.cloudPollSchedule?.epoch === this.realtimeEpoch;
    const inFlight = this.cloudPollInFlight > 0;
    return {
      enabled: intervalMs !== null && intervalMs > 0 && (this.pollTimer.pending || inFlight),
      intervalMs,
      scheduledAtMs: pending ? this.cloudPollSchedule!.scheduledAtMs : null,
      nextDueAtMs: pending ? this.cloudPollSchedule!.nextDueAtMs : null,
      inFlight,
    };
  }

  /** The effective cloud poll interval in ms — the configured {@link EufyMegaOptions.pollMs} or the default. */
  get pollIntervalMs(): number {
    return this.opts.pollMs ?? DEFAULT_POLL_MS;
  }

  /**
   * Change the cloud poll interval at runtime; `ms` is the gap between polls, `0` disables polling.
   *
   * Takes effect immediately: the pending tick is cancelled and the loop re-armed at the new interval
   * (or left cancelled for `0`). Unlike the constructor {@link EufyMegaOptions.pollMs}, this can be
   * changed after login.
   */
  setPollInterval(ms: number): void {
    this.opts.pollMs = ms;
    this.pollTimer.cancel();
    this.cloudPollSchedule = undefined;
    this.schedulePoll();
  }

  /**
   * One poll pass: re-read the device list, land what moved on the live devices, announce every property
   * whose value changed, and emit a semantic event for every param that changed value since the last pass.
   *
   * `propertyChanged` is the generic channel this exists for: most readable members arrive only as a
   * cloud param and no push carries them, so re-reading was the only way a caller could learn one had
   * moved and re-reading cannot say WHEN. A capability's own `source:"poll"` mapping is beside it, for a
   * state that carries something a bare property change cannot (`contact.ts` maps the contact param as a
   * third transport for a state its push and its station notify also report).
   *
   * Each change is decoded against the reporting device's capabilities, the same argument the push path
   * passes: a param id claimed by more than one capability cannot be resolved without it, so a poll
   * event declared on a contested id would be declared and then silently never emitted.
   *
   * Also emits `deviceState` for each device the diff reports as having re-reported. That is tracked
   * apart from the param diff because the two are different facts: the cloud can re-stamp a param with
   * an unchanged VALUE, which is no state change to report but is fresh proof the device is alive. A
   * device absent from the previous pass is skipped — first sight is discovery, not a transition;
   * {@link deviceState} answers an initial reading.
   */
  private async pollOnce(epoch = this.realtimeEpoch): Promise<void> {
    const revision = this.realtimeReportRevision;
    if (epoch === this.realtimeEpoch) this.cloudPollInFlight++;
    try {
      const diff = await this.registry.pollChanges();
      this.reconcileStorageTelemetryOwners();
      if (epoch !== this.realtimeEpoch) return;
      const params = diff.params.filter((change) => {
        const device = this.liveDevices.get(change.deviceSn)?.deref();
        return !device || (this.realtimeParamIds.get(device)?.get(change.paramType) ?? 0) <= revision;
      });
      const reconciled = this.reconcilePolledReads(params);
      for (const dev of diff.added) this.emit("deviceAdded", dev);
      for (const dev of diff.removed) this.emit("deviceRemoved", dev);
      this.applyPolledParams(params);
      for (const change of params)
        for (const out of decodeCapabilityEvent({ source: "poll", ...change }, this.capsForEvent(change.deviceSn)))
          this.emitSemantic(out.event, out.payload, { refresh: out.refresh });
      for (const dev of diff.reported) this.emit("deviceState", this.stateOf(dev));
      for (const sn of new Set(params.map((change) => change.deviceSn)))
        if (!reconciled.has(sn)) await this.widenCapabilities(sn);
      const generation = this.realtimeGeneration;
      // During stored playback the held scheduled read covers this one.
      if (
        generation?.epoch === epoch &&
        !this.rtc.playbackActive() &&
        (await this.refreshRealtimeStates(generation, "cloud_poll")).refreshed
      )
        this.scheduleStateRefresh(generation, true);
    } catch (e) {
      this.reportError(e, "cloud_poll");
    } finally {
      if (epoch === this.realtimeEpoch) this.cloudPollInFlight = Math.max(0, this.cloudPollInFlight - 1);
    }
  }

  /**
   * Discover first cloud fields from the already refreshed roster, even when the registry correctly
   * reports no value transition. Re-resolve before landing changed values, so their named reads agree.
   * Only newly present cloud IDs are initialized here; realtime reports still outrank stale siblings.
   */
  private reconcilePolledReads(changes: readonly ParamChange[]): Set<string> {
    const reconciled = new Set<string>();
    for (const cached of this.registry.list()) {
      const dev = this.liveDevices.get(cached.sn)?.deref();
      if (!dev) continue;
      this.polledReads.set(dev, Symbol());
      const oldContext = this.readContexts.get(dev);
      const raw = (cached.raw ?? {}) as Record<string, unknown>;
      const station = stationOf(cached);
      const category = typeof raw.category === "string" ? cached.category : (oldContext?.category ?? cached.category);
      const reclassified =
        (cached.model !== undefined && cached.model !== oldContext?.model) ||
        (category !== undefined && category !== oldContext?.category);
      const rec: DeviceRecord = {
        deviceType:
          typeof raw.device_type === "number" ? raw.device_type : reclassified ? undefined : oldContext?.deviceType,
        model: cached.model ?? oldContext?.model,
        category,
        name: cached.name ?? oldContext?.name,
        parentSn:
          station !== cached.sn
            ? station
            : Object.hasOwn(raw, "parent_sn") || Object.hasOwn(raw, "station_sn")
              ? ""
              : oldContext?.stationSerial,
        params: cached.params ?? {},
        paramUpdatedAt: cached.paramUpdatedAt ?? {},
      };
      const previousNamespace = namespaceForCodec(dev.codec);
      const gained = dev.reresolve(rec);
      const switched = previousNamespace !== namespaceForCodec(dev.codec);
      if (switched) this.realtimeParamIds.delete(dev);
      const present = new Set(Object.keys(rec.params).map(Number));
      const ids = new Set([...(switched ? [] : (this.boundParamIds.get(cached.sn) ?? [])), ...present]);
      if (oldContext) {
        const ctx = this.contextForRecord(cached.sn, rec, rec.model ? this.dpCatalogCache.get(rec.model) : undefined);
        if (typeof raw.device_channel !== "number") ctx.channel = oldContext.channel;
        ctx.paramIds = ids;
        ctx.capabilities = new Set(dev.capabilities);
        const comparable = (value: CommandContext) => ({
          ...value,
          paramIds: [...value.paramIds].sort((a, b) => a - b),
          capabilities: value.capabilities ? [...value.capabilities].sort() : undefined,
        });
        if (!structuralEqual(comparable(oldContext), comparable(ctx))) {
          dev.bindActions(
            ctx,
            this.commandSinkFor(cached.sn),
            this.mediaProviderFor(cached.sn),
            this.ff09SettingsReaderFor(cached.sn, ctx),
            rawDpCodec,
          );
          this.readContexts.set(dev, ctx);
        }
      }
      const previous = switched ? new Set<number>() : (this.cloudParamIds.get(dev) ?? present);
      const realtime = this.realtimeParamIds.get(dev);
      const moved = new Set(
        changes.filter((change) => change.deviceSn === cached.sn).map((change) => change.paramType),
      );
      const initial: RawParams = {};
      const returning: RawParams = {};
      const known = switched ? undefined : this.boundParamIds.get(cached.sn);
      for (const id of present)
        if (!previous.has(id) && !realtime?.has(id) && !moved.has(id)) {
          const params = known?.has(id) ? returning : initial;
          params[id] = rec.params[id]!;
        }
      if (Object.keys(initial).length) dev.applyParams(initial);
      if (Object.keys(returning).length) this.applyAndAnnounce(dev, returning);
      this.cloudParamIds.set(dev, present);
      this.boundParamIds.set(cached.sn, ids);
      if (gained.length)
        this.emit("deviceCapabilities", { deviceSn: cached.sn, gained, capabilities: [...dev.capabilities] });
      reconciled.add(cached.sn);
    }
    return reconciled;
  }

  /**
   * Land a poll pass's CHANGES on every live {@link Device} and announce what moved, BEFORE anything
   * else derived from them is emitted.
   *
   * Ordered that way because live state is the map every capability getter reads: a listener reading a
   * getter inside a poll event handler has to see the value that event is about. The read-through
   * freshness policy cannot stand in for this — it fires on a READ of a stale value and hands that read
   * the stale one, so a value nothing happens to read is never refreshed by it.
   *
   * The CHANGES, not the whole post-change map {@link ParamChange} also carries. That map is there so an
   * event decode can read sibling params; applying it would revert every id a realtime report made
   * fresher, because {@link DeviceRegistry.applyRealtimeParams} keeps a report apart from the cloud
   * record's params — the cloud list carries the pre-report value long after the device volunteered the
   * new one, so an open door reads as closed on the next pass that sees anything on that device move.
   *
   * That precedence is the reason a moved id is also RETIRED from the report map
   * ({@link DeviceRegistry.retireRealtimeParams}). The report outranks the cloud only while it is the
   * fresher half, and a diff on that id is the cloud stating a transition of its own — so left in place
   * the report would outrank it forever, and the next join of the two halves would revert this pass's
   * value and announce the revert. Retired for EVERY device the diff touched, not only a live one: the
   * join also feeds the `Device` a later {@link getDevice} builds, which no live entry exists for yet.
   */
  private applyPolledParams(changes: readonly ParamChange[]): void {
    const byDevice = new Map<string, RawParams>();
    for (const change of changes) {
      const params = byDevice.get(change.deviceSn) ?? {};
      params[change.paramType] = change.to;
      byDevice.set(change.deviceSn, params);
    }
    const shadow: (() => void)[] = [];
    for (const [sn, params] of byDevice) {
      shadow.push(() => this.recordStateEvidence(sn, params, { source: "cloud_poll", receivedAtMs: null }));
      this.registry.retireRealtimeParams(sn, Object.keys(params).map(Number));
      const device = this.liveDeviceToAnnounce(sn);
      if (device) {
        for (const id of Object.keys(params).map(Number)) this.realtimeParamIds.get(device)?.delete(id);
        this.applyAndAnnounce(device, params, "recorded", shadow);
      }
    }
    this.finishShadow(shadow);
  }

  /**
   * The live {@link Device} for a serial, for a path that is about to ANNOUNCE against it — reporting
   * once when one the caller asked for has since been collected.
   *
   * An announcement carries the value read out of that device's own live state, so a collected device
   * cannot be announced for, and the caller is the only thing keeping one alive — {@link liveDevices} is
   * weak by contract. Losing announcements that way fails in the three worst ways at once: it is
   * non-deterministic (it turns on when the collector runs, so it holds in development and stops under
   * memory pressure), silent (no error, the events simply cease), and non-local (the obligation is on
   * {@link getDevice}, the symptom shows on `propertyChanged`).
   *
   * Neither alternative is available: re-deriving the value outside live state is two answers for one
   * reading, which is the disagreement the announcement exists to remove, and keeping every device alive
   * here reverses this map's own invariant. So it is LOUD.
   *
   * Reported only for a serial the caller DID ask for, since one never fetched has no object by definition
   * and was never owed an announcement — reporting those would name most of the account on every pass. The
   * dead entry is dropped as it is reported, which is what makes it once: a device let go on purpose must
   * not narrate every inbound signal for the rest of the session, and a later {@link getDevice} re-registers
   * the serial and resumes announcing.
   *
   * Deliberately not routed through {@link reportError}: nothing in this SDK failed, so it must not reach a
   * host's `error` handling. It is a usage fact, reported at `warn`.
   */
  private liveDeviceToAnnounce(sn: string): Device | undefined {
    const held = this.liveDevices.get(sn);
    if (!held) return undefined;
    const device = held.deref();
    if (device) return device;
    this.liveDevices.delete(sn);
    this.opts.logger?.warn?.(
      `[eufy] ${sn}: the Device handed to this caller has been garbage-collected, so its propertyChanged ` +
        `announcements have stopped. Keep a reference to every Device you want them for; getDevice(sn) resumes them.`,
    );
    return undefined;
  }

  /**
   * Apply a param map to one live {@link Device} and announce every property it moved, one
   * `propertyChanged` each. The one place the two halves are joined, shared by all three inbound paths
   * that reach live state.
   *
   * The device decides which of the changed names it will stand behind and what value each carries
   * ({@link Device.announcements}), so this stays a fan-out: no capability name, no member id, and no
   * second conversion of a wire value that could disagree with the getter beside it.
   *
   * Only a device a caller is HOLDING is announced for, because the announced value is read out of that
   * device's own live state and a serial nobody asked for has none. Resolving one on demand could not
   * help: a device built from the already-updated record has nothing to diff against, so the pass that
   * created it could never be the pass it announces. Such a device's liveness still reaches a host as
   * `deviceState`.
   *
   * Echoes of the SDK's own writes are announced rather than suppressed. An inbound path cannot tell a
   * change it caused from one an external actor caused, and suppressing on that guess is unsound, not
   * merely conservative: if a user also changes the value in the vendor app inside the window, the real
   * external change is the one lost — a wrong state held indefinitely, against one redundant idempotent
   * re-read.
   */
  private applyAndAnnounce(
    device: Device,
    params: RawParams,
    evidenceMode?: "recorded" | "cached",
    deferredShadow?: (() => void)[],
  ): void {
    const changed = device.applyParams(params);
    for (const change of device.announcements(changed))
      this.emitSemantic("propertyChanged", { deviceSn: device.sn, ...change });
    const shadow = deferredShadow ?? [];
    shadow.push(() => {
      if (evidenceMode !== "recorded")
        this.recordStateEvidence(device.sn, params, { source: "legacy_unknown", receivedAtMs: null }, true);
      const evidence = this.projectStateEvidence(device, params);
      for (const [property, record] of Object.entries(evidence))
        this.runShadow(() => this.emit("propertyEvidenceChanged", { deviceSn: device.sn, property, evidence: record }));
    });
    if (!deferredShadow) this.finishShadow(shadow);
  }

  /**
   * Re-resolve a device a caller is holding, in case fresher evidence granted it a capability.
   *
   * A capability is granted on evidence the device reports, so one resolved before it had reported a
   * param lacks the capability that param proves — permanently, for that object, even once the value
   * starts arriving. This closes the gap for the `Device` instances already handed out: on new
   * evidence they gain the accessor, bound, without the caller re-fetching.
   *
   * Only widens, never retracts, and re-binds only when something was actually gained, so the common
   * poll costs one set comparison. Best-effort: a device that has been dropped, or a re-bind that
   * fails, must not break the poll loop for every other device.
   *
   * The whole record goes in, never a field-by-field copy of it: since this path only ever ADDS, a
   * field left behind here re-grants what the first resolution deliberately withheld — an attached
   * camera would take back the hub's guard mode on the first param change the poll saw.
   */
  private async widenCapabilities(sn: string): Promise<void> {
    const dev = this.liveDevices.get(sn)?.deref();
    if (!dev) return;
    try {
      const gained = dev.reresolve(await this.registry.record(sn));
      if (!gained.length) return;
      const ctx = await this.commandContext(sn);
      dev.bindActions(
        ctx,
        this.commandSinkFor(sn),
        this.mediaProviderFor(sn),
        this.ff09SettingsReaderFor(sn, ctx),
        rawDpCodec,
      );
      this.boundParamIds.set(sn, ctx.paramIds);
      this.emit("deviceCapabilities", { deviceSn: sn, gained, capabilities: [...dev.capabilities] });
    } catch (e) {
      this.reportError(e, "state_refresh");
    }
  }

  /**
   * Open the P2P session for ONE device's station, and nothing else.
   *
   * Auto-realtime warms every wired station on the account, which is what a host driving a
   * fleet wants. A caller that needs exactly one station does not: an unreachable station broadcasts a
   * local lookup to `255.255.255.255` **once a second for the full connect timeout** and sends a PPCS
   * lookup to every cloud address in the same tick, so warming a fleet to talk to one camera is a
   * burst of broadcast and NAT churn on the user's network for stations nobody asked about. Pair this
   * with `autoRealtime: false` to open only what is being used.
   *
   * Resolves when the station is connected; rejects on its connect timeout. Best-effort and idempotent
   * — an already-open session resolves immediately.
   */
  async connectStation(deviceSn: string, signal?: AbortSignal): Promise<void> {
    if (!this.registry.list().length) await this.getDevices();
    await this.p2p.ensureStation(this.p2p.stationKeyOf(deviceSn), signal);
  }

  /** Eagerly open P2P sessions for WIRED stations only (persistent — they don't drain). Battery
   *  stations stay closed until an on-demand open. Best-effort per station. */
  private async warmWiredP2P(
    readiness = createPlaneReadiness(),
    signal?: AbortSignal,
  ): Promise<RealtimePlaneReadiness> {
    const wired = new Set<string>();
    const devices = this.registry.list();
    for (const d of this.registry.p2pDevices()) {
      const key = this.p2p.stationKeyOf(d.sn);
      const station = devices.find((device) => device.sn === key);
      if (station && RtcCommandRouter.claimsDevice(station)) continue;
      if (this.stationPower(key) === "wired") wired.add(key);
    }
    readiness.required = wired.size;
    readiness.pending = wired.size;
    await Promise.all(
      [...wired].map((sn) =>
        this.p2p.ensureStation(sn, signal).then(
          () => {
            readiness.ready++;
            readiness.pending--;
          },
          (_error) => {
            if (signal?.aborted) return;
            readiness.failed++;
            readiness.pending--;
          },
        ),
      ),
    );
    return readiness;
  }

  /**
   * A station's power tier for the P2P lifecycle: a HomeBase/station is `"wired"` (persistent); a
   * standalone device uses {@link cameraPowerTier}, including its mains-only model evidence.
   * Keyed on the STATION's own power, never a child's (a battery cam attached to a wired HomeBase draws
   * from the base's persistent session). Reads capabilities on the client side — no model type leaks to
   * transport (the router only ever sees the `"wired"|"battery"` string).
   */
  private stationPower(parentSn: string): PowerTier {
    const d = this.registry.list().find((x) => x.sn === parentSn);
    if (!d) return "wired";
    if (d.deviceClass === "homebase") return "wired";
    const raw = (d.raw ?? {}) as Record<string, any>;
    const caps = resolveDevice({
      deviceType: typeof raw.device_type === "number" ? (raw.device_type as number) : undefined,
      model: d.model,
      category: d.category,
      params: d.params ?? {},
    }).capabilities;
    return cameraPowerTier(d.model, new Set(caps));
  }

  /**
   * Speculatively open the P2P session of the station behind `deviceSn`, if the caller opted this
   * semantic event in — so a stream or talkback opened right after a doorbell ring or a detection starts
   * warm instead of paying a cold open.
   *
   * Four gates. `autoRealtime: false` means the SDK opens nothing on its own initiative at all;
   * {@link EufyMegaOptions.prewarmEvents} must name the event, and it names none by default, which is
   * what makes pre-warm opt-in; the station must be one the account actually reports; and its power tier
   * must be one {@link EufyMegaOptions.prewarmTiers} allows.
   *
   * The tier is resolved for the STATION whose session would open, which is why an attached camera is
   * judged by its base — {@link P2PCommandRouter.stationKeyOf} is the single source of that mapping, and
   * {@link stationPower} of the tier. A station with no record of its own is declined rather than
   * pre-warmed: {@link stationPower} answers `"wired"` for one it cannot find, because the tier it feeds
   * the session lifecycle must always be an answer — and taking that answer here is how a battery camera
   * gets pre-warmed under a `"wired"`-only opt-in.
   *
   * Best-effort and unawaited: a pre-warm nobody uses must cost the caller nothing, so a failed open
   * surfaces on `error` like any other background transport failure.
   */
  private prewarmForEvent(event: string, deviceSn: string): void {
    if (this.opts.autoRealtime === false) return;
    if (!this.prewarmEvents.has(event)) return;
    const station = this.p2p.stationKeyOf(deviceSn);
    if (!this.registry.list().some((device) => device.sn === station)) return;
    if (!this.prewarmTiers.has(this.stationPower(station))) return;
    void this.p2p.prewarm(station, this.opts.prewarmMs);
  }

  /**
   * Connect a secure-MQTT transport for one credential scope (appliances: vacuum, light, plug,
   * display) using credentials fetched from the cloud, and return it **connected but not installed**:
   * {@link ensureMqttStarted} owns installing it, subscribing devices, and the epoch check, so that
   * lifecycle lives in exactly one place. Only ever called through {@link ensureMqttStarted}.
   *
   * Identified by a client id built from this client's `openudid`, not by the certificate's name:
   * that name is `{user_id}-{app_name}`, which every client on the account shares per line, and a
   * duplicate client id is a takeover the broker resolves by evicting the incumbent. The id shape is
   * the app's own (`android-{app_name}-{uid}-{uuid}-{ts}`, see {@link buildAppShapedClientId}), which
   * the broker grants on the `eufy_security` credential.
   *
   * It separates two clients exactly as far as their `openudid` does: a caller that supplies none
   * gets the value derived from the account, which every such client shares — the same condition
   * under which their logins already displace each other (`MegaClientConfig.openudid`).
   *
   * A client id the broker REFUSES falls back to the certificate's name, since a shared channel beats
   * none, and that transport then keeps that name until {@link disconnect}. Only a refusal: a connect
   * that fails for any other reason rejects the bring-up, which clears its memo in
   * {@link ensureMqttStarted} so the next one asks under this client's own id again — a dropped
   * socket must not be what moves a process onto the shared name for good.
   */
  private async startMqtt(scope: MqttScope): Promise<SecureMqtt> {
    const auth = this.mega.auth;
    if (!auth) throw new Error("login() first");
    if (!this.registry.list().length) await this.getDevices();

    const creds = await this.getUserMqttInfo(mqttAppName(scope));
    const ownClientId = buildAppShapedClientId({
      appName: creds.app_name ?? mqttAppName(scope) ?? "eufy_mega",
      uid: creds.user_id ?? auth.userId,
      mqttUuid: mqttUuidFrom(this.mega.openudid),
    });
    try {
      return await this.connectMqtt(creds, ownClientId);
    } catch (e) {
      if (!isNotAuthorized(e)) throw e;
      this.opts.logger?.warn(
        "[smqtt] the broker refused this client's own id; connecting under the certificate's name, which " +
          "another client signed in to this account takes over",
        e,
      );
      return await this.connectMqtt(creds);
    }
  }

  /**
   * Connect one secure-MQTT transport under `clientId`, or under the certificate's own name when it is
   * omitted, and wire its decode and fan-out. See {@link startMqtt} for which id is used and why.
   *
   * The fan-out is wired once the connection stands, so an attempt that is discarded — a client id the
   * broker refuses, a socket that dies mid-handshake — never reports a connection a consumer never had;
   * the connect it just completed is announced here instead. Errors raised while connecting are held
   * only to keep an emitter without an `error` listener from throwing, and are reported once the
   * transport is one a consumer owns.
   *
   * The inbound decode is gated by the reporting device's own capabilities, so one line's decoder never
   * runs against another's traffic, and the DP frame is unwrapped here — the layer that may import the
   * transport — so a capability reads tags without owning any framing.
   */
  private async connectMqtt(creds: SecureMqttCredentials, clientId?: string): Promise<SecureMqtt> {
    const transport = new SecureMqtt({ credentials: creds, clientId, logger: this.opts.logger });

    const whileConnecting: unknown[] = [];
    const hold = (e: unknown): void => void whileConnecting.push(e);
    transport.on("error", hold);
    await transport.connect();
    transport.off("error", hold);

    transport.on("connect", () => this.emit("connect"));
    transport.on("disconnect", (r) => this.emit("disconnect", r));
    transport.on("message", (m) => {
      this.emit("message", m); // raw MQTT message (low-level escape hatch)
      if (m.deviceSn) {
        const dev = this.registry.list().find((d) => d.sn === m.deviceSn);
        if (dev?.category === "eufy_home_tuya") {
          const dps = parseTuyaDpReport(m.raw);
          if (dps) {
            this.tuyaDpRouter.deliver(m.deviceSn, dps);
            return;
          }
        }
      }
      if (m.deviceSn) {
        // The map stream. A protocol-41 message is nothing else, so it stops here rather than being
        // walked by DP parsers that would each correctly decline it.
        const frame = parseBizMapFrame(m.raw);
        if (frame) {
          this.emit("mapFrame", { deviceSn: m.deviceSn, frame });
          this.applyMapFrame(m.deviceSn, frame);
          return;
        }
      }
      if (m.topic) this.processAvailabilityMessage(m.topic, m.raw);
      const signal = {
        source: "mqtt" as const,
        deviceSn: m.deviceSn,
        topic: m.topic,
        raw: m.raw,
        frame: parseDpMessage(m.raw),
        dpParams: parseAiotDpReport(m.raw),
      };
      const caps = m.deviceSn ? this.capsForEvent(m.deviceSn) : undefined;
      this.applyRealtimeReport(m.deviceSn, decodeCapabilityState(signal, caps));
      for (const out of decodeCapabilityEvent(signal, caps))
        this.emitSemantic(out.event, out.payload, { edge: true, refresh: out.refresh });
    });
    transport.on("error", (e) => this.reportError(e, "mqtt"));

    this.emit("connect");
    for (const e of whileConnecting) this.reportError(e, "mqtt");
    return transport;
  }

  /**
   * Subscribe the devices on one credential scope; a failing subscribe is reported, not fatal (one
   * unreachable device must not stop the rest of the roster from coming up).
   */
  private async subscribeMqttDevices(scope: MqttScope, transport: SecureMqtt): Promise<void> {
    for (const d of this.getMqttDevices().filter((dev) => mqttScopeFor(dev) === scope)) {
      try {
        await transport.subscribeDevice(d);
        await this.sendRealtimeInit(d.sn);
        // For Tuya clean-line devices, poll cached DPs immediately after subscribe so the
        // capability getters have state before the first realtime push arrives.
        if (d.category === "eufy_home_tuya") {
          this.tuya
            .fetchDps(d.sn)
            .then((dps) => {
              if (dps) this.tuyaDpRouter.deliver(d.sn, dps);
            })
            .catch((e) => this.reportError(e, "state_refresh"));
        }
      } catch (e) {
        this.reportError(e, "realtime_subscription");
      }
    }
  }

  /**
   * Send whatever a device's capabilities want sent once its realtime channel is up — for a line whose
   * state is pushed on change with no heartbeat, the request that makes its state readable before the
   * first write. Best-effort: reported, never fatal, since a device that ignores it is only left with
   * the state it would have had anyway.
   */
  private async sendRealtimeInit(sn: string): Promise<void> {
    const caps = this.registry.capabilitiesForDevice(sn);
    if (!caps || !needsRealtimeInit(caps)) return;
    const cmds = buildRealtimeInit(caps, await this.commandContext(sn));
    if (!cmds.length) return;
    const sink = this.commandSinkFor(sn);
    for (const cmd of cmds) await sink.dispatch(cmd);
  }

  /**
   * The open P2P sessions, by key. P2P is auto-managed: wired stations are warmed at login, battery
   * stations open on demand (command / stream, or an opted-in event pre-warm) and idle-detach — so this
   * map grows and shrinks over time.
   *
   * A station's own session is keyed by its serial, and `p2pConnect(stationSn)` / `p2pClose(stationSn)`
   * track those. A station serving more than one camera at once also holds a session per extra camera,
   * keyed `<stationSn>#live:<channel>` — these carry media alone and raise no connection events, because
   * a station announces its state to every client that connects and reporting each copy would double
   * every event the station's own session already delivers.
   */
  getP2pSessions(): Map<string, P2PSession> {
    return this.p2p.getSessions();
  }

  /**
   * The liveness facts for one device — see {@link DeviceState}. Facts, not an `online` verdict: "how
   * long is too long" is a threshold that belongs to the caller, and it differs per device class.
   *
   * The `deviceState` event announces when a device reports in.
   */
  deviceState(sn: string): DeviceState {
    const dev = this.registry.list().find((d) => d.sn === sn);
    return dev ? this.stateOf(dev) : { sn, stationSn: this.p2p.stationKeyOf(sn) };
  }

  /**
   * Return the latest explicit availability observation for `sn`, or `undefined` when no verified
   * vendor signal has been observed. This never derives a state from {@link DeviceState.lastSeenMs},
   * connection silence, P2P lifecycle, operation failures or caller-selected timeouts.
   */
  deviceAvailability(sn: string): AvailabilityObservation | undefined {
    return this.availabilityObservations.get(sn);
  }

  /** Decode a verified wire signal, then assign its device-availability semantics at the client seam. */
  private processAvailabilityMessage(topic: string, raw: unknown): void {
    const signal = parseStateInfoSignal(topic, raw);
    if (!signal) return;
    this.applyAvailabilityObservation({
      entity: { kind: "device", sn: signal.deviceSn },
      availability: signal.status ? "available" : "unavailable",
      source: { transport: "smqtt", signal: "state-info" },
      scope: "device",
      ...(signal.observedAt === undefined ? {} : { observedAt: signal.observedAt }),
      ...(signal.sequence === undefined ? {} : { sequence: signal.sequence }),
      receivedAt: Date.now(),
    });
  }

  /**
   * Retain one authoritative observation per device and emit only state transitions. When both the
   * previous and incoming envelopes supply ordering evidence, an older message cannot overwrite newer
   * device truth. Exact duplicate ordering cannot reverse state. If comparable vendor ordering is
   * absent, handler arrival order defines which explicit observation is later. A same-state observation
   * still refreshes the retained evidence without re-emitting.
   */
  private applyAvailabilityObservation(observation: AvailabilityObservation): void {
    const sn = observation.entity.sn;
    const previous = this.availabilityObservations.get(sn);
    if (previous) {
      const sameSource =
        previous.source.transport === observation.source.transport &&
        previous.source.signal === observation.source.signal;
      const bothTimed = previous.observedAt !== undefined && observation.observedAt !== undefined;
      if (bothTimed && observation.observedAt! < previous.observedAt!) return;
      if (sameSource && (!bothTimed || observation.observedAt === previous.observedAt)) {
        if (
          previous.sequence !== undefined &&
          observation.sequence !== undefined &&
          observation.sequence < previous.sequence
        ) {
          return;
        }
        if (
          previous.sequence !== undefined &&
          observation.sequence === previous.sequence &&
          observation.availability !== previous.availability
        ) {
          return;
        }
      }
    }

    this.availabilityObservations.set(sn, observation);
    if (previous?.availability !== observation.availability) this.emit("availability", observation);
  }

  /**
   * The {@link DeviceState} for a device record already in hand — the shape {@link deviceState} returns
   * once it has resolved the serial, reused by the poll loop so emitting for a batch of devices doesn't
   * re-scan the roster per device.
   */
  private stateOf(dev: EufyDevice): DeviceState {
    return { sn: dev.sn, stationSn: this.p2p.stationKeyOf(dev.sn), lastSeenMs: dev.lastSeenMs };
  }

  /**
   * The capability set to disambiguate an inbound push/poll id with, or `undefined` when the serial is
   * unknown. Push ids are namespaced per device family, so the same integer means different things on
   * different hardware; `decodeEvent` needs the device's capabilities to pick the right mapping and
   * deliberately stays silent rather than guessing when it can't.
   */
  private capsForEvent(deviceSn: string | undefined): ReadonlySet<Capability> | undefined {
    return deviceSn ? this.registry.capabilitiesForDevice(deviceSn) : undefined;
  }

  /**
   * **Write** a device property. Asks the capability modules to build the command for this
   * `(name, value)` — the module owns how THIS device applies it. No `(name, value)` recipe → the
   * device doesn't support the property, so we throw {@link CapabilityNotSupportedError} rather than
   * a silent no-op. On success the device echoes the new state back as a param update — read it with
   * {@link getDevice} to confirm.
   *
   * @param sn device serial.
   * @param name property name (e.g. "light", "brightness", "enabled").
   * @param value desired value.
   *
   * @example
   * ```ts
   * await eufy.setProperty(sn, "brightness", 50);
   * await eufy.setProperty(sn, "light", true);
   * ```
   */
  async setProperty(sn: string, name: string, value: boolean | number | string): Promise<void> {
    await this.executeProperty(sn, name, value);
  }

  /** Execute one property invocation and return its own immutable transport receipt. */
  async setPropertyWithReceipt(
    sn: string,
    name: string,
    value: boolean | number | string,
    options: PropertyExecutionOptions = {},
  ): Promise<CommandReceipt> {
    return this.executeProperty(sn, name, value, options);
  }

  /** Dispatch once and return temporal-only report ownership for this requested guard mode. */
  async setGuardModeWithReceipt(
    sn: string,
    value: boolean | number | string,
    intentGeneration?: string,
    options: { signal?: AbortSignal } = {},
  ) {
    return this.executeGuardProperty(
      sn,
      value,
      intentGeneration,
      async (guard) => {
        await this.executePreparedProperty(sn, "armingMode", value, undefined, undefined, guard);
      },
      options.signal,
    );
  }

  private async executeGuardProperty(
    sn: string,
    value: boolean | number | string,
    caller: string | undefined,
    dispatch: (guard: GuardOperation) => Promise<void>,
    signal?: AbortSignal,
  ) {
    const request = guardModeRequest(value);
    if (!request) throw new Error("invalid requested guard mode");
    if (caller !== undefined && (typeof caller !== "string" || !/^[A-Za-z0-9_-]{1,64}$/.test(caller)))
      throw new Error("invalid guard intent generation");
    const station = this.registry.list().find((row) => row.sn === sn)?.stationSn || sn;
    const guard = this.guardOwner().begin(sn, station, request.param, request.requestedMode, caller);
    return this.guardOwner().run(
      guard,
      async () => {
        try {
          await dispatch(guard);
        } catch (error) {
          this.guardOwner().finish(guard, "not_reported", "transport_uncertain");
          throw error;
        }
      },
      signal,
    );
  }

  /** Cache-only recovery, current runtime only; never dispatches a command. */
  getGuardConfirmation(handle: string) {
    return this.guardOwner().get(handle);
  }
  getGuardConfirmationDiagnostics() {
    return this.guardOwner().diagnostics();
  }

  /** Cache-only, observe-only assessment of this camera's connectivity evidence. */
  cameraHealth(sn: string) {
    return this.cameraHealthIngress.status(sn);
  }

  /** Last suppressed signal receipt only; no cache preparation or device work is performed. */
  getRssiSuppressionDiagnostics(sn: string) {
    return this.cameraHealthIngress.rssiSuppression(sn);
  }

  /** Passive local automatic-send permission; neither a read nor proof of device availability. */
  propertyCommandHealth(sn: string, property: string) {
    return this.commandHealth.status(sn, property);
  }

  /** Verify a current observation; explicit resume permits fresh session acquisition without replay. */
  async confirmLateContraryEffect(
    sn: string,
    intent: number,
    options: { signal?: AbortSignal; resumeSession?: boolean } = {},
  ) {
    return this.lateContrary.confirm(sn, intent, options.signal, options.resumeSession === true);
  }

  /** Release socket-owned observation without creating a command or acquiring a session. */
  cancelLateContraryEffect(sn: string, intent: number): void {
    this.lateContrary.cancel(sn, intent);
  }

  /** Atomic cached roster and its inventory quality; performs no network work. */
  getInventorySnapshot() {
    return this.registry.inventorySnapshot();
  }
  async getDevicesWithInventory() {
    const devices = await this.getDevices();
    return { devices, inventoryEvidence: this.registry.evidenceFor(devices) };
  }
  getInventoryErrorDiagnostics() {
    return this.registry.getInventoryErrors();
  }

  /** Sanitized physical cloud POST observations; this getter starts no work. */
  getCloudHttpDiagnostics() {
    return this.mega.getCloudHttpDiagnostics();
  }

  /** Invocation-local preparation only, ending before the selected transport's own stages. */
  getPropertyPreparationDiagnostics(): PropertyPreparationDiagnostics {
    return this.propertyPreparationRecorder.diagnostics();
  }

  /** Observe preparation without changing the property invocation's outcome or transport policy. */
  private async executeProperty(
    sn: string,
    name: string,
    value: boolean | number | string,
    options?: PropertyExecutionOptions,
  ): Promise<CommandReceipt> {
    const observation = this.propertyPreparationRecorder.begin(name === "armingMode" ? "guard_mode" : "other");
    try {
      if (name === "armingMode") {
        let commandReceipt: CommandReceipt | undefined;
        await observation.run(() =>
          this.executeGuardProperty(
            sn,
            value,
            undefined,
            async (guard) => {
              commandReceipt = await this.executePreparedProperty(sn, name, value, options, observation, guard);
            },
            options?.signal,
          ),
        );
        return commandReceipt ?? Object.freeze({ status: "acknowledged", sendAttempted: false, effect: "unconfirmed" });
      }
      return await observation.run(() => this.executePreparedProperty(sn, name, value, options, observation));
    } finally {
      observation.finish("failed");
    }
  }

  /** Preparation and dispatch share invocation ordering and one frozen profile lifetime. */
  private async executePreparedProperty(
    sn: string,
    name: string,
    value: boolean | number | string,
    options?: PropertyExecutionOptions,
    observation?: PropertyPreparationObservation,
    guard?: GuardOperation,
  ): Promise<CommandReceipt> {
    const ordinal = this.commandIntents.allocate();
    const bornAtMs = performance.now();
    const wallAtEntry = Date.now();
    const invocation: PropertyInvocation = {
      ordinal,
      guard,
      receiptRequested: options !== undefined || guard !== undefined,
      preparation: observation,
    };
    const terminal = (status: CommandReceipt["status"]): CommandReceipt => {
      const receipt: CommandReceipt = invocation.execution
        ? this.rtc.recordUnsentReceipt(status, invocation.execution)
        : Object.freeze({ status, sendAttempted: false, effect: "unconfirmed", intent: ordinal });
      this.cameraHealthIngress.command(sn)?.finish(receipt);
      return receipt;
    };
    if (options?.profile !== undefined && options.profile !== "bounded-state-v1") return terminal("validation_failed");
    if (options?.automatic !== undefined && typeof options.automatic !== "boolean")
      return terminal("validation_failed");
    if ((options?.automatic === true || options?.correction === true) && options?.profile !== "bounded-state-v1")
      return terminal("validation_failed");
    if (
      options?.correctionExpiresAtMs !== undefined &&
      (options.correction !== true ||
        options.profile !== "bounded-state-v1" ||
        !Number.isFinite(options.correctionExpiresAtMs) ||
        options.correctionExpiresAtMs <= 0 ||
        options.correctionExpiresAtMs > wallAtEntry + 600_000)
    )
      return terminal("validation_failed");
    let controller: AbortController | undefined;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let rejectPreparation: (() => void) | undefined;
    const epoch = this.realtimeEpoch;
    if (options?.profile) {
      const remaining = options.remainingBudgetMs ?? 72_000;
      const expiry = options.callerExpiresAtMs ?? wallAtEntry + remaining;
      const uncertainty = options.clockUncertaintyMs ?? 0;
      if (
        ![remaining, expiry, uncertainty].every(Number.isFinite) ||
        remaining <= 0 ||
        remaining > Number.MAX_SAFE_INTEGER ||
        expiry <= 0 ||
        expiry > Number.MAX_SAFE_INTEGER ||
        uncertainty < 0 ||
        uncertainty > 1_000
      )
        return terminal("validation_failed");
      const totalByMs = bornAtMs + Math.min(72_000, remaining, expiry - wallAtEntry - uncertainty);
      invocation.execution = {
        profile: options.profile,
        bornAtMs,
        sendByMs: Math.min(
          bornAtMs + 60_000,
          totalByMs - 12_000,
          bornAtMs + (options.correctionExpiresAtMs ?? Infinity) - wallAtEntry - uncertainty,
          options.correctionExpiresAtMs === undefined
            ? Infinity
            : (this.lateContrary.correctionDeadline(sn, value) ?? bornAtMs),
        ),
        totalByMs,
        wallExpiresAtMs: Math.min(expiry, options.correctionExpiresAtMs ?? Infinity),
        clockUncertaintyMs: uncertainty,
        wallOffsetMs: wallAtEntry - bornAtMs,
        intent: ordinal,
        origin: options.correction === true ? "correction" : "caller",
        automatic: options.automatic === true || options.correction === true,
      };
      if (this.propertyPreparations.size >= 1_024) return terminal("queue_full");
      if (invocation.execution.sendByMs <= bornAtMs) return terminal("expired_before_send");
      controller = new AbortController();
      this.propertyPreparations.add(controller);
      invocation.execution = {
        ...invocation.execution,
        signal: options.signal ? AbortSignal.any([controller.signal, options.signal]) : controller.signal,
      };
    } else {
      if (this.propertyPreparations.size >= 1_024) throw new Error("command preparation capacity exhausted");
      controller = new AbortController();
      this.propertyPreparations.add(controller);
    }
    const preparationSignal = invocation.execution?.signal ?? controller.signal;
    const preparationByMs = invocation.execution?.sendByMs ?? Math.min(bornAtMs + 60_000, guard?.deadline ?? Infinity);
    try {
      preparationSignal?.throwIfAborted();
      observation?.mark("command_context");
      const preparation = this.commandContext(sn);
      const ctx = await Promise.race([
        preparation,
        new Promise<never>((_, reject) => {
          rejectPreparation = () => reject(new Error("command preparation cancelled"));
          preparationSignal?.addEventListener("abort", rejectPreparation, { once: true });
          timer = setTimeout(
            () => reject(new Error("command preparation expired")),
            Math.max(0, Math.ceil(preparationByMs - performance.now())),
          );
        }),
      ]);
      clearTimeout(timer);
      if (rejectPreparation) preparationSignal?.removeEventListener("abort", rejectPreparation);
      if (epoch !== this.realtimeEpoch) {
        if (options?.profile) return terminal("closed_before_send");
        throw new Error("command preparation interrupted");
      }
      invocation.execution?.signal?.throwIfAborted();
      if (!invocation.execution && performance.now() >= preparationByMs) throw new Error("command preparation expired");
      if (invocation.execution && performance.now() >= invocation.execution.sendByMs)
        return terminal("expired_before_send");
      if (guard && !this.guardOwner().current(guard)) return terminal("superseded_before_send");
      observation?.mark("command_build");
      const cmd = buildCapabilityCommand(name, value, ctx);
      if (!cmd) throw new CapabilityNotSupportedError(sn, name);
      if (invocation.execution) {
        const observation = commandObservation(cmd);
        if (
          !this.rtcDevice(sn) ||
          !observation?.replaceableState ||
          !observation.lateEffectReadback ||
          !observation.passiveReadback ||
          typeof value !== "boolean"
        )
          return terminal("validation_failed");
        invocation.execution = { ...invocation.execution, preparationWaitMs: performance.now() - bornAtMs };
      }
      if (options?.correction === true) this.lateContrary.prepareCorrection(sn, ordinal, value);
      observation?.mark("dispatch_preparation");
      await this.commandSinkFor(sn, invocation).dispatch(cmd);
      if (invocation.receipt && !invocation.transportAttempted)
        this.cameraHealthIngress.command(sn)?.finish(invocation.receipt);
      return (
        invocation.receipt ??
        Object.freeze({ status: "acknowledged", sendAttempted: true, effect: "unconfirmed", intent: ordinal })
      );
    } catch (error) {
      if (!options?.profile) throw error;
      if (invocation.transportAttempted)
        return Object.freeze({
          status:
            epoch !== this.realtimeEpoch
              ? "closed_after_send"
              : invocation.execution?.signal?.aborted
                ? "cancelled_after_send"
                : "ack_timeout",
          sendAttempted: true,
          effect: "unknown",
          intent: ordinal,
        });
      if (epoch !== this.realtimeEpoch) return terminal("closed_before_send");
      if (invocation.execution?.signal?.aborted) return terminal("cancelled_before_send");
      if (invocation.execution && performance.now() >= invocation.execution.sendByMs)
        return terminal("expired_before_send");
      return terminal("validation_failed");
    } finally {
      this.lateContrary.finishCorrection(sn, ordinal);
      clearTimeout(timer);
      if (rejectPreparation) preparationSignal?.removeEventListener("abort", rejectPreparation);
      if (controller) this.propertyPreparations.delete(controller);
    }
  }

  /**
   * Restart a HomeBase.
   *
   * **HomeBases only** — restart is a hub operation, so a non-HomeBase serial (a camera, an NVR)
   * throws rather than doing nothing. The hub drops its connection and returns after a minute or two,
   * so everything behind it is briefly offline. Verified on real hardware.
   */
  async reboot(sn: string): Promise<void> {
    const ctx = await this.commandContext(sn);
    if (!isHomeBase({ deviceType: ctx.deviceType, model: ctx.model })) {
      throw new Error(
        `reboot: ${sn} is not a HomeBase (deviceType ${ctx.deviceType ?? "?"}, model ${ctx.model ?? "?"}) — ` +
          `restart is a hub-only operation`,
      );
    }
    await this.p2p.rebootStation(sn);
  }

  /**
   * Build the {@link CommandContext} for a device: the evidence a capability uses to resolve a
   * command variant (channel, codec, deviceType, model, reported param/DP ids) plus the RESOLVED
   * capability set that gates command building.
   *
   * Resolves from the same fresh `DeviceRegistry.record` (`get_device_param_list` overlay +
   * category) and `resolveDevice` that {@link getDevice} uses, so the capability set here is byte-for-byte
   * what `device.has(cap)` / `buildActions` saw — a command is never rejected for a capability the
   * device model advertises.
   *
   * `paramIds` is cloud params UNION whatever the device reported over realtime — it is the evidence
   * gate behind the typed read getters, so a line whose state only ever arrives live still advertises
   * exactly the reads it has.
   */
  private async fetchDpCatalog(model: string): Promise<DpCatalog> {
    const cached = this.dpCatalogCache.get(model);
    if (cached) return cached;
    try {
      const raw = await this.mega.getProductDataPoint(model);
      const catalog = parseDpCatalog(raw);
      this.dpCatalogCache.set(model, catalog);
      return catalog;
    } catch {
      this.dpCatalogCache.set(model, EMPTY_DP_CATALOG);
      return EMPTY_DP_CATALOG;
    }
  }

  private async commandContext(sn: string, known?: DeviceRecord): Promise<ReadContext> {
    const rec = known ?? (await this.registry.record(sn));
    const resolved = resolveDevice(rec);
    const dpCatalog =
      (resolved.codec === "vacuum" || resolved.codec === "mower") && rec.model
        ? await this.fetchDpCatalog(rec.model)
        : undefined;
    return this.contextForRecord(sn, rec, dpCatalog);
  }

  /** Parent family facts from the same cached station link used by command routing; no I/O. */
  private parentStationContext(dev: EufyDevice): Pick<CommandContext, "stationDeviceType" | "stationModel"> {
    const stationSn = dev.stationSn || dev.sn;
    const station = stationSn !== dev.sn ? this.registry.list().find((entry) => entry.sn === stationSn) : undefined;
    return { stationDeviceType: cachedDeviceType(station), stationModel: station?.model };
  }

  /** Refresh held manifests after any roster load, including loads initiated by a per-device read. */
  private reconcileStationContexts(): void {
    const roster = new Map(this.registry.list().map((cached) => [cached.sn, cached]));
    for (const held of this.stationContextDevices) {
      const dev = held.deref();
      if (!dev) {
        this.stationContextDevices.delete(held);
        continue;
      }
      const cached = roster.get(dev.sn);
      if (!cached) continue;
      const station = stationOf(cached);
      if (dev.stationSn !== station) dev.reresolve({ parentSn: station === cached.sn ? "" : station });
      dev.setStationContext(this.parentStationContext(cached));
      const raw = (cached.raw ?? {}) as Record<string, unknown>;
      dev.setMetadataContext({
        firmwareVersion: recordString(raw, "main_sw_version"),
        hardwareVersion: recordString(raw, "main_hw_version"),
        firmwareSubVersion: recordString(raw, "sec_sw_version"),
      });
    }
  }

  /** Publish changed firmware from already received roster records, including metadata-only changes. */
  private reconcileFirmwareVersions(): void {
    const roster = this.registry.list();
    const present = new Set(roster.map((device) => device.sn));
    for (const sn of this.firmwareVersions.keys()) if (!present.has(sn)) this.firmwareVersions.delete(sn);
    for (const device of roster) {
      const raw = (device.raw ?? {}) as Record<string, unknown>;
      const firmware = recordString(raw, "main_sw_version");
      if (this.firmwareVersions.has(device.sn) && this.firmwareVersions.get(device.sn) === firmware) continue;
      this.firmwareVersions.set(device.sn, firmware);
      this.emit("deviceMetadata", { deviceSn: device.sn, firmwareVersion: firmware ?? null });
    }
  }

  /** The same context derivation for fetched records and cached polls; this half performs no I/O. */
  private contextForRecord(sn: string, rec: DeviceRecord, dpCatalog?: DpCatalog): ReadContext {
    // Resolve the record synchronously from the registry (already loaded by `record()`) — the same
    // single lookup the command sink uses, and it never opens a transport just to read a record.
    const dev = this.registry.require(sn);
    const raw = (dev.raw ?? {}) as Record<string, any>;
    const rawChannel = raw.device_channel;
    const channel = typeof rawChannel === "number" ? rawChannel : 0;
    const member = (raw.member ?? {}) as Record<string, any>;
    const resolved = resolveDevice(rec);
    return {
      channel,
      codec: resolved.codec,
      deviceType: rec.deviceType,
      model: rec.model,
      category: rec.category,
      serial: sn,
      stationSerial: rec.parentSn,
      // Identity metadata for `info`, for a host's device-registry surface. `name` = the app-shown
      // device_name (registry's `name`), not the resolved codec/inferred name. firmware/hardware come
      // straight off the device record: `main_sw_version` / `main_hw_version` — the same fields the v6
      // app maps to `firmware_main_version` / `hardware_version`. `undefined` when the record omits them.
      name: dev.name,
      firmwareVersion: recordString(raw, "main_sw_version"),
      hardwareVersion: recordString(raw, "main_hw_version"),
      firmwareSubVersion: recordString(raw, "sec_sw_version"),
      macAddress: recordString(raw, "wifi_mac"),
      updateAvailable: raw.needUpdate === true || raw.needUpdate === 1 || raw.needUpdate === "1",
      paramIds: new Set([...Object.keys(rec.params), ...Object.keys(rec.dpParams ?? {})].map(Number)),
      capabilities: new Set(resolved.capabilities),
      // Member identity for ff09-* command devices (see core/contracts Ff09Identity).
      adminUserId: typeof member.admin_user_id === "string" ? member.admin_user_id : undefined,
      shortUserId: typeof member.short_user_id === "string" ? member.short_user_id : undefined,
      accountName: this.mega.accountName || undefined,
      // The same claim the command sink routes on — a capability gates its P2P-only variants (e.g.
      // setRainMode) on this. Keyed on the P2P stack's own predicate (a usable `p2p_did` endpoint).
      hasP2p: P2PCommandRouter.claimsDevice(dev),
      // Topology as the record states it: a parent that isn't the device itself means HomeBase-attached.
      homeBaseAttached: !!rec.parentSn && rec.parentSn !== sn,
      ...this.parentStationContext(dev),
      dpCatalog: resolved.codec === "vacuum" || resolved.codec === "mower" ? dpCatalog : undefined,
    };
  }

  /**
   * **Generic P2P request/reply query** — sends a `SET_PAYLOAD` sub-command and resolves with the
   * reply frame's `payload`. Transport-only escape hatch (the router owns the wire); the caller owns
   * the sub-command id and the reply shape (e.g. the doorbell's 6237 quick-response list).
   * @internal
   */
  p2pQuery(sn: string, subCmd: number, opts: { timeoutMs?: number } = {}): Promise<Record<string, unknown>> {
    return this.p2p.p2pQuery(sn, subCmd, opts);
  }

  /** Dispatch a normalized cloud push without taking ownership of its session persistence. */
  private onCloudPush(ev: PushEvent): void {
    this.cameraHealthIngress.cloudPush(ev);
    this.thumbnailEvidence.push(ev);
    if (ev.eventName === undefined && ev.eventType != null) ev.eventName = detectionName(ev.eventType);
    if (ev.thumbnailCandidate) void this.observeStoredImage(ev.thumbnailCandidate);
    this.emit("push", ev);
    const signal = {
      source: "push" as const,
      eventType: ev.eventType,
      eventName: ev.eventName,
      deviceSn: ev.deviceSn,
      stationSn: ev.stationSn,
      thumbnailUrl: ev.thumbnailUrl,
      deliveryId: ev.raw?.persistentId,
      payload: ev.payload as Record<string, unknown>,
    };
    const outputs = decodeCapabilityEvent(signal, this.capsForEvent(ev.deviceSn));
    const model = this.registry.list().find((device) => device.sn === ev.deviceSn)?.model;
    this.eventRoutingRecorder.record(
      "cloud_push",
      outputs.length ? "mapped" : "unmapped",
      model,
      signal.payload,
      outputs,
      undefined,
      ev.eventType,
      ev.raw?.payload?.event_time,
    );
    for (const out of outputs) {
      this.emitSemantic(out.event, out.payload, { edge: true, refresh: out.refresh });
      const dsn = (out.payload.deviceSn as string | undefined) ?? ev.deviceSn;
      if (dsn) this.prewarmForEvent(out.event, dsn);
    }
  }

  /**
   * Connect FCM push — the always-on, server-initiated channel that delivers event + **thumbnail**
   * notifications (motion/person/doorbell/package, each with a thumbnail URL). Independent of
   * MQTT/P2P. On first run it registers a push token, tells the eufy cloud to push to it, then holds
   * the socket. With a `pushStore`, the token + seen ids persist so later runs just reconnect. Emits:
   *   - `push(event)` — normalised `PushEvent` (deviceSn, eventType, eventName,
   *     thumbnailUrl, cipher, payload, raw)
   *   - `pushRaw(raw)` — the raw `RawPushMessage`
   *   - `pushConnect` / `pushDisconnect`
   *
   * Started automatically by {@link ensureRealtime} after login. A semantic event the caller opted into
   * via {@link EufyMegaOptions.prewarmEvents} — none by default — also speculatively pre-warms that
   * camera's P2P session, so a following stream or talkback starts warm; {@link prewarmForEvent} owns that
   * decision, and the router stays event-agnostic.
   *
   * Returns the connected client rather than installing it. Registration can outlive a `disconnect()`,
   * and {@link ensureRealtime} owns the decision of whether a finished bring-up is still the current
   * one — so this never overwrites a channel a later login already brought up.
   */
  private async startPush(signal?: AbortSignal): Promise<PushClient> {
    if (!this.mega.auth) throw new Error("login() first");
    const store = this.opts.pushStore ?? new MemoryFcmStore();
    let persisted = store.load();
    if (!persisted) {
      const creds = await new FcmRegistrar(this.opts.logger).register();
      persisted = { creds, persistentIds: [] };
      store.save(persisted);
    }
    const persistedCreds = persisted.creds;

    // Tell the eufy cloud to push this account's events to our token (best-effort
    // — the MCS socket still receives even if this call's exact shape drifts).
    try {
      await this.mega.registerPushToken(persisted.creds.fcmToken);
    } catch (e) {
      this.reportError(e, "push_connection");
    }

    const client = new PushClient(persisted.creds, this.opts.logger, this.pushLifecycle);
    client.setPersistentIds(persisted.persistentIds);
    client.on("connect", () => this.emit("pushConnect"));
    client.on("disconnect", () => this.emit("pushDisconnect"));
    client.on("message", (raw: RawPushMessage) => this.emit("pushRaw", raw));
    client.on("push", (ev: PushEvent) => {
      this.onCloudPush(ev);
      try {
        store.save({ creds: persistedCreds, persistentIds: client.getPersistentIds() });
      } catch (e) {
        this.reportError(e, "push_connection");
      }
    });
    await new Promise<void>((resolve, reject) => {
      const cleanup = () => {
        signal?.removeEventListener("abort", onAbort);
        client.off("connect", onConnect);
        client.off("error", onError);
      };
      const onConnect = () => {
        cleanup();
        resolve();
      };
      const onError = (error: Error) => {
        cleanup();
        client.close();
        reject(error);
      };
      const onAbort = () => {
        cleanup();
        client.close();
        reject(new RealtimeStartupSupersededError());
      };
      if (signal?.aborted) return onAbort();
      signal?.addEventListener("abort", onAbort, { once: true });
      client.once("connect", onConnect);
      client.once("error", onError);
      client.connect();
    });
    client.on("error", (e) => this.reportError(e, "push_connection"));
    return client;
  }

  /** Admit only exact, account-known devices with resolved snapshot evidence into the passive store. */
  private async observeStoredImage(candidate: NonNullable<PushEvent["thumbnailCandidate"]>): Promise<void> {
    if (!this.storedImages || candidate.attribution.kind !== "device") {
      this.thumbnailEvidence.decision(!this.storedImages ? "disabled" : "non_device");
      return;
    }
    const account = this.mega.auth?.userId;
    if (!account) {
      this.thumbnailEvidence.decision("no_account");
      return;
    }
    try {
      if (!this.registry.list().length) {
        await this.registry.getDevices();
        this.reconcileStorageTelemetryOwners();
      }
      if (this.mega.auth?.userId !== account) {
        this.thumbnailEvidence.decision("account_changed");
        return;
      }
      const caps = this.registry.capabilitiesForDevice(candidate.attribution.deviceSn);
      if (caps && hasProvidedAction(caps, "snapshotStored")) {
        this.thumbnailEvidence.decision("admitted");
        this.storedImages.observe(candidate.attribution.deviceSn, candidate.url, candidate.eventTime);
      } else {
        this.thumbnailEvidence.decision("unsupported");
      }
    } catch (e) {
      this.thumbnailEvidence.decision("admission_error");
      this.reportError(e, "image");
    }
  }

  /**
   * Tear down every realtime channel: close the secure-MQTT transport, all P2P sessions, and the FCM
   * push socket. Idempotent — safe to call when nothing is connected. Leaves the login session intact
   * (call {@link login} again to reconnect without re-authenticating).
   */
  async disconnect(): Promise<void> {
    this.guardOwner().close();
    for (const controller of this.propertyPreparations) controller.abort();
    this.propertyPreparations.clear();
    this.commandIntents.close();
    this.realtimeEpoch++;
    this.guardOwner();
    this.cloudPollInFlight = 0;
    this.lateContrary.close();
    this.lateEffects.close();
    this.commandHealth.close();
    for (const device of this.registry.list()) {
      this.cameraHealthIngress.parent(device.stationSn || device.sn, "disconnected", "rtc");
      this.cameraHealthIngress.parent(device.stationSn || device.sn, "disconnected", "p2p");
    }
    for (const sn of [...this.storageTelemetryOwners.keys()]) this.invalidateStorageTelemetryOwner(sn);
    this.stateRefreshEvidence = emptyStateRefreshEvidence();
    this.eventRoutingRecorder = new EventRoutingRecorder();
    this.rtcObservationRecorder = new RtcObservationRecorder();
    this.thumbnailEvidence.clear();
    for (const abort of this.observationReads) abort.abort();
    this.observationReads.clear();
    this.stateTransitions.clear();
    this.commandRefreshes.clear();
    if (this.realtimeGeneration) {
      const generation = this.realtimeGeneration;
      generation.superseded = readinessSnapshot(generation.result ?? generation.readiness, "superseded");
      generation.abort.abort();
      this.settleRealtimeGeneration(generation, "superseded");
    }
    await this.teardownRealtime();
  }

  /**
   * Disconnect and forget every installed secure-MQTT transport.
   *
   * Clearing both installed transports and their in-flight memos lets the next successful login own a
   * fresh set. Individual stale attempts retain their epoch guard and close only the transport they
   * created, so they cannot clear a successor generation's map.
   */
  private async closeMqttTransports(): Promise<void> {
    const transports = [...this.transports.values()];
    this.transports.clear();
    this.mqttReady.clear();
    const results = await Promise.allSettled(transports.map(async (transport) => transport.disconnect()));
    const failures = results.flatMap((result) => (result.status === "rejected" ? [result.reason] : []));
    if (failures.length === 1) throw failures[0];
    if (failures.length > 1) throw new AggregateError(failures, "multiple MQTT transports failed to close");
  }

  /**
   * Close every realtime channel and stop the poll loop.
   *
   * Safe to run twice: owned channels are detached before awaiting disposal. The edge-trigger's memory
   * of announced states goes with them: it describes what was announced over a connection that no longer exists,
   * and keeping it would suppress the first report after a reconnect as a duplicate — leaving nothing
   * announced until the state next physically changes.
   */
  private async teardownRealtime(): Promise<void> {
    this.pollTimer.cancel();
    this.cloudPollSchedule = undefined;
    this.stateRefreshTimer.cancel();
    this.stateRefreshSchedule = undefined;
    this.stateRefreshLifecycle++;
    if (this.realtimeGeneration) {
      this.realtimeGeneration.stateRefreshDeferrals = undefined;
      this.realtimeGeneration.stateRefreshPlaybackDeferrals = undefined;
    }
    for (const entry of this.reportRefreshes.values()) clearTimeout(entry.timer);
    this.reportRefreshes.clear();
    this.lastStateAnnounced.clear();
    const push = this.pushClient;
    this.pushClient = undefined;
    // Independent channels close together, so one failed or hung close cannot skip the others.
    const results = await Promise.allSettled(
      [() => this.closeMqttTransports(), () => this.rtc.close(), () => this.p2p.closeAll(), () => push?.close()].map(
        async (close) => close(),
      ),
    );
    const failures = results.flatMap((result) => (result.status === "rejected" ? [result.reason] : []));
    if (failures.length === 1) throw failures[0];
    if (failures.length > 1) throw new AggregateError(failures, "multiple realtime channels failed to close");
  }

  /** True if a usable session (restored from store or freshly logged in) is held. */
  get loggedIn(): boolean {
    return this.mega.loggedIn;
  }

  /** Tear down realtime, clear passive media, and forget the persisted login session. */
  async logout(): Promise<void> {
    await this.disconnect();
    this.clearSession();
  }

  /** Forget the persisted session (forces a fresh login + 2FA next time) and clear account-owned media. */
  clearSession(): void {
    for (const sn of [...this.storageTelemetryOwners.keys()]) this.invalidateStorageTelemetryOwner(sn);
    this.storedImages?.clear();
    this.storedImageAccount = undefined;
    this.cameraHealthIngress.roster([]);
    this.mega.clearSession();
  }
}

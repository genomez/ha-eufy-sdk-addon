/** Modified for genomez S1 experimental source preview, 2026-10-14. */
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { PersistedSession, SessionStore } from "../../core/store.js";
import type { EufyDevice } from "../../core/types.js";
import { normalizePushEvent } from "../../transport/push/push-client.js";
import type { PushEvent, ThumbnailCandidate } from "../../transport/push/types.js";
import { LoginStatus, SessionExpiredError, type LoginResult } from "../../transport/http/mega-client.js";
import { EufyMega } from "../eufy-mega.js";
import { LiveSnapshotUnavailableError } from "../../core/contracts.js";

const CAMERA_SN = "T8000P0000000001";
const UNKNOWN_SN = "T8000P0000000002";
const NO_SNAPSHOT_SN = "T8000P0000000003";
const IMAGE_URL = "https://security-app.eufylife.com/media/thumbnail.jpg";

function session(userId = "synthetic-user"): PersistedSession {
  return {
    userId,
    accountUserId: userId,
    authToken: "synthetic-token",
    region: "us-pr",
    openudid: "0000000000000000",
    shareKey: "00000000000000000000000000000000",
    keyIdent: "synthetic-key",
    tokenExpiresAt: 0,
    savedAt: 0,
  };
}

function sessionStore(userId = "synthetic-user"): SessionStore {
  let retained: PersistedSession | null = session(userId);
  return {
    load: () => retained,
    save: (next) => (retained = next),
    clear: () => (retained = null),
  };
}

function jpeg(body = "image"): Buffer {
  return Buffer.from([0xff, 0xd8, 0xff, ...Buffer.from(body), 0xff, 0xd9]);
}

/** A baseline JPEG whose SOF0 declares the geometry a reader has to answer with. */
function jpegOf(width: number, height: number): Buffer {
  const sof0 = Buffer.alloc(12);
  sof0.writeUInt16BE(0xffc0, 0);
  sof0.writeUInt16BE(11, 2);
  sof0.writeUInt8(8, 4);
  sof0.writeUInt16BE(height, 5);
  sof0.writeUInt16BE(width, 7);
  sof0.writeUInt8(1, 9);
  return Buffer.concat([Buffer.from([0xff, 0xd8]), sof0, Buffer.from([0xff, 0xd9])]);
}

function cameraRecord(sn = CAMERA_SN): EufyDevice {
  return {
    sn,
    model: "T8170",
    category: "eufy_security",
    realtime: "p2p",
    p2pDid: "XXXXXXX-000000-XXXXX",
    params: {},
    paramUpdatedAt: {},
    raw: {
      device_sn: sn,
      device_model: "T8170",
      device_type: 30,
      station_sn: sn,
      p2p_did: "XXXXXXX-000000-XXXXX",
    },
  } as EufyDevice;
}

type ClientInternals = {
  mega: {
    downloadImage(url: string, p2pDid?: string): Promise<Buffer>;
    login(): Promise<LoginResult>;
  };
  registry: {
    list(): EufyDevice[];
    record(sn: string): Promise<{
      deviceType: number;
      model: string;
      category: string;
      params: Record<number, string>;
      paramUpdatedAt: Record<number, number>;
    }>;
    require(sn: string): EufyDevice;
    capabilitiesForDevice(sn: string): ReadonlySet<string> | undefined;
  };
  onCloudPush(event: PushEvent): void;
  observeStoredImage(candidate: ThumbnailCandidate): Promise<void>;
  p2p: { mediaProviderFor(sn: string): { snapshotLive(opts?: unknown): Promise<unknown> } };
  mediaProviderFor(sn: string): {
    snapshotLive(opts?: unknown): Promise<{ jpeg: Buffer; width: number; height: number; retained?: true }>;
    snapshotStored?(): Promise<{ jpeg: Buffer; eventTime?: number }>;
  };
};

function makeClient(storedSnapshotCache?: boolean) {
  const eufy = new EufyMega({
    email: "user@example.invalid",
    password: "unused",
    store: sessionStore(),
    autoRealtime: false,
    ...(storedSnapshotCache === undefined ? {} : { storedSnapshotCache }),
  });
  const internals = eufy as unknown as ClientInternals;
  const camera = cameraRecord();
  const noSnapshot = cameraRecord(NO_SNAPSHOT_SN);

  const list = vi.spyOn(internals.registry, "list").mockReturnValue([camera, noSnapshot]);
  vi.spyOn(internals.registry, "record").mockResolvedValue({
    deviceType: 30,
    model: "T8170",
    category: "eufy_security",
    params: {},
    paramUpdatedAt: {},
  });
  vi.spyOn(internals.registry, "require").mockImplementation((sn) => {
    if (sn === CAMERA_SN) return camera;
    if (sn === NO_SNAPSHOT_SN) return noSnapshot;
    throw new Error(`unknown test device ${sn}`);
  });
  vi.spyOn(internals.registry, "capabilitiesForDevice").mockImplementation((sn) => {
    if (sn === CAMERA_SN) return new Set(["camera", "snapshot"]);
    if (sn === NO_SNAPSHOT_SN) return new Set(["camera"]);
    return undefined;
  });
  const download = vi.spyOn(internals.mega, "downloadImage");
  return { eufy, internals, download, list };
}

function exactCandidate(deviceSn = CAMERA_SN): ThumbnailCandidate {
  return { url: IMAGE_URL, attribution: { kind: "device", deviceSn } };
}

async function storedSnapshotAction(eufy: EufyMega) {
  const camera = (await eufy.getDevice(CAMERA_SN)).camera?.();
  expect(camera?.snapshotStored).toBeTypeOf("function");
  return camera!.snapshotStored!;
}

async function retainImage(client: ReturnType<typeof makeClient>, image = jpeg()) {
  client.download.mockResolvedValue(image);
  const action = await storedSnapshotAction(client.eufy);
  await client.internals.observeStoredImage(exactCandidate());
  await vi.waitFor(async () => expect(action()).resolves.toEqual({ jpeg: image }));
  return action;
}

describe("stored snapshot client lifecycle", () => {
  beforeEach(() => vi.restoreAllMocks());

  it("carries candidate event time through the client and model action", async () => {
    const client = makeClient();
    client.download.mockResolvedValue(jpeg());
    const action = await storedSnapshotAction(client.eufy);
    await client.internals.observeStoredImage({ ...exactCandidate(), eventTime: 1790000000000 });
    await vi.waitFor(() => expect(action()).resolves.toEqual({ jpeg: jpeg(), eventTime: 1790000000000 }));
  });

  it("exposes counters from the actual push admission and retained cache without additional work", async () => {
    const client = makeClient();
    client.download.mockResolvedValue(jpeg());
    const action = await storedSnapshotAction(client.eufy);
    client.internals.onCloudPush(
      normalizePushEvent({
        payload: { event_time: "1790000000", payload: { device_sn: CAMERA_SN, pic_url: IMAGE_URL } },
      }),
    );
    await vi.waitFor(() => expect(action()).resolves.toEqual({ jpeg: jpeg(), eventTime: 1790000000000 }));
    expect(client.eufy.getThumbnailDiagnostics()).toMatchObject({
      enabled: true,
      counters: {
        normalization_preserved: 1,
        admitted: 1,
        cache_input_valid: 1,
        cache_retained_valid: 1,
        retention_preserved: 1,
      },
    });
    client.eufy.getThumbnailDiagnostics();
    expect(client.download).toHaveBeenCalledOnce();
    await client.eufy.disconnect();
    expect(Object.values(client.eufy.getThumbnailDiagnostics().counters).every((value) => value === 0)).toBe(true);
  });

  it("binds snapshotStored by default on a camera with snapshot evidence", async () => {
    const { eufy } = makeClient();

    const camera = (await eufy.getDevice(CAMERA_SN)).camera?.();

    expect(camera?.snapshotStored).toBeTypeOf("function");
  });

  it("storedSnapshotCache:false omits snapshotStored and ignores push candidates", async () => {
    const { eufy, internals, download } = makeClient(false);

    const camera = (await eufy.getDevice(CAMERA_SN)).camera?.();
    await internals.observeStoredImage(exactCandidate());

    expect(camera?.snapshotStored).toBeUndefined();
    expect(download).not.toHaveBeenCalled();
    expect(eufy.getThumbnailDiagnostics()).toMatchObject({ enabled: false, counters: { disabled: 1 } });
  });

  it("eagerly downloads an exact eligible candidate while snapshotStored remains passive", async () => {
    const client = makeClient();
    const image = jpeg("eager");
    client.download.mockResolvedValue(image);
    const action = await storedSnapshotAction(client.eufy);

    await client.internals.observeStoredImage(exactCandidate());

    expect(client.download).toHaveBeenCalledOnce();
    expect(client.download).toHaveBeenCalledWith(IMAGE_URL, "XXXXXXX-000000-XXXXX");
    await vi.waitFor(async () => expect(action()).resolves.toEqual({ jpeg: image }));
    await expect(action()).resolves.toEqual({ jpeg: image });
    expect(client.download).toHaveBeenCalledOnce();
  });

  it("uses the parent station key input for an attached camera image", async () => {
    const client = makeClient();
    const stationSn = "T8000P0000000004";
    const child = { ...cameraRecord(CAMERA_SN), stationSn, p2pDid: undefined };
    const station = { ...cameraRecord(stationSn), p2pDid: "XXXXXXX-000001-XXXXX" };
    client.list.mockReturnValue([child, station]);
    client.download.mockResolvedValue(jpeg());

    await client.internals.observeStoredImage(exactCandidate());

    expect(client.download).toHaveBeenCalledWith(IMAGE_URL, "XXXXXXX-000001-XXXXX");
  });

  it.each([
    ["ambiguous", { url: IMAGE_URL, attribution: { kind: "ambiguous" } }],
    ["station-attributed", { url: IMAGE_URL, attribution: { kind: "station", stationSn: CAMERA_SN } }],
    ["unknown-device", exactCandidate(UNKNOWN_SN)],
    ["device without snapshot evidence", exactCandidate(NO_SNAPSHOT_SN)],
  ] satisfies Array<[string, ThumbnailCandidate]>)("discards a %s candidate", async (_label, candidate) => {
    const { internals, download } = makeClient();

    await internals.observeStoredImage(candidate);

    expect(download).not.toHaveBeenCalled();
  });

  it("clearSession clears retained bytes and makes a stale bound action require login", async () => {
    const client = makeClient();
    const action = await retainImage(client);

    client.eufy.clearSession();

    await expect(action()).rejects.toThrow("login() first");
  });

  it("logout clears retained bytes and makes a stale bound action require login", async () => {
    const client = makeClient();
    const action = await retainImage(client);

    await client.eufy.logout();

    await expect(action()).rejects.toThrow("login() first");
  });

  it("a successful login for a replacement account clears retained bytes", async () => {
    const client = makeClient();
    await client.eufy.login();
    const action = await retainImage(client, jpeg("first-account"));
    vi.spyOn(client.internals.mega, "login").mockResolvedValue({
      status: LoginStatus.Ok,
      session: { userId: "replacement-user", authToken: "replacement-token", raw: {} },
    });

    await client.eufy.login();

    await expect(action()).rejects.toMatchObject({ reason: "not-observed" });
  });

  it("a successful same-account login clears a session failure and keeps retained metadata", async () => {
    const client = makeClient();
    await client.eufy.login();
    const image = jpeg("before-expiry");
    const eventTime = 1790000000000;
    client.download.mockResolvedValueOnce(image);
    const action = await storedSnapshotAction(client.eufy);
    await client.internals.observeStoredImage({ ...exactCandidate(), eventTime });
    await vi.waitFor(() => expect(action()).resolves.toEqual({ jpeg: image, eventTime }));
    const expired = new SessionExpiredError("synthetic session expiry");
    client.download.mockRejectedValueOnce(expired);
    await client.internals.observeStoredImage({
      ...exactCandidate(),
      url: `${IMAGE_URL}?next`,
      eventTime: eventTime + 1,
    });
    await vi.waitFor(() => expect(action()).rejects.toBe(expired));
    const diagnostics = client.eufy.getThumbnailDiagnostics();

    await client.eufy.login();

    await expect(action()).resolves.toEqual({ jpeg: image, eventTime });
    expect(client.download).toHaveBeenCalledTimes(2);
    expect(client.eufy.getThumbnailDiagnostics().counters.lifecycle_error).toBe(diagnostics.counters.lifecycle_error);
  });

  it("ignores an old session failure while the new-login fetch is pending", async () => {
    const client = makeClient();
    await client.eufy.login();
    const image = jpeg("retained");
    const action = await retainImage(client, image);
    const old = Promise.withResolvers<Buffer>();
    const fresh = Promise.withResolvers<Buffer>();
    client.download.mockReturnValueOnce(old.promise).mockReturnValueOnce(fresh.promise);
    await client.internals.observeStoredImage({ ...exactCandidate(), url: `${IMAGE_URL}?next` });
    await client.eufy.login();
    old.reject(new SessionExpiredError("synthetic old expiry"));
    await new Promise(setImmediate);

    await expect(action()).resolves.toEqual({ jpeg: image });
    expect(client.download).toHaveBeenCalledTimes(3);
    fresh.resolve(jpeg("fresh"));
    await vi.waitFor(() => expect(action()).resolves.toEqual({ jpeg: jpeg("fresh") }));
  });

  it("refetches a candidate whose session failure outlived login, preserving its event time", async () => {
    const client = makeClient();
    await client.eufy.login();
    const action = await storedSnapshotAction(client.eufy);
    const old = Promise.withResolvers<Buffer>();
    const image = jpeg("after-login");
    client.download.mockReturnValueOnce(old.promise).mockResolvedValueOnce(image);
    await client.internals.observeStoredImage({ ...exactCandidate(), eventTime: 1790000000000 });
    await client.eufy.login();
    old.reject(new SessionExpiredError("synthetic old expiry"));
    await new Promise(setImmediate);

    expect(client.download).toHaveBeenCalledTimes(2);
    await expect(action()).resolves.toEqual({ jpeg: image, eventTime: 1790000000000 });
    expect(client.eufy.getThumbnailDiagnostics().counters.lifecycle_error).toBe(0);
  });

  it("does not clear a session failure when login requires further authentication", async () => {
    const client = makeClient();
    const action = await retainImage(client);
    const expired = new SessionExpiredError("synthetic expiry");
    client.download.mockRejectedValueOnce(expired);
    await client.internals.observeStoredImage({ ...exactCandidate(), url: `${IMAGE_URL}?next` });
    await vi.waitFor(() => expect(action()).rejects.toBe(expired));
    vi.spyOn(client.internals.mega, "login").mockResolvedValue({ status: LoginStatus.TwoFactor, method: "email" });

    await client.eufy.login();

    await expect(action()).rejects.toBe(expired);
  });
});

/**
 * A live still refused because a sibling is being watched answers with the retained one.
 *
 * One session serves one camera at a time, a still does not open a connection of its own, and a live view
 * outranks a tile — so the still is genuinely unavailable rather than broken. Failing there empties a caller's tile; answering the retained bytes keeps
 * it populated, and `retained` says they are not current so nothing mistakes them for a fresh capture.
 */
describe("a live still that could not be captured", () => {
  const refuse = (internals: ClientInternals) =>
    vi.spyOn(internals.p2p, "mediaProviderFor").mockReturnValue({
      snapshotLive: () => Promise.reject(new LiveSnapshotUnavailableError("no-keyframe", "no-keyframe")),
    } as never);

  it("answers the retained bytes, marked as retained, with the geometry the image declares", async () => {
    const { eufy, internals, download } = makeClient();
    download.mockResolvedValue(jpegOf(1920, 1080));
    await eufy.login();
    await internals.observeStoredImage(exactCandidate());
    await vi.waitFor(() => expect(internals.mediaProviderFor(CAMERA_SN).snapshotStored!()).resolves.toBeDefined());
    refuse(internals);

    const still = await internals.mediaProviderFor(CAMERA_SN).snapshotLive();

    expect(still).toMatchObject({ width: 1920, height: 1080, retained: true });
    expect(still.jpeg.equals(jpegOf(1920, 1080))).toBe(true);
  });

  it("lets the refusal stand when nothing is retained", async () => {
    const { eufy, internals } = makeClient();
    await eufy.login();
    refuse(internals);

    await expect(internals.mediaProviderFor(CAMERA_SN).snapshotLive()).rejects.toBeInstanceOf(
      LiveSnapshotUnavailableError,
    );
  });

  it("never marks a fresh capture as retained, even with bytes in hand", async () => {
    const { eufy, internals, download } = makeClient();
    download.mockResolvedValue(jpegOf(640, 480));
    await eufy.login();
    await internals.observeStoredImage(exactCandidate());
    await vi.waitFor(() => expect(internals.mediaProviderFor(CAMERA_SN).snapshotStored!()).resolves.toBeDefined());
    vi.spyOn(internals.p2p, "mediaProviderFor").mockReturnValue({
      snapshotLive: () => Promise.resolve({ jpeg: jpegOf(2560, 1440), width: 2560, height: 1440 }),
    } as never);

    const still = await internals.mediaProviderFor(CAMERA_SN).snapshotLive();

    expect(still.width).toBe(2560);
    expect(still.retained).toBeUndefined();
  });
});

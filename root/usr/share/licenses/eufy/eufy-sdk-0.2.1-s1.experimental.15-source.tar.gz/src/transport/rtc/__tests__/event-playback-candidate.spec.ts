import { afterEach, describe, expect, it, vi } from "vitest";
import { zstdCompressSync } from "node:zlib";
import {
  EventPlaybackCandidate,
  chicagoInstant,
  playbackRequest,
  reservePlaybackSelectors,
  selectPlayback,
} from "../event-playback-candidate.js";
import { PlaybackIngress } from "../playback-ingress.js";
import { buildPortalHeader, parsePortalHeader, parsePortalPacket } from "../portal-packet.js";
import { packetize, PtcsFramer } from "../ptcs-framer.js";
import { PORTAL_KEEPALIVE } from "../portal-keepalive.js";
import { performance as nativePerformance } from "node:perf_hooks";

afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
});
const binary = (command: number, body: Buffer, selector = 6, channel = 101, segment = 9) =>
  Buffer.concat([buildPortalHeader(command, body.length, channel, segment, selector), body]);
const json = (value: unknown, segment = 9) => binary(1351, Buffer.from(JSON.stringify(value)), 0, 0, segment);
const video = (size = 7, timestamp = 0, sequence = 0) => {
  const body = Buffer.alloc(22 + size);
  body.writeUInt32LE(size);
  body[5] = 1;
  body.writeUInt32LE(timestamp >>> 0, 14);
  body.writeUInt16LE(sequence & 0xffff, 6);
  Buffer.from([0, 0, 0, 1, 0x26, 1, 0x80]).copy(body, 22);
  return binary(1300, body);
};
let frameId = 0;
function wrapped(frame: Buffer, channel = 4, compressed = false, payloadBytes = 1000) {
  const packets = packetize(compressed ? zstdCompressSync(frame) : frame, {
    channel,
    frameId: ++frameId,
    payloadBytes,
  });
  if (compressed) for (const p of packets) p.writeUInt16LE(p.readUInt16LE(18) | 0x0800, 18);
  return packets;
}
const row = (start: string, end = start, id = 40) => ({
  record_id: id,
  device_sn: "camera-synthetic",
  start_time: start,
  end_time: end,
});

describe("database-backed Chicago conversion", () => {
  it.each([
    ["2026-01-15 12:00:00", "2026-01-15T18:00:00Z"],
    ["2026-07-15 12:00:00", "2026-07-15T17:00:00Z"],
    ["2026-03-08 01:59:59", "2026-03-08T07:59:59Z"],
    ["2026-03-08 03:00:00", "2026-03-08T08:00:00Z"],
    ["2026-11-01 00:59:59", "2026-11-01T05:59:59Z"],
    ["2026-11-01 02:00:00", "2026-11-01T08:00:00Z"],
  ])("uniquely maps %s", (local, utc) => expect(chicagoInstant(local)).toBe(Date.parse(utc) / 1000));
  it.each([
    "2026-03-08 02:00:00",
    "2026-03-08 02:59:59",
    "2026-11-01 01:00:00",
    "2026-11-01 01:59:59",
    "2026-02-30 12:00:00",
    "2026-01-01 24:00:00",
    "2026-07-01",
    "2026-07-01 12:00:60",
    "私密",
  ])("refuses %s", (local) => expect(chicagoInstant(local)).toBeUndefined());
  it.each(["2026-11-01 01:30:00", "2026-07-02 12:00:00", "2026-07-01 12:00:55"])(
    "selects an older valid clip when the newest time is %s",
    (newest) => {
      expect(
        selectPlayback(
          [row("2026-07-01 12:00:00", undefined, 39), row(newest)],
          new Set(["camera-synthetic"]),
          new Set(["excluded-synthetic"]),
          Date.parse("2026-07-01T17:01:00Z"),
        ),
      ).toEqual({ selectionOutcome: "selected", record: 39, begin: chicagoInstant("2026-07-01 12:00:00") });
    },
  );
  it("excludes private camera policy and duplicate selectors", () => {
    const r = row("2026-07-01 12:00:00");
    expect(selectPlayback([r], new Set(["camera-synthetic"]), new Set(["camera-synthetic"]))).toEqual({
      selectionOutcome: "no_camera_rows",
    });
    expect(selectPlayback([r, r], new Set(["camera-synthetic"]), new Set())).toEqual({
      selectionOutcome: "time_invalid",
    });
  });
  it.each([
    [[], "no_rows"],
    [[{ ...row("2026-07-01 12:00:00"), device_sn: "other-synthetic" }], "no_camera_rows"],
    [[row("invalid")], "time_invalid"],
    [[row("2026-07-01 12:00:00", "2026-06-30 12:00:00")], "time_invalid"],
    [[row("2026-07-01 12:00:00", "2026-07-01 12:00:55")], "end_not_past"],
    [[row("2026-07-02 12:00:00")], "end_not_past"],
  ])("reports selection outcome for %j", (rows, selectionOutcome) => {
    expect(
      selectPlayback(rows as unknown[], new Set(["camera-synthetic"]), new Set(), Date.parse("2026-07-01T17:01:00Z")),
    ).toEqual({ selectionOutcome });
  });
  it.each([null, [], "malformed", { record_id: 0 }, { record_id: 1.5 }, { record_id: "41" }])(
    "refuses the entire table for malformed row %j",
    (bad) =>
      expect(selectPlayback([row("2026-07-01 12:00:00"), bad], new Set(["camera-synthetic"]), new Set())).toEqual({
        selectionOutcome: "time_invalid",
      }),
  );
});

it("reserves both selectors without wrap or reuse", () => {
  const used = new Set([1]);
  expect(reservePlaybackSelectors(used)).toEqual([6, 7]);
  expect(reservePlaybackSelectors(used)).toEqual([8, 9]);
  for (let n = 6; n <= 249; n++) used.add(n);
  expect(reservePlaybackSelectors(used)).toBeUndefined();
});
it("uses the captured envelope and same-record next-selector stop", () => {
  for (const sub of [0, 1, 3] as const) {
    const packet = playbackRequest("synthetic", 40, 6, sub, sub + 10, 1000000);
    const h = parsePortalHeader(packet)!;
    const p = JSON.parse(packet.subarray(16).toString());
    expect(h).toMatchObject({
      commandId: 1700,
      channel: 255,
      devType: 2,
      isResponse: sub === 3 ? 7 : 6,
      segment: sub + 10,
    });
    expect(p).toMatchObject({
      cmd: 6001,
      commandType: 6001,
      segmen: sub + 10,
      data: { cmd: sub, record_id: 40, play_id: sub === 3 ? 7 : 6, device_sn: "" },
    });
    expect(Object.hasOwn(p.data, "begin_time")).toBe(sub === 0);
  }
});

describe("A1 real framing path", () => {
  it.each([
    [1350, 0],
    [1351, 2],
  ])("delivers compressed control %s on route %s during capture and cleanup", async (command, route) => {
    const end = vi.fn(),
      delivered: unknown[] = [];
    const guard = new PlaybackIngress({
      end,
      media: () => {
        throw Error("unexpected_media");
      },
    });
    guard.reserve(6, 7);
    guard.capturing = true;
    const framer = new PtcsFramer();
    await framer.init(
      () => {
        throw Error("network_disabled");
      },
      (bytes, link) => {
        if (guard.decoded(bytes, link)) delivered.push(parsePortalPacket(bytes, link));
      },
    );
    const bytes = command === 1350 ? binary(command, Buffer.alloc(4), 1, 0) : json({ cmd: 1400, payload: { code: 0 } });
    try {
      for (const capturing of [true, false]) {
        guard.capturing = capturing;
        for (const p of wrapped(bytes, route, true)) if (guard.native(p)) framer.recvPacket(p);
      }
      expect(delivered).toHaveLength(2);
      expect(end).not.toHaveBeenCalled();
      expect(guard.evidence.unknown).toBe(false);
    } finally {
      framer.destroy();
    }
  });
  it.each([0, 1, 2, 3, 5, 9])(
    "inflates then discards compressed wrong-route media on %s before the parser",
    async (route) => {
      const delivered = vi.fn(),
        media = vi.fn(),
        end = vi.fn();
      const guard = new PlaybackIngress({ end, media });
      guard.reserve(6, 7);
      guard.capturing = true;
      const framer = new PtcsFramer();
      await framer.init(
        () => {},
        (bytes, link) => {
          if (guard.decoded(bytes, link)) delivered(bytes);
        },
      );
      try {
        for (const p of wrapped(video(), route, true)) if (guard.native(p)) framer.recvPacket(p);
        expect(delivered).not.toHaveBeenCalled();
        expect(media).not.toHaveBeenCalled();
        expect(guard.evidence.wrongRouteFrames).toBe(1);
        expect(guard.evidence.wrongRouteBytes).toBe(video().length);
        expect(end).toHaveBeenCalledWith("transport_mismatch");
        expect(guard.lastPlausibleMs).toBeGreaterThan(0);
      } finally {
        framer.destroy();
      }
    },
  );
  it("caps wrong-route traffic at 64 frames while retaining ordinary delivery", () => {
    const end = vi.fn(),
      guard = new PlaybackIngress({ end, media: () => {} });
    guard.reserve(6, 7);
    for (let n = 0; n < 64; n++) guard.decoded(video(), 3);
    expect(end).toHaveBeenLastCalledWith("capped_wrong_route");
    expect(guard.decoded(json({ cmd: 1400 }), 3)).toBe(true);
  });
  it.each([1, 3, 5, 9])(
    "preserves baseline inflation and ordinary delivery on non-playback route %s",
    async (route) => {
      const media = vi.fn(),
        end = vi.fn(),
        guard = new PlaybackIngress({ end, media });
      guard.capturing = true;
      const delivered = vi.fn(),
        framer = new PtcsFramer();
      await framer.init(
        () => {},
        (frame, link) => {
          if (guard.decoded(frame, link)) delivered(frame);
        },
      );
      try {
        for (const p of wrapped(json({ cmd: 1400 }), route, true)) if (guard.native(p)) framer.recvPacket(p);
        expect(delivered).toHaveBeenCalledOnce();
        expect(media).not.toHaveBeenCalled();
        expect(end).not.toHaveBeenCalled();
      } finally {
        framer.destroy();
      }
    },
  );
  it("handles bare media without parsing and preserves bare control", () => {
    const guard = new PlaybackIngress({ end: () => {}, media: () => {} });
    guard.reserve(6, 7);
    expect(guard.native(video())).toBe(false);
    expect(guard.native(json({ cmd: 1400 }))).toBe(true);
    expect(guard.native(PORTAL_KEEPALIVE)).toBe(true);
    expect(guard.evidence.nativeMessages).toBe(3);
  });
  it("rejects preallocation and decompression bombs", () => {
    const end = vi.fn(),
      media = vi.fn(),
      guard = new PlaybackIngress({ end, media });
    guard.reserve(6, 7);
    guard.capturing = true;
    const oversized = wrapped(Buffer.alloc(8388609))[0]!;
    expect(guard.native(oversized)).toBe(false);
    for (const p of wrapped(binary(1300, Buffer.alloc(8388609)), 4, true)) guard.native(p);
    expect(media).not.toHaveBeenCalled();
    expect(guard.evidence.unknown).toBe(false);
  });
  it("collects compressed playback with bounded native output", () => {
    const media = vi.fn(),
      guard = new PlaybackIngress({ end: () => {}, media });
    guard.reserve(6, 7);
    guard.capturing = true;
    for (const p of wrapped(video(), 4, true)) guard.native(p);
    expect(media).toHaveBeenCalledOnce();
    expect(guard.evidence.decodedWorkBytes).toBe(8388608);
  });
  it("refuses decode after capture and resets cessation for duplicate fragments", () => {
    let now = 1;
    const media = vi.fn(),
      guard = new PlaybackIngress({ now: () => now, end: () => {}, media });
    guard.reserve(6, 7);
    guard.capturing = true;
    const p = wrapped(binary(1300, Buffer.alloc(2000)), 4, false)[0]!;
    guard.native(p);
    now = 1000;
    guard.native(p);
    guard.finishCapture();
    now = 2500;
    guard.native(p);
    expect(guard.lastPlausibleMs).toBe(2500);
    expect(guard.observationComplete()).toBe(true);
    expect(media).not.toHaveBeenCalled();
  });
  it("retains unresolved control partials when unrelated ACK completes", () => {
    const guard = new PlaybackIngress({ end: () => {}, media: () => {} });
    guard.native(wrapped(binary(1300, Buffer.alloc(2000)), 0)[0]!);
    expect(guard.observationComplete()).toBe(false);
    guard.native(wrapped(json({ cmd: 1400 }), 2)[0]!);
    guard.decoded(json({ cmd: 1400 }), 3);
    expect(guard.observationComplete()).toBe(false);
  });
});

function candidateSetup({
  experiment = undefined as import("../playback-telemetry.js").PlaybackExperiment | undefined,
  pauseThrows = false,
  ownerChanged = false,
  matching = true,
  release = true,
  absent = false,
  eof = false,
  stopSend = "sent" as "sent" | "refused" | "throws",
  streaming = false,
  streamingFrames = 24,
  nativeFrameIntervalMs = 0,
  refusal = "none",
  refusalState = 0,
  refusalCode = 7,
} = {}) {
  vi.useFakeTimers();
  vi.spyOn(nativePerformance, "now").mockImplementation(() => performance.now());
  const controller = new AbortController(),
    sent: Buffer[] = [],
    markers: boolean[] = [];
  let segment = 0,
    continuous = true,
    markerFails = false,
    latched = false;
  const candidate = new EventPlaybackCandidate({
    experiment,
    transferSpeed: 1,
    deadlineMs: performance.now() + (streaming ? 91000 : 24000),
    captureMs: streaming ? 60000 : undefined,
    video: streaming ? () => {} : undefined,
    continuous: () => continuous,
    startAllowed: () => true,
    signal: controller.signal,
    account: "synthetic",
    segment: () => ++segment,
    marker: (value) => {
      if (markerFails) throw Error("synthetic_persistence_failure");
      markers.push(value);
    },
    latch: (value) => {
      latched = value;
    },
    send: (p) => {
      sent.push(p);
      const body = JSON.parse(p.subarray(16).toString());
      if (body.data.cmd === 0 && refusal !== "none") {
        if (refusal === "after-ack") candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 1, code: 0 } }), 3);
        if (refusal === "after-media") for (const packet of wrapped(video())) candidate.ingress.native(packet);
        candidate.ingress.decoded(
          json({
            cmd: 6001,
            payload: {
              state: refusalState,
              code: refusalCode,
              ...(refusal === "unmatched"
                ? {}
                : {
                    segmen:
                      refusal === "mismatched"
                        ? body.segmen + 1
                        : refusal === "noncomparable"
                          ? String(body.segmen)
                          : body.segmen,
                  }),
            },
          }),
          3,
        );
        return true;
      }
      if (body.data.cmd === 0) {
        candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 1, code: 0 } }), 3);
        for (let n = 0; n < (streaming ? streamingFrames : 1); n++)
          for (const packet of wrapped(
            video(streaming ? 256 * 1024 : 7, n * nativeFrameIntervalMs, nativeFrameIntervalMs ? n : 0),
          ))
            candidate.ingress.native(packet);
        if (eof) candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 14 } }), 3);
        if (ownerChanged) continuous = false;
      }
      if (body.data.cmd === 1 && pauseThrows) throw new Error("synthetic");
      if (body.data.cmd === 3 && stopSend !== "sent") {
        // A status notification still arrives asynchronously even though this send failed.
        setTimeout(
          () => candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 15, segmen: body.segmen } }), 3),
          50,
        );
        if (stopSend === "throws") throw new Error("synthetic_stop");
        return false;
      }
      if (body.data.cmd === 3 && release)
        candidate.ingress.decoded(
          json({ cmd: 6001, payload: { state: 2, code: 15, segmen: matching ? body.segmen : 200 } }),
          3,
        );
      if (body.data.cmd === 3 && absent)
        candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 0, code: 7 } }), 3);
      return true;
    },
  });
  return {
    candidate,
    controller,
    sent,
    markers,
    latch: () => latched,
    failMarker: () => {
      markerFails = true;
    },
  };
}

it.each(["time_refused", "timeout"] as const)(
  "no-start %s reports clean health without touching a latch",
  async (reason) => {
    const s = candidateSetup();
    s.candidate.end(reason);
    expect(await s.candidate.observe()).toMatchObject({
      captureOutcome: reason,
      startAttempted: false,
      ownerContinuous: true,
      healthOutcome: "clean",
      latchPersisted: false,
      latchRetained: false,
    });
    expect(s.sent).toHaveLength(0);
    expect(s.markers).toEqual([]);
    expect(s.latch()).toBe(false);
  },
);

it("clears a persisted prestart latch when admission changes before sending", async () => {
  let allowed = true,
    latched = false;
  const markers: boolean[] = [],
    send = vi.fn();
  const candidate = new EventPlaybackCandidate({
    deadlineMs: nativePerformance.now() + 24000,
    continuous: () => true,
    startAllowed: () => allowed,
    send,
    segment: () => 1,
    account: "synthetic",
    marker: (value) => {
      markers.push(value);
      if (value) allowed = false;
    },
    latch: (value) => {
      latched = value;
    },
    signal: new AbortController().signal,
  });
  await candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  expect(await candidate.observe()).toMatchObject({
    startAttempted: false,
    healthOutcome: "clean",
    latchPersisted: true,
    latchRetained: false,
    latchCleared: true,
  });
  expect(markers).toEqual([true, false]);
  expect(latched).toBe(false);
  expect(send).not.toHaveBeenCalled();
});

it("reports a pre-dispatch storage failure without sending or retaining the live-view latch", async () => {
  const s = candidateSetup();
  s.failMarker();
  await s.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  expect(await s.candidate.observe()).toMatchObject({
    captureOutcome: "storage_failed",
    startAttempted: false,
    latchPersistenceFailed: true,
    latchRetained: false,
    releaseOutcome: "not_started",
    cessationOutcome: "not_started",
  });
  expect(s.sent).toHaveLength(0);
  expect(s.latch()).toBe(false);
  expect(vi.getTimerCount()).toBe(0);
});

it("streams a complete clip beyond the probe byte cutoff through EOF and qualified release", async () => {
  const s = candidateSetup({ streaming: true, eof: true });
  await s.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  const pending = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(5010);
  expect(await pending).toMatchObject({
    captureOutcome: "eof",
    videoFrames: 24,
    boundedMediaObserved: true,
    cutoff: false,
    releaseOutcome: "release_confirmed",
    latchCleared: true,
  });
  expect(s.candidate.receipt.nativeBytes).toBeGreaterThan(4 * 1024 ** 2);
});

it("retains streaming video beyond expected duration until EOF through unconfirmed cleanup", async () => {
  vi.useFakeTimers();
  vi.spyOn(nativePerformance, "now").mockImplementation(() => performance.now());
  const output = vi.fn(),
    sent: number[] = [];
  const candidate = new EventPlaybackCandidate({
    deadlineMs: performance.now() + 34000,
    captureMs: 18000,
    expectedMs: 3000,
    video: output,
    continuous: () => true,
    startAllowed: () => true,
    signal: new AbortController().signal,
    account: "synthetic",
    segment: () => 1,
    marker: () => {},
    latch: () => {},
    send: (packet) => {
      sent.push(JSON.parse(packet.subarray(16).toString()).data.cmd);
      return true;
    },
  });
  const capture = candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 1, code: 0 } }), 3);
  const inject = () => {
    for (const packet of wrapped(video())) candidate.ingress.native(packet);
  };
  for (let i = 0; i <= 45; i++) {
    if (i) await vi.advanceTimersByTimeAsync(Math.round((i * 3000) / 45) - Math.round(((i - 1) * 3000) / 45));
    inject();
  }
  await vi.advanceTimersByTimeAsync(500);
  inject();
  expect(output).toHaveBeenCalledTimes(47);
  expect(candidate.receipt.captureOutcome).not.toBe("complete");
  await vi.advanceTimersByTimeAsync(250);
  inject();
  candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 14 } }), 3);
  await capture;
  expect(sent).toEqual([0, 1, 3]);
  const observing = candidate.observe();
  for (let i = 0; i < 16; i++) {
    await vi.advanceTimersByTimeAsync(1000);
    inject();
  }
  expect(await observing).toMatchObject({
    captureOutcome: "eof",
    videoFrames: 48,
    randomAccess: true,
    boundedMediaObserved: true,
    releaseOutcome: "stop_unconfirmed",
    latchRetained: true,
  });
  expect(output).toHaveBeenCalledTimes(48);
});

it.each([
  ["burst", [0, 20]],
  [
    "stall-gap",
    [...Array.from({ length: 15 }, (_, i) => i * 60), ...Array.from({ length: 16 }, (_, i) => 2100 + i * 60)],
  ],
  ["sparse", [0, 500, 1000, 1500, 2000, 2500, 3000]],
  ["delayed-tail", Array.from({ length: 37 }, (_, i) => Math.round(i * (2400 / 36)))],
])("refuses incomplete retained coverage for %s despite a completion-margin frame", async (_, arrivals) => {
  const s = candidateSetup({ streaming: true, streamingFrames: 0 });
  Reflect.get(s.candidate, "opts").expectedMs = 3000;
  const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  let previous = 0;
  for (const arrival of [...arrivals, 3750]) {
    await vi.advanceTimersByTimeAsync(arrival - previous);
    for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
    previous = arrival;
  }
  expect(s.candidate.receipt.captureOutcome).not.toBe("complete");
  expect(s.candidate.receipt.videoFrames).toBe(arrivals.length + 1);
  await vi.advanceTimersByTimeAsync(60001);
  await capture;
  const observing = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(16001);
  expect(await observing).toMatchObject({ captureOutcome: "capped", boundedMediaObserved: false });
});

it("does not certify incomplete retained media on EOF even with confirmed release", async () => {
  const s = candidateSetup({ streaming: true, streamingFrames: 2, eof: true });
  Reflect.get(s.candidate, "opts").expectedMs = 3000;
  await s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  const observing = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(5010);
  expect(await observing).toMatchObject({
    captureOutcome: "eof",
    releaseOutcome: "release_confirmed",
    boundedMediaObserved: false,
  });
});

it.each([1300, 1301, 1303])("poisons observation for live media command %s on an unconsumed channel", (command) => {
  const guard = new PlaybackIngress({ observeOnly: true, liveAllowed: () => true, media: vi.fn(), end: vi.fn() });
  guard.decoded(binary(command, Buffer.alloc(22), 1, 102), 5);
  expect(guard.prestartSafe()).toBe(false);
});

it.each([1300, 1301, 1303])("permits observation for live media command %s on the accepted channel", (command) => {
  const guard = new PlaybackIngress({ observeOnly: true, liveAllowed: () => true, media: vi.fn(), end: vi.fn() });
  guard.decoded(binary(command, Buffer.alloc(22), 1, 101), 5);
  expect(guard.prestartSafe()).toBe(true);
});

it.each([1, 24])(
  "does not complete duration capture on wall time alone with %s retained frames",
  async (streamingFrames) => {
    const s = candidateSetup({ streaming: true, streamingFrames });
    Reflect.get(s.candidate, "opts").expectedMs = 3000;
    const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
    await vi.advanceTimersByTimeAsync(4000);
    if (streamingFrames === 1) for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
    await vi.advanceTimersByTimeAsync(56001);
    await capture;
    expect(s.candidate.receipt.captureOutcome).toBe("capped");
    s.candidate.ingress.stopExpiry();
  },
);

it("refuses a duration capture without a keyframe start", async () => {
  const s = candidateSetup({ streaming: true, streamingFrames: 0 });
  Reflect.get(s.candidate, "opts").expectedMs = 3000;
  const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  const delta = video();
  delta[42] = 0x02;
  for (const packet of wrapped(delta)) s.candidate.ingress.native(packet);
  await capture;
  expect(s.candidate.receipt).toMatchObject({ captureOutcome: "invalid_media", videoFrames: 0, randomAccess: false });
  s.candidate.ingress.stopExpiry();
});

it.each([0, 1, 2, 3, 5, 9])(
  "continued rejected traffic on route %s prevents silence until the global deadline",
  async (route) => {
    const s = candidateSetup({ eof: true });
    await s.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
    expect(s.candidate.receipt.stopStatusCount).toBe(1);
    const framer = new PtcsFramer();
    await framer.init(
      () => {},
      (frame, link) => {
        s.candidate.ingress.decoded(frame, link);
      },
    );
    try {
      const pending = s.candidate.observe();
      for (let i = 0; i < 26; i++) {
        await vi.advanceTimersByTimeAsync(900);
        const p = packetize(Buffer.from("invalid compressed synthetic bytes"), {
          channel: route,
          frameId: ++frameId,
        })[0]!;
        p.writeUInt16LE(p.readUInt16LE(18) | 0x0800, 18);
        expect(s.candidate.ingress.native(p)).toBe(true);
        const outcome = framer.recvPacket(p);
        expect(outcome).toBe("rejected");
        s.candidate.ingress.received(outcome);
        expect(s.candidate.ingress.lastPlausibleMs).toBe(performance.now());
        expect(s.candidate.ingress.observationComplete()).toBe(false);
      }
      await vi.advanceTimersByTimeAsync(610);
      expect(await pending).toMatchObject({
        cessationOutcome: "cessation_unknown",
        latchRetained: true,
        latchCleared: false,
        unknown: false,
      });
      expect(s.markers).toEqual([true]);
      expect(s.latch()).toBe(true);
    } finally {
      framer.destroy();
    }
  },
);

it.each(["refused", "throws"] as const)(
  "stop send %s with a delayed stop status never reports ceased or clears the latch",
  async (stopSend) => {
    const s = candidateSetup({ stopSend, eof: true });
    await s.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
    const pending = s.candidate.observe();
    await vi.advanceTimersByTimeAsync(24000);
    const result = await pending;
    expect(result.stopSent).toBe(false);
    expect(result.cessationOutcome).toBe("cessation_unknown");
    expect(result.latchCleared).toBe(false);
    expect(result.latchRetained).toBe(true);
    expect(s.latch()).toBe(true);
  },
);

it("late re-latch failure stays latched and is observable after qualified release", async () => {
  const s = candidateSetup({ eof: true });
  await s.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  const pending = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(5010);
  expect((await pending).latchCleared).toBe(true);
  s.failMarker();
  s.candidate.ingress.native(video());
  expect(s.latch()).toBe(true);
  expect(s.candidate.receipt).toMatchObject({
    latchPersistenceFailed: true,
    latchRetained: true,
    latchCleared: false,
    releaseOutcome: "release_unknown",
  });
});

describe("mandatory finalizer and observational release", () => {
  it.each([true, false])(
    "cleanup survives demand with pause failure=%s and measured handoff below 100ms",
    async (pauseThrows) => {
      const { candidate, controller, sent } = candidateSetup({ pauseThrows });
      const run = candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
      controller.abort();
      await run;
      const handoff = performance.now();
      expect(sent.map((p) => JSON.parse(p.subarray(16).toString()).data.cmd)).toEqual([0, 1, 3]);
      expect(handoff).toBeLessThan(100);
      candidate.finalize();
      expect(sent).toHaveLength(3);
      const observation = candidate.observe();
      await vi.advanceTimersByTimeAsync(5010);
      expect((await observation).releaseOutcome).toBe("release_confirmed");
    },
  );
  it.each([true, false])("2/15 uses explicit segment-match boolean=%s under exclusivity", async (matching) => {
    const { candidate } = candidateSetup({ matching, eof: true });
    await candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
    const pending = candidate.observe();
    await vi.advanceTimersByTimeAsync(5010);
    const result = await pending;
    expect(result.releaseOutcome).toBe("release_confirmed");
    expect(result.segmenComparable).toBe(true);
    expect(result.segmenMatchesRequest).toBe(matching);
    expect(result.boundedMediaObserved).toBe(true);
    expect(result.accepted).toBe(false);
  });
  it.each([true, false])("0/7 requires prior EOF=%s", async (eof) => {
    const { candidate, controller } = candidateSetup({ release: false, absent: true, eof });
    const capture = candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
    if (!eof) controller.abort();
    await capture;
    const pending = candidate.observe();
    await vi.advanceTimersByTimeAsync(24010);
    expect((await pending).releaseOutcome).toBe(eof ? "release_confirmed" : "stop_unconfirmed");
  });
  it("never sends through a replacement owner", async () => {
    const { candidate, sent } = candidateSetup({ ownerChanged: true });
    const capture = candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
    await vi.advanceTimersByTimeAsync(20);
    await capture;
    const result = await candidate.observe();
    expect(sent).toHaveLength(1);
    expect(result.latchRetained).toBe(true);
    expect(result.ownerContinuous).toBe(false);
  });
  it("opaque direct reply is consumed before generic body decoding", async () => {
    const { candidate, controller } = candidateSetup();
    const capture = candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
    expect(candidate.ingress.decoded(binary(1700, Buffer.alloc(132, 255), 1, 255, 1), 1)).toBe(false);
    expect(candidate.receipt.directStartMatched).toBe(true);
    controller.abort();
    await capture;
  });
});

it.each([true, false])(
  "rejected capture with stop confirmation=%s preserves failure and qualifies cleanup independently",
  async (release) => {
    const s = candidateSetup({ release });
    const capture = s.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
    const p = wrapped(Buffer.from("invalid synthetic zstd"))[0]!;
    p.writeUInt16LE(p.readUInt16LE(18) | 0x0800, 18);
    s.candidate.ingress.native(p);
    await capture;
    const observe = s.candidate.observe();
    await vi.advanceTimersByTimeAsync(release ? 5010 : 24010);
    const result = await observe;
    expect(result).toMatchObject({
      captureOutcome: "invalid_media",
      boundedMediaObserved: false,
      cessationOutcome: release ? "ceased" : "cessation_unknown",
      releaseOutcome: release ? "release_confirmed" : "stop_unconfirmed",
      latchCleared: release,
      latchRetained: !release,
      unknown: false,
      firstRejectionReason: "zstd-header",
      firstRejectedClass: "playback",
      compressionState: "flagged",
      rejectionCount: 1,
      declaredSizeBucket: "le8KiB",
      assembledSizeBucket: "le8KiB",
      outputSizeBucket: "unknown",
      zstdWindowBucket: "unknown",
      assemblerDecompression: 1,
    });
    expect(s.latch()).toBe(!release);
  },
);

it("accepts a synthetic non-single-segment 8 MiB zstd window and output above 256 KiB", () => {
  const collected = vi.fn();
  const guard = new PlaybackIngress({ end: vi.fn(), media: collected });
  guard.reserve(6, 7);
  guard.capturing = true;
  const bytes = binary(1300, Buffer.alloc(400000));
  const chunks: Buffer[] = [Buffer.from([0x28, 0xb5, 0x2f, 0xfd, 0x00, 0x68])];
  for (let i = 0; i < bytes.length; i += 131072) {
    const part = bytes.subarray(i, i + 131072),
      header = Buffer.alloc(3);
    header.writeUIntLE((part.length << 3) | (i + part.length === bytes.length ? 1 : 0), 0, 3);
    chunks.push(header, part);
  }
  const wire = packetize(Buffer.concat(chunks), { channel: 4, frameId: ++frameId });
  for (const p of wire) {
    p.writeUInt16LE(p.readUInt16LE(18) | 0x0800, 18);
    guard.native(p);
  }
  expect(collected).toHaveBeenCalledExactlyOnceWith(
    bytes,
    expect.objectContaining({ frameId: expect.any(Number), sequence: expect.any(Number) }),
  );
  expect(guard.evidence).toMatchObject({
    rejected: 0,
    decodedWorkBytes: 8388608,
    compressionState: "decoded",
    zstdWindowBucket: "le8MiB",
    outputSizeBucket: "le8MiB",
  });
  const malformed = Buffer.from("invalid");
  guard.native(malformed);
  const frozen = { ...guard.evidence };
  for (const p of wrapped(video(), 4, true)) guard.native(p);
  expect(guard.evidence.firstRejectionReason).toBe(frozen.firstRejectionReason);
  expect(guard.evidence.compressionState).toBe(frozen.compressionState);
});

it("waits within the global deadline for a delayed stop and five fresh seconds", async () => {
  const s = candidateSetup({ release: false });
  const capture = s.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  s.candidate.ingress.native(Buffer.from("synthetic-invalid"));
  await capture;
  const observe = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(7000);
  expect(s.latch()).toBe(true);
  s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 15 } }), 3);
  await vi.advanceTimersByTimeAsync(4999);
  expect(s.latch()).toBe(true);
  await vi.advanceTimersByTimeAsync(20);
  expect(await observe).toMatchObject({
    captureOutcome: "invalid_media",
    releaseOutcome: "release_confirmed",
    cessationOutcome: "ceased",
    latchCleared: true,
  });
});

it("releases concurrent reservations while bounding cumulative decoder work", () => {
  const media = vi.fn(),
    end = vi.fn();
  const guard = new PlaybackIngress({ end, media });
  guard.reserve(6, 7);
  guard.capturing = true;
  for (let n = 0; n < 5; n++) for (const p of wrapped(video(), 4, true)) guard.native(p);
  expect(media).toHaveBeenCalledTimes(4);
  expect(guard.evidence.decodedWorkBytes).toBe(33554432);
  expect(guard.evidence.firstRejectionReason).toBe("limits");
  expect(end).toHaveBeenLastCalledWith("invalid_media");
});

it.each([
  ["night bursts", 2500, 12000, true, "none"],
  ["night smaller bursts", 1200, 12000, true, "none"],
  ["short EOF", 2500, 60000, false, "span"],
  ["late EOF tail", 3100, 12000, true, "none"],
] as const)("retained EOF diagnostics: %s", async (_, gap, expectedMs, accepted, completenessFailure) => {
  const s = candidateSetup({ streaming: true, streamingFrames: 0, release: false });
  Reflect.get(s.candidate, "opts").expectedMs = expectedMs;
  const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  const arrivals = Array.from({ length: 141 }, (_, i) => i * 60 + (i >= 40 ? gap : 0) + (i >= 80 ? gap : 0));
  let previous = 0;
  for (const at of arrivals) {
    await vi.advanceTimersByTimeAsync(at - previous);
    for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
    previous = at;
  }
  const segment = parsePortalHeader(s.sent[0]!)!.segment;
  s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 14, segmen: segment } }), 3);
  await capture;
  const observing = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(16001);
  const retained = arrivals;
  expect(await observing).toMatchObject({
    captureOutcome: "eof",
    boundedMediaObserved: accepted,
    retainedVideoFrames: retained.length,
    retainedVideoSpanMs: retained.at(-1),
    maxVideoGapMs: gap + 60,
    completenessFailure,
    latchCleared: false,
    latchRetained: true,
    releaseOutcome: "stop_unconfirmed",
  });
});

it.each([
  ["slow prefix", 70, 2000, 230, "eof", true],
  ["night small gaps", 120, 1200, 15, "eof", true],
  ["night large gaps", 120, 2500, 15, "eof", true],
  ["absolute tail limit", 120, 2000, 16, "eof", true],
  ["relative tail limit", 200, 2000, 20, "eof", true],
  ["relative tail exceeded", 200, 2000, 21, "eof", true],
  ["non-EOF tail", 120, 0, 20, "capped", true],
] as const)("post-cutoff video: %s", async (_, frames, gap, dropped, outcome, accepted) => {
  const s = candidateSetup({ streaming: true, streamingFrames: 0 });
  Reflect.get(s.candidate, "opts").expectedMs = 12000;
  const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  const arrivals = Array.from(
    { length: frames },
    (_, i) =>
      Math.round((i * (11900 - gap * 2)) / (frames - 1)) +
      (i >= Math.floor(frames / 3) ? gap : 0) +
      (i >= Math.floor((frames * 2) / 3) ? gap : 0),
  );
  arrivals.push(...Array.from({ length: dropped }, (_, i) => 12001 + i * (dropped > 100 ? 100 : 20)));
  let previous = 0;
  for (const at of arrivals) {
    await vi.advanceTimersByTimeAsync(at - previous);
    for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
    previous = at;
  }
  if (outcome === "eof") {
    const segment = parsePortalHeader(s.sent[0]!)!.segment;
    s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 14, segmen: segment } }), 3);
  } else s.candidate.end(outcome);
  await capture;
  const observing = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(5010);
  expect(await observing).toMatchObject({
    captureOutcome: outcome,
    retainedVideoFrames: frames + dropped,
    retainedVideoSpanMs: arrivals.at(-1),
    droppedAfterCutoff: 0,
    boundedMediaObserved: accepted,
    completenessFailure: accepted ? "none" : "truncated",
  });
});

it.each([
  ["full coverage, long pause", 11544, 3525, 0, "none", 129],
  ["full coverage boundary", 11000, 8000, 0, "none", 129],
  ["partial coverage, long pause", 10900, 3525, 0, "none", 129],
  ["full coverage, late tail", 11544, 3525, 40, "none", 129],
  ["full coverage, sparse", 11544, 3525, 0, "density", 40],
  ["coverage boundary", 10200, 3500, 0, "none", 61],
  ["below coverage boundary", 10199, 3500, 0, "span", 61],
  ["density boundary", 12000, 3500, 0, "none", 61],
  ["below density boundary", 12000, 3500, 0, "density", 60],
  ["paused density boundary", 15000, 3500, 0, "none", 76],
  ["below paused density boundary", 15000, 3500, 0, "density", 75],
] as const)("EOF pause tolerance: %s", (_, span, gap, dropped, failure, frames) => {
  const s = candidateSetup({});
  const c = s.candidate as unknown as Record<string, unknown>;
  Reflect.get(s.candidate, "opts").expectedMs = 12000;
  Object.assign(c, {
    eofSeen: true,
    firstVideoAt: 0,
    lastVideoAt: span,
    maxVideoGapMs: gap,
    droppedAfterCutoff: dropped,
  });
  Object.assign(Reflect.get(s.candidate, "receipt"), {
    captureOutcome: "eof",
    randomAccess: true,
    videoFrames: frames,
  });
  expect(Reflect.apply(Reflect.get(s.candidate, "retainedMediaFailure"), s.candidate, [])).toBe(failure);
});

it.each([
  [60000, 231, 59815, 12908, 14312],
  [22000, 106, 21900, 3000, 4297],
  [12000, 180, 11933, 67, 5967],
] as const)(
  "complete variable cadence EOF uses native headers: %s ms",
  async (expectedMs, frames, span, gap, arrivalSpan) => {
    const s = candidateSetup({ streaming: true, streamingFrames: 0, release: false });
    Object.assign(Reflect.get(s.candidate, "opts"), { expectedMs, transferSpeed: 2 });
    const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
    let previous = 0;
    for (let i = 0; i < frames; i++) {
      const at = Math.round((i * arrivalSpan) / (frames - 1));
      const timestamp =
        expectedMs === 12000
          ? Math.round((i * 1000) / 15)
          : i < 6
            ? [0, 400, 1000, 2500, 2900, 3500][i]!
            : 3500 +
              Math.round(((i - 5 - (i >= 80 ? 1 : 0)) * (span - gap - 3500)) / (frames - 7)) +
              (i >= 80 ? gap : 0);
      await vi.advanceTimersByTimeAsync(at - previous);
      for (const packet of wrapped(video(7, timestamp, 65500 + i))) s.candidate.ingress.native(packet);
      previous = at;
    }
    s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 14 } }), 3);
    await capture;
    expect(await s.candidate.observe(true)).toMatchObject({
      captureOutcome: "eof",
      completenessFailure: "none",
      boundedMediaObserved: true,
      durationBasis: "native_header",
      mediaDurationMs: Math.round(span + 1000 / 15),
      retainedVideoFrames: frames,
      retainedVideoSpanMs: arrivalSpan,
      nativeFrameTiming: { timestampDeltaTicks: span, sequenceDelta: frames - 1 },
    });
  },
);

it.each(["short", "overlong", "skipped", "repeated", "constant", "regression", "non-ms", "no-random-access", "no-eof"])(
  "native EOF proof fails closed: %s",
  (mode) => {
    const s = candidateSetup({});
    Reflect.get(s.candidate, "opts").expectedMs = 60000;
    Object.assign(s.candidate, { eofSeen: mode !== "no-eof", firstVideoAt: 0, lastVideoAt: 14312 });
    Object.assign(s.candidate.receipt, {
      captureOutcome: "eof",
      randomAccess: mode !== "no-random-access",
      videoFrames: 231,
    });
    const timing = Reflect.get(s.candidate, "nativeFrameTiming");
    for (let i = 0; i < 231; i++) {
      let timestamp =
        i === 0
          ? 0
          : 67 + Math.round(((i - 1) * ((mode === "short" ? 40000 : mode === "overlong" ? 62000 : 59815) - 67)) / 229);
      if (mode === "regression" && i === 100) timestamp -= 1000;
      if (mode === "non-ms") timestamp = i;
      const sequence =
        mode === "constant"
          ? 0
          : i + (mode === "skipped" && i >= 100 ? 1 : 0) - (mode === "repeated" && i === 100 ? 1 : 0);
      timing.add(video(7, timestamp, sequence).subarray(16), i);
    }
    expect(Reflect.apply(Reflect.get(s.candidate, "retainedMediaFailure"), s.candidate, [])).toBe(
      mode === "no-random-access" ? "random_access" : "span",
    );
    expect(timing.completeDurationMs(60000)).toBe(mode === "no-random-access" || mode === "no-eof" ? 59882 : undefined);
  },
);

it("short variable cadence native span rejects EOF even when delivery coverage and density pass", () => {
  const s = candidateSetup({});
  Reflect.get(s.candidate, "opts").expectedMs = 22000;
  Object.assign(s.candidate, { eofSeen: true, firstVideoAt: 0, lastVideoAt: 22000 });
  Object.assign(s.candidate.receipt, { captureOutcome: "eof", randomAccess: true, videoFrames: 120 });
  const timing = Reflect.get(s.candidate, "nativeFrameTiming");
  for (let i = 0; i < 120; i++) {
    const timestamp = Math.round((i * 10000) / 119) + (i >= 60 ? 3000 : 0);
    timing.add(video(7, timestamp, i).subarray(16), i);
  }
  expect(Reflect.apply(Reflect.get(s.candidate, "retainedMediaFailure"), s.candidate, [])).toBe("truncated");
});

it("non-EOF keeps the strict pause limit at full coverage", () => {
  const s = candidateSetup({});
  const c = s.candidate as unknown as Record<string, unknown>;
  Reflect.get(s.candidate, "opts").expectedMs = 12000;
  Object.assign(c, { eofSeen: false, firstVideoAt: 0, lastVideoAt: 11800, maxVideoGapMs: 1500 });
  Object.assign(Reflect.get(s.candidate, "receipt"), {
    captureOutcome: "complete",
    randomAccess: true,
    videoFrames: 180,
  });
  expect(Reflect.apply(Reflect.get(s.candidate, "retainedMediaFailure"), s.candidate, [])).toBe("gap");
});

it.each([0, 1, 15000])("EOF rejects two frames despite positive span: %s ms", async (span) => {
  const s = candidateSetup({ streaming: true, streamingFrames: 0, release: false });
  Reflect.get(s.candidate, "opts").expectedMs = 7000;
  const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
  await vi.advanceTimersByTimeAsync(span);
  for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
  s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 14 } }), 3);
  await capture;
  const observing = s.candidate.observe(true);
  await vi.advanceTimersByTimeAsync(16001);
  expect(await observing).toMatchObject({
    captureOutcome: "eof",
    retainedVideoFrames: 2,
    droppedAfterCutoff: 0,
    boundedMediaObserved: false,
    completenessFailure: span >= 6000 ? "density" : "span",
  });
});

it.each([
  [65535, "none"],
  [100000, "none"],
] as const)("EOF ignores historical cutoff counters: %s dropped", (dropped, failure) => {
  const s = candidateSetup({});
  const c = s.candidate as unknown as Record<string, unknown>;
  Reflect.get(s.candidate, "opts").expectedMs = 3_000_000;
  Object.assign(c, { eofSeen: true, firstVideoAt: 0, lastVideoAt: 2_990_000, maxVideoGapMs: 2000 });
  Object.assign(Reflect.get(s.candidate, "receipt"), {
    captureOutcome: "eof",
    randomAccess: true,
    videoFrames: 700_000,
    droppedAfterCutoff: 65535,
  });
  c.droppedAfterCutoff = dropped;
  expect(Reflect.apply(Reflect.get(s.candidate, "retainedMediaFailure"), s.candidate, [])).toBe(failure);
});

it.each([
  ["short low-fps", [0, 750, 1500, 2250, 3000], 7000, true, false],
  ["dense short EOF", Array.from({ length: 51 }, (_, i) => i * 86), 7000, true, false],
  ["density boundary", Array.from({ length: 16 }, (_, i) => i * 200), 3000, true, true],
  ["below density boundary", Array.from({ length: 15 }, (_, i) => i * 210), 3000, true, false],
  ["large gap sparse", [0, 500, 2000, 2500, 3000], 7000, true, false],
  ["absolute floor sparse", [0, 400, 800], 1500, true, false],
  ["relative floor", [0, 750, 1500, 2250], 7000, true, false],
  ["non-EOF short", [0, 750, 1500, 2250, 3000], 7000, false, false],
  ["non-EOF low-fps", [0, 750, 1500, 2250, 3000], 3000, false, false],
] as const)("EOF coverage: %s", async (_, arrivals, expectedMs, eof, accepted) => {
  const s = candidateSetup({ streaming: true, streamingFrames: 0 });
  Reflect.get(s.candidate, "opts").expectedMs = expectedMs;
  const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  let previous = 0;
  for (const at of arrivals) {
    await vi.advanceTimersByTimeAsync(at - previous);
    for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
    previous = at;
  }
  if (eof) s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 2, code: 14 } }), 3);
  else s.candidate.end("complete");
  await capture;
  const observing = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(5010);
  expect(await observing).toMatchObject({ boundedMediaObserved: accepted });
  if (accepted) expect(s.candidate.receipt.mediaDurationMs).toBeGreaterThan(0);
});

it.each([1300, 1301, 1303])("drains trailing LIVE command %s without permanent poisoning", (command) => {
  let now = 0;
  const guard = new PlaybackIngress({ now: () => now, observeOnly: true, media: vi.fn(), end: vi.fn() });
  guard.liveEnded();
  now = 9999;
  guard.decoded(binary(command, Buffer.alloc(22), 1, 101), 5);
  expect(guard.prestartSafe()).toBe(true);
  now = 90000;
  expect(guard.prestartSafe()).toBe(true);
  guard.decoded(binary(command, Buffer.alloc(22), 1, 101), 5);
  expect(guard.prestartSafe()).toBe(true);
});

it.each([
  [5, 102],
  [4, 101],
  [5, 101, 2],
])("preserves poisoning during live drain for link/channel %s/%s", (link, channel, selector = 1) => {
  let now = 0;
  const guard = new PlaybackIngress({ now: () => now, observeOnly: true, media: vi.fn(), end: vi.fn() });
  guard.liveEnded();
  guard.decoded(binary(1300, Buffer.alloc(22), selector, channel), link);
  now = 20000;
  expect(guard.prestartSafe()).toBe(false);
});

it.each(["matched", "unmatched", "after-media", "late-ack", "late-media"])(
  "terminal refusal safety: %s",
  async (refusal) => {
    const s = candidateSetup({ refusal, release: false });
    await s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
    if (refusal === "late-ack") s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 1, code: 0 } }), 3);
    if (refusal === "late-media") for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
    const observing = s.candidate.observe();
    await vi.advanceTimersByTimeAsync(24001);
    const receipt = await observing;
    expect(receipt.stationRefusalConfirmed).toBe(refusal === "matched");
    expect(receipt.latchCleared).toBe(false);
    expect(receipt.latchRetained).toBe(true);
    expect(receipt.releaseOutcome).toBe(
      refusal === "matched" || refusal === "late-media" ? "stop_unconfirmed" : "release_unknown",
    );
    expect(receipt.stationStatusCounts).toContainEqual({ state: 0, code: 7, count: 1 });
  },
);

it.each(["matched", "unmatched", "mismatched", "noncomparable", "after-ack", "after-media", "late-ack", "late-media"])(
  "no stored video refusal safety: %s",
  async (refusal) => {
    const s = candidateSetup({ refusal, refusalState: 2, refusalCode: 18, release: false });
    await s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
    if (refusal === "late-ack") s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 1, code: 0 } }), 3);
    if (refusal === "late-media") for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
    const observing = s.candidate.observe();
    await vi.advanceTimersByTimeAsync(24001);
    const receipt = await observing;
    expect(receipt).toMatchObject({
      captureOutcome: "start_refused",
      stationRefusalConfirmed: refusal === "matched",
      ownerContinuous: true,
      stopSent: true,
      cessationOutcome: refusal === "matched" ? "ceased" : "cessation_unknown",
      latchCleared: false,
      latchRetained: true,
    });
    expect(receipt.releaseOutcome).not.toBe("release_confirmed");
    expect(receipt.stationStatusCounts).toContainEqual({ state: 2, code: 18, count: 1 });
  },
);

it.each([
  [0, 7],
  [2, 18],
])("invalidated refusal %s/%s with stop release keeps the latch", async (refusalState, refusalCode) => {
  const s = candidateSetup({ refusal: "late-media", refusalState, refusalCode, release: true });
  await s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
  const observing = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(24001);
  const receipt = await observing;
  expect(receipt).toMatchObject({ stationRefusalConfirmed: false, latchCleared: false, latchRetained: true });
  expect(receipt.releaseOutcome).not.toBe("release_confirmed");
});

it.each(["stop-refused", "owner-changed"])("no stored video refusal requires cleanup authority: %s", async (kind) => {
  const s = candidateSetup({
    refusal: "matched",
    refusalState: 2,
    refusalCode: 18,
    release: false,
    stopSend: kind === "stop-refused" ? "refused" : "sent",
  });
  await s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  if (kind === "owner-changed") Reflect.get(s.candidate, "opts").continuous = () => false;
  const observing = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(24001);
  expect(await observing).toMatchObject({
    stationRefusalConfirmed: false,
    cessationOutcome: "cessation_unknown",
    latchRetained: true,
    latchCleared: false,
  });
});

it.each(["matching", "mismatched", "absent", "noncomparable"])("EOF segment correlation: %s", async (kind) => {
  const s = candidateSetup({ streaming: true, streamingFrames: 0 });
  Reflect.get(s.candidate, "opts").expectedMs = 7000;
  const capture = s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  for (let i = 0; i < 36; i++) {
    if (i) await vi.advanceTimersByTimeAsync(200);
    for (const packet of wrapped(video())) s.candidate.ingress.native(packet);
  }
  const segment = parsePortalHeader(s.sent[0]!)!.segment;
  s.candidate.ingress.decoded(
    json({
      cmd: 6001,
      payload: {
        state: 2,
        code: 14,
        ...(kind === "absent"
          ? {}
          : { segmen: kind === "matching" ? segment : kind === "mismatched" ? segment + 1 : "unknown" }),
      },
    }),
    3,
  );
  await capture;
  const observing = s.candidate.observe();
  await vi.advanceTimersByTimeAsync(16001);
  expect((await observing).boundedMediaObserved).toBe(kind !== "mismatched");
});

it("bounds poison telemetry and records ambiguity and coarse live ages", () => {
  let now = 0;
  const guard = new PlaybackIngress({
    now: () => now,
    observeOnly: true,
    liveAllowed: () => false,
    liveTargetAmbiguous: () => true,
    end: vi.fn(),
    media: vi.fn(),
  });
  guard.liveStarted();
  now = 11000;
  guard.liveEnded();
  now = 12000;
  for (let channel = 102; channel < 142; channel++) guard.decoded(binary(1300, Buffer.alloc(22), 1, channel), 5);
  const evidence = guard.observationEvidence();
  expect(evidence.poisonCounts).toHaveLength(32);
  expect(evidence.poisonOverflow).toBe(8);
  expect(evidence.poisonCounts[0]).toMatchObject({
    cause: "channel",
    link: 5,
    cmd: 1300,
    channel: 102,
    selector: "1",
    liveTargetAmbiguous: true,
    sinceLiveStart: "lt60s",
    sinceLiveStop: "lt10s",
    count: 1,
  });
  evidence.poisonCounts[0]!.count = 0;
  expect(guard.observationEvidence().poisonCounts[0]!.count).toBe(1);
});

it("malformed LIVE lengths and unknown framing remain unsafe", () => {
  for (const frame of [Buffer.alloc(3), binary(1300, Buffer.alloc(22), 1, 101).subarray(0, -1)]) {
    const guard = new PlaybackIngress({ observeOnly: true, end: vi.fn(), media: vi.fn() });
    guard.decoded(frame, 5);
    expect(guard.prestartSafe()).toBe(false);
    expect(guard.observationEvidence().poisonCounts.length).toBeGreaterThan(0);
  }
});

it("bounds station status classes and saturates repeated counts", async () => {
  const s = candidateSetup({ refusal: "matched" });
  await s.candidate.capture({ record: 1, begin: 1 }, [6, 7]);
  for (let code = 100; code < 140; code++)
    s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 0, code } }), 3);
  expect(s.candidate.receipt.stationStatusCounts).toHaveLength(32);
  expect(s.candidate.receipt.stationStatusOverflow).toBe(10);
  const status = s.candidate.receipt.stationStatusCounts.find((r) => r.code === 7)!;
  status.count = 65535;
  s.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 0, code: 7 } }), 3);
  expect(status.count).toBe(65535);
});

it("always records timeline offsets, arrival buckets and PTCS header evidence", async () => {
  const f = candidateSetup({ streaming: true, eof: true });
  f.candidate.mark("admissionGrantedMs");
  await f.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  const receipt = await f.candidate.observe(true);
  expect(Object.keys(receipt.timeline!)).toEqual([
    "admissionGrantedMs",
    "startSentMs",
    "startAcknowledgedMs",
    "firstVideoFrameMs",
    "eofStatusMs",
  ]);
  expect(Object.values(receipt.timeline!)).toEqual([...Object.values(receipt.timeline!)].sort((a, b) => a - b));
  expect(receipt.arrivalFps).toEqual({ buckets: 1, min: 24, median: 24, max: 24 });
  expect(receipt.frameTiming).toMatchObject({
    frames: 24,
    timestampDeltaMs: 23,
    maxTimestampGapMs: 1,
    mediaTimestampValidated: false,
  });
  expect(receipt.nativeFrameTiming).toMatchObject({
    frames: 24,
    timestampDeltaTicks: 0,
    sequenceDelta: 0,
    mediaTimestampValidated: false,
  });
  expect(receipt.experiment).toBeUndefined();
});

it("accelerated EOF uses catalog duration and repeats the experiment tuple during cleanup", async () => {
  const experiment = { playSpeed: 8, playType: 1, clientType: "WEB", maxClips: 1 } as const;
  const f = candidateSetup({ streaming: true, eof: true, experiment });
  Reflect.get(f.candidate, "opts").expectedMs = 10000;
  await f.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  const receipt = await f.candidate.observe(true);
  expect(receipt).toMatchObject({
    experiment,
    mediaDurationMs: 10000,
    durationBasis: "catalog_experiment",
    boundedMediaObserved: true,
  });
  for (const packet of f.sent)
    expect(JSON.parse(packet.subarray(16).toString()).data).toMatchObject({
      play_speed: 8,
      play_type: 1,
      client_type: "WEB",
    });
});

it.each(["no-eof", "unexpected", "preempted"])("experimental %s retains bounded cleanup", async (mode) => {
  const experiment = { playSpeed: 8, playType: 1, clientType: "WEB", maxClips: 1 } as const;
  const f = candidateSetup({ streaming: true, experiment });
  Reflect.get(f.candidate, "opts").expectedMs = 10000;
  const capture = f.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  if (mode === "unexpected") f.candidate.ingress.decoded(json({ cmd: 6001, payload: { state: 9, code: 99 } }), 3);
  else if (mode === "preempted") f.controller.abort();
  else await vi.advanceTimersByTimeAsync(60001);
  await capture;
  const observing = f.candidate.observe();
  await vi.advanceTimersByTimeAsync(16001);
  expect(await observing).toMatchObject({
    experiment,
    boundedMediaObserved: false,
    pauseAttempted: true,
    stopAttempted: true,
  });
  expect(f.sent.map((p) => JSON.parse(p.subarray(16).toString()).data.cmd)).toEqual([0, 1, 3]);
});

it("active EOF prefers an advancing catalog-consistent native timestamp word", async () => {
  const experiment = { playSpeed: 8, playType: 1, clientType: "WEB", maxClips: 1 } as const;
  const f = candidateSetup({ streaming: true, eof: true, experiment, streamingFrames: 20, nativeFrameIntervalMs: 500 });
  Reflect.get(f.candidate, "opts").expectedMs = 10200;
  await f.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  expect(await f.candidate.observe(true)).toMatchObject({
    mediaDurationMs: 10000,
    durationBasis: "native_header_experiment",
    nativeFrameTiming: {
      timestampDeltaTicks: 9500,
      maxTimestampGapTicks: 500,
      sequenceDelta: 19,
      mediaTimestampValidated: false,
    },
  });
});

it("delivers each native header timestamp beside the unchanged HEVC access unit", async () => {
  const f = candidateSetup({ streaming: true, eof: true, streamingFrames: 3, nativeFrameIntervalMs: 4069 });
  const delivered = vi.fn();
  Reflect.get(f.candidate, "opts").video = delivered;
  await f.candidate.capture({ record: 40, begin: 1000000 }, [6, 7]);
  expect(delivered.mock.calls.map(([, timing]) => timing)).toEqual([
    { nativeTimestamp: 0 },
    { nativeTimestamp: 4069 },
    { nativeTimestamp: 8138 },
  ]);
  expect(delivered.mock.calls.every(([bytes]) => bytes.length === 256 * 1024 && bytes.readUInt32BE(0) === 1)).toBe(
    true,
  );
});

it("90 kHz early EOF cannot bypass arrival coverage and density", () => {
  const s = candidateSetup({});
  Reflect.get(s.candidate, "opts").expectedMs = 60000;
  Object.assign(s.candidate, { eofSeen: true, firstVideoAt: 0, lastVideoAt: 670 });
  Object.assign(s.candidate.receipt, { captureOutcome: "eof", randomAccess: true, videoFrames: 11 });
  const timing = Reflect.get(s.candidate, "nativeFrameTiming");
  for (let i = 0; i < 11; i++) timing.add(video(7, i * 6000, i).subarray(16), i * 67);
  expect(timing.completeDurationMs(60000)).toBeUndefined();
  expect(Reflect.apply(Reflect.get(s.candidate, "retainedMediaFailure"), s.candidate, [])).toBe("span");
});

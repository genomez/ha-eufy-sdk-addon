import { EventEmitter } from "node:events";
import { afterEach, expect, it, vi } from "vitest";
import { RtcCommandRouter } from "../command-router.js";
import type { RtcSession } from "../session.js";
import type { RtcIngressGuard } from "../playback-ingress.js";
import type { EufyDevice } from "../../../core/types.js";
import { buildPortalHeader, parsePortalHeader } from "../portal-packet.js";
import { packetize, PtcsFramer } from "../ptcs-framer.js";
import { PORTAL_KEEPALIVE, PORTAL_KEEPALIVE_MS } from "../portal-keepalive.js";
import { performance as nativePerformance } from "node:perf_hooks";
import { zstdCompressSync } from "node:zlib";
import { normalizeRecordingRows, recordingAccountNamespace } from "../recordings.js";

const station = "T9000SYNTHETIC",
  camera = "camera-synthetic";
const owners: RtcCommandRouter[] = [];
afterEach(() => {
  owners.splice(0).forEach((r) => r.close());
  vi.restoreAllMocks();
  vi.useRealTimers();
});
class Session extends EventEmitter {
  isConnected = false;
  sent: Buffer[] = [];
  raw: Buffer[] = [];
  echoRaw = true;
  guard?: RtcIngressGuard;
  framer = new PtcsFramer();
  counter = 0;
  releaseStatus = true;
  refusal = "none";
  refusalState = 0;
  refusalCode = 7;
  eof = true;
  corruptMedia = false;
  mediaEnabled = true;
  tableReply = true;
  tableResultCode = 0;
  tableRows: unknown[] = [
    { device_sn: camera, record_id: 40, start_time: "2026-01-15 12:00:00", end_time: "2026-01-15 12:00:01" },
  ];
  attachIngressGuard(guard: RtcIngressGuard | undefined) {
    this.guard = guard;
  }
  async connect() {
    await this.framer.init(
      () => {},
      (frame, link) => {
        if (this.guard && !this.guard.decoded(frame, link)) return;
        this.emit(link === 4 || link === 5 || link === 2 ? "mediaData" : "commandData", frame, link);
      },
    );
    this.isConnected = true;
    this.emit("connected");
  }
  close() {
    this.isConnected = false;
    this.framer.destroy();
    this.emit("close");
  }
  inject(packet: Buffer) {
    if (!this.guard || this.guard.native(packet)) {
      if (packet.equals(PORTAL_KEEPALIVE)) this.emit("keepaliveEcho");
      else {
        const outcome = this.framer.recvPacket(packet);
        this.guard?.received?.(outcome);
      }
    }
  }
  input(command: number, body: unknown, route = 2, channel = 0, selector = 0, segment = 0) {
    const data = Buffer.isBuffer(body) ? body : Buffer.from(JSON.stringify(body));
    for (const p of packetize(
      Buffer.concat([buildPortalHeader(command, data.length, channel, segment, selector), data]),
      { channel: route, frameId: ++this.counter, payloadBytes: 40 },
    ))
      this.inject(p);
  }
  sendRaw(packet: Buffer) {
    if (!this.isConnected) return false;
    this.raw.push(Buffer.from(packet));
    if (this.echoRaw) this.inject(packet);
    return true;
  }
  sendCommand(packet: Buffer) {
    this.sent.push(packet);
    const h = parsePortalHeader(packet)!,
      p = h.commandId === 1103 ? { cmd: 1103 } : JSON.parse(packet.subarray(16).toString());
    queueMicrotask(() => {
      if (h.commandId === 1700) {
        this.input(1700, Buffer.alloc(132), 0, 255, 1, h.segment);
        if (p.data.cmd === 0 && this.refusal !== "none") {
          this.input(1351, {
            cmd: 6001,
            payload: {
              state: this.refusalState,
              code: this.refusalCode,
              ...(this.refusal === "matched" ? { segmen: h.segment } : {}),
            },
          });
          return;
        }
        if (p.data.cmd === 0 && this.mediaEnabled) {
          this.input(1351, { cmd: 6001, payload: { state: 1, code: 0 } });
          const media = Buffer.alloc(29);
          media.writeUInt32LE(7);
          media[5] = 1;
          Buffer.from([0, 0, 0, 1, 0x26, 1, 0x80]).copy(media, 22);
          if (this.corruptMedia) {
            const bad = packetize(Buffer.from("synthetic-invalid-compression"), {
              channel: 4,
              frameId: ++this.counter,
            })[0]!;
            bad.writeUInt16LE(bad.readUInt16LE(18) | 0x0800, 18);
            this.inject(bad);
          } else this.input(1300, media, 4, 101, h.isResponse);
          if (this.eof) this.input(1351, { cmd: 6001, payload: { state: 2, code: 14 } });
        }
        if (p.data.cmd === 3 && this.releaseStatus)
          this.input(1351, { cmd: 6001, payload: { state: 2, code: 15, segmen: p.segmen } });
        return;
      }
      this.input(h.commandId, Buffer.alloc(4), 0, h.channel, 1, h.segment);
      if (p.cmd === 1103) this.input(1103, { params: [] }, 2, 2);
      if (p.cmd === 1306 && this.tableReply)
        this.input(
          1306,
          {
            cmd: 10000,
            table: "history_record_info",
            transaction: p.payload.transaction,
            mIntRet: this.tableResultCode,
            data: this.tableRows,
          },
          2,
          255,
        );
    });
    return true;
  }
}
async function fixture(commandKeepaliveMs?: number) {
  vi.useFakeTimers();
  vi.spyOn(nativePerformance, "now").mockImplementation(() => performance.now());
  const sessions: Session[] = [],
    marker: boolean[] = [];
  const router = new RtcCommandRouter({
    identity: () => ({ authToken: "synthetic", userId: "synthetic" }),
    accountName: () => "synthetic",
    shard: () => "us",
    idleCloseMs: 900000,
    sessionRefreshMs: 600000,
    commandKeepaliveMs,
    findDevice: (sn) =>
      ({ sn, stationSn: station, model: sn === station ? "T9000" : "T8425", raw: { device_channel: 2 } }) as EufyDevice,
    createSession: () => {
      const session = new Session();
      sessions.push(session);
      return session as unknown as RtcSession;
    },
  });
  owners.push(router);
  router.configurePlaybackSafety(false, (value) => marker.push(value));
  const read = router.refreshInformation(station);
  await vi.advanceTimersByTimeAsync(1);
  await read;
  sessions[0]!.inject(PORTAL_KEEPALIVE);
  await vi.advanceTimersByTimeAsync(60001);
  const owner = Reflect.get(router, "sessions").get(station);
  expect({
    continuous: Reflect.get(router, "storageCandidateOwnerMatches").call(router, station, owner),
    connected: owner.session.isConnected,
    pending: owner.pendingExchanges === 0,
    replacement: !owner.replacement,
    refresh: !owner.refreshPending,
    renewal: owner.connectedAtMs + 600000 - Date.now() > 30000,
  }).toEqual({ continuous: true, connected: true, pending: true, replacement: true, refresh: true, renewal: true });
  expect({
    marker: !!Reflect.get(router, "playbackMarker"),
    latch: !Reflect.get(router, "playbackUnresolved"),
    playback: Reflect.get(router, "playbackProbes").size === 0,
    table: Reflect.get(router, "eventTableProbes").size === 0,
    live: Reflect.get(router, "lives").size === 0,
    taint: !owner.informationTainted,
    renewal:
      (owner.refreshBusyCooldownAtMs ?? owner.refreshRetryAtMs ?? owner.connectedAtMs + 600000) - Date.now() > 30000,
  }).toEqual({ marker: true, latch: true, playback: true, table: true, live: true, taint: true, renewal: true });
  expect({
    covered: performance.now() - owner.playbackObservation.observedSinceMs >= 60000,
    ordinary: owner.playbackObservation.ordinaryFrames > 0,
    keepalive: owner.playbackObservation.keepalives > 0,
    ingressSafe: owner.playbackObservation.prestartSafe(),
    information: !!owner.lastInformationRead,
    idle: owner.scheduler.idle,
    leases: owner.leases === 0,
  }).toEqual({
    covered: true,
    ordinary: true,
    keepalive: true,
    ingressSafe: true,
    information: true,
    idle: true,
    leases: true,
  });
  return { router, session: sessions[0]!, sessions, marker };
}
const options = () => ({
  enabled: true,
  cameras: new Set([camera]),
  excluded: new Set(["excluded-synthetic"]),
  fresh: () => true,
});

it("aborts an active person probe and releases its lease before playback admission", async () => {
  const { router, session } = await fixture();
  session.tableReply = false;
  const probeRead = Reflect.get(router, "readEventCandidate").call(
    router,
    station,
    { timeoutMs: 2000 },
    undefined,
    true,
  );
  await vi.advanceTimersByTimeAsync(0);
  const probe = Reflect.get(router, "eventPersonProbes").get(station);
  expect(probe.controller.signal.aborted).toBe(false);
  session.tableReply = true;
  const playback = router.readEventPlaybackCandidate(station, options());
  expect(probe.controller.signal.aborted).toBe(true);
  await vi.advanceTimersByTimeAsync(0);
  expect(await probeRead).toMatchObject({ outcome: "abandoned" });
  expect(Reflect.get(router, "eventPersonProbes").size).toBe(0);
  expect(Reflect.get(router, "eventTableProbes").size).toBe(0);
  await vi.advanceTimersByTimeAsync(5100);
  expect(await playback).toMatchObject({ admissionGateName: "none", startAttempted: true, captureOutcome: "eof" });
});

it.each(["time", "bytes", "abort", "live", "eof"] as const)(
  "armed download uses clip authority and always replaces after %s cutoff",
  async (bound) => {
    const { router, session, sessions, marker } = await fixture();
    const clip = sealedClip(router, session),
      file = vi.fn(),
      mediaReady = vi.fn(),
      controller = new AbortController();
    const before = session.sent.length;
    const pending = router.readEventPlaybackCandidate(station, {
      ...options(),
      signal: controller.signal,
      clip: {
        ...clip,
        file,
        mediaReady,
        experiment: { mode: "download", playSpeed: 1, playType: 1, clientType: "WEB", maxClips: 1 },
      },
    });
    await vi.advanceTimersByTimeAsync(1);
    const start = session.sent.slice(before).find((p) => parsePortalHeader(p)!.commandId === 1350)!;
    expect(JSON.parse(start.subarray(16).toString())).toMatchObject({
      cmd: 1024,
      payload: { streamId: 6, recordIds: [{ record_id: clip.selector.record, device_sn: clip.selector.cameraSn }] },
    });
    expect(session.sent.slice(before).some((p) => parsePortalHeader(p)!.commandId === 1700)).toBe(false);
    if (bound === "bytes") {
      for (let i = 0; i < 64; i++)
        for (const p of packetize(Buffer.alloc(4 * 1024 * 1024), { channel: 3, frameId: ++session.counter }))
          session.inject(p);
    } else if (bound === "abort") controller.abort();
    else if (bound === "eof") session.input(1351, { cmd: 1024, payload: { cmd: 0, code: 0 } });
    const live = bound === "live" ? router.mediaProviderFor(camera).live!() : undefined;
    await vi.advanceTimersByTimeAsync(bound === "time" ? 60010 : 10);
    const receipt = await pending;
    expect(receipt).toMatchObject({
      mode: "download",
      captureOutcome: bound === "eof" ? "eof" : bound === "abort" || bound === "live" ? "preempted" : "capped",
      boundedMediaObserved: false,
      reconnectOutcome: "connected",
      download: {
        ackReceived: true,
        ackStatus: 0,
        cancelAttempted: true,
        cancelSent: true,
        fileBytes: bound === "bytes" ? 256 * 1024 * 1024 : 0,
      },
    });
    const commands = session.sent.slice(before).filter((p) => parsePortalHeader(p)!.commandId === 1350);
    expect(commands).toHaveLength(2);
    expect(JSON.parse(commands[1]!.subarray(16).toString())).toMatchObject({
      cmd: 1024,
      payload: { cmd: 0, backupPath: "abcd" },
    });
    expect(sessions).toHaveLength(2);
    expect(session.isConnected).toBe(false);
    expect(router.getPlaybackSafetyDiagnostics().reconnect.attempts).toBe(1);
    expect(mediaReady).not.toHaveBeenCalled();
    expect(marker).toEqual([]);
    if (live) {
      const consumer = await live;
      expect(Reflect.get(router, "lives").get(station).live).toBeDefined();
      expect(Reflect.get(router, "sessions").get(station).session).toBe(sessions[1]);
      consumer.stop();
    }
  },
);

it("download refuses invalid sealed selection and unsafe admission without dispatch or replacement", async () => {
  const { router, session, sessions } = await fixture();
  const clip = {
    ...sealedClip(router, session),
    file: vi.fn(),
    experiment: { mode: "download", playSpeed: 1, playType: 1, clientType: "WEB", maxClips: 1 } as const,
  };
  const before = session.sent.length;
  await expect(
    router.readEventPlaybackCandidate(station, {
      ...options(),
      clip: { ...clip, selector: { ...clip.selector, record: clip.selector.record + 1 } },
    }),
  ).rejects.toMatchObject({ reason: "not_found" });
  const receipt = await router.readEventPlaybackCandidate(station, { ...options(), enabled: false, clip });
  expect(receipt).toMatchObject({ mode: "download", admissionGateName: "disabled", startAttempted: false });
  expect(session.sent).toHaveLength(before);
  expect(sessions).toHaveLength(1);
});

it("exact sealed clip bypasses newest selection and returns typed video after clean release", async () => {
  const { router, session, marker } = await fixture();
  const scope = {
    stationSn: station,
    cameraSns: new Set([camera]),
    identityKey: new Uint8Array(32).fill(7),
    accountNamespace: recordingAccountNamespace(new Uint8Array(32).fill(7), "synthetic"),
  };
  Reflect.get(router, "deps").recordings = { enabled: true, stationBinding: station, allowedCameras: scope.cameraSns };
  const result = normalizeRecordingRows(session.tableRows, scope);
  if (result.status !== "ok") throw Error("fixture");
  const selector = result.rows[0]!.playbackSelector!,
    video = vi.fn();
  const before = session.sent.filter((p) => parsePortalHeader(p)!.commandId === 1350).length;
  const pending = router.readEventPlaybackCandidate(station, {
    ...options(),
    excluded: new Set(),
    clip: { scope, selector, video },
  });
  await vi.advanceTimersByTimeAsync(5100);
  expect(await pending).toMatchObject({
    admissionGate: 0,
    captureOutcome: "eof",
    releaseOutcome: "release_confirmed",
    latchCleared: true,
    reconnectOutcome: "not_needed",
    ingressVideoFrames: 1,
    ingressAudioFrames: 0,
  });
  expect(video).toHaveBeenCalledOnce();
  expect(marker).toEqual([]);
  expect(router.getPlaybackSafetyDiagnostics().reconnect.attempts).toBe(0);
  expect(session.sent.filter((p) => parsePortalHeader(p)!.commandId === 1350)).toHaveLength(before);
});

it("a clip longer than the optional renewal interval starts under lease deferral", async () => {
  const { router, session, marker } = await fixture();
  const key = new Uint8Array(32).fill(7),
    scope = {
      stationSn: station,
      cameraSns: new Set([camera]),
      identityKey: key,
      accountNamespace: recordingAccountNamespace(key, "synthetic"),
    };
  Reflect.get(router, "deps").recordings = { enabled: true, stationBinding: station, allowedCameras: scope.cameraSns };
  const result = normalizeRecordingRows(
    [{ ...(session.tableRows[0] as object), end_time: "2026-01-15 12:20:00" }],
    scope,
  );
  if (result.status !== "ok") throw Error("fixture");
  const pending = router.readEventPlaybackCandidate(station, {
    ...options(),
    excluded: new Set(),
    clip: { scope, selector: result.rows[0]!.playbackSelector!, video: () => {} },
  });
  await vi.advanceTimersByTimeAsync(5100);
  expect(await pending).toMatchObject({ admissionGate: 0, startAttempted: true, latchRetained: false });
  expect(marker).toEqual([]);
});

it("direct live callers wait for full-clip cleanup before attaching a consumer", async () => {
  const { router, session, marker } = await fixture();
  session.eof = false;
  const key = new Uint8Array(32).fill(7),
    scope = {
      stationSn: station,
      cameraSns: new Set([camera]),
      identityKey: key,
      accountNamespace: recordingAccountNamespace(key, "synthetic"),
    };
  Reflect.get(router, "deps").recordings = { enabled: true, stationBinding: station, allowedCameras: scope.cameraSns };
  const result = normalizeRecordingRows(session.tableRows, scope);
  if (result.status !== "ok") throw Error("fixture");
  const pulling = router.readEventPlaybackCandidate(station, {
    ...options(),
    excluded: new Set(),
    clip: { scope, selector: result.rows[0]!.playbackSelector!, video: () => {} },
  });
  await vi.advanceTimersByTimeAsync(1);
  expect(marker).toEqual([]);
  const consumer = {},
    attach = vi.fn(() => consumer);
  Reflect.get(router, "lives").set(station, {
    sn: camera,
    pending: 0,
    controller: new AbortController(),
    ready: Promise.resolve({ attach }),
  });
  const live = Reflect.get(router, "attachLive").call(router, camera);
  await vi.advanceTimersByTimeAsync(100);
  expect(attach).not.toHaveBeenCalled();
  await vi.advanceTimersByTimeAsync(5100);
  expect(await pulling).toMatchObject({
    captureOutcome: "preempted",
    releaseOutcome: "release_confirmed",
    latchCleared: true,
  });
  expect(await live).toBe(consumer);
  expect(attach).toHaveBeenCalledOnce();
  expect(marker).toEqual([]);
});
it.each(["time_refused", "table_failed", "table_timeout", "selectors_exhausted", "admission_after_dispatch"])(
  "no-start %s leaves the playback slot clear and health clean",
  async (refusal) => {
    const { router, session, marker } = await fixture();
    const owner = Reflect.get(router, "sessions").get(station);
    if (refusal === "time_refused")
      session.tableRows = [{ device_sn: camera, record_id: 40, start_time: "invalid", end_time: "invalid" }];
    if (refusal === "table_failed") session.tableResultCode = -1;
    if (refusal === "table_timeout") session.tableReply = false;
    if (refusal === "selectors_exhausted")
      for (let selector = 6; selector <= 249; selector++) owner.playbackSelectors.add(selector);
    let fresh = true;
    const beforeDispatch = vi.fn(() => {
      if (refusal === "admission_after_dispatch") fresh = false;
    });
    const pending = router.readEventPlaybackCandidate(station, { ...options(), beforeDispatch, fresh: () => fresh });
    await vi.advanceTimersByTimeAsync(8100);
    const result = await pending;
    expect(result).toMatchObject({
      startAttempted: false,
      pauseSent: false,
      stopSent: false,
      ownerContinuous: true,
      healthOutcome: "clean",
      cessationOutcome: "not_started",
      releaseOutcome: "not_started",
      latchPersisted: false,
      latchRetained: false,
      latchPersistenceFailed: false,
    });
    if (refusal === "time_refused")
      expect(result).toMatchObject({ captureOutcome: "time_refused", selectionOutcome: "time_invalid" });
    if (refusal === "selectors_exhausted") expect(result.selectionOutcome).toBe("selected");
    expect(beforeDispatch).toHaveBeenCalledOnce();
    expect(marker).toEqual([]);
    expect(session.sent.filter((packet) => parsePortalHeader(packet)!.commandId === 1700)).toHaveLength(0);
    expect(router.getPlaybackSafetyDiagnostics()).toMatchObject({ unresolved: false, active: false });
  },
);
it("a pre-dispatch marker failure leaves direct live attachment available", async () => {
  const { router, session } = await fixture();
  router.configurePlaybackSafety(false, () => {
    throw Error("synthetic_storage_failure");
  });
  const pending = router.readEventPlaybackCandidate(station, options());
  await vi.advanceTimersByTimeAsync(100);
  expect(await pending).toMatchObject({
    captureOutcome: "storage_failed",
    startAttempted: false,
    latchRetained: false,
  });
  expect(session.sent.filter((packet) => parsePortalHeader(packet)!.commandId === 1700)).toHaveLength(0);
  expect(router.getPlaybackSafetyDiagnostics()).toMatchObject({ unresolved: false, active: false });
  const consumer = {},
    attach = vi.fn(() => consumer);
  Reflect.get(router, "lives").set(station, {
    sn: camera,
    pending: 0,
    controller: new AbortController(),
    ready: Promise.resolve({ attach }),
  });
  expect(await Reflect.get(router, "attachLive").call(router, camera)).toBe(consumer);
  expect(attach).toHaveBeenCalledOnce();
});
it("full current-table/start/pause/next-selector stop path uses one original owner and releases its scheduler", async () => {
  const { router, session, sessions, marker } = await fixture();
  const enqueue = vi.spyOn(Reflect.get(router, "sessions").get(station).scheduler, "enqueue");
  const opts = options();
  const fresh = vi.fn(opts.fresh);
  opts.fresh = fresh;
  const pending = router.readEventPlaybackCandidate(station, opts);
  await vi.advanceTimersByTimeAsync(5100);
  expect((await pending).admissionGate).toBe(0);
  expect(fresh).toHaveBeenCalled();
  expect(enqueue).toHaveBeenCalledOnce();
  const result = await pending;
  expect(result).toMatchObject({
    captureOutcome: "eof",
    releaseOutcome: "release_confirmed",
    cessationOutcome: "ceased",
    boundedMediaObserved: true,
    latchCleared: true,
  });
  expect(marker).toEqual([true, false]);
  expect(sessions).toHaveLength(1);
  const playback = session.sent.filter((p) => parsePortalHeader(p)!.commandId === 1700);
  expect(playback.map((p) => JSON.parse(p.subarray(16).toString()).data.cmd)).toEqual([0, 1, 3]);
  expect(playback.map((p) => parsePortalHeader(p)!.isResponse)).toEqual([6, 6, 7]);
  expect(router.getPlaybackSafetyDiagnostics()).toMatchObject({ unresolved: false, active: false });
});
it("qualified release re-latches and refuses live after admitted traffic exceeds the old budget", async () => {
  const { router, session, marker } = await fixture();
  const pending = router.readEventPlaybackCandidate(station, options());
  await vi.advanceTimersByTimeAsync(5100);
  expect(await pending).toMatchObject({
    releaseOutcome: "release_confirmed",
    cessationOutcome: "ceased",
    latchCleared: true,
  });
  expect(marker).toEqual([true, false]);
  const live = packetize(Buffer.concat([buildPortalHeader(1300, 512, 101, 9, 1), Buffer.alloc(512)]), {
    channel: 5,
    frameId: 30000,
    payloadBytes: 1000,
  })[0]!;
  for (let i = 0; i < 16385; i++) session.inject(live);
  expect(router.getPlaybackSafetyDiagnostics().unresolved).toBe(false);
  const bytes = zstdCompressSync(Buffer.concat([buildPortalHeader(1301, 4, 101, 9, 7), Buffer.alloc(4)]));
  const reserved = packetize(bytes, { channel: 4, frameId: 30001, payloadBytes: 1000 });
  expect(reserved).toHaveLength(1);
  reserved[0]!.writeUInt16LE(reserved[0]!.readUInt16LE(18) | 0x0800, 18);
  session.inject(reserved[0]!);
  expect(router.getPlaybackSafetyDiagnostics().unresolved).toBe(true);
  expect(marker).toEqual([true, false, true]);
  await expect(router.mediaProviderFor(camera).live!()).rejects.toThrow("playback_slot_uncertain");
  expect(session.sent.filter((p) => parsePortalHeader(p)!.commandId === 1700)).toHaveLength(3);
});
it("missing release survives a new owner and blocks live while ordinary control remains usable", async () => {
  const { router, session, sessions } = await fixture();
  session.releaseStatus = false;
  const pending = router.readEventPlaybackCandidate(station, options());
  await vi.advanceTimersByTimeAsync(24010);
  expect((await pending).releaseOutcome).toBe("stop_unconfirmed");
  await expect(router.mediaProviderFor(camera).live!()).rejects.toThrow("playback_slot_uncertain");
  session.close();
  const control = router.dispatchCommand(camera, { kind: "set-payload", cmd: 1400, payload: { value: 0 }, channel: 2 });
  await vi.advanceTimersByTimeAsync(1);
  await control;
  expect(sessions).toHaveLength(2);
  expect(router.getPlaybackSafetyDiagnostics().unresolved).toBe(true);
});
it("queued correction demand preempts capture and gets the scheduler immediately after both cleanup sends", async () => {
  const { router, session } = await fixture();
  session.eof = false;
  const pending = router.readEventPlaybackCandidate(station, options());
  await vi.advanceTimersByTimeAsync(1);
  const before = performance.now();
  const correction = router.dispatchCommand(camera, {
    kind: "set-payload",
    cmd: 1400,
    payload: { value: 0 },
    channel: 2,
  });
  await vi.advanceTimersByTimeAsync(1);
  await correction;
  expect(performance.now() - before).toBeLessThan(100);
  const kinds = session.sent.map((p) => {
    const h = parsePortalHeader(p)!;
    if (h.commandId === 1103) return 1103;
    const data = JSON.parse(p.subarray(16).toString());
    return h.commandId === 1700 ? data.data.cmd : data.cmd;
  });
  expect(kinds.slice(-4)).toEqual([0, 1, 3, 1400]);
  await vi.advanceTimersByTimeAsync(5100);
  expect((await pending).captureOutcome).toBe("preempted");
});
it("dormant safety leaves ordinary, compressed, keepalive and live traffic identical to baseline", async () => {
  const { router, session, marker } = await fixture();
  router.configurePlaybackSafety(false, (value) => marker.push(value), false);
  expect(session.guard).toBeUndefined();
  const baseline = new Session();
  await baseline.connect();
  const trace = (s: Session) => {
    const result: unknown[] = [];
    s.on("commandData", (frame, link) => result.push(["control", frame.toString("hex"), link]));
    s.on("mediaData", (frame, link) => result.push(["live", frame.toString("hex"), link]));
    s.on("keepaliveEcho", () => result.push(["keepalive"]));
    return result;
  };
  const expected = trace(baseline),
    actual = trace(session);
  try {
    let id = 9000;
    for (const [command, route, compressed] of [
      [1350, 0, false],
      [1351, 2, true],
      [1300, 1, false],
      [1301, 5, true],
    ] as const) {
      const data = Buffer.concat([
        buildPortalHeader(command, 4, command >= 1300 && command <= 1301 ? 101 : 0, 0, 1),
        Buffer.alloc(4),
      ]);
      const parts = packetize(compressed ? zstdCompressSync(data) : data, { channel: route, frameId: ++id });
      for (const p of parts) {
        if (compressed) p.writeUInt16LE(p.readUInt16LE(18) | 0x0800, 18);
        baseline.inject(p);
        session.inject(p);
      }
    }
    baseline.inject(PORTAL_KEEPALIVE);
    session.inject(PORTAL_KEEPALIVE);
    expect(actual).toEqual(expected);
    expect(actual).toHaveLength(5);
    expect(marker).toEqual([]);
    const refresh = router.refreshInformation(station);
    await vi.advanceTimersByTimeAsync(1);
    await refresh;
    expect(session.guard).toBeUndefined();
  } finally {
    baseline.close();
  }
});
it("dormant unresolved state preserves the cross-restart media block required by the latch contract", async () => {
  const { router, session } = await fixture();
  router.configurePlaybackSafety(true, () => {}, false);
  expect(session.guard).toBeDefined();
  await expect(router.mediaProviderFor(camera).live!()).rejects.toThrow("playback_slot_uncertain");
  const control = router.dispatchCommand(camera, { kind: "set-payload", cmd: 1400, payload: { value: 0 }, channel: 2 });
  await vi.advanceTimersByTimeAsync(1);
  await control;
  expect(router.getPlaybackSafetyDiagnostics().unresolved).toBe(true);
});

it("a failed capture drains cleanly and permits another attempt on the same owner", async () => {
  const { router, session, sessions, marker } = await fixture();
  session.corruptMedia = true;
  const beforeDispatch = vi.fn();
  const failed = router.readEventPlaybackCandidate(station, { ...options(), beforeDispatch });
  await vi.advanceTimersByTimeAsync(5100);
  expect(await failed).toMatchObject({
    captureOutcome: "invalid_media",
    boundedMediaObserved: false,
    releaseOutcome: "release_confirmed",
    cessationOutcome: "ceased",
    latchCleared: true,
    unknown: false,
  });
  expect(beforeDispatch).toHaveBeenCalledOnce();
  expect(router.getPlaybackSafetyDiagnostics().unresolved).toBe(false);
  session.corruptMedia = false;
  const next = router.readEventPlaybackCandidate(station, options());
  await vi.advanceTimersByTimeAsync(5100);
  expect(await next).toMatchObject({ captureOutcome: "eof", releaseOutcome: "release_confirmed", latchCleared: true });
  expect(sessions).toHaveLength(1);
  expect(marker).toEqual([true, false, true, false]);
});

function sealedClip(router: RtcCommandRouter, session: Session) {
  const key = new Uint8Array(32).fill(7);
  const scope = {
    stationSn: station,
    cameraSns: new Set([camera]),
    identityKey: key,
    accountNamespace: recordingAccountNamespace(key, "synthetic"),
  };
  Reflect.get(router, "deps").recordings = { enabled: true, stationBinding: station, allowedCameras: scope.cameraSns };
  const result = normalizeRecordingRows(session.tableRows, scope);
  if (result.status !== "ok") throw Error("fixture");
  return { scope, selector: result.rows[0]!.playbackSelector!, video: () => {} };
}

it.each([true, false])(
  "fresh playback owner gets an early keepalive without bypassing observation (echo=%s)",
  async (echo) => {
    const { router, session, sessions } = await fixture(PORTAL_KEEPALIVE_MS);
    const clip = sealedClip(router, session);
    const original = Reflect.get(router, "sessions").get(station);
    const reconnecting = Reflect.get(router, "reconnectPlayback").call(router, station, original);
    await vi.advanceTimersByTimeAsync(0);
    expect(await reconnecting).toMatchObject({ reconnectOutcome: "connected" });
    const replacement = Reflect.get(router, "sessions").get(station);
    const fresh = sessions[1]!;
    fresh.echoRaw = echo;
    expect(replacement).not.toBe(original);
    expect(fresh.isConnected).toBe(true);
    expect(replacement.playbackObservation.ordinaryFrames).toBeGreaterThan(0);
    expect(replacement.playbackObservation.keepalives).toBe(0);
    const connectedAt = performance.now();
    await vi.advanceTimersByTimeAsync(999);
    expect(fresh.raw).toEqual([]);
    expect(replacement.playbackObservation.keepalives).toBe(0);
    await vi.advanceTimersByTimeAsync(1);
    expect(fresh.raw).toEqual([PORTAL_KEEPALIVE]);
    expect(replacement.playbackObservation.keepalives).toBe(echo ? 1 : 0);
    expect(await router.readEventPlaybackCandidate(station, { ...options(), clip })).toMatchObject({
      admissionGateName: "observation_window",
      startAttempted: false,
    });
    await vi.advanceTimersByTimeAsync(3999);
    expect(await router.readEventPlaybackCandidate(station, { ...options(), clip })).toMatchObject({
      admissionGateName: "observation_window",
      startAttempted: false,
    });
    await vi.advanceTimersByTimeAsync(1);
    expect(performance.now() - connectedAt).toBe(5000);
    const pending = router.readEventPlaybackCandidate(station, { ...options(), clip });
    await vi.advanceTimersByTimeAsync(0);
    if (echo) {
      expect(Reflect.get(router, "playbackProbes").get(station).candidate.receipt).toMatchObject({
        admissionGateName: "none",
        startAttempted: true,
      });
      await vi.advanceTimersByTimeAsync(5100);
      expect(await pending).toMatchObject({ admissionGateName: "none", captureOutcome: "eof" });
    } else {
      expect(await pending).toMatchObject({ admissionGateName: "no_keepalives", startAttempted: false });
      expect(fresh.sent.filter((p) => parsePortalHeader(p)!.commandId === 1700)).toEqual([]);
    }
  },
);

it("names a transient admission refusal when freshness changes before the scheduler recheck", async () => {
  const { router, session } = await fixture();
  let fresh = true;
  const pending = router.readEventPlaybackCandidate(station, {
    ...options(),
    clip: sealedClip(router, session),
    fresh: () => fresh,
    beforeDispatch: () => {
      fresh = false;
    },
  });
  await vi.advanceTimersByTimeAsync(1);
  expect(await pending).toMatchObject({
    captureOutcome: "not_admitted",
    startAttempted: false,
    admissionGate: 26,
    admissionGateName: "start_not_allowed",
  });
  expect(session.sent.filter((packet) => parsePortalHeader(packet)!.commandId === 1700)).toHaveLength(0);
});

it("keeps a slow correlated EOF capture alive beyond duration plus fifteen seconds", async () => {
  const { router, session } = await fixture();
  session.tableRows = [
    { device_sn: camera, record_id: 40, start_time: "2026-01-15 12:00:00", end_time: "2026-01-15 12:00:12" },
  ];
  session.eof = false;
  const clip = sealedClip(router, session);
  const pending = router.readEventPlaybackCandidate(station, { ...options(), clip });
  await vi.advanceTimersByTimeAsync(1);
  const body = Buffer.alloc(29);
  body.writeUInt32LE(7);
  body[5] = 1;
  Buffer.from([0, 0, 0, 1, 0x26, 1, 0x80]).copy(body, 22);
  for (let i = 1; i <= 120; i++) {
    await vi.advanceTimersByTimeAsync(i === 40 || i === 80 ? 1500 : 70);
    session.input(1300, body, 4, 101, 6);
  }
  await vi.advanceTimersByTimeAsync(19000);
  const start = session.sent.find((packet) => parsePortalHeader(packet)!.commandId === 1700)!;
  session.input(1351, { cmd: 6001, payload: { state: 2, code: 14, segmen: parsePortalHeader(start)!.segment } });
  await vi.advanceTimersByTimeAsync(16001);
  expect(await pending).toMatchObject({
    captureOutcome: "eof",
    boundedMediaObserved: true,
    completenessFailure: "none",
    maxVideoGapMs: 1500,
  });
});

it("EOF capture reconnects and re-admits the replacement after observation and a live view", async () => {
  const { router, session, sessions } = await fixture();
  session.eof = false;
  session.releaseStatus = false;
  const clip = sealedClip(router, session),
    video = vi.fn();
  const pending = router.readEventPlaybackCandidate(station, { ...options(), clip: { ...clip, video } });
  await vi.advanceTimersByTimeAsync(1);
  const body = Buffer.alloc(29);
  body.writeUInt32LE(7);
  body[5] = 1;
  Buffer.from([0, 0, 0, 1, 0x26, 1, 0x80]).copy(body, 22);
  const input = () => session.input(1300, body, 4, 101, 6);
  for (let i = 0; i < 15; i++) {
    await vi.advanceTimersByTimeAsync(60);
    input();
  }
  await vi.advanceTimersByTimeAsync(850);
  for (let i = 0; i < 3; i++) input();
  session.input(1351, { cmd: 6001, payload: { state: 2, code: 14 } });
  await vi.advanceTimersByTimeAsync(1);
  for (let i = 0; i < 16; i++) {
    input();
    await vi.advanceTimersByTimeAsync(1000);
  }
  expect(await pending).toMatchObject({
    captureOutcome: "eof",
    boundedMediaObserved: true,
    releaseOutcome: "stop_unconfirmed",
    reconnectOutcome: "connected",
  });
  expect(video).toHaveBeenCalledTimes(19);
  const replacement = Reflect.get(router, "sessions").get(station);
  expect(replacement.lastInformationRead).toBeDefined();
  expect(replacement.playbackObservation.ordinaryFrames).toBeGreaterThan(0);
  expect(Reflect.get(router, "playbackHolds").size).toBe(0);
  const refused = await router.readEventPlaybackCandidate(station, { ...options(), clip });
  expect(refused).toMatchObject({ captureOutcome: "not_admitted", admissionGateName: "no_keepalives" });
  const livePending = router.mediaProviderFor(camera).live!();
  await vi.advanceTimersByTimeAsync(1);
  const consumer = await livePending;
  sessions[1]!.input(1300, body, 5, 101, 1);
  consumer.stop();
  sessions[1]!.inject(PORTAL_KEEPALIVE);
  await vi.advanceTimersByTimeAsync(60001);
  expect(replacement.playbackObservation.prestartSafe()).toBe(true);
  const next = router.readEventPlaybackCandidate(station, { ...options(), clip });
  await vi.advanceTimersByTimeAsync(5100);
  expect(await next).toMatchObject({ admissionGateName: "none", captureOutcome: "eof" });
});

it("no-media unconfirmed clip replaces the session, holds reads and live, then releases without a marker", async () => {
  const { router, session, sessions, marker } = await fixture();
  session.mediaEnabled = false;
  session.releaseStatus = false;
  const clip = sealedClip(router, session);
  const connected = Promise.withResolvers<void>();
  const create = Reflect.get(router, "deps").createSession;
  Reflect.get(router, "deps").createSession = () => {
    const next = create() as Session;
    const connect = next.connect.bind(next);
    next.connect = async () => {
      await connected.promise;
      await connect();
    };
    return next;
  };
  const pulling = router.readEventPlaybackCandidate(station, { ...options(), clip });
  await vi.advanceTimersByTimeAsync(21100);
  expect(router.getPlaybackSafetyDiagnostics()).toMatchObject({ unresolved: true, reconnect: { attempts: 1 } });
  expect(await router.readRecordingCatalog(clip.scope)).toMatchObject({ reason: "busy" });
  const retired = Reflect.get(router, "sessions").get(station);
  let liveSettled = false;
  const live = router.mediaProviderFor(camera).live!().finally(() => {
    liveSettled = true;
  });
  await vi.advanceTimersByTimeAsync(100);
  expect(liveSettled).toBe(false);
  expect(Reflect.get(router, "lives").has(station)).toBe(false);
  expect(retired.leases).toBe(0);
  expect(session.sent.filter((p) => parsePortalHeader(p)!.commandId === 1350)).toHaveLength(0);
  connected.resolve();
  await vi.advanceTimersByTimeAsync(1);
  expect(await pulling).toMatchObject({
    captureOutcome: "no_media",
    startAcknowledged: false,
    releaseOutcome: "stop_unconfirmed",
    reconnectOutcome: "connected",
    ingressVideoFrames: 0,
    ingressAudioFrames: 0,
  });
  const consumer = await live;
  const replacement = Reflect.get(router, "sessions").get(station);
  const entry = Reflect.get(router, "lives").get(station);
  expect(replacement).not.toBe(retired);
  expect(replacement.session).toBe(sessions[1]);
  expect(Reflect.get(entry.live, "opts").session).toBe(replacement.session);
  expect(retired.leases).toBe(0);
  expect(replacement.leases).toBe(1);
  expect(session.sent.filter((p) => parsePortalHeader(p)!.commandId === 1350)).toHaveLength(0);
  const starts = sessions[1]!.sent.filter((p) => parsePortalHeader(p)!.commandId === 1350);
  expect(starts).toHaveLength(1);
  expect(JSON.parse(starts[0]!.subarray(16).toString())).toMatchObject({ cmd: 1003 });
  expect(session.isConnected).toBe(false);
  expect(sessions).toHaveLength(2);
  expect(router.getPlaybackSafetyDiagnostics()).toMatchObject({ unresolved: false, reconnect: { connected: 1 } });
  expect(marker).toEqual([]);
  consumer.stop();
  expect(replacement.leases).toBe(0);
});

it.each(["failed", "timed_out"] as const)(
  "failed %s playback recovery preserves the owner and blocks unsafe live acquisition",
  async (outcome) => {
    const { router, session, sessions } = await fixture();
    const retired = Reflect.get(router, "sessions").get(station);
    const connected = Promise.withResolvers<void>();
    if (outcome === "failed") {
      const create = Reflect.get(router, "deps").createSession;
      Reflect.get(router, "deps").createSession = () => {
        const next = create() as Session;
        if (sessions.length === 2) next.connect = () => connected.promise;
        return next;
      };
    } else {
      vi.spyOn(router as unknown as { replaceSession: () => Promise<void> }, "replaceSession").mockImplementation(
        () => new Promise(() => {}),
      );
    }
    const recovering = Reflect.get(router, "reconnectPlayback").call(router, station, retired);
    let liveSettled = false;
    const live = router.mediaProviderFor(camera).live!()
      .catch((error: Error) => error)
      .finally(() => {
        liveSettled = true;
      });
    await vi.advanceTimersByTimeAsync(outcome === "timed_out" ? 59999 : 100);
    expect(liveSettled).toBe(false);
    expect(Reflect.get(router, "lives").has(station)).toBe(false);
    expect(retired.leases).toBe(0);
    if (outcome === "failed") connected.reject(new Error("synthetic connection failure"));
    await vi.advanceTimersByTimeAsync(1);
    expect(await recovering).toMatchObject({ reconnectOutcome: outcome });
    expect(liveSettled).toBe(true);
    expect(await live).toMatchObject({ message: "playback_slot_uncertain" });
    expect(Reflect.get(router, "sessions").get(station)).toBe(retired);
    expect(session.isConnected).toBe(true);
    expect(retired.leases).toBe(0);
    expect(router.getPlaybackSafetyDiagnostics().unresolved).toBe(true);
  },
);

it("uncertain clip retains its owner and safety latch on replacement failure", async () => {
  const { router, session } = await fixture();
  session.releaseStatus = false;
  const owner = Reflect.get(router, "sessions").get(station);
  owner.refreshAttempts = 2;
  Reflect.get(router, "deps").createSession = () => {
    throw Error("synthetic connection failure");
  };
  const pending = router.readEventPlaybackCandidate(station, { ...options(), clip: sealedClip(router, session) });
  await vi.advanceTimersByTimeAsync(16100);
  expect(await pending).toMatchObject({ reconnectOutcome: "failed" });
  expect(session.isConnected).toBe(true);
  expect(router.getPlaybackSafetyDiagnostics().unresolved).toBe(true);
  expect(Reflect.get(router, "sessions").get(station)).toBe(owner);
});

it("reconnect hard cap releases waiters and preserves ownership when renewal never settles", async () => {
  const { router, session } = await fixture();
  const owner = Reflect.get(router, "sessions").get(station);
  vi.spyOn(router as unknown as { replaceSession: () => Promise<void> }, "replaceSession").mockImplementation(
    () => new Promise(() => {}),
  );
  const recovering = Reflect.get(router, "reconnectPlayback").call(router, station, owner);
  let finished = false;
  const waiter = Reflect.get(router, "waitForPlaybackReconnect")
    .call(router, station)
    .then(() => {
      finished = true;
    });
  await vi.advanceTimersByTimeAsync(59999);
  expect(finished).toBe(false);
  await vi.advanceTimersByTimeAsync(1);
  expect(await recovering).toEqual({ reconnectOutcome: "timed_out", reconnectDurationMs: 60000 });
  await waiter;
  expect(session.isConnected).toBe(true);
  expect(router.getPlaybackSafetyDiagnostics()).toMatchObject({ unresolved: true, reconnect: { timedOut: 1 } });
});

it("admits playback after sequential live stops and trailing LIVE media on the same owner", async () => {
  const { router, session } = await fixture();
  for (const target of [camera, "second-camera-synthetic"]) {
    const pending = router.mediaProviderFor(target).live!();
    await vi.advanceTimersByTimeAsync(1);
    const consumer = await pending;
    session.input(1300, Buffer.alloc(22), 5, 101, 1);
    await vi.advanceTimersByTimeAsync(11000);
    session.input(1300, Buffer.alloc(22), 5, 101, 1);
    consumer.stop();
    for (const command of [1300, 1301, 1303]) session.input(command, Buffer.alloc(22), 5, 101, 1);
  }
  await vi.advanceTimersByTimeAsync(20000);
  for (const command of [1300, 1301, 1303]) session.input(command, Buffer.alloc(22), 5, 101, 1);
  expect(Reflect.get(router, "sessions").get(station).liveTargetAmbiguous).toBe(true);
  const next = router.readEventPlaybackCandidate(station, options());
  await vi.advanceTimersByTimeAsync(5100);
  expect(await next).toMatchObject({ admissionGateName: "none", captureOutcome: "eof" });
});

it.each([false, true])("late playback fragments recover a finished clip compressed=%s", async (compressed) => {
  const { router, session, sessions } = await fixture();
  const pending = router.readEventPlaybackCandidate(station, { ...options(), clip: sealedClip(router, session) });
  await vi.advanceTimersByTimeAsync(5100);
  expect(await pending).toMatchObject({ releaseOutcome: "release_confirmed", reconnectOutcome: "not_needed" });
  const frame = Buffer.concat([buildPortalHeader(1300, 5000, 101, 9, 6), Buffer.alloc(5000)]);
  const fragments = packetize(compressed ? zstdCompressSync(frame) : frame, {
    channel: 4,
    frameId: ++session.counter,
    payloadBytes: 8,
  });
  expect(fragments.length).toBeGreaterThan(1);
  if (compressed) for (const p of fragments) p.writeUInt16LE(p.readUInt16LE(18) | 0x0800, 18);
  session.inject(fragments.at(-1)!);
  await vi.advanceTimersByTimeAsync(10);
  expect(sessions).toHaveLength(2);
  expect(session.isConnected).toBe(false);
  expect(Reflect.get(router, "sessions").get(station).session).toBe(sessions[1]);
  expect(router.getPlaybackSafetyDiagnostics().reconnect).toMatchObject({ attempts: 1, connected: 1 });
});

it.each([
  ["matched", false],
  ["matched", true],
  ["unmatched", false],
  ["matched", false, 2, 18],
  ["matched", true, 2, 18],
  ["unmatched", false, 2, 18],
])(
  "clip refusal reconnect safety: %s release=%s state=%s code=%s",
  async (refusal, releaseStatus, state = 0, code = 7) => {
    const { router, session, sessions } = await fixture();
    session.refusal = refusal;
    session.refusalState = state as number;
    session.refusalCode = code as number;
    session.releaseStatus = releaseStatus as boolean;
    const pending = router.readEventPlaybackCandidate(station, { ...options(), clip: sealedClip(router, session) });
    await vi.advanceTimersByTimeAsync(25000);
    const receipt = await pending;
    expect(receipt).toMatchObject({
      captureOutcome: "start_refused",
      startAcknowledged: false,
      stationRefusalConfirmed: refusal === "matched",
      reconnectOutcome: "connected",
      latchRetained: true,
      latchCleared: false,
      ownerContinuous: true,
      stopSent: true,
      cessationOutcome: refusal === "matched" ? "ceased" : "cessation_unknown",
    });
    expect(sessions).toHaveLength(2);
    expect(session.isConnected).toBe(false);
    expect(Reflect.get(router, "sessions").get(station).session).toBe(sessions[1]);
    session.input(1351, { cmd: 6001, payload: { state: 1, code: 0 } });
    expect(Reflect.get(router, "sessions").get(station).session).toBe(sessions[1]);
    expect(router.getPlaybackSafetyDiagnostics().reconnect.attempts).toBe(1);
  },
);

it.each([
  ["connected", undefined],
  ["failed", undefined],
  ["connected", { playSpeed: 8, playType: 1, clientType: "WEB", maxClips: 1 }],
  ["failed", { playSpeed: 8, playType: 1, clientType: "WEB", maxClips: 1 }],
] as const)(
  "EOF media is delivered before %s cleanup and live waits for retirement with %j",
  async (outcome, experiment) => {
    const { router, session, sessions } = await fixture();
    session.eof = false;
    session.releaseStatus = false;
    const connected = Promise.withResolvers<void>();
    const create = Reflect.get(router, "deps").createSession;
    Reflect.get(router, "deps").createSession = () => {
      const next = create() as Session;
      const connect = next.connect.bind(next);
      next.connect = async () => {
        await connected.promise;
        if (outcome === "failed") throw new Error("synthetic setup failure");
        await connect();
      };
      return next;
    };
    const mediaReady = vi.fn();
    let settled = false;
    const pulling = router
      .readEventPlaybackCandidate(station, {
        ...options(),
        clip: { ...sealedClip(router, session), mediaReady, experiment },
      })
      .finally(() => {
        settled = true;
      });
    await vi.advanceTimersByTimeAsync(250);
    const body = Buffer.alloc(29);
    body.writeUInt32LE(7);
    body[5] = 1;
    Buffer.from([0, 0, 0, 1, 0x26, 1, 0x80]).copy(body, 22);
    for (let i = 0; i < 5; i++) session.input(1300, body, 4, 101, 6);
    session.input(1351, { cmd: 6001, payload: { state: 2, code: 14 } });
    await vi.advanceTimersByTimeAsync(1);
    expect(mediaReady).toHaveBeenCalledOnce();
    expect(mediaReady.mock.calls[0]![0]).toMatchObject({
      captureOutcome: "eof",
      boundedMediaObserved: true,
      mediaDurationMs: 1000,
    });
    expect(settled).toBe(false);
    expect(router.getPlaybackSafetyDiagnostics().reconnect.attempts).toBe(1);
    if (outcome === "connected") {
      let liveSettled = false;
      const live = router.mediaProviderFor(camera).live!().then((consumer) => {
        liveSettled = true;
        return consumer;
      });
      await vi.advanceTimersByTimeAsync(50);
      expect(liveSettled).toBe(false);
      session.input(1300, body, 4, 101, 6);
      expect(Reflect.get(router, "lives").size).toBe(0);
      connected.resolve();
      await vi.advanceTimersByTimeAsync(1);
      const consumer = await live;
      expect(Reflect.get(Reflect.get(router, "lives").get(station).live, "opts").session).toBe(sessions[1]);
      consumer.stop();
    } else {
      connected.resolve();
      await vi.advanceTimersByTimeAsync(1);
    }
    expect(await pulling).toMatchObject({
      captureOutcome: "eof",
      boundedMediaObserved: true,
      reconnectOutcome: outcome,
    });
  },
);

it.each([4999, 5000])("foreground readiness requires five seconds: %s ms", async (age) => {
  const { router, session } = await fixture();
  const clip = sealedClip(router, session);
  const owner = Reflect.get(router, "sessions").get(station);
  owner.connectedAtMonotonicMs = performance.now() - age;
  owner.playbackObservation.observedSinceMs = performance.now() - age;
  const pending = router.readEventPlaybackCandidate(station, { ...options(), clip });
  await vi.advanceTimersByTimeAsync(5100);
  expect(await pending).toMatchObject(
    age < 5000
      ? { admissionGateName: "observation_window", startAttempted: false }
      : { admissionGateName: "none", startAttempted: true },
  );
});

it.each([5000, 59999])("diagnostic probes keep the sixty-second observation window: %s ms", async (age) => {
  const { router } = await fixture();
  const owner = Reflect.get(router, "sessions").get(station);
  owner.playbackObservation.observedSinceMs = performance.now() - age;
  const pending = router.readEventPlaybackCandidate(station, options());
  await vi.advanceTimersByTimeAsync(100);
  expect(await pending).toMatchObject({ admissionGateName: "observation_window", startAttempted: false });
});

it("a renewal inside the capture window is deferred without aborting the clip", async () => {
  const { router, session } = await fixture();
  session.eof = false;
  const clip = sealedClip(router, session);
  const owner = Reflect.get(router, "sessions").get(station);
  clearTimeout(owner.refreshTimer);
  owner.refreshTimer = undefined;
  owner.connectedAtMs = Date.now() - 599900;
  Reflect.get(router, "armRefresh").call(router, station, owner);
  const pending = router.readEventPlaybackCandidate(station, { ...options(), clip });
  await vi.advanceTimersByTimeAsync(250);
  expect(owner.refreshPending).toBe(true);
  expect(Reflect.get(router, "playbackProbes").get(station).candidate.receipt.captureOutcome).not.toBe("preempted");
  const body = Buffer.alloc(29);
  body.writeUInt32LE(7);
  body[5] = 1;
  Buffer.from([0, 0, 0, 1, 0x26, 1, 0x80]).copy(body, 22);
  for (let i = 0; i < 5; i++) session.input(1300, body, 4, 101, 6);
  session.input(1351, { cmd: 6001, payload: { state: 2, code: 14 } });
  await vi.advanceTimersByTimeAsync(1);
  expect(await pending).toMatchObject({
    captureOutcome: "eof",
    boundedMediaObserved: true,
    reconnectOutcome: "connected",
  });
});

it.each([9999, 10000])("sealed events use a ten-second end margin: %s ms", async (age) => {
  const { router, session } = await fixture();
  vi.setSystemTime(Date.parse("2026-01-15T18:00:01Z") + age);
  const pending = router.readEventPlaybackCandidate(station, { ...options(), clip: sealedClip(router, session) });
  await vi.advanceTimersByTimeAsync(5100);
  expect(await pending).toMatchObject(
    age < 10000
      ? { captureOutcome: "time_refused", startAttempted: false }
      : { captureOutcome: "eof", startAttempted: true },
  );
});

it("plumbs dynamic ICE policy to new shared sessions and retains selected pair types in receipts", async () => {
  const { router, session, sessions } = await fixture();
  const deps = Reflect.get(router, "deps");
  let policy: "relay" | "all" | undefined = "all";
  deps.icePolicyAtSessionCreation = () => policy;
  const factory = deps.createSession;
  const policies: string[] = [];
  deps.createSession = (o: { peer: { icePolicy: string } }) => {
    policies.push(o.peer.icePolicy);
    return factory(o);
  };
  Object.assign(session, { getSelectedIceCandidateTypes: () => ({ local: "host", remote: "srflx" }) });
  const experiment = { playSpeed: 4, playType: 1, clientType: "WEB", maxClips: 2, icePolicy: "all" } as const;
  session.eof = false;
  const clip = {
    ...sealedClip(router, session),
    experiment,
    mediaReady: undefined as ((r: unknown) => void) | undefined,
  };
  const ready = vi.fn();
  clip.mediaReady = ready;
  const pending = router.readEventPlaybackCandidate(station, { ...options(), clip });
  await vi.advanceTimersByTimeAsync(10);
  const body = Buffer.alloc(29);
  body.writeUInt32LE(7);
  body[5] = 1;
  Buffer.from([0, 0, 0, 1, 0x26, 1, 0x80]).copy(body, 22);
  session.input(1300, body, 4, 101, 6);
  session.input(1351, { cmd: 6001, payload: { state: 2, code: 14 } });
  await vi.advanceTimersByTimeAsync(100);
  const receipt = await pending;
  expect(receipt).toMatchObject({
    experiment,
    selectedIceCandidateType: "host",
    selectedRemoteIceCandidateType: "srflx",
    durationBasis: "catalog_experiment",
    reconnectOutcome: "connected",
  });
  expect(ready).toHaveBeenCalledOnce();
  expect(receipt.timeline!.releaseSettledMs).toBeGreaterThanOrEqual(receipt.timeline!.mediaReadyMs!);
  expect(policies).toEqual(["all"]);
  policy = undefined;
  const replacement = Reflect.get(router, "reconnectPlayback").call(
    router,
    station,
    Reflect.get(router, "sessions").get(station),
  );
  await vi.advanceTimersByTimeAsync(10);
  await replacement;
  expect(policies).toEqual(["all", "relay"]);
  expect(sessions).toHaveLength(3);
});

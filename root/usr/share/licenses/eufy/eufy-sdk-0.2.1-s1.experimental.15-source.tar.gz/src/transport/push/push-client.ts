/** Modified for genomez S1 experimental source preview, 2026-10-14. */
/**
 * FCM/MCS push client — holds a persistent TLS connection to Google's MCS
 * (mtalk.google.com:5228), logs in with the check-in androidId/securityToken,
 * heartbeats, and decodes DataMessageStanza pushes into eufy PushEvents.
 *
 * Implements Google's FCM/MCS push protocol; live-verified against real account pushes.
 */
import { PushLifecycleRecorder } from "./lifecycle-diagnostics.js";
import { thumbnailSourceTime } from "./thumbnail-time.js";
import { EventEmitter } from "node:events";
import tls from "node:tls";
import { mcsRoot } from "./proto.js";
import { MessageTag } from "./message-tags.js";
import { McsParser } from "./parser.js";
import type {
  FcmCredentials,
  McsMessage,
  PushEvent,
  PushPayload,
  RawPushMessage,
  ThumbnailCandidate,
} from "./types.js";
import { noopLogger, type Logger } from "../../core/logger.js";

const HOST = "mtalk.google.com";
const PORT = 5228;
const MCS_VERSION = 41;
const HEARTBEAT_MS = 5 * 60 * 1000;
const SILENCE_MS = HEARTBEAT_MS + 60 * 1000;

function readNullTerminated(buf: Buffer): string {
  const i = buf.indexOf(0);
  return buf.toString("utf8", 0, i === -1 ? buf.length : i);
}

function nonemptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

/**
 * Normalises a decoded eufy envelope without consulting device semantics; semantic event names remain unset.
 * @internal
 */
export function normalizePushEvent(raw: RawPushMessage): PushEvent {
  const env = raw.payload ?? {};
  let inner: unknown = env.payload ?? env;
  if (typeof inner === "string") {
    try {
      inner = JSON.parse(inner);
    } catch {
      inner = undefined;
    }
  }
  const p: PushPayload = typeof inner === "object" && inner ? (inner as PushPayload) : {};
  const eventType = (p.event_type ?? p.a) as number | undefined;
  const url = nonemptyString(p.pic_url) ? p.pic_url : nonemptyString(p.thumbnail) ? p.thumbnail : undefined;
  let thumbnailCandidate: ThumbnailCandidate | undefined;
  if (url) {
    const deviceClaims = [p.device_sn, env.device_sn].filter(nonemptyString);
    const deviceSn = deviceClaims[0];
    const stationClaims = [p.station_sn, env.station_sn, p.s].filter(nonemptyString);
    const stationSn = stationClaims[0];
    thumbnailCandidate = {
      url,
      ...thumbnailSourceTime(env.event_time, p),
      attribution:
        deviceSn && deviceClaims.every((claim) => claim === deviceSn)
          ? { kind: "device", deviceSn }
          : deviceClaims.length === 0 && stationSn
            ? {
                kind: "station",
                ...(stationClaims.every((claim) => claim === stationSn) ? { stationSn } : {}),
              }
            : { kind: "ambiguous" },
    };
  }
  return {
    deviceSn: (p.device_sn ?? env.device_sn ?? p.s) as string | undefined,
    stationSn: (p.station_sn ?? env.station_sn) as string | undefined,
    eventType,
    thumbnailUrl: (p.pic_url ?? p.thumbnail) as string | undefined,
    thumbnailCandidate,
    cipher: (p.cipher ?? p.k) as number | undefined,
    payload: p,
    raw,
  };
}

export class PushClient extends EventEmitter {
  /** Consecutive MCS login rejections tolerated (self-healing propagation) before surfacing an error. */
  private static readonly MAX_LOGIN_FAILURES = 3;
  private socket?: tls.TLSSocket;
  private attempt = 0;
  private readonly parser = new McsParser();
  private heartbeatTimer?: ReturnType<typeof setInterval>;
  private reconnectTimer?: ReturnType<typeof setTimeout>;
  private currentDelay = 0;
  private persistentIds: string[] = [];
  private loggedIn = false;
  private closing = false;
  /** Last decoded inbound MCS frame, including heartbeat pings and acknowledgments. */
  private lastRxMs = 0;
  /** Consecutive MCS login rejections — transient ones self-heal via reconnect (see {@link onMessage}). */
  private loginFailures = 0;
  /**
   * How many of {@link persistentIds} the last `LoginRequest` reported; a successful `LoginResponse`
   * acknowledges them, so they are dropped then.
   */
  private reportedIds = 0;

  constructor(
    private readonly creds: FcmCredentials,
    private readonly logger: Logger = noopLogger,
    private readonly lifecycle = new PushLifecycleRecorder(),
  ) {
    super();
    this.parser.on("message", (m: McsMessage) => this.onMessage(m));
  }

  /** Persistent ids already seen (set this from storage to avoid re-delivery). */
  setPersistentIds(ids: string[]): void {
    this.persistentIds = ids;
  }
  getPersistentIds(): string[] {
    return this.persistentIds;
  }

  /**
   * Open the MCS connection and log in.
   *
   * `servername` is passed explicitly: Node sends SNI only when told to, never deriving it from `host`,
   * and this endpoint answers a connection without SNI with a self-signed certificate naming
   * `invalid2.invalid` — which now fails the handshake rather than being accepted. Verification matters
   * because the login request carries the account's `securityToken`, and an unverified peer could both
   * read it and inject forged pushes into the event path.
   */
  connect(): void {
    this.closing = false;
    this.stopHeartbeat();
    this.parser.reset();
    this.loggedIn = false;
    const attempt = this.lifecycle.beginAttempt();
    this.attempt = attempt;
    this.lifecycle.record("connecting", attempt, { loggedIn: this.loggedIn, closing: this.closing });
    const socket = tls.connect(PORT, HOST, { servername: HOST });
    this.socket = socket;
    socket.setKeepAlive(true);
    socket.on("secureConnect", () => {
      this.lifecycle.record("tls_connected", attempt, {
        loggedIn: this.loggedIn,
        closing: this.closing,
        staleSocket: this.socket !== undefined && socket !== this.socket,
      });
      if (this.closing || socket !== this.socket || socket.destroyed) return;
      this.logger.debug("[push] TLS connected, sending login");
      socket.write(this.buildLoginRequest());
    });
    let frameFailed = false;
    socket.on("data", (d: Buffer) => {
      if (this.closing || socket !== this.socket || socket.destroyed || frameFailed) return;
      this.parser.handleData(d, () => {
        frameFailed = true;
        this.lifecycle.record("frame_parse_failed", attempt, {
          loggedIn: this.loggedIn,
          closing: this.closing,
        });
        socket.destroy();
      });
    });
    let closed = false;
    socket.on("close", (hadError: boolean) => {
      this.lifecycle.record(
        "socket_closed",
        attempt,
        {
          loggedIn: this.loggedIn,
          closing: this.closing,
          staleSocket: this.socket !== undefined && socket !== this.socket,
        },
        { hadError },
      );
      if (closed) return;
      closed = true;
      if (this.socket !== undefined && socket !== this.socket) return;
      this.onClose();
    });
    socket.on("error", (e: NodeJS.ErrnoException) => {
      this.lifecycle.record(
        "socket_error",
        attempt,
        {
          loggedIn: this.loggedIn,
          closing: this.closing,
          staleSocket: this.socket !== undefined && socket !== this.socket,
        },
        { errorCode: e.code },
      );
      this.emit("error", e);
    });
  }

  private buildLoginRequest(): Buffer {
    const LoginRequest = mcsRoot().lookupType("mcs_proto.LoginRequest");
    const hexAndroidId = BigInt(this.creds.androidId).toString(16);
    const obj = {
      adaptiveHeartbeat: false,
      authService: 2,
      authToken: this.creds.securityToken,
      id: "chrome-63.0.3234.0",
      domain: "mcs.android.com",
      deviceId: `android-${hexAndroidId}`,
      networkType: 1,
      resource: this.creds.androidId,
      user: this.creds.androidId,
      useRmq2: true,
      setting: [{ name: "new_vc", value: "1" }],
      clientEvent: [],
      receivedPersistentId: this.persistentIds,
    };
    this.reportedIds = this.persistentIds.length;
    const buf = LoginRequest.encodeDelimited(obj).finish();
    return Buffer.concat([Buffer.from([MCS_VERSION, MessageTag.LoginRequest]), buf]);
  }

  private buildHeartbeatPing(): Buffer {
    const Ping = mcsRoot().lookupType("mcs_proto.HeartbeatPing");
    const buf = Ping.encodeDelimited({}).finish();
    return Buffer.concat([Buffer.from([MessageTag.HeartbeatPing]), buf]);
  }

  private buildHeartbeatAck(lastStreamId?: number): Buffer {
    const Ack = mcsRoot().lookupType("mcs_proto.HeartbeatAck");
    const obj = lastStreamId ? { lastStreamIdReceived: lastStreamId } : {};
    const buf = Ack.encodeDelimited(obj).finish();
    return Buffer.concat([Buffer.from([MessageTag.HeartbeatAck]), buf]);
  }

  private onMessage(m: McsMessage): void {
    if (this.closing) return;
    this.lastRxMs = Date.now();
    switch (m.tag) {
      case MessageTag.LoginResponse:
        if (m.object?.error) {
          this.onLoginError(m.object.error);
        } else {
          this.loggedIn = true;
          this.lifecycle.record("login_accepted", this.attempt, { loggedIn: this.loggedIn, closing: this.closing });
          this.currentDelay = 0;
          this.loginFailures = 0;
          this.persistentIds = this.persistentIds.slice(this.reportedIds);
          this.reportedIds = 0;
          this.startHeartbeat();
          this.logger.debug("[push] logged in");
          this.emit("connect");
        }
        break;
      case MessageTag.DataMessageStanza:
        this.handleDataMessage(m.object);
        break;
      case MessageTag.HeartbeatPing:
        if (this.socket) this.socket.write(this.buildHeartbeatAck(m.object?.lastStreamIdReceived));
        break;
      case MessageTag.HeartbeatAck:
        break;
      case MessageTag.Close:
        this.lifecycle.record("server_close", this.attempt, { loggedIn: this.loggedIn, closing: this.closing });
        this.logger.debug("[push] server sent Close");
        this.socket?.destroy();
        break;
    }
  }

  /**
   * Handle an MCS `LoginResponse` carrying an error. Google occasionally rejects the FIRST login right
   * after check-in (`wrong_secret`) while the freshly-registered androidId/securityToken propagates —
   * it succeeds on the very next attempt. So a login rejection is treated as **transient**: log it and
   * close the socket to let the existing backoff reconnect retry with the same creds, rather than
   * surfacing a self-healing blip as a host-facing `error`. Only once it persists past
   * {@link MAX_LOGIN_FAILURES} consecutive attempts (creds genuinely stale) is it emitted as `error`.
   */
  private onLoginError(error: unknown): void {
    this.lifecycle.record("login_rejected", this.attempt, { loggedIn: this.loggedIn, closing: this.closing });
    this.loginFailures++;
    const msg = `MCS login error: ${JSON.stringify(error)}`;
    if (this.loginFailures >= PushClient.MAX_LOGIN_FAILURES) {
      this.emit("error", new Error(`${msg} (after ${this.loginFailures} attempts)`));
    } else {
      this.logger.warn(`[push] ${msg} — retrying (attempt ${this.loginFailures})`);
    }
    this.socket?.destroy(); // → onClose → scheduleReconnect
  }

  /** Keep sibling source clocks and identity claims with a decoded device body. */
  private handleDataMessage(object: any): void {
    if (object?.persistentId) this.persistentIds.push(object.persistentId);
    const data: Record<string, any> = Object.create(null);
    for (const kv of object?.appData ?? []) {
      if (kv.key === "payload") {
        const json = readNullTerminated(Buffer.from(kv.value, "base64"));
        try {
          data.payload = JSON.parse(json);
        } catch {
          data.payload = json;
        }
      } else {
        data[kv.key] = kv.value;
      }
    }
    const decoded = data.payload;
    const packedEnvelope =
      decoded !== null &&
      typeof decoded === "object" &&
      !Array.isArray(decoded) &&
      Object.prototype.hasOwnProperty.call(decoded, "payload");
    const raw: RawPushMessage = {
      id: object?.id,
      from: object?.from,
      to: object?.to,
      category: object?.category,
      persistentId: object?.persistentId,
      ttl: object?.ttl,
      sent: object?.sent,
      payload: packedEnvelope || Object.keys(data).length === 1 ? (decoded ?? data) : data,
    };
    this.emit("message", raw);
    const event = normalizePushEvent(raw);
    if (event) this.emit("push", event);
  }

  /** Ping periodically; inbound silence tears down the socket for the existing close/backoff path. */
  private startHeartbeat(): void {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      if (this.closing || !this.socket || !this.loggedIn) return;
      if (Date.now() - this.lastRxMs >= SILENCE_MS) {
        this.stopHeartbeat();
        this.lifecycle.record("inbound_silence", this.attempt, { loggedIn: this.loggedIn, closing: this.closing });
        this.logger.debug("[push] no inbound within a heartbeat window — reconnecting");
        this.socket?.destroy();
        return;
      }
      this.socket.write(this.buildHeartbeatPing());
    }, HEARTBEAT_MS);
  }
  private stopHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = undefined;
  }

  private onClose(): void {
    this.stopHeartbeat();
    this.loggedIn = false;
    this.emit("disconnect");
    if (!this.closing) this.scheduleReconnect();
  }

  private scheduleReconnect(): void {
    if (this.closing || this.reconnectTimer) return;
    const delay = this.currentDelay === 0 ? 5000 : this.currentDelay;
    if (this.currentDelay < 60000) this.currentDelay += 10000;
    else if (this.currentDelay < 600000) this.currentDelay += 60000;
    this.lifecycle.record(
      "reconnect_scheduled",
      this.attempt,
      { loggedIn: this.loggedIn, closing: this.closing },
      { retryDelayMs: delay },
    );
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined;
      if (!this.closing) this.connect();
    }, delay);
  }

  close(): void {
    this.closing = true;
    this.lifecycle.record("close_requested", this.attempt, { loggedIn: this.loggedIn, closing: this.closing });
    this.stopHeartbeat();
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = undefined;
    this.socket?.destroy();
    this.socket = undefined;
  }
}

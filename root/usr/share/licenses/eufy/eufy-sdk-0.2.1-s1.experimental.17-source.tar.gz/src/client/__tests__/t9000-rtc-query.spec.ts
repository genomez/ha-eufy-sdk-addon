import { EventEmitter } from "node:events";
import { afterEach, describe, expect, it, vi } from "vitest";
import { RtcCommandRouter } from "../../transport/rtc/command-router.js";
import type { RtcSession } from "../../transport/rtc/session.js";
import type { EufyDevice } from "../../core/types.js";
import type { Command } from "../../core/contracts.js";
import { noopLogger } from "../../core/logger.js";
import { buildPortalHeader, parsePortalHeader, PortalLinkType } from "../../transport/rtc/portal-packet.js";
import { bind } from "../../model/capabilities/__tests__/bind.js";
import type { DoorbellActions } from "../../model/capabilities/doorbell.js";

function fixture(autoAck = true) {
  const station = {
    sn: "fixture-station-private",
    stationSn: "fixture-station-private",
    model: "T9000",
    raw: { member: { admin_user_id: "fixture-account-private" } },
  } as EufyDevice;
  const target = {
    sn: "fixture-camera-private",
    stationSn: station.sn,
    model: "T8214",
    raw: { device_channel: 2 },
  } as EufyDevice;
  let identity: { authToken: string; userId: string } | undefined = {
    authToken: "fixture-token-private",
    userId: "fixture-user-private",
  };
  const packets: Buffer[] = [];
  const logger = { ...noopLogger, debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() };
  const session = Object.assign(new EventEmitter(), {
    isConnected: false,
    async connect() {
      session.isConnected = true;
      session.emit("connected");
    },
    sendCommand(packet: Buffer): boolean {
      packets.push(packet);
      const header = parsePortalHeader(packet)!;
      if (autoAck)
        queueMicrotask(() =>
          session.emit(
            "commandData",
            Buffer.concat([buildPortalHeader(header.commandId, 4, header.channel, header.segment, 1), Buffer.alloc(4)]),
            1,
          ),
        );
      return true;
    },
    sendRaw() {
      return true;
    },
    close() {
      session.isConnected = false;
      session.emit("close");
    },
  });
  const createSession = vi.fn(() => session as unknown as RtcSession);
  const router = new RtcCommandRouter({
    identity: () => identity,
    shard: () => "fixture",
    accountName: () => "fixture",
    findDevice: (sn) => (sn === station.sn ? station : sn === target.sn ? target : undefined),
    createSession,
    logger,
  });
  const notify = (
    over: {
      link?: number;
      outer?: number;
      channel?: number;
      cmd?: number;
      segment?: number;
      response?: number;
      payload?: unknown;
      code?: number;
    } = {},
  ) => {
    const header = parsePortalHeader(packets.at(-1)!)!;
    const body = Buffer.from(
      JSON.stringify({
        cmd: over.cmd ?? 6237,
        payload: over.payload ?? {
          voice_list: [{ voice_id: 3, voice_name: "Fixture response", voice_path: "fixture-path" }],
        },
        ...(over.code === undefined ? {} : { code: over.code }),
      }),
    );
    session.emit(
      "commandData",
      Buffer.concat([
        buildPortalHeader(
          over.outer ?? 1351,
          body.length,
          over.channel ?? 2,
          over.segment ?? header.segment,
          over.response ?? 0,
        ),
        body,
      ]),
      over.link ?? 3,
    );
  };
  return {
    router,
    session,
    packets,
    target,
    station,
    createSession,
    notify,
    logger,
    logout: () => {
      identity = undefined;
    },
  };
}
async function ready() {
  for (let i = 0; i < 50; i++) await Promise.resolve();
}
afterEach(() => vi.useRealTimers());

describe("production RTC dispatch and query", () => {
  it.each([
    { kind: "set-param", param: 1045, value: 1, channel: 2, form: "direct-binary" },
    { kind: "p2p-station-scalar", cmd: 1249, value: 75, channel: 2 },
    { kind: "raw-text", cmd: 2731, text: "fixture-private-text", channel: 2 },
    { kind: "set-payload", cmd: 1422, payload: { latitude: "fixture-location-private" }, channel: 2 },
  ] as Command[])("executes and acknowledges $kind without identity in receipts or logs", async (command) => {
    const f = fixture();
    try {
      const receipt = await f.router.dispatchCommandWithReceipt(f.target.sn, command);
      expect(receipt).toMatchObject({ status: "acknowledged", sendAttempted: true, effect: "unconfirmed" });
      expect(f.packets).toHaveLength(1);
      const serialized = JSON.stringify([
        receipt,
        f.router.getCommandDiagnostics(),
        f.logger.debug.mock.calls,
        f.logger.info.mock.calls,
        f.logger.warn.mock.calls,
        f.logger.error.mock.calls,
      ]);
      for (const secret of [
        f.target.sn,
        f.station.sn,
        "fixture-account-private",
        "fixture-token-private",
        "fixture-private-text",
        "fixture-location-private",
      ])
        expect(serialized).not.toContain(secret);
    } finally {
      f.router.close();
    }
  });
  it("refuses a mismatched direct-binary channel before connection", async () => {
    const f = fixture();
    try {
      await expect(
        f.router.dispatchCommand(f.target.sn, {
          kind: "set-param",
          param: 1045,
          value: 1,
          form: "direct-binary",
          channel: 3,
        }),
      ).rejects.toThrow(/reported device channel/);
      expect(f.createSession).not.toHaveBeenCalled();
    } finally {
      f.router.close();
    }
  });

  it("rejects a negative query ACK without waiting for a notification", async () => {
    const f = fixture();
    try {
      const result = f.router.payloadQuery(f.target.sn, 6237).catch((error: unknown) => error);
      await ready();
      const header = parsePortalHeader(f.packets[0]!)!;
      const body = Buffer.alloc(4);
      body.writeInt32LE(-110);
      f.session.emit("commandData", Buffer.concat([buildPortalHeader(1350, 4, 2, header.segment, 1), body]), 1);
      expect(await result).toMatchObject({ message: "RTC payload query rejected: -110" });
    } finally {
      f.router.close();
    }
  });

  it("fetches and parses quick responses through the RTC media provider", async () => {
    const f = fixture();
    try {
      const { acts } = bind<DoorbellActions>(
        "doorbell",
        { codec: "camera", channel: 2, stationModel: "T9000", paramIds: new Set() },
        { media: f.router.mediaProviderFor(f.target.sn) },
      );
      const result = acts.quickResponses!();
      await ready();
      expect(JSON.parse(f.packets[0]!.subarray(16).toString())).toMatchObject({ cmd: 6237, payload: {}, mValue3: 0 });
      f.notify();
      expect(await result).toEqual([{ voiceId: 3, name: "Fixture response", path: "fixture-path", custom: true }]);
    } finally {
      f.router.close();
    }
  });
  it("ignores ACKs and unrelated notifications until the matching reply", async () => {
    const f = fixture();
    try {
      let settled = false;
      const result = f.router.payloadQuery(f.target.sn, 6237).then((value) => {
        settled = true;
        return value;
      });
      await ready();
      for (const over of [
        { channel: 3 },
        { link: 1 },
        { outer: 1350 },
        { cmd: 6238 },
        { segment: 200 },
        { response: 1 },
        { payload: [] },
      ])
        f.notify(over);
      await ready();
      expect(settled).toBe(false);
      f.notify({ segment: 0 });
      expect((await result).voice_list).toBeInstanceOf(Array);
      expect(f.session.listenerCount("commandData")).toBe(1);
    } finally {
      f.router.close();
    }
  });
  it("serializes unsegmented same-device queries", async () => {
    const f = fixture();
    try {
      const first = f.router.payloadQuery(f.target.sn, 6237);
      const second = f.router.payloadQuery(f.target.sn, 6237);
      await ready();
      expect(f.packets).toHaveLength(1);
      f.notify({ segment: 0 });
      await first;
      await ready();
      expect(f.packets).toHaveLength(2);
      f.notify({ segment: 0 });
      await second;
    } finally {
      f.router.close();
    }
  });
  it.each(["close", "timeout", "logout", "reject"])("cleans up a failed query: %s", async (reason) => {
    vi.useFakeTimers();
    const f = fixture();
    try {
      const result = f.router.payloadQuery(f.target.sn, 6237, { timeoutMs: 100 }).catch((error: unknown) => error);
      await ready();
      if (reason === "close") f.session.close();
      else if (reason === "reject") f.notify({ code: -1 });
      else {
        if (reason === "logout") {
          f.logout();
          f.notify();
        }
        await vi.advanceTimersByTimeAsync(100);
      }
      const error = await result;
      expect(error).toBeInstanceOf(Error);
      expect(String(error)).not.toContain(f.target.sn);
      expect(String(error)).not.toContain(f.station.sn);
      if (reason === "timeout" || reason === "logout") expect(f.session.isConnected).toBe(true);
    } finally {
      f.router.close();
    }
  });
  it.each([0, -1, 60001, NaN])("refuses invalid query timeout %s before connect", async (timeoutMs) => {
    const f = fixture();
    try {
      await expect(f.router.payloadQuery(f.target.sn, 6237, { timeoutMs })).rejects.toThrow(/options/);
      expect(f.createSession).not.toHaveBeenCalled();
    } finally {
      f.router.close();
    }
  });
});

describe("query isolation and live privacy", () => {
  it("retires only a timed-out query, preserving live media and queued commands", async () => {
    vi.useFakeTimers();
    const f = fixture();
    try {
      const stream = await f.router.mediaProviderFor(f.target.sn).live();
      const stopped = vi.fn();
      stream.on("stop", stopped);
      const query = f.router.payloadQuery(f.target.sn, 6237, { timeoutMs: 100 }).catch((e: unknown) => e);
      await ready();
      const queued = f.router.dispatchCommand(f.target.sn, {
        kind: "set-param",
        param: 1045,
        value: 1,
        form: "direct-binary",
        channel: 2,
      });
      await ready();
      await vi.advanceTimersByTimeAsync(100);
      expect(await query).toBeInstanceOf(Error);
      await queued;
      expect(f.session.isConnected).toBe(true);
      expect(stopped).not.toHaveBeenCalled();
      expect(f.createSession).toHaveBeenCalledOnce();
      expect(f.packets.map((p) => parsePortalHeader(p)!.commandId)).toContain(1045);
      await expect(f.router.payloadQuery(f.target.sn, 6237)).rejects.toThrow(/retired/);
      const unrelated = f.router.payloadQuery(f.target.sn, 6238);
      await ready();
      f.notify({ cmd: 6238 });
      await unrelated;
      stream.stop();
    } finally {
      f.router.close();
    }
  });

  it("surfaces notification rejection codes", async () => {
    const f = fixture();
    try {
      const query = f.router.payloadQuery(f.target.sn, 6237).catch((e: unknown) => e);
      await ready();
      f.notify({ code: -110 });
      expect(await query).toMatchObject({ message: "RTC payload query rejected: -110" });
    } finally {
      f.router.close();
    }
  });

  it.each(["close", "timeout", "reject", "send"])("keeps live logs and errors private: %s", async (reason) => {
    vi.useFakeTimers();
    const f = fixture(reason !== "reject");
    const errors: string[] = [];
    try {
      if (reason === "send") vi.spyOn(f.session, "sendCommand").mockReturnValue(false);
      try {
        const stream = await f.router.mediaProviderFor(f.target.sn).live();
        stream.on("error", (e) => errors.push(e.message));
        await ready();
        const notify = Buffer.from(JSON.stringify({ cmd: 1366, payload: { private: f.station.sn } }));
        f.session.emit("commandData", Buffer.concat([buildPortalHeader(1351, notify.length, 2, 0), notify]), 3);
        if (reason === "timeout") await vi.advanceTimersByTimeAsync(25000);
        else if (reason === "close") f.session.close();
        else if (reason === "reject") {
          const header = parsePortalHeader(f.packets[0]!)!;
          const body = Buffer.alloc(4);
          body.writeInt32LE(-110);
          f.session.emit("commandData", Buffer.concat([buildPortalHeader(1350, 4, 255, header.segment, 1), body]), 1);
        }
        stream.stop();
      } catch (e) {
        errors.push((e as Error).message);
      }
      const output = JSON.stringify([
        errors,
        ...[f.logger.debug, f.logger.info, f.logger.warn, f.logger.error].map((l) => l.mock.calls),
      ]);
      for (const secret of [
        f.station.sn,
        f.target.sn,
        "fixture-account-private",
        "fixture-user-private",
        "fixture-token-private",
      ])
        expect(output).not.toContain(secret);
      expect(f.logger.info).toHaveBeenCalled();
      expect(errors.length).toBeGreaterThan(0);
    } finally {
      f.router.close();
    }
  });
});

describe("bounded query quarantine", () => {
  async function timeout(f: ReturnType<typeof fixture>) {
    const first = f.router.payloadQuery(f.target.sn, 6237, { timeoutMs: 100 }).catch((e: unknown) => e);
    await ready();
    await vi.advanceTimersByTimeAsync(100);
    expect(String(await first)).toMatch(/RTC payload query timed out|expired_before_send/);
  }
  async function retry(f: ReturnType<typeof fixture>) {
    const next = f.router.payloadQuery(f.target.sn, 6237);
    await ready();
    f.notify({ segment: 0 });
    expect((await next).voice_list).toBeInstanceOf(Array);
  }
  it.each([false, true])("lifts quarantine after 45 seconds on a held session, busy=%s", async (busy) => {
    vi.useFakeTimers();
    const f = fixture();
    try {
      const stream = await f.router.mediaProviderFor(f.target.sn).live();
      const stopped = vi.fn();
      stream.on("stop", stopped);
      const body = Buffer.alloc(30);
      body.writeUInt32LE(8, 0);
      body[4] = 1;
      body[5] = 1;
      Buffer.from([0, 0, 0, 1, 0x26, 1, 0xaf, 0]).copy(body, 22);
      const media = setInterval(
        () =>
          f.session.emit(
            "mediaData",
            Buffer.concat([buildPortalHeader(1300, body.length, 101, 0, 0), body]),
            PortalLinkType.LIVE,
          ),
        1000,
      );
      stream.on("stop", () => clearInterval(media));
      await timeout(f);
      await vi.advanceTimersByTimeAsync(30000);
      if (busy)
        await f.router.dispatchCommand(f.target.sn, {
          kind: "set-param",
          param: 1045,
          value: 1,
          form: "direct-binary",
          channel: 2,
        });
      await vi.advanceTimersByTimeAsync(14999);
      await expect(f.router.payloadQuery(f.target.sn, 6237)).rejects.toThrow(/quarantine/);
      await vi.advanceTimersByTimeAsync(1);
      await retry(f);
      expect(stopped).not.toHaveBeenCalled();
      expect(f.createSession).toHaveBeenCalledOnce();
      stream.stop();
    } finally {
      f.router.close();
    }
  });
  it.each([0, 1])("drains a matching late reply early, segmented=%s", async (segmented) => {
    vi.useFakeTimers();
    const f = fixture();
    try {
      await timeout(f);
      for (const wrong of [
        { link: 1 },
        { channel: 3 },
        { cmd: 6238 },
        { segment: 200 },
        { outer: 1350 },
        { response: 1 },
        { payload: [] },
      ])
        f.notify(wrong);
      await expect(f.router.payloadQuery(f.target.sn, 6237)).rejects.toThrow(/quarantine/);
      f.notify(segmented ? {} : { segment: 0 });
      await retry(f);
      expect(f.createSession).toHaveBeenCalledOnce();
    } finally {
      f.router.close();
    }
  });
  it("does not quarantine a query that times out before send", async () => {
    vi.useFakeTimers();
    const f = fixture(false);
    try {
      const block = f.router.dispatchCommand(f.target.sn, { kind: "set-payload", cmd: 1716, payload: {}, channel: 2 });
      await ready();
      await timeout(f);
      expect(f.packets).toHaveLength(1);
      const header = parsePortalHeader(f.packets[0]!)!;
      f.session.emit(
        "commandData",
        Buffer.concat([buildPortalHeader(header.commandId, 4, header.channel, header.segment, 1), Buffer.alloc(4)]),
        1,
      );
      await block;
      await retry(f);
    } finally {
      f.router.close();
    }
  });
});

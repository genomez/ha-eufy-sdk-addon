import { describe, expect, it, vi } from "vitest";
import type { Command } from "../../core/contracts.js";
import type { EufyDevice } from "../../core/types.js";
import { Device } from "../../model/device.js";
import type { MotionActions } from "../../model/capabilities/motion.js";
import { buildRtcControlPacket } from "../../transport/rtc/control-command.js";
import { parsePortalHeader, PORTAL_HEADER_LENGTH } from "../../transport/rtc/portal-packet.js";
import { CommandIntentRegistry } from "../command-intents.js";
import { DeviceRegistry, type DeviceRecord } from "../device-registry.js";
import { EufyMega } from "../eufy-mega.js";
import { PropertyPreparationRecorder } from "../property-preparation-diagnostics.js";

/** Constructor-free facade: real preparation, context, admission and routing with no live clients. */
function fixture(model: string, channel: unknown, stationModel = "T9000", duplicate = false) {
  const station = { sn: "fixture-station", model: stationModel, raw: {} } as EufyDevice;
  const target = {
    sn: "fixture-camera",
    stationSn: station.sn,
    model,
    raw: { device_channel: channel },
  } as EufyDevice;
  const devices = [station, target];
  if (duplicate) devices.push({ ...target, sn: "fixture-other-camera" });
  const record: DeviceRecord = {
    model,
    parentSn: station.sn,
    params: { 1298: JSON.stringify({ ai_detect_type: 0x3000f }) },
    paramUpdatedAt: {},
  };
  const registry = Object.assign(Object.create(DeviceRegistry.prototype) as DeviceRegistry, {
    devices,
    list: () => devices,
    require: () => target,
    record: async () => record,
  });
  const rtc = vi.fn(async () => {});
  const p2p = vi.fn(async () => {});
  const app: EufyMega = Object.assign(Object.create(EufyMega.prototype), {
    registry,
    mega: {},
    parameterWrites: new Map(),
    deviceParamRevisions: new Map(),
    parameterReadSnapshots: new Map(),
    liveDevices: new Map(),
    realtimeEpoch: 0,
    propertyPreparations: new Set(),
    propertyPreparationRecorder: new PropertyPreparationRecorder(),
    commandIntents: new CommandIntentRegistry(),
    lateEffects: { begin: () => undefined, finish: () => false },
    lateContrary: { finishCorrection: () => {} },
    rtc: { commandTimeoutMs: 1_000, dispatchCommand: rtc },
    p2p: { dispatchCommand: p2p },
  });
  const internal = app as unknown as {
    contextForRecord(sn: string, record: DeviceRecord): Parameters<Device["bindActions"]>[0];
  };
  const context = internal.contextForRecord(target.sn, record);
  const device = Device.fromRecord(target.sn, record);
  device.bindActions(context, { dispatch: async () => {} });
  return { app, target, rtc, p2p, device };
}

describe("T9000 AI detection target channel", () => {
  it.each(["T8134", "T8425", "T8170", "T8171", "T8416", "T8426", "T8214"])(
    "routes every bit and restore for %s on zero and nonzero channels",
    async (model) => {
      for (const channel of [0, 1, 3, 9]) {
        const { app, target, rtc, p2p, device } = fixture(model, channel);
        expect((device.motion!() as MotionActions).aiDetectType).toBe(0x3000f);
        expect((device.motion!() as MotionActions).setAiDetectType).toBeTypeOf("function");
        const masks = [1, 2, 4, 8].flatMap((bit) => [0x3000f & ~bit, 0x3000f]);
        for (const mask of masks) await app.setProperty(target.sn, "aiDetectType", mask);
        expect(rtc).toHaveBeenCalledTimes(masks.length);
        for (const [index, args] of rtc.mock.calls.entries()) {
          const [sn, command] = args as unknown as [string, Command];
          expect(sn).toBe(target.sn);
          expect(command).toEqual({
            kind: "set-payload",
            cmd: 1298,
            payload: { ai_detect_type: masks[index], channel },
            channel,
            mValue3: 0,
            form: "auto",
          });
          const packet = buildRtcControlPacket(command, "", channel, 1);
          expect(parsePortalHeader(packet)).toMatchObject({ commandId: 1350, channel });
          expect(JSON.parse(packet.subarray(PORTAL_HEADER_LENGTH).toString())).toMatchObject({
            cmd: 1298,
            mValue3: 0,
            payload: { ai_detect_type: masks[index], channel },
          });
        }
        expect(p2p).not.toHaveBeenCalled();
        expect(app.getPropertyPreparationDiagnostics()).toMatchObject({ prepared: masks.length, failures: 0 });
      }
    },
  );

  it.each([undefined, "3", -1, 1.5, 255, 256, NaN])("withholds a setter for invalid channel %s", async (channel) => {
    const { app, target, rtc, p2p, device } = fixture("T8134", channel);
    expect((device.motion!() as MotionActions).aiDetectType).toBe(0x3000f);
    expect((device.motion!() as MotionActions).setAiDetectType).toBeUndefined();
    expect(device.getPropertySpecs().find((spec) => spec.name === "aiDetectType")?.writable).toBe(false);
    await expect(app.setProperty(target.sn, "aiDetectType", 0x3000e)).rejects.toThrow();
    expect(rtc).not.toHaveBeenCalled();
    expect(p2p).not.toHaveBeenCalled();
  });

  it.each([0, 3])("withholds a setter for duplicate channel %s", async (channel) => {
    const { app, target, rtc, device } = fixture("T8170", channel, "T9000", true);
    expect((device.motion!() as MotionActions).setAiDetectType).toBeUndefined();
    await expect(app.setProperty(target.sn, "aiDetectType", 0x3000e)).rejects.toThrow();
    expect(rtc).not.toHaveBeenCalled();
  });

  it("retains the P2P outer zero channel and payload target", async () => {
    const { app, target, rtc, p2p } = fixture("T8134", 3, "T8030");
    await app.setProperty(target.sn, "aiDetectType", 0x3000e);
    expect(p2p).toHaveBeenCalledWith(
      target.sn,
      expect.objectContaining({
        channel: 0,
        payload: { ai_detect_type: 0x3000e, channel: 3 },
        mValue3: 0,
        form: "auto",
      }),
    );
    expect(rtc).not.toHaveBeenCalled();
  });
});

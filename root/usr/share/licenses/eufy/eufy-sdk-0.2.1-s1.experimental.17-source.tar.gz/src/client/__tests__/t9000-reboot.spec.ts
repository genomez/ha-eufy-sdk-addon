import { describe, expect, it, vi } from "vitest";
import { EufyMega } from "../eufy-mega.js";
import { Device } from "../../model/device.js";
import { DeviceRegistry } from "../device-registry.js";

describe("station reboot admission", () => {
  it.each([{ devices: [] }, { devices: [{ sn: "fixture-other-station", model: "T8030" }] }])(
    "rejects an unknown device without disclosing registry identities",
    async ({ devices }) => {
      const prepare = vi.fn();
      const reboot = vi.fn();
      const registry = Object.assign(Object.create(DeviceRegistry.prototype), { devices, list: () => devices });
      const app = Object.assign(Object.create(EufyMega.prototype), {
        registry,
        commandContext: prepare,
        p2p: { rebootStation: reboot },
      }) as EufyMega;
      await expect(app.reboot("fixture-missing-station")).rejects.toThrow(
        /^reboot: device not known; reboot is not supported$/,
      );
      expect(prepare).not.toHaveBeenCalled();
      expect(reboot).not.toHaveBeenCalled();
    },
  );
  it.each([{ model: "T9000" }, { model: "T9000-family" }, { deviceType: 27 }])(
    "rejects T9000 before context preparation or transport use",
    async (facts) => {
      const prepare = vi.fn();
      const reboot = vi.fn();
      const app = Object.assign(Object.create(EufyMega.prototype), {
        registry: {
          list: () => [{ sn: "fixture-station", ...facts, raw: { device_type: facts.deviceType } }],
          require: () => ({ ...facts, raw: { device_type: facts.deviceType } }),
        },
        commandContext: prepare,
        p2p: { rebootStation: reboot },
      }) as EufyMega;
      expect(Device.fromRecord("fixture-station", facts).canReboot).toBe(false);
      await expect(app.reboot("fixture-station")).rejects.toThrow("unsupported on T9000");
      expect(prepare).not.toHaveBeenCalled();
      expect(reboot).not.toHaveBeenCalled();
    },
  );
  it("retains the classic HomeBase route", async () => {
    const facts = { model: "T8030", deviceType: 18 };
    const reboot = vi.fn(async () => {});
    const app = Object.assign(Object.create(EufyMega.prototype), {
      registry: { list: () => [{ sn: "fixture-station", ...facts }], require: () => facts },
      commandContext: async () => facts,
      p2p: { rebootStation: reboot },
    }) as EufyMega;
    expect(Device.fromRecord("fixture-station", facts).canReboot).toBe(true);
    await app.reboot("fixture-station");
    expect(reboot).toHaveBeenCalledWith("fixture-station");
  });
});

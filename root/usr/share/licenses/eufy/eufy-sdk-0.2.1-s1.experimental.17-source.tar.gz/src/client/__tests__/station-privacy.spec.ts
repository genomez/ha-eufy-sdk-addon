import { readFileSync } from "node:fs";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { EufyDevice } from "../../core/types.js";
import { Device } from "../../model/device.js";
import {
  buildPortalHeader,
  parsePortalPacket,
  PortalLinkType,
  type PortalResponse,
} from "../../transport/rtc/portal-packet.js";
import { linkTypeForChannel, packetize, PtcsChannel, PtcsReassembler } from "../../transport/rtc/ptcs-framer.js";
import type { DeviceRegistry } from "../device-registry.js";
import { EufyMega } from "../eufy-mega.js";
import type { RtcReportIdentity } from "../rtc-late-contrary.js";
import type { RtcCommandRouter } from "../../transport/rtc/command-router.js";
import { rtcStateParameters } from "../rtc-state.js";

const STATION = "test-station";
const CAMERA_A = "test-camera-a";
const CAMERA_B = "test-camera-b";
const PARAM = 6250;
const SECONDS = 1_795_491_600;
const clients: EufyMega[] = [];
afterEach(async () => {
  for (const client of clients.splice(0)) await client.disconnect();
  vi.restoreAllMocks();
});

function fixture(
  models: ReadonlyArray<readonly [string, string]> = [
    [CAMERA_A, "T8416"],
    [CAMERA_B, "T8416"],
  ],
) {
  const client = new EufyMega({
    email: "synthetic",
    password: "synthetic",
    autoRealtime: false,
    pollMs: 0,
    storedSnapshotCache: false,
  });
  clients.push(client);
  const inner = client as unknown as {
    registry: DeviceRegistry;
    rtc: RtcCommandRouter;
    mega: { getDeviceParamList: () => Promise<{ params: unknown[] }> };
    liveDevices: Map<string, WeakRef<Device>>;
    boundParamIds: Map<string, ReadonlySet<number>>;
    onRtcFrame: (station: string, frame: PortalResponse, identity?: RtcReportIdentity) => void;
    pollOnce: () => Promise<void>;
  };
  const initial = { [PARAM]: "1" };
  const cameras = models.map(([sn, model], index) => ({
    sn,
    model,
    stationSn: STATION,
    raw: { device_channel: 13 + index },
    params: { ...initial },
  }));
  const setRoster = (devices = cameras) => {
    (inner.registry as unknown as { devices: EufyDevice[] }).devices = [
      { sn: STATION, model: "T9000", raw: {} },
      ...devices,
    ] as EufyDevice[];
  };
  setRoster();
  vi.spyOn(inner.mega, "getDeviceParamList").mockResolvedValue({
    params: [{ param_type: PARAM, param_value: "1" }],
  });
  const devices = new Map(
    cameras.map(({ sn, model }) => {
      const device = Device.fromRecord(sn, { model, parentSn: STATION, params: initial });
      inner.liveDevices.set(sn, new WeakRef(device));
      inner.boundParamIds.set(sn, new Set([PARAM]));
      return [sn, device];
    }),
  );
  const receipt = vi.spyOn(inner.rtc, "informationFrameReceivedAtMs");
  function deliver(frame: PortalResponse, receivedAtMs = SECONDS * 1000 + 500, identity?: RtcReportIdentity) {
    receipt.mockReturnValue(receivedAtMs);
    inner.onRtcFrame(STATION, frame, identity);
  }
  return { client, inner, cameras, devices, deliver, setRoster };
}

function row(channel = 13, param_value: unknown = "MA==", update_time: unknown = SECONDS) {
  return { channel, param_type: PARAM, param_value, update_time };
}

function liveRow(channel: number, deviceSn: string, value: string, updateTime = SECONDS) {
  return {
    ...row(channel, value, updateTime),
    create_time: SECONDS - 60,
    device_sn: deviceSn,
    param_id: 539,
    status: 0,
  };
}

function packet(data: unknown, commandId = 1103, isResponse = 0) {
  const body = Buffer.from(typeof data === "string" ? data : JSON.stringify(data));
  return parsePortalPacket(
    Buffer.concat([buildPortalHeader(commandId, body.length, 255, 0, isResponse), body]),
    PortalLinkType.NOTIFY,
  )!;
}

function direct(...rows: unknown[]) {
  return packet({ db_bypass_str: rows });
}

function periodicParams(value: string) {
  return packet({ params: [{ dev_type: 13, param_type: PARAM, param_value: value }] });
}

describe("station privacy information", () => {
  it("publishes the first segmented periodic 1103 before the camera is bound", async () => {
    const { client, inner, deliver } = fixture();
    inner.liveDevices.clear();
    inner.boundParamIds.clear();
    const observed = vi.fn();
    client.on("propertiesObserved", observed);
    const receivedAtMs = SECONDS * 1000 + 500;
    const body = Buffer.from(
      JSON.stringify({
        params: [
          ...Array.from({ length: 256 }, (_, index) => ({
            dev_type: 0,
            param_type: 10_000 + index,
            param_value: "0",
          })),
          { dev_type: 14, param_type: PARAM, param_value: "0" },
        ],
      }),
    );
    const frame = Buffer.concat([buildPortalHeader(1103, body.length, 255, 7, 0), body]);
    const packets = packetize(frame, { channel: PtcsChannel.NOTIFY, frameId: 1 });
    const receiver = new PtcsReassembler((wire, channel) => {
      const parsed = parsePortalPacket(wire, linkTypeForChannel(channel));
      expect(parsed).toMatchObject({ commandId: 1103, channel: 255, segment: 7, linkType: 3 });
      deliver(parsed!, receivedAtMs, {
        sessionGeneration: 1,
        sequence: 1,
        receivedAtMonotonicMs: 100,
      });
    });
    expect(packets.length).toBeGreaterThan(1);
    for (const packet of packets.slice(0, -1)) expect(receiver.push(packet)).toBe(true);
    expect(observed).not.toHaveBeenCalled();
    expect(receiver.push(packets.at(-1)!)).toBe(true);

    const device = await client.getDevice(CAMERA_B);
    expect(device.getPropertyValue("privacy")).toBe(false);
    const evidence = client.getStateEvidence(CAMERA_B).privacy;
    expect(evidence).toMatchObject({ source: "rtc_push", status: "current", receivedAtMs, producerTimeMs: null });
    expect(observed).toHaveBeenCalledExactlyOnceWith(
      expect.objectContaining({
        deviceSn: CAMERA_B,
        properties: { privacy: false },
        evidence: { privacy: evidence },
      }),
    );
  });

  it("starts unknown with stale cloud state and keeps the first station receipt across reads and polls", async () => {
    const { client, inner, deliver } = fixture();
    const device = await client.getDevice(CAMERA_A);
    expect(device.getProperty("privacy")).toBeUndefined();
    expect(client.getStateEvidence(CAMERA_A).privacy).toBeUndefined();
    deliver(periodicParams("0"));
    vi.spyOn(inner.registry, "pollChanges").mockResolvedValue({
      params: [{ deviceSn: CAMERA_A, paramType: PARAM, to: "1", from: "0", params: { [PARAM]: "1" } }],
      added: [],
      removed: [],
      reported: [],
    });
    await inner.pollOnce();
    expect(device.getPropertyValue("privacy")).toBe(false);
    expect((await client.getDevice(CAMERA_A)).camera?.()?.privacy).toBe(false);
    expect(client.getStateEvidence(CAMERA_A).privacy).toMatchObject({ source: "rtc_push", status: "current" });
  });

  it.each([0, 1, 20, 30])(
    "confirms and publishes a 6250 change with %is producer clock lag before ACK",
    async (lag) => {
      const { client, inner, deliver } = fixture();
      const device = await client.getDevice(CAMERA_A);
      const observed = vi.fn();
      const changed = vi.fn();
      client.on("propertiesObserved", observed);
      client.on("propertyChanged", changed);
      const seconds = Math.floor(Date.now() / 1000);
      const producerSeconds = seconds - lag;
      deliver(direct(row(13, "MA==", producerSeconds - 1)), seconds * 1000);
      vi.spyOn(inner.rtc, "getSessionScope").mockReturnValue({ station: STATION, sessionGeneration: 1 });
      const dispatch = vi
        .spyOn(inner.rtc, "dispatchCommandWithReceipt")
        .mockImplementation(async (_sn, _cmd, options) => {
          options?.onSent?.(seconds * 1000);
          deliver(packet({ cmd: 1103, db_bypass_str: [row(13, "MQ==", producerSeconds)] }, 1351), seconds * 1000 + 1, {
            sessionGeneration: 1,
            sequence: 1,
            receivedAtMonotonicMs: performance.now(),
          });
          expect(observed).toHaveBeenLastCalledWith(
            expect.objectContaining({
              deviceSn: CAMERA_A,
              properties: { privacy: true },
              evidence: {
                privacy: expect.objectContaining({ source: "rtc_push", producerTimeMs: producerSeconds * 1000 }),
              },
            }),
          );
          return { status: "acknowledged", effect: "unconfirmed", sendAttempted: true };
        });
      await expect(client.setPropertyWithReceipt(CAMERA_A, "privacy", true)).resolves.toMatchObject({
        status: "acknowledged",
        effect: "confirmed_report",
      });
      expect(dispatch).toHaveBeenCalledExactlyOnceWith(
        CAMERA_A,
        {
          kind: "set-channel-payload",
          cmd: 6250,
          channel: 13,
          payload: { switch: 1 },
        },
        expect.anything(),
      );
      expect(changed).toHaveBeenLastCalledWith(
        expect.objectContaining({ deviceSn: CAMERA_A, property: "privacy", value: true }),
      );
      expect(device.getPropertyValue("privacy")).toBe(true);
    },
  );

  it.each([
    { reason: "at the prior timed floor", floorLag: 1, reportLag: 1 },
    { reason: "outside the backward tolerance", floorLag: 40, reportLag: 31 },
  ])("does not confirm a matching report $reason", async ({ floorLag, reportLag }) => {
    const { client, inner, deliver } = fixture();
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout"] });
    try {
      const seconds = Math.floor(Date.now() / 1000);
      const receivedAtMs = seconds * 1000 + 1;
      deliver(direct(row(13, "MQ==", seconds - floorLag)), seconds * 1000);
      vi.spyOn(inner.rtc, "getSessionScope").mockReturnValue({ station: STATION, sessionGeneration: 1 });
      vi.spyOn(inner.rtc, "dispatchCommandWithReceipt").mockImplementation(async (_sn, _cmd, options) => {
        options?.onSent?.(seconds * 1000);
        deliver(packet({ cmd: 1103, db_bypass_str: [row(13, "MQ==", seconds - reportLag)] }, 1351), receivedAtMs, {
          sessionGeneration: 1,
          sequence: 1,
          receivedAtMonotonicMs: performance.now(),
        });
        return { status: "acknowledged", effect: "unconfirmed", sendAttempted: true };
      });
      const rejected = expect(client.setPropertyWithReceipt(CAMERA_A, "privacy", true)).rejects.toMatchObject({
        name: "StateConvergenceError",
        property: "privacy",
      });
      await vi.advanceTimersByTimeAsync(0);
      expect(client.getStateEvidence(CAMERA_A).privacy).toMatchObject({
        receivedAtMs,
        producerTimeMs: (seconds - reportLag) * 1000,
      });
      await vi.advanceTimersByTimeAsync(5_000);
      await rejected;
    } finally {
      vi.useRealTimers();
    }
  });

  it("serializes privacy writes through confirmation and gives the queued write a full command deadline", async () => {
    const { client, inner, deliver } = fixture();
    vi.useFakeTimers({ toFake: ["Date", "setTimeout", "clearTimeout"] });
    try {
      vi.spyOn(inner.rtc, "getSessionScope").mockReturnValue({ station: STATION, sessionGeneration: 1 });
      const dispatched = Promise.withResolvers<void>();
      const deadlines: { startedAt: number; deadlineAtMs?: number }[] = [];
      const dispatch = vi
        .spyOn(inner.rtc, "dispatchCommandWithReceipt")
        .mockImplementation(async (sn, _cmd, options) => {
          const startedAt = Date.now();
          deadlines.push({ startedAt, deadlineAtMs: options?.deadlineAtMs });
          options?.onSent?.(startedAt);
          if (sn === CAMERA_A) {
            deliver(periodicParams("0"), startedAt + 1);
            dispatched.resolve();
          } else {
            deliver(
              packet({ cmd: 1103, db_bypass_str: [row(14, "MA==", Math.floor(startedAt / 1000))] }, 1351),
              startedAt + 1,
              { sessionGeneration: 1, sequence: 2, receivedAtMonotonicMs: performance.now() },
            );
          }
          return { status: "acknowledged", effect: "unconfirmed", sendAttempted: true };
        });
      const first = expect(client.setProperty(CAMERA_A, "privacy", false)).rejects.toMatchObject({
        name: "StateConvergenceError",
        property: "privacy",
      });
      await dispatched.promise;
      const next = client.setProperty(CAMERA_B, "privacy", false);
      await vi.advanceTimersByTimeAsync(0);
      expect(dispatch).toHaveBeenCalledTimes(1);
      await vi.advanceTimersByTimeAsync(5_000);
      await first;
      await next;
      expect(dispatch.mock.calls.map(([sn]) => sn)).toEqual([CAMERA_A, CAMERA_B]);
      const firstStartedAt = deadlines[0]!.startedAt;
      expect(deadlines).toEqual(
        [firstStartedAt, firstStartedAt + 5_000].map((startedAt) => ({
          startedAt,
          deadlineAtMs: startedAt + inner.rtc.commandTimeoutMs,
        })),
      );
    } finally {
      vi.useRealTimers();
    }
  });
  it.each([
    ["MA==", "0"],
    ["MQ==", "1"],
    [0, "0"],
    [1, "1"],
  ])("decodes a timed row %j and resolves its camera channel", (raw, value) => {
    const { inner } = fixture();
    const observe = vi.fn();
    expect(rtcStateParameters(STATION, direct(row(14, raw)), inner.registry, observe)).toEqual(
      new Map([[CAMERA_B, { [PARAM]: value }]]),
    );
    expect(observe).toHaveBeenCalledWith(CAMERA_B, PARAM, String(raw), value, {
      channel: 14,
      changeTimeMs: SECONDS * 1000,
      periodic: true,
    });
  });

  it("accepts a full database row when its channel and device serial agree", () => {
    const { inner } = fixture();
    const observe = vi.fn();
    const frame = direct(liveRow(14, CAMERA_B, "MQ=="), liveRow(14, CAMERA_A, "MA=="));

    expect(rtcStateParameters(STATION, frame, inner.registry, observe)).toEqual(
      new Map([[CAMERA_B, { [PARAM]: "1" }]]),
    );
    expect(observe.mock.calls).toEqual([
      [CAMERA_B, PARAM, "MQ==", "1", { channel: 14, changeTimeMs: SECONDS * 1000, periodic: true }],
    ]);
  });

  it("rejects malformed, unrelated and ambiguously owned station rows", () => {
    const { inner, cameras, setRoster } = fixture();
    const malformed = direct(
      { channel: 13, param_type: PARAM, update_time: SECONDS },
      row(13, "bad"),
      row(13, 2),
      row(13, "Mg=="),
      row(13, "MA==", 0),
      row(13, "MA==", SECONDS + 0.5),
      row(13, "MA==", Number.MAX_SAFE_INTEGER),
      { device_sn: CAMERA_A, param_type: PARAM, param_value: "MA==", update_time: SECONDS },
      { ...row(), device_sn: CAMERA_B },
      row(40),
    );
    expect(rtcStateParameters(STATION, malformed, inner.registry).size).toBe(0);
    expect(rtcStateParameters("wrong-station", direct(row()), inner.registry).size).toBe(0);
    const truncated = packet(JSON.stringify({ db_bypass_str: [row()] }).slice(0, -1));
    expect(rtcStateParameters(STATION, truncated, inner.registry).size).toBe(0);
    const flat = { cmd: 1103, db_bypass_str: [row()], params: [{ channel: 13, param_type: 1035, param_value: 0 }] };
    expect(rtcStateParameters(STATION, packet(flat, 1351), inner.registry)).toEqual(
      new Map([[CAMERA_A, { [PARAM]: "0" }]]),
    );
    expect(rtcStateParameters(STATION, packet(flat, 1351, 1), inner.registry).size).toBe(0);
    expect(
      rtcStateParameters(
        STATION,
        packet({ cmd: 1103, db_bypass_str: [{ channel: 13, param_type: PARAM, param_value: "MA==" }] }, 1351),
        inner.registry,
      ).size,
    ).toBe(0);
    setRoster([...cameras, { ...cameras[0]!, sn: "ambiguous-camera" }]);
    expect(rtcStateParameters(STATION, direct(row()), inner.registry).size).toBe(0);
    setRoster([{ ...cameras[0]!, model: "T8425" }, cameras[1]!]);
    expect(rtcStateParameters(STATION, packet(flat, 1351), inner.registry).size).toBe(0);
  });

  it("keeps other models and parameters on the ordinary information path", () => {
    const { inner, cameras, setRoster } = fixture();
    setRoster([{ ...cameras[0]!, model: "T8425" }, cameras[1]!]);
    const observe = vi.fn();
    const frame = packet({
      params: [
        { dev_type: 13, param_type: PARAM, param_value: "0" },
        { dev_type: 14, param_type: 1035, param_value: "1" },
      ],
    });
    expect(rtcStateParameters(STATION, frame, inner.registry, observe)).toEqual(
      new Map([
        [CAMERA_A, { [PARAM]: "0" }],
        [CAMERA_B, { 1035: "1" }],
      ]),
    );
    expect(observe.mock.calls).toEqual([
      [CAMERA_A, PARAM, "0", "0", undefined],
      [CAMERA_B, 1035, "1", "1", undefined],
    ]);
  });

  it("changes only the addressed T8416 privacy value in a full 1351/1103 dump", () => {
    const otherCamera = "test-camera-c";
    const { client, inner, devices, deliver } = fixture([
      [CAMERA_A, "T8416"],
      [CAMERA_B, "T8416"],
      [otherCamera, "T8425"],
    ]);
    deliver(direct(liveRow(14, CAMERA_B, "MQ==")));
    const unchanged = client.getStateEvidence(CAMERA_B).privacy!;
    deliver(packet({ params: [{ dev_type: 15, param_type: PARAM, param_value: "1" }] }));
    const ordinary = client.getStateEvidence(otherCamera).privacy;
    expect(ordinary).toMatchObject({ producerTimeMs: null, status: "uncertain" });
    const evidenceEvents = vi.fn();
    client.on("propertyEvidenceChanged", evidenceEvents);
    const receivedAtMs = (SECONDS + 2) * 1000;
    deliver(
      packet(
        {
          cmd: 1103,
          db_bypass_str: [
            liveRow(13, CAMERA_A, "MA==", SECONDS + 1),
            liveRow(14, CAMERA_B, "MQ=="),
            liveRow(15, otherCamera, "MA=="),
          ],
        },
        1351,
      ),
      receivedAtMs,
    );

    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(false);
    expect(devices.get(CAMERA_B)?.getProperty("privacy")?.value).toBe(true);
    expect(client.getStateEvidence(CAMERA_B).privacy).toEqual({ ...unchanged, receivedAtMs });
    expect(inner.registry.knownParam(otherCamera, PARAM)).toBe("1");
    expect(client.getStateEvidence(otherCamera).privacy).toEqual(ordinary);
    expect(evidenceEvents.mock.calls.map(([evidence]) => evidence.deviceSn)).toEqual([CAMERA_A]);
  });

  it("retains the station value through later unqualified cloud receipts and advances on newer station time", async () => {
    const { client, inner, devices, deliver } = fixture();
    const device = devices.get(CAMERA_A)!;
    const snapshots = vi.fn();
    const evidenceEvents = vi.fn();
    client.on("deviceState", snapshots);
    client.on("propertyEvidenceChanged", evidenceEvents);
    const registry = inner.registry as unknown as {
      onCloudEvidence: (
        sn: string,
        params: Record<number, string>,
        times: Record<number, number>,
        receipt: number,
      ) => void;
    };
    const cloud = (value: string, receivedAtMs: number) =>
      registry.onCloudEvidence(CAMERA_A, { [PARAM]: value }, { [PARAM]: SECONDS - 100_000 }, receivedAtMs);
    cloud("1", SECONDS * 1000 - 1);
    deliver(direct(row()));
    expect(device.getProperty("privacy")?.value).toBe(false);
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    expect(first).toMatchObject({
      source: "rtc_push",
      receivedAtMs: SECONDS * 1000 + 500,
      producerTimeMs: SECONDS * 1000,
      status: "current",
      confirmationEligible: false,
    });
    vi.spyOn(inner.registry, "pollChanges").mockImplementation(async () => {
      cloud("1", (SECONDS + 60) * 1000);
      return {
        params: [{ deviceSn: CAMERA_A, paramType: PARAM, to: "1", from: "0", params: { [PARAM]: "1" } }],
        added: [],
        removed: [],
        reported: [],
      };
    });
    await inner.pollOnce();
    expect(device.getProperty("privacy")?.value).toBe(false);
    expect(inner.registry.knownParam(CAMERA_A, PARAM)).toBe("0");
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual(first);
    deliver(direct(row()), (SECONDS + 120) * 1000);
    deliver(direct(row(13, "MQ==", SECONDS - 1)), (SECONDS + 130) * 1000);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({ ...first, receivedAtMs: (SECONDS + 120) * 1000 });
    expect(snapshots).toHaveBeenCalledTimes(1);
    expect(evidenceEvents).toHaveBeenCalledTimes(1);
    deliver(direct(row(13, "MQ==", SECONDS + 150)), (SECONDS + 151) * 1000);
    expect(device.getProperty("privacy")?.value).toBe(true);
    expect(client.getStateEvidence(CAMERA_A).privacy).toMatchObject({
      producerTimeMs: (SECONDS + 150) * 1000,
      receivedAtMs: (SECONDS + 151) * 1000,
    });
    expect(snapshots).toHaveBeenCalledTimes(2);
    expect(evidenceEvents).toHaveBeenCalledTimes(2);
  });

  it.each([
    ["untimed db row", () => direct({ channel: 13, param_type: PARAM, param_value: "MA==" }), SECONDS],
    ["dev_type row", () => periodicParams("0"), SECONDS],
    ["newer timed db row", () => direct(row(13, "MA==", SECONDS + 29)), SECONDS + 29],
  ] as const)("renews a matching periodic %s without a revision or events", (_form, frame, producerSeconds) => {
    const { client, deliver } = fixture();
    const snapshots = vi.fn();
    const evidenceEvents = vi.fn();
    client.on("deviceState", snapshots);
    client.on("propertyEvidenceChanged", evidenceEvents);
    deliver(direct(row()));
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    const receivedAtMs = (SECONDS + 30) * 1000;
    deliver(frame(), receivedAtMs);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({
      ...first,
      receivedAtMs,
      producerTimeMs: producerSeconds * 1000,
    });
    expect(snapshots).toHaveBeenCalledTimes(1);
    expect(evidenceEvents).toHaveBeenCalledTimes(1);
  });

  it("renews the timed privacy receipt across 20 matching mixed periodic frames without events", () => {
    const { client, deliver } = fixture();
    const snapshots = vi.fn();
    const evidenceEvents = vi.fn();
    const observations = vi.fn();
    client.on("deviceState", snapshots);
    client.on("propertyEvidenceChanged", evidenceEvents);
    client.on("propertiesObserved", observations);
    const frame = packet({
      params: [{ dev_type: 13, param_type: PARAM, param_value: "0" }],
      db_bypass_str: [liveRow(13, CAMERA_A, "MA==")],
    });
    deliver(frame);
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    expect(first.producerTimeMs).toBe(SECONDS * 1000);
    expect(snapshots).toHaveBeenCalledTimes(1);
    expect(evidenceEvents).toHaveBeenCalledTimes(1);
    snapshots.mockClear();
    evidenceEvents.mockClear();
    observations.mockClear();

    for (let repeat = 1; repeat <= 20; repeat++) {
      const receivedAtMs = first.receivedAtMs! + repeat * 30_000;
      deliver(frame, receivedAtMs);
      expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({ ...first, receivedAtMs });
    }
    expect(snapshots).not.toHaveBeenCalled();
    expect(evidenceEvents).not.toHaveBeenCalled();
    expect(observations).not.toHaveBeenCalled();
  });

  it("prefers an eligible timed row over a disagreeing params row after the hold expires", () => {
    const { client, devices, deliver } = fixture();
    deliver(direct(liveRow(13, CAMERA_A, "MA==")));
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    const receivedAtMs = first.receivedAtMs! + 90_000;
    deliver(
      packet({
        params: [{ dev_type: 13, param_type: PARAM, param_value: "1" }],
        db_bypass_str: [liveRow(13, CAMERA_A, "MA==")],
      }),
      receivedAtMs,
    );

    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(false);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({ ...first, receivedAtMs });
  });

  it("uses the periodic params row when a timed row in the same frame is older", () => {
    const { client, deliver } = fixture();
    deliver(direct(row()));
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    const receivedAtMs = (SECONDS + 30) * 1000;
    deliver(
      packet({
        params: [{ dev_type: 13, param_type: PARAM, param_value: "0" }],
        db_bypass_str: [row(13, "MQ==", SECONDS - 1)],
      }),
      receivedAtMs,
    );
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({ ...first, receivedAtMs });
  });

  it("applies the hold to a disagreeing periodic fallback in a frame with an older timed row", () => {
    const { client, devices, deliver } = fixture();
    deliver(direct(row()));
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    const timedReceipt = first.receivedAtMs!;
    const frame = packet({
      params: [{ dev_type: 13, param_type: PARAM, param_value: "1" }],
      db_bypass_str: [row(13, "MQ==", SECONDS - 1)],
    });

    deliver(frame, timedReceipt + 59_000);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual(first);
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(false);

    deliver(frame, timedReceipt + 60_000);
    expect(client.getStateEvidence(CAMERA_A).privacy).toMatchObject({
      receivedAtMs: timedReceipt + 60_000,
      producerTimeMs: null,
    });
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(true);
  });

  it.each([
    ["db row", () => direct({ channel: 13, param_type: PARAM, param_value: "MA==" })],
    ["dev_type row", () => periodicParams("0")],
  ] as const)("establishes station privacy from an untimed periodic %s", (_form, frame) => {
    const { client, devices, deliver } = fixture();
    const receivedAtMs = (SECONDS + 30) * 1000;
    deliver(frame(), receivedAtMs);
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(false);
    expect(client.getStateEvidence(CAMERA_A).privacy).toMatchObject({
      source: "rtc_push",
      receivedAtMs,
      producerTimeMs: null,
      producerDomain: null,
      status: "current",
    });
  });

  it("allows a conflicting periodic value at 60 seconds from the timed receipt despite freshness renewal", () => {
    const { client, devices, deliver } = fixture();
    deliver(direct(row()));
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    const timedReceipt = first.receivedAtMs!;
    deliver(periodicParams("0"), timedReceipt + 30_000);
    deliver(periodicParams("1"), timedReceipt + 59_000);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({ ...first, receivedAtMs: timedReceipt + 30_000 });
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(false);

    const receivedAtMs = timedReceipt + 60_000;
    deliver(periodicParams("1"), receivedAtMs);
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(true);
    const replacement = client.getStateEvidence(CAMERA_A).privacy!;
    expect(replacement).toMatchObject({ receivedAtMs, producerTimeMs: null, producerDomain: null });
    expect(replacement.revision).toBeGreaterThan(first.revision);
    deliver(packet({ cmd: 1103, db_bypass_str: [row(13, "MA==", SECONDS + 61)] }, 1351), receivedAtMs + 2000);
    deliver(direct(row(13, "MQ==", SECONDS + 60)), receivedAtMs + 3000);
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(false);
    expect(client.getStateEvidence(CAMERA_A).privacy).toMatchObject({ producerTimeMs: (SECONDS + 61) * 1000 });
  });

  it("rejects timed rows at or below the last timed change after an untimed replacement", () => {
    const { client, devices, deliver } = fixture();
    const changes = vi.fn();
    client.on("propertyEvidenceChanged", changes);
    deliver(direct(row(13, "MQ==")));
    const timedReceipt = client.getStateEvidence(CAMERA_A).privacy!.receivedAtMs!;
    deliver(periodicParams("0"), timedReceipt + 60_000);
    const replacement = client.getStateEvidence(CAMERA_A).privacy!;
    changes.mockClear();

    deliver(packet({ cmd: 1103, db_bypass_str: [row(13, "MQ=="), row(14)] }, 1351), timedReceipt + 61_000);
    expect(devices.get(CAMERA_B)?.getProperty("privacy")?.value).toBe(false);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual(replacement);
    expect(changes).toHaveBeenCalledTimes(1);

    for (const [offset, producerSeconds] of [
      [62_000, SECONDS],
      [63_000, SECONDS - 1],
    ]) {
      const receivedAtMs = timedReceipt + offset;
      deliver(
        packet({
          params: [{ dev_type: 13, param_type: PARAM, param_value: "0" }],
          db_bypass_str: [row(13, "MQ==", producerSeconds)],
        }),
        receivedAtMs,
      );
      expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({ ...replacement, receivedAtMs });
      expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(false);
    }
    expect(changes).toHaveBeenCalledTimes(1);
  });

  it("accepts a strictly newer timed change after an untimed replacement", () => {
    const { client, devices, deliver } = fixture();
    deliver(direct(row(13, "MQ==")));
    const timedReceipt = client.getStateEvidence(CAMERA_A).privacy!.receivedAtMs!;
    deliver(periodicParams("0"), timedReceipt + 60_000);
    const replacement = client.getStateEvidence(CAMERA_A).privacy!;

    const receivedAtMs = timedReceipt + 61_000;
    deliver(packet({ cmd: 1103, db_bypass_str: [row(13, "MQ==", SECONDS + 1)] }, 1351), receivedAtMs);
    const newer = client.getStateEvidence(CAMERA_A).privacy!;
    expect(newer).toMatchObject({ receivedAtMs, producerTimeMs: (SECONDS + 1) * 1000 });
    expect(newer.revision).toBeGreaterThan(replacement.revision);
    deliver(periodicParams("0"), receivedAtMs + 59_000);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual(newer);
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(true);
  });

  it("renews freshness from a repeated timed row without extending the hold", () => {
    const { client, devices, deliver } = fixture();
    const repeated = direct(row());
    deliver(repeated);
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    const timedReceipt = first.receivedAtMs!;

    deliver(repeated, timedReceipt + 59_000);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({ ...first, receivedAtMs: timedReceipt + 59_000 });
    deliver(periodicParams("1"), timedReceipt + 60_000);
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(true);
    expect(client.getStateEvidence(CAMERA_A).privacy!.revision).toBeGreaterThan(first.revision);
  });

  it("ignores a lagging periodic row after an app toggle", () => {
    const { client, devices, deliver } = fixture();
    const snapshots = vi.fn();
    const evidenceEvents = vi.fn();
    client.on("deviceState", snapshots);
    client.on("propertyEvidenceChanged", evidenceEvents);
    deliver(direct(row()));
    const toggleReceipt = (SECONDS + 120) * 1000;
    deliver(packet({ cmd: 1103, db_bypass_str: [row(13, "MQ==", SECONDS + 119)] }, 1351), toggleReceipt);
    const toggled = client.getStateEvidence(CAMERA_A).privacy!;

    deliver(periodicParams("0"), toggleReceipt + 3_000);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual(toggled);
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(true);
    expect(snapshots).toHaveBeenCalledTimes(2);
    expect(evidenceEvents).toHaveBeenCalledTimes(2);
  });

  it("qualifies matching untimed state in place when a timed app row arrives", () => {
    const { client, devices, deliver } = fixture();
    const snapshots = vi.fn();
    const evidenceEvents = vi.fn();
    client.on("deviceState", snapshots);
    client.on("propertyEvidenceChanged", evidenceEvents);
    deliver(periodicParams("1"));
    deliver(periodicParams("0"), (SECONDS + 1) * 1000);
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    expect(first.producerTimeMs).toBeNull();
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(false);

    const receivedAtMs = (SECONDS + 2) * 1000;
    deliver(packet({ cmd: 1103, db_bypass_str: [row(13, "MA==", SECONDS + 2)] }, 1351), receivedAtMs);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual({
      ...first,
      receivedAtMs,
      producerTimeMs: receivedAtMs,
      producerDomain: "device_sample_time",
    });
    expect(snapshots).toHaveBeenCalledTimes(2);
    expect(evidenceEvents).toHaveBeenCalledTimes(2);
  });

  it("accepts a conflicting timed row for the same second when received later", () => {
    const { client, devices, deliver } = fixture();
    deliver(direct(row()));
    const first = client.getStateEvidence(CAMERA_A).privacy!;
    const receivedAtMs = first.receivedAtMs! + 100;
    deliver(packet({ cmd: 1103, db_bypass_str: [row(13, "MQ==")] }, 1351), receivedAtMs);
    const replacement = client.getStateEvidence(CAMERA_A).privacy!;
    expect(replacement).toMatchObject({ receivedAtMs, producerTimeMs: first.producerTimeMs });
    expect(replacement.revision).toBeGreaterThan(first.revision);
    deliver(direct(row()), receivedAtMs - 1);
    expect(client.getStateEvidence(CAMERA_A).privacy).toEqual(replacement);
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(true);
  });

  it("replays redacted camera app toggles while retaining the unchanged sibling row", () => {
    const captures = JSON.parse(readFileSync(new URL("./fixtures/privacy-6250-step1.json", import.meta.url), "utf8"));
    const { client, devices, deliver } = fixture();
    const changes = vi.fn();
    client.on("propertyEvidenceChanged", changes);
    const [on, off] = captures;
    const toggledCamera = devices.get(CAMERA_B)!;
    toggledCamera.applyParams({ [PARAM]: "0" });
    for (const [capture, expected] of [
      [on, true],
      [off, false],
    ] as const) {
      const frame = packet(capture.data, capture.commandId, capture.isResponse);
      expect(frame.channel).toBe(capture.channel);
      deliver(frame, capture.receivedAtMs);
      expect(toggledCamera.getProperty("privacy")?.value).toBe(expected);
      expect(client.getStateEvidence(CAMERA_B).privacy).toMatchObject({
        source: "rtc_push",
        receivedAtMs: capture.receivedAtMs,
        producerTimeMs:
          capture.data.db_bypass_str.find((entry: { channel: number }) => entry.channel === 14).update_time * 1000,
      });
    }
    expect(devices.get(CAMERA_A)?.getProperty("privacy")?.value).toBe(true);
    expect(client.getStateEvidence(CAMERA_A).privacy).toMatchObject({
      source: "rtc_push",
      receivedAtMs: off.receivedAtMs,
      producerTimeMs:
        on.data.db_bypass_str.find((entry: { channel: number }) => entry.channel === 13).update_time * 1000,
    });
    expect(changes.mock.calls.filter(([{ deviceSn }]) => deviceSn === CAMERA_A)).toHaveLength(1);
    expect(changes.mock.calls.filter(([{ deviceSn }]) => deviceSn === CAMERA_B)).toHaveLength(2);
  });
});

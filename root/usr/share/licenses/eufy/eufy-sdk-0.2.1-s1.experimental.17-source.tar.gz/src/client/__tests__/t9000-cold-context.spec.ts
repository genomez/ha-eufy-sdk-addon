import { afterEach, describe, expect, it, vi } from "vitest";
import type { Command, CommandReceipt } from "../../core/contracts.js";
import type { EufyDevice } from "../../core/types.js";
import { Device } from "../../model/device.js";
import type { CommandContext } from "../../model/capabilities/types.js";
import { EufyMega } from "../eufy-mega.js";
import type { DeviceRecord, DeviceRegistry } from "../device-registry.js";

const motion = { enable: 1, time: 30, brightness: 50, mode: 1, schedule: [], retained: true };
const schedule = { schedule: [{ start: "18:00", end: "20:00" }], retained: true };
const capture = { cur_mode: 1, mode_0: { quality: 3 }, mode_1: { quality: 2 } };
const params = {
  1045: "1",
  1400: "1",
  1421: JSON.stringify(schedule),
  1422: JSON.stringify(motion),
  2731: Buffer.from(JSON.stringify(capture)).toString("base64"),
};
const context: CommandContext = {
  codec: "camera",
  model: "T8425",
  deviceType: 47,
  channel: 2,
  stationModel: "T9000",
  homeBaseAttached: true,
  paramIds: new Set(Object.keys(params).map(Number)),
};

function fixture(stationModel = "T9000", model = "T8425", reported: Record<number, string> = params) {
  const app = new EufyMega({ email: "fixture@example.com", password: "synthetic", autoRealtime: false });
  const station = { sn: "fixture-station", stationSn: "fixture-station", model: stationModel, raw: {} } as EufyDevice;
  const camera = {
    sn: "fixture-camera",
    stationSn: station.sn,
    model,
    category: "eufy_security",
    deviceClass: "camera",
    api: "mega",
    realtime: "p2p",
    params: reported,
    raw: { device_type: model === "T8214" ? 94 : 47, device_channel: 2 },
  } as EufyDevice;
  const record: DeviceRecord = {
    model,
    deviceType: model === "T8214" ? 94 : 47,
    parentSn: station.sn,
    params: reported,
    paramUpdatedAt: {},
    dpParams: {},
  };
  const internal = app as unknown as {
    registry: DeviceRegistry;
    reconcileStationContexts(): void;
    reconcilePolledReads(changes: []): Set<string>;
    applyRealtimeState(sn: string, params: Record<number, string>): void;
    commandSinkFor(
      sn: string,
      invocation?: { receipt?: CommandReceipt },
    ): { dispatch(command: Command): Promise<void> };
  };
  vi.spyOn(internal.registry, "record").mockResolvedValue(record);
  vi.spyOn(internal.registry, "list").mockReturnValue([camera, station]);
  vi.spyOn(internal.registry, "require").mockReturnValue(camera);
  Object.assign(internal.registry, { devices: [camera, station] });
  const sent: Command[] = [];
  vi.spyOn(internal, "commandSinkFor").mockReturnValue({ dispatch: async (command) => void sent.push(command) });
  vi.spyOn(app.api, "post").mockRejectedValue(new Error("Unexpected network request"));
  return { app, camera, sent, record, internal };
}

async function expectColdSettings(device: Device, sent: Command[]) {
  const light = device.light!()!;
  expect(light.lightSchedule).toBe(JSON.stringify(schedule.schedule));
  expect([
    light.motionLightEnabled,
    light.motionLightDuration,
    light.motionLightBrightness,
    light.motionLightMode,
  ]).toEqual([true, 30, 50, 1]);
  expect(device.getProperties()).not.toHaveProperty("unknown_1421");
  expect(device.getProperties()).not.toHaveProperty("unknown_1422");
  await light.setLightSchedule!("[]");
  await light.setMotionLightDuration!(45);
  expect(sent.slice(-2)).toEqual([
    { kind: "set-payload", cmd: 1421, payload: { ...schedule, schedule: [] }, channel: 2, mValue3: 0, form: undefined },
    { kind: "set-payload", cmd: 1422, payload: { ...motion, time: 45 }, channel: 2, mValue3: 0, form: undefined },
  ]);
}

afterEach(() => vi.restoreAllMocks());

describe("held context lifecycle regressions", () => {
  it.each(["report", "roster"])("accepts %s updates after disconnect without a composite snapshot", async (path) => {
    const f = fixture("T9000", "T8425", { 1045: "1" });
    const device = await f.app.getDevice(f.camera.sn);
    await f.app.disconnect();
    if (path === "report") {
      expect(() => f.internal.applyRealtimeState(f.camera.sn, { 1045: "0" })).not.toThrow();
      expect(device.readRawParameter(1045)).toBe("0");
    } else {
      f.camera.raw = { device_type: 47, device_channel: 3 };
      expect(() => f.internal.reconcileStationContexts()).not.toThrow();
    }
    expect(device.camera!()!.setRecordingQuality).toBeUndefined();
    expect(f.sent).toEqual([]);
  });

  it("keeps serving the live handle's raw state to composite writes after disconnect", async () => {
    // The bridge watchdog calls disconnect() and logs in again; snapshots are cleared, but the
    // held handle still owns the current values and writes must keep composing on them.
    const f = fixture();
    const device = await f.app.getDevice(f.camera.sn);
    const internal = f.app as unknown as { readContexts: WeakMap<Device, CommandContext> };
    await f.app.disconnect();
    expect(internal.readContexts.get(device)!.readParameter!(1422)).toBe(params[1422]);
    await device.light!()!.setMotionLightDuration!(45);
    expect(f.sent.at(-1)).toEqual({
      kind: "set-payload",
      cmd: 1422,
      payload: { ...motion, time: 45 },
      channel: 2,
      mValue3: 0,
      form: undefined,
    });
  });

  it("returns undefined to old readers after the current device changes namespace", async () => {
    const f = fixture();
    const older = await f.app.getDevice(f.camera.sn);
    const internal = f.app as unknown as { readContexts: WeakMap<Device, CommandContext> };
    const ctx = internal.readContexts.get(older)!;
    f.record.model = "T2080";
    f.record.deviceType = undefined;
    f.record.category = "clean";
    f.record.params = {};
    await f.app.getDevice(f.camera.sn);
    expect(() => ctx.readParameter!(2731)).not.toThrow();
    expect(ctx.readParameter!(2731)).toBeUndefined();
    await expect(older.camera!()!.setRecordingQuality!(1)).rejects.toThrow();
    expect(f.sent).toEqual([]);
  });

  it("does not rebind standalone contexts on the second poll and roster cycle", async () => {
    const f = fixture();
    f.camera.stationSn = f.camera.sn;
    f.camera.raw = { device_type: 47, device_channel: 2, station_sn: "" };
    f.record.parentSn = "";
    const device = await f.app.getDevice(f.camera.sn);
    const bind = vi.spyOn(device, "bindActions");
    f.internal.reconcileStationContexts();
    f.internal.reconcilePolledReads([]);
    bind.mockClear();
    f.internal.reconcileStationContexts();
    f.internal.reconcilePolledReads([]);
    expect(bind).not.toHaveBeenCalled();
  });

  it("uses the fresh standalone channel after an attached device loses its parent", async () => {
    const f = fixture();
    const held = await f.app.getDevice(f.camera.sn);
    f.camera.stationSn = f.camera.sn;
    f.camera.raw = { device_type: 47, station_sn: "" };
    f.record.parentSn = "";
    f.internal.reconcileStationContexts();
    const fresh = await f.app.getDevice(f.camera.sn);
    await held.camera!()!.setStatusLed!(true);
    await fresh.camera!()!.setStatusLed!(true);
    expect(f.sent).toEqual([expect.objectContaining({ channel: 0 }), expect.objectContaining({ channel: 0 })]);
    vi.mocked(f.internal.commandSinkFor).mockRestore();
    f.camera.stationSn = "fixture-station";
    f.internal.reconcileStationContexts();
    await expect(held.camera!()!.setStatusLed!(true)).rejects.toThrow();
    expect(f.sent).toHaveLength(2);
  });
});

describe("station context on the first retained report", () => {
  it.each(["late-station", "changed-parent"])("refreshes all held contexts after %s", async (change) => {
    const f = fixture("T9000", "T8425", { ...params, 1277: "1" });
    const roster = [...f.internal.registry.list()];
    if (change === "late-station") vi.mocked(f.internal.registry.list).mockReturnValue([f.camera]);
    const held = [await f.app.getDevice(f.camera.sn), await f.app.getDevice(f.camera.sn)];
    if (change === "changed-parent") {
      f.camera.stationSn = "fixture-new-station";
      roster[1] = { ...roster[1]!, sn: f.camera.stationSn, stationSn: f.camera.stationSn };
    }
    Object.assign(f.internal.registry, { devices: roster });
    vi.mocked(f.internal.registry.list).mockReturnValue(roster);
    f.internal.reconcileStationContexts();
    for (const device of held) {
      await device.camera!()!.setStatusLed!(true);
      expect(device.light!()!.setMotionLightDuration).toBeTypeOf("function");
    }
    expect(f.sent).toEqual(held.map(() => expect.objectContaining({ param: 1045, channel: 2 })));
    const setters = held.map((device) => device.camera!()!.setNightVision!);
    for (const channel of [undefined, "2", -1, 1.5, 255, NaN, Infinity, "duplicate", "missing-station"]) {
      const unsafe = channel === "missing-station" ? [f.camera] : [...roster];
      f.camera.raw = { device_type: 47, device_channel: channel === "duplicate" ? 2 : channel };
      if (channel === "duplicate") unsafe.push({ ...f.camera, sn: "fixture-other-camera" });
      Object.assign(f.internal.registry, { devices: unsafe });
      vi.mocked(f.internal.registry.list).mockReturnValue(unsafe);
      f.internal.reconcileStationContexts();
      for (const setter of setters) await expect(setter(2)).rejects.toThrow();
      expect(f.sent).toHaveLength(2);
    }
  });

  it.each([
    ["aiDetectType", 0],
    ["aiDetectType", 9],
    ["nightVision", 0],
    ["nightVision", 9],
  ] as const)("uses the current channel from both held handles for %s on channel %s", async (property, channel) => {
    for (const stationModel of ["T9000", "T8030"]) {
      const { app, camera, sent, internal } = fixture(stationModel, "T8425", { 1298: "196623", 1277: "1" });
      const held = await app.getDevice(camera.sn);
      const fresh = await app.getDevice(camera.sn);
      const setters = [held, fresh].map((device) =>
        property === "aiDetectType" ? device.motion!()!.setAiDetectType! : device.camera!()!.setNightVision!,
      );
      camera.raw = { ...(camera.raw as Record<string, unknown>), device_channel: channel };
      const roster = [...internal.registry.list()];
      Object.assign(internal.registry, { devices: roster });
      vi.mocked(internal.registry.list).mockReturnValue(roster);
      held.setMetadataContext({ firmwareVersion: "synthetic-version" });
      const value = property === "aiDetectType" ? 0x3000e : 2;
      for (const set of setters) await set(value);
      await (property === "aiDetectType" ? held.motion!()!.setAiDetectType! : held.camera!()!.setNightVision!)(value);
      for (const command of sent) {
        expect(command).toMatchObject({ channel: stationModel === "T9000" ? channel : 0, payload: { channel } });
      }
      expect(sent).toHaveLength(3);
    }
  });

  it.each(["aiDetectType", "nightVision"] as const)(
    "withholds held %s setters when current channel evidence is unsafe",
    async (property) => {
      for (const stationModel of ["T9000", "T8030"]) {
        for (const channel of [
          undefined,
          "9",
          -1,
          1.5,
          255,
          256,
          NaN,
          Infinity,
          "duplicate",
          "missing-device",
          "missing-station",
          "changed-parent",
        ]) {
          const { app, camera, sent, internal } = fixture(stationModel, "T8425", { 1298: "196623", 1277: "1" });
          const held = await app.getDevice(camera.sn);
          await app.getDevice(camera.sn);
          const set = property === "aiDetectType" ? held.motion!()!.setAiDetectType! : held.camera!()!.setNightVision!;
          let roster = [...internal.registry.list()];
          if (channel === "duplicate") roster.push({ ...camera, sn: "fixture-other-camera" });
          else if (channel === "missing-device") roster = roster.slice(1);
          else if (channel === "missing-station") roster = roster.slice(0, 1);
          else if (channel === "changed-parent") camera.stationSn = "fixture-other-station";
          else camera.raw = { ...(camera.raw as Record<string, unknown>), device_channel: channel };
          Object.assign(internal.registry, { devices: roster });
          vi.mocked(internal.registry.list).mockReturnValue(roster);
          await expect(set(property === "aiDetectType" ? 0x3000e : 2)).rejects.toThrow();
          expect(sent).toHaveLength(0);
        }
      }
    },
  );

  it("populates composite getters and writes on cold construction and every fresh getDevice", async () => {
    const { app, camera, sent } = fixture();
    const first = await app.getDevice(camera.sn);
    await expectColdSettings(first, sent);
    const fresh = await app.getDevice(camera.sn);
    expect(fresh).not.toBe(first);
    await expectColdSettings(fresh, sent);
  });

  it("resolves recording-quality read labels for a T9000-attached T8425", async () => {
    const { app, camera } = fixture();
    const device = await app.getDevice(camera.sn);
    expect(
      device
        .describe()
        .details.flatMap((detail) => detail.reads)
        .find((read) => read.property === "recordingQuality"),
    ).toMatchObject({ values: [1, 2, 3], labels: { 1: "720P", 2: "1080P", 3: "3K" } });
    expect(device.camera!()!.recordingQuality).toBe(2);
  });

  it.each(["binding", "later station context"])(
    "reindexes retained configs on %s without a new observation",
    async (path) => {
      const device = Device.fromRecord("fixture-camera", {
        model: "T8425",
        deviceType: 47,
        parentSn: "fixture-station",
        params,
      });
      device.applyParams(params, 1234);
      const sent: Command[] = [];
      const sink = { dispatch: async (command: Command) => void sent.push(command) };
      if (path === "binding") device.bindActions(context, sink);
      else {
        device.bindActions({ ...context, stationModel: undefined }, sink);
        device.setStationContext(context);
      }
      await expectColdSettings(device, sent);
      expect(device.getProperty("lightSchedule")?.ts).toBe(1234);
      expect(device.getProperty("motionLightEnabled")?.ts).toBe(1234);
      device.setStationContext(context);
      expect(device.applyParams({ 1421: params[1421], 1422: params[1422] }, 5678)).toEqual([]);
    },
  );

  it("refuses recording-quality writes on a doorbell with no 2731 report", async () => {
    const { app, camera, sent } = fixture("T9000", "T8214", { 1045: "1" });
    const device = await app.getDevice(camera.sn);
    const setter = device.camera?.()?.setRecordingQuality;
    expect(setter).toBeUndefined();
    expect(
      device
        .describe()
        .details.flatMap((detail) => detail.reads)
        .some((read) => read.property === "recordingQuality"),
    ).toBe(false);
    expect(sent).toEqual([]);
  });

  it.each(["T8030", "T8010"])("preserves %s state, labels and exact command bodies", async (stationModel) => {
    const { app, camera, sent } = fixture(stationModel);
    const device = await app.getDevice(camera.sn);
    const before = JSON.stringify(device.toJSON());
    expect(device.light!()!.setLightSchedule).toBeUndefined();
    expect(device.light!()!.setMotionLightDuration).toBeUndefined();
    expect(device.getProperty("unknown_1421")?.value).toBe(params[1421]);
    expect(device.getProperty("motionActivateLight")?.value).toEqual(motion);
    expect(device.getProperty("unknown_1422")).toBeUndefined();
    expect(
      device
        .describe()
        .details.flatMap((detail) => detail.reads)
        .find((read) => read.property === "recordingQuality")?.labels,
    ).toEqual({ 1: "HD (720P)", 2: "Full HD (1080P)", 3: "Max" });
    device.setStationContext({ stationModel });
    expect(JSON.stringify(device.toJSON())).toBe(before);
    await device.camera!()!.setRecordingQuality!(2);
    await device.camera!()!.setStatusLed!(true);
    expect(sent.map((command) => Buffer.from(JSON.stringify(command)))).toEqual([
      Buffer.from(
        JSON.stringify({
          kind: "set-payload",
          cmd: 2731,
          payload: { channel: 0, mode: 0, primary_view: 0, quality: 2 },
          channel: 2,
          mValue3: 0,
          form: "auto",
        }),
      ),
      Buffer.from(JSON.stringify({ kind: "set-param", param: 1045, value: 1, form: "int-string", channel: 2 })),
    ]);
  });
});

describe("serialized composite writes through held and fresh handles", () => {
  it.each([1421, 1422, 2731])("uses the latest report through a superseded handle for %s", async (param) => {
    const f = fixture();
    const older = await f.app.getDevice(f.camera.sn);
    const scheduleSetter = older.light!()!.setLightSchedule!;
    const retained =
      param === 1421
        ? () => scheduleSetter("[]")
        : param === 1422
          ? older.light!()!.setMotionLightDuration!.bind(undefined, 45)
          : older.camera!()!.setRecordingQuality!.bind(undefined, 1);
    const fresh = await f.app.getDevice(f.camera.sn);
    const latest =
      param === 1421
        ? { ...schedule, retained: "latest" }
        : param === 1422
          ? { ...motion, brightness: 90 }
          : { ...capture, mode_1: { quality: 3, audio: 1 } };
    f.internal.applyRealtimeState(f.camera.sn, { [param]: JSON.stringify(latest) });
    expect(older.readRawParameter(param)).toBe(params[param as keyof typeof params]);
    expect(fresh.readRawParameter(param)).toBe(JSON.stringify(latest));
    if (param === 1422) await fresh.light!()!.setMotionLightEnabled!(false);
    await retained();
    const command = f.sent.at(-1)!;
    const actual = command.kind === "raw-text" ? JSON.parse(Buffer.from(command.text, "base64").toString()) : command;
    expect(actual).toMatchObject(
      param === 2731
        ? { ...latest, mode_0: { quality: 1 } }
        : { payload: { ...latest, ...(param === 1421 ? { schedule: [] } : { time: 45, enable: 0 }) } },
    );
  });

  it("keeps the authoritative snapshot after the newest handle is collected", async () => {
    const f = fixture();
    const older = await f.app.getDevice(f.camera.sn);
    f.record.params = { ...params, 1422: JSON.stringify({ ...motion, brightness: 90 }) };
    await f.app.getDevice(f.camera.sn);
    const internals = f.app as unknown as { liveDevices: Map<string, WeakRef<Device>> };
    internals.liveDevices.set(f.camera.sn, { deref: () => undefined } as WeakRef<Device>);
    await older.light!()!.setMotionLightDuration!(45);
    expect(f.sent[0]).toMatchObject({ payload: { ...motion, brightness: 90, time: 45 } });
    const fresh = await f.app.getDevice(f.camera.sn);
    await fresh.light!()!.setMotionLightDuration!(45);
    expect(f.sent[1]).toMatchObject({ payload: { ...motion, brightness: 90, time: 45 } });
  });

  it("preserves prior ACKed fields across concurrent edits and fresh handles without changing observed reads", async () => {
    const f = fixture();
    const first = await f.app.getDevice(f.camera.sn);
    const second = await f.app.getDevice(f.camera.sn);
    await Promise.all([
      first.light!()!.setMotionLightBrightness!(70),
      second.light!()!.setMotionLightDuration!(45),
      first.light!()!.setAutoSpotlight(false, { mode: 2 }),
    ]);
    expect(f.sent).toHaveLength(3);
    expect(f.sent[2]).toMatchObject({ payload: { ...motion, brightness: 70, time: 45, enable: 0, mode: 2 } });
    expect(first.light!()!.motionLightBrightness).toBe(50);
    expect(second.light!()!.motionLightDuration).toBe(30);
  });

  it("does not compose a rejected change into the next write", async () => {
    const f = fixture();
    let reject = true;
    vi.mocked(f.internal.commandSinkFor).mockReturnValue({
      dispatch: async (command) => {
        if (reject) {
          reject = false;
          throw new Error("rejected: -110");
        }
        f.sent.push(command);
      },
    });
    const device = await f.app.getDevice(f.camera.sn);
    const failure = device.light!()!.setMotionLightBrightness!(70).catch((error: unknown) => error);
    const next = device.light!()!.setMotionLightDuration!(45);
    expect(await failure).toBeInstanceOf(Error);
    await next;
    expect(f.sent).toEqual([expect.objectContaining({ payload: { ...motion, time: 45 } })]);
  });

  it.each([false, true])("a report supersedes an overlay, including before ACK: %s", async (duringAck) => {
    const f = fixture();
    const device = await f.app.getDevice(f.camera.sn);
    if (duringAck)
      vi.mocked(f.internal.commandSinkFor).mockReturnValue({
        dispatch: async (command) => {
          f.sent.push(command);
          device.applyParams({ 1422: JSON.stringify({ ...motion, brightness: 80 }) });
        },
      });
    if (duringAck)
      device.bindActions(
        {
          ...context,
          parameterWrites: (
            f.internal as unknown as {
              contextForRecord(sn: string, record: typeof f.record): CommandContext;
            }
          ).contextForRecord(f.camera.sn, f.record).parameterWrites,
        },
        f.internal.commandSinkFor(f.camera.sn),
      );
    await device.light!()!.setMotionLightBrightness!(70);
    device.applyParams({ 1422: JSON.stringify({ ...motion, brightness: 80 }) });
    await device.light!()!.setMotionLightDuration!(45);
    expect(f.sent[1]).toMatchObject({ payload: { ...motion, brightness: 80, time: 45 } });
  });

  it("preserves reported sibling fields for queued schedule and capture writes", async () => {
    const f = fixture();
    const device = await f.app.getDevice(f.camera.sn);
    await Promise.all([
      device.light!()!.setLightSchedule!(JSON.stringify([{ start: "19:00" }])),
      device.light!()!.setLightSchedule!(JSON.stringify([{ start: "20:00" }])),
      device.camera!()!.setRecordingQuality!(2),
      device.camera!()!.setRecordingQuality!(1),
    ]);
    const schedules = f.sent.filter((c) => c.kind === "set-payload" && c.cmd === 1421);
    expect(schedules[1]).toMatchObject({ payload: { ...schedule, schedule: [{ start: "20:00" }] } });
    const captures = f.sent.filter((c) => c.kind === "raw-text");
    expect(captures).toHaveLength(2);
    expect(JSON.parse(Buffer.from(captures[1]!.text, "base64").toString())).toEqual({
      ...capture,
      mode_0: { quality: 1 },
    });
  });

  it.each(["bad", "{}", JSON.stringify({ ...capture, mode_1: [] })])(
    "withholds recording setter for malformed report %s",
    async (raw) => {
      const f = fixture("T9000", "T8425", { ...params, 2731: raw });
      const device = await f.app.getDevice(f.camera.sn);
      expect(device.camera!()!.setRecordingQuality).toBeUndefined();
      expect(
        device
          .describe()
          .details.flatMap((d) => d.reads)
          .find((r) => r.property === "recordingQuality")?.writable,
      ).toBe(false);
    },
  );

  it("retains published unknown schedule state on a device without light", async () => {
    const f = fixture("T8030", "T8214", { 1045: "1", 1421: params[1421] });
    const device = await f.app.getDevice(f.camera.sn);
    expect(device.getProperty("unknown_1421")?.value).toBe(params[1421]);
    expect(device.getProperty("lightScheduleConfig")).toBeUndefined();
  });
});

it("preserves published retained state on a standalone floodlight", () => {
  const device = Device.fromRecord("fixture-standalone", { model: "T8425", deviceType: 47, params });
  device.bindActions({ ...context, stationModel: undefined, homeBaseAttached: false }, { dispatch: async () => {} });
  expect(device.getProperty("motionActivateLight")?.value).toEqual(motion);
  expect(device.getProperty("unknown_1421")?.value).toBe(params[1421]);
  expect(device.getProperty("unknown_1422")).toBeUndefined();
});

it("updates recording write availability when a held device reports a new config shape", async () => {
  const f = fixture();
  const device = await f.app.getDevice(f.camera.sn);
  expect(device.camera!()!.setRecordingQuality).toBeTypeOf("function");
  device.applyParams({ 2731: "bad" });
  expect(device.camera!()!.setRecordingQuality).toBeUndefined();
  device.applyParams({ 2731: params[2731] });
  expect(device.camera!()!.setRecordingQuality).toBeTypeOf("function");
});

it("advances generic property composition only for acknowledged receipts", async () => {
  const f = fixture();
  let reject = true;
  vi.mocked(f.internal.commandSinkFor).mockImplementation((_sn, invocation) => ({
    dispatch: async (command) => {
      f.sent.push(command);
      if (invocation)
        invocation.receipt = {
          status: reject ? "rejected" : "acknowledged",
          sendAttempted: true,
          effect: "unconfirmed",
        };
      reject = false;
    },
  }));
  expect(await f.app.setPropertyWithReceipt(f.camera.sn, "motionLightBrightness", 70)).toMatchObject({
    status: "rejected",
  });
  await f.app.setPropertyWithReceipt(f.camera.sn, "motionLightDuration", 45);
  expect(f.sent[1]).toMatchObject({ payload: { ...motion, time: 45 } });
  await f.app.setPropertyWithReceipt(f.camera.sn, "motionLightBrightness", 70);
  await f.app.setPropertyWithReceipt(f.camera.sn, "motionLightDuration", 55);
  expect(f.sent[3]).toMatchObject({ payload: { ...motion, brightness: 70, time: 55 } });
});

it("does not retain a composition snapshot merely from advertising a setter", async () => {
  const f = fixture();
  await f.app.getDevice(f.camera.sn);
  f.record.params = { ...params, 1422: JSON.stringify({ ...motion, brightness: 90 }) };
  const fresh = await f.app.getDevice(f.camera.sn);
  await fresh.light!()!.setMotionLightDuration!(45);
  expect(f.sent[0]).toMatchObject({ payload: { ...motion, brightness: 90, time: 45 } });
});

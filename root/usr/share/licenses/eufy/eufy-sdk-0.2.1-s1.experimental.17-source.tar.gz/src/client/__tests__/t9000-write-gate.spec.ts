import type { Command } from "../../core/contracts.js";
import { T9000_VERIFIED_CONTROL_LAYOUTS } from "../../transport/rtc/control-command.js";
import { vi } from "vitest";
import { EufyMega } from "../eufy-mega.js";
import type { DeviceRegistry } from "../device-registry.js";
import type { EufyDevice } from "../../core/types.js";
import { Device } from "../../model/device.js";
import { describe, expect, it } from "vitest";
import { bind } from "../../model/capabilities/__tests__/bind.js";
import { buildCommand, describeCapabilities, mergeProperties } from "../../model/capabilities/index.js";
import type { CameraActions } from "../../model/capabilities/camera.js";
import type { LightActions } from "../../model/capabilities/light.js";
import { bindMembers, type Members } from "../../model/capabilities/members.js";
import type { CommandContext } from "../../model/capabilities/types.js";
import { rtcCommandRoutable } from "../../transport/rtc/control-command.js";

const ctx: CommandContext = {
  codec: "camera",
  model: "T8170",
  deviceType: 19,
  channel: 2,
  stationModel: "T9000",
  homeBaseAttached: true,
  paramIds: new Set([1045, 1207, 1400]),
  capabilities: new Set(["camera", "light"]),
  acceptsCommand: rtcCommandRoutable,
};

describe("setter admission after device routing", () => {
  it.each([
    ["T8217", "T9000", true],
    ["T8214", "T9000", false],
    ["T8214", "T9000A", true],
  ] as const)(
    "keeps %s spotlight read-only on %s with known channel %s",
    (model, stationModel, channelIsUnambiguous) => {
      const context = { ...ctx, model, stationModel, channelIsUnambiguous, deviceType: 94 };
      const { acts } = bind<LightActions>("light", context, { read: () => ({ value: false }) });
      expect(acts.isOn).toBe(false);
      expect(acts.set).toBeUndefined();
      expect(acts.on).toBeUndefined();
      expect(acts.off).toBeUndefined();
      expect(mergeProperties(["light"], context).find((p) => p.name === "light")?.writable).toBe(false);
      expect(buildCommand("light", true, context)).toBeUndefined();
      expect(rtcCommandRoutable({ kind: "set-param", param: 1400, value: 1, form: "int-string", channel: 2 })).toBe(
        false,
      );
    },
  );

  it("requires a reported 1400 before offering the T8214 spotlight write", () => {
    const context = { ...ctx, model: "T8214", deviceType: 94, channelIsUnambiguous: true, paramIds: new Set([1401]) };
    expect(buildCommand("light", true, context)).toBeUndefined();
    expect(bind<LightActions>("light", context).acts.set).toBeUndefined();
  });

  it("keeps carryable scalars and removes a privacy burst setter", () => {
    const { acts } = bind<CameraActions>("camera", ctx);
    expect(acts.setImageFlipped).toBeTypeOf("function");
    expect(acts.setStatusLed).toBeTypeOf("function");
    expect(acts.setPrivacy).toBeUndefined();
    expect(buildCommand("privacy", true, ctx)).toBeUndefined();
  });
  it("keeps an unsupported int-string light read, removes its setter, and marks it read-only", () => {
    const { acts } = bind<LightActions>("light", ctx, { read: () => ({ value: true }) });
    expect(acts.isOn).toBe(true);
    expect(acts.set).toBeUndefined();
    const descriptor = describeCapabilities({ light: acts }, ctx)[0]!;
    expect(descriptor.reads.find((r) => r.accessor === "isOn")?.writable).toBe(false);
    expect(mergeProperties(["light"], ctx).find((p) => p.name === "light")?.writable).toBe(false);
    expect(buildCommand("light", true, ctx)).toBeUndefined();
  });
  it("refuses binary string params and accessory ringtone controls on T9000", () => {
    const members = {
      quality: {
        description: "Fixture scalar",
        param: 1286,
        type: "number",
        kind: "scalar",
        write: (value, context) => ({
          kind: "set-param",
          param: 1286,
          value: Number(value),
          form: "direct-binary",
          channel: context.channel,
        }),
      },
    } satisfies Members;
    const acts = bindMembers(members, {
      ctx: { ...ctx, paramIds: new Set([1286]) },
      sink: { dispatch: async () => {} },
      read: () => undefined,
    });
    expect(acts.setQuality).toBeUndefined();
    expect(Object.getOwnPropertyDescriptor(acts, "quality")?.get).toBeTypeOf("function");
    expect(
      buildCommand("dingdongRingtone", 0, {
        ...ctx,
        model: "T8214",
        deviceType: 94,
        capabilities: new Set(["doorbell"]),
        paramIds: new Set([1718]),
      }),
    ).toBeUndefined();
  });
  it("withholds value-dependent setters if either direction cannot route", () => {
    const members = {
      toggle: {
        description: "Fixture toggle",
        type: "bool",
        kind: "boolean",
        writeOnly: true,
        write: (v, c) =>
          v
            ? { kind: "set-payload", cmd: 1, payload: {}, channel: c.channel }
            : { kind: "p2p-privacy-burst", enabled: false, channel: c.channel },
      },
    } satisfies Members;
    expect(
      bindMembers(members, { ctx, sink: { dispatch: async () => {} }, read: () => undefined }).setToggle,
    ).toBeUndefined();
  });
  it("injects dictionary and topology gates from the actual facade context", () => {
    const app = new EufyMega({ email: "fixture@example.com", password: "fixture" });
    const station = { sn: "fixture-station", stationSn: "fixture-station", model: "T9000", raw: {} } as EufyDevice;
    const target = {
      sn: "fixture-camera",
      stationSn: station.sn,
      model: "T8425",
      raw: { device_channel: 2 },
    } as EufyDevice;
    const record = { model: "T8425", deviceType: 47, parentSn: station.sn, params: { 1045: "1", 1422: "{}" } };
    const internals = app as unknown as {
      registry: DeviceRegistry;
      contextForRecord(sn: string, rec: typeof record): CommandContext;
      parentStationContext(dev: EufyDevice): CommandContext;
    };
    vi.spyOn(internals.registry, "list").mockReturnValue([target, station]);
    vi.spyOn(internals.registry, "require").mockReturnValue(target);
    try {
      const context = internals.contextForRecord(target.sn, record);
      expect(
        context.acceptsCommand!({ kind: "set-param", param: 1422, value: 1, form: "direct-binary", channel: 2 }),
      ).toBe(false);
      const device = Device.fromRecord(target.sn, record);
      device.bindActions(context, { dispatch: async () => {} });
      expect(device.camera!()!.setPrivacy).toBeUndefined();
      station.model = "T8030";
      device.setStationContext(internals.parentStationContext(target));
      expect(device.camera!()!.setPrivacy).toBeTypeOf("function");
    } finally {
      vi.restoreAllMocks();
    }
  });

  it("preserves every P2P setter when the primary transport has no refusal gate", () => {
    const p2p = { ...ctx, stationModel: "T8030", acceptsCommand: undefined };
    expect(bind<CameraActions>("camera", p2p).acts.setPrivacy).toBeTypeOf("function");
    expect(bind<LightActions>("light", p2p).acts.set).toBeTypeOf("function");
  });
});

function facadeContext(stationTarget = false) {
  const app = new EufyMega({ email: "fixture@example.com", password: "synthetic", autoRealtime: false });
  const reported = Object.fromEntries(
    [
      1101, 1011, 1015, 1035, 1045, 1145, 1207, 1214, 1230, 1235, 1240, 1241, 1246, 1249, 1250, 1251, 1281, 1400, 1401,
      1403, 1410, 1702, 1703, 1704, 1705, 1706, 1708,
    ].map((id) => [id, "1"]),
  );
  const station = {
    sn: "fixture-station",
    stationSn: "fixture-station",
    model: "T9000",
    raw: { device_type: 27 },
  } as EufyDevice;
  const camera = {
    sn: "fixture-camera",
    stationSn: station.sn,
    model: "T8425",
    raw: { device_type: 47, device_channel: 2 },
  } as EufyDevice;
  const target = stationTarget ? station : camera;
  const rec = {
    model: target.model,
    deviceType: stationTarget ? 27 : 47,
    parentSn: stationTarget ? undefined : station.sn,
    params: reported,
  };
  const internal = app as unknown as {
    registry: DeviceRegistry;
    contextForRecord(sn: string, record: typeof rec): CommandContext;
  };
  vi.spyOn(internal.registry, "list").mockReturnValue([camera, station]);
  vi.spyOn(internal.registry, "require").mockReturnValue(target);
  const context = internal.contextForRecord(target.sn, rec);
  const device = Device.fromRecord(target.sn, rec);
  device.bindActions(context, { dispatch: async () => {} });
  return { context, device };
}

it.each([false, true])("real facade withholds unverified setters on station target=%s", (stationTarget) => {
  try {
    const { context, device } = facadeContext(stationTarget);
    if (stationTarget) {
      expect(device.siren!()!.setAlarmVolume).toBeUndefined();
    } else {
      expect(device.rtsp!()!.setPublished).toBeUndefined();
      expect(device.rtsp!()!.publish).toBeUndefined();
      expect(device.rtsp!()!.withdraw).toBeUndefined();
      expect(device.camera!()!.setAntiTheftDetection).toBeUndefined();
      expect(device.light!()!.setColorTemp).toBeUndefined();
      expect(device.battery!()!.setWorkingMode).toBeUndefined();
      expect(
        device
          .describe()
          .details.flatMap((d) => d.reads)
          .find((r) => r.property === "rtspStream")?.writable,
      ).toBe(false);
    }
    for (const param of [1015, 1145, 1235, 1246, 1410])
      expect(
        context.acceptsCommand!({
          kind: "set-param",
          param,
          value: 1,
          form: "direct-binary",
          channel: context.channel,
        }),
      ).toBe(false);
  } finally {
    vi.restoreAllMocks();
  }
});

it.each([false, true])(
  "real facade offers every allowlisted parameter with its verified layout, station=%s",
  (stationTarget) => {
    try {
      const { context } = facadeContext(stationTarget);
      for (const [layout, params] of Object.entries(T9000_VERIFIED_CONTROL_LAYOUTS)) {
        for (const param of params) {
          // The int-string write has a separate attached-doorbell topology test.
          if (layout === "int-string") continue;
          const command: Command =
            layout === "direct-binary"
              ? { kind: "set-param", param, value: 1, form: "direct-binary", channel: context.channel }
              : layout === "station-132"
                ? { kind: "p2p-station-scalar", cmd: param, value: 1, channel: context.channel }
                : { kind: "raw-text", cmd: param, text: "fixture", channel: context.channel };
          const members = {
            setting: { param, type: "number", kind: "scalar", description: "Fixture setting", write: () => command },
          } satisfies Members;
          const actions = bindMembers(members, {
            ctx: context,
            sink: { dispatch: async () => {} },
            read: () => undefined,
          });
          expect(actions.setSetting, `${param}:${layout}`).toBeTypeOf("function");
        }
      }
    } finally {
      vi.restoreAllMocks();
    }
  },
);

it("does not hide ff09, mqtt-dp or aiot-dp writes routed outside the RTC portal", () => {
  try {
    const { context } = facadeContext();
    const commands: Command[] = [
      { kind: "ff09-setting-toggle", adminUserId: "fixture", deviceSn: "fixture", settingId: 1, value: true },
      { kind: "mqtt-dp", mqttCmdCode: 1, cmdCode: 1, fields: [] },
      { kind: "aiot-dp", dp: 1, value: true },
    ];
    for (const command of commands) {
      const members = {
        setting: { type: "number", kind: "scalar", description: "Fixture setting", write: () => command },
      } satisfies Members;
      expect(
        bindMembers(members, { ctx: context, sink: { dispatch: async () => {} }, read: () => undefined }).setSetting,
      ).toBeTypeOf("function");
    }
  } finally {
    vi.restoreAllMocks();
  }
});

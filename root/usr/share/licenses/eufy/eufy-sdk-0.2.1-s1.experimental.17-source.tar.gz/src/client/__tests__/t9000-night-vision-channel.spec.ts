import { describe, expect, it, vi } from "vitest";
import type { Command } from "../../core/contracts.js";
import type { EufyDevice } from "../../core/types.js";
import { Device } from "../../model/device.js";
import type { CameraActions } from "../../model/capabilities/camera.js";
import { buildRtcControlPacket } from "../../transport/rtc/control-command.js";
import { parsePortalHeader, PORTAL_HEADER_LENGTH } from "../../transport/rtc/portal-packet.js";
import { CommandIntentRegistry } from "../command-intents.js";
import { DeviceRegistry, type DeviceRecord } from "../device-registry.js";
import { EufyMega } from "../eufy-mega.js";
import { PropertyPreparationRecorder } from "../property-preparation-diagnostics.js";

/** Constructor-free facade: real preparation, context, admission and routing with no live clients. */
function fixture(model: string, channel: unknown, stationModel = "T9000", duplicate = false) {
  const station = { sn: "fixture-station", model: stationModel, raw: {} } as EufyDevice;
  const target = {
    sn: "fixture-camera",
    stationSn: station.sn,
    model,
    raw: { device_channel: channel },
  } as EufyDevice;
  const devices = [station, target];
  if (duplicate) devices.push({ ...target, sn: "fixture-other-camera" });
  const record: DeviceRecord = {
    model,
    parentSn: station.sn,
    params: { 1277: "1" },
    paramUpdatedAt: {},
  };
  const registry = Object.assign(Object.create(DeviceRegistry.prototype) as DeviceRegistry, {
    devices,
    list: () => devices,
    require: () => target,
    record: async () => record,
  });
  const rtc = vi.fn(async () => {});
  const p2p = vi.fn(async () => {});
  const app: EufyMega = Object.assign(Object.create(EufyMega.prototype), {
    registry,
    mega: {},
    parameterWrites: new Map(),
    deviceParamRevisions: new Map(),
    parameterReadSnapshots: new Map(),
    liveDevices: new Map(),
    realtimeEpoch: 0,
    propertyPreparations: new Set(),
    propertyPreparationRecorder: new PropertyPreparationRecorder(),
    commandIntents: new CommandIntentRegistry(),
    lateEffects: { begin: () => undefined, finish: () => false },
    lateContrary: { finishCorrection: () => {} },
    rtc: { commandTimeoutMs: 1_000, dispatchCommand: rtc },
    p2p: { dispatchCommand: p2p },
  });
  const internal = app as unknown as {
    contextForRecord(sn: string, record: DeviceRecord): Parameters<Device["bindActions"]>[0];
  };
  const context = internal.contextForRecord(target.sn, record);
  const device = Device.fromRecord(target.sn, record);
  device.bindActions(context, { dispatch: async () => {} });
  return { app, target, rtc, p2p, device };
}

describe("T9000 night vision target channel", () => {
  it.each(["T8134", "T8425", "T8170", "T8171", "T8416", "T8426", "T8214"])(
    "routes %s through the facade on zero and nonzero channels",
    async (model) => {
      for (const channel of [0, 1, 3, 9]) {
        const { app, target, rtc, p2p, device } = fixture(model, channel);
        expect((device.camera!() as CameraActions).setNightVision).toBeTypeOf("function");
        // A T8416 has no spotlight mode; its third mode is 3 ("Infrared On").
        const modes = model === "T8416" ? [0, 1, 3] : [0, 1, 2];
        for (const mode of modes) await app.setProperty(target.sn, "nightVision", mode);
        expect(rtc).toHaveBeenCalledTimes(3);
        for (const [index, args] of rtc.mock.calls.entries()) {
          const mode = modes[index];
          const [, command] = args as unknown as [string, Command];
          expect(command).toEqual({
            kind: "set-payload",
            cmd: 1277,
            payload: { night_sion: mode, channel },
            channel,
            mValue3: 0,
            form: "auto",
          });
          const packet = buildRtcControlPacket(command, "", channel, 1);
          expect(parsePortalHeader(packet)).toMatchObject({ commandId: 1350, channel });
          expect(JSON.parse(packet.subarray(PORTAL_HEADER_LENGTH).toString())).toMatchObject({
            cmd: 1277,
            mValue3: 0,
            payload: { night_sion: mode, channel },
          });
        }
        expect(p2p).not.toHaveBeenCalled();
        expect(app.getPropertyPreparationDiagnostics()).toMatchObject({ prepared: 3, failures: 0 });
      }
    },
  );
  it.each([undefined, "3", -1, 256, 1.5, NaN, Infinity])("withholds unsafe channel %s", async (channel) => {
    const { app, target, device, rtc, p2p } = fixture("T8425", channel);
    expect((device.camera!() as CameraActions).setNightVision).toBeUndefined();
    expect(
      device
        .describe()
        .details.flatMap((d) => d.reads)
        .find((r) => r.property === "nightVision")?.writable,
    ).toBe(false);
    await expect(app.setProperty(target.sn, "nightVision", 1)).rejects.toThrow();
    expect(rtc).not.toHaveBeenCalled();
    expect(p2p).not.toHaveBeenCalled();
  });
  it("withholds duplicate channels", async () => {
    const { app, target, device, rtc, p2p } = fixture("T8425", 3, "T9000", true);
    expect((device.camera!() as CameraActions).setNightVision).toBeUndefined();
    await expect(app.setProperty(target.sn, "nightVision", 1)).rejects.toThrow();
    expect(rtc).not.toHaveBeenCalled();
    expect(p2p).not.toHaveBeenCalled();
  });
  it("preserves other station envelopes", async () => {
    const { app, target, rtc, p2p } = fixture("T8425", 3, "T8030");
    await app.setProperty(target.sn, "nightVision", 1);
    expect(p2p).toHaveBeenCalledWith(
      target.sn,
      expect.objectContaining({
        channel: 0,
        payload: { night_sion: 1, channel: 3 },
        mValue3: 0,
        form: "auto",
      }),
    );
    expect(rtc).not.toHaveBeenCalled();
  });
});

import { afterEach, expect, it, vi } from "vitest";
import type { Command } from "../../core/contracts.js";
import type { DeviceRegistry } from "../device-registry.js";
import type { Device } from "../../model/device.js";
import type { CommandContext } from "../../model/capabilities/types.js";
import { EufyMega } from "../eufy-mega.js";

const sn = "synthetic-floodlight";
const motion = {
  enable: 1,
  time: 180,
  brightness: 100,
  mode: 1,
  schedule: [{ start: "18:00", end: "23:00" }],
  latitude: "0.000000",
  extension: { retained: true },
};
const capture = {
  cur_mode: 0,
  mode_0: { quality: 2, audio: 1 },
  mode_1: { quality: 3, audio: 0 },
  extension: { retained: true },
};
const cases = [
  {
    param: 1422,
    property: "motionLightBrightness",
    value: 80,
    report: motion,
    cloud: { ...motion, time: 90 },
    patch: { brightness: 80 },
    scalar: ["100", "80"],
    invalid: { ...motion, time: "90" },
  },
  {
    param: 1421,
    property: "lightSchedule",
    value: "[]",
    report: motion,
    cloud: { ...motion, mode: 2 },
    patch: { schedule: [] },
    scalar: ["100", "80"],
    invalid: { schedule: "invalid" },
  },
  {
    param: 2731,
    property: "recordingQuality",
    value: "720P",
    report: capture,
    cloud: { ...capture, mode_1: { quality: 3, audio: 1 } },
    patch: { mode_0: { quality: 1, audio: 1 } },
    scalar: ["2", "1"],
    invalid: { ...capture, mode_1: { audio: 0 } },
  },
];

function encode(value: unknown, wrappers = 0): string {
  let raw = JSON.stringify(value);
  for (let i = 0; i < wrappers; i++) raw = Buffer.from(raw).toString("base64");
  return raw;
}

async function fixture(initial: Record<number, string> = {}) {
  const log = vi.fn();
  const app = new EufyMega({
    email: "fixture@example.com",
    password: "synthetic",
    autoRealtime: false,
    logger: { debug: log, info: log, warn: log, error: log },
  });
  const internal = app as unknown as {
    registry: DeviceRegistry;
    pollOnce(): Promise<void>;
    applyRealtimeState(sn: string, params: Record<number, string>): void;
    commandSinkFor(sn: string): { dispatch(command: Command): Promise<void> };
  };
  const cloud = { 1045: "1", 1400: "1", ...initial };
  const overlay: Record<number, string> = {};
  vi.spyOn(app.api, "post").mockImplementation(async (_service, path) => {
    if (path.endsWith("get_house_list")) return { house_infos: [] } as never;
    if (!path.endsWith("get_devs_list")) throw new Error("Unexpected network request");
    return {
      devices: [
        { device_sn: "synthetic-station", device_model: "T9000", category: "eufy_security" },
        {
          device_sn: sn,
          station_sn: "synthetic-station",
          device_model: "T8425",
          device_type: 47,
          device_channel: 2,
          category: "eufy_security",
          params: Object.entries(cloud).map(([param, value]) => ({ param_type: Number(param), param_value: value })),
        },
      ],
    } as never;
  });
  vi.spyOn(app.api, "getDeviceParamList").mockImplementation(
    async () =>
      ({
        params: Object.entries(overlay).map(([param, value]) => ({ param_type: Number(param), param_value: value })),
      }) as never,
  );
  const sent: Command[] = [];
  vi.spyOn(internal, "commandSinkFor").mockReturnValue({ dispatch: async (command) => void sent.push(command) });
  await internal.registry.pollChanges();
  return { app, internal, cloud: cloud as Record<number, string>, overlay, sent, log };
}

function config(command: Command): unknown {
  if (command.kind === "set-payload") return command.payload;
  if (command.kind === "raw-text") return JSON.parse(Buffer.from(command.text, "base64").toString("utf8"));
  throw new Error("Expected composite command");
}

function privateLogs(f: Awaited<ReturnType<typeof fixture>>): void {
  expect(JSON.stringify(f.log.mock.calls)).not.toMatch(/latitude|0\.000000|cur_mode|retained|schedule|brightness/);
  for (const c of cases) {
    for (let wrappers = 0; wrappers <= 2; wrappers++) {
      expect(JSON.stringify(f.log.mock.calls)).not.toContain(encode(c.report, wrappers));
      expect(JSON.stringify(f.log.mock.calls)).not.toContain(encode(c.cloud, wrappers));
      expect(JSON.stringify(f.log.mock.calls)).not.toContain(encode(c.invalid, wrappers));
    }
  }
}

afterEach(() => vi.restoreAllMocks());

it.each(cases.flatMap((c) => [false, true].map((duringPoll) => ({ ...c, duringPoll }))))(
  "preserves newer $param after a lagging poll and collection, duringPoll=$duringPoll",
  async (c) => {
    const f = await fixture({ [c.param]: encode(c.cloud) });
    const older = await f.app.getDevice(sn);
    const fresh = await f.app.getDevice(sn);
    let release!: () => void;
    const waiting = new Promise<void>((resolve) => (release = resolve));
    const getDevices = f.internal.registry.getDevices.bind(f.internal.registry);
    vi.spyOn(f.internal.registry, "getDevices").mockImplementationOnce(async () => {
      await waiting;
      return getDevices();
    });
    if (c.duringPoll) f.cloud[c.param] = encode({ ...c.cloud, stale: true });
    else f.internal.applyRealtimeState(sn, { [c.param]: encode(c.report) });
    const poll = f.internal.pollOnce();
    if (c.duringPoll) f.internal.applyRealtimeState(sn, { [c.param]: encode(c.report) });
    release();
    await poll;
    expect(fresh.readRawParameter(c.param)).toBe(encode(c.report));
    const internal = f.app as unknown as {
      liveDevices: Map<string, WeakRef<Device>>;
      readContexts: WeakMap<Device, CommandContext>;
    };
    internal.liveDevices.set(sn, { deref: () => undefined } as WeakRef<Device>);
    expect(internal.readContexts.get(older)!.readParameter!(c.param)).toBe(encode(c.report));
    if (c.param === 1421) await older.light!()!.setLightSchedule!("[]");
    else if (c.param === 1422) await older.light!()!.setMotionLightBrightness!(80);
    else await older.camera!()!.setRecordingQuality!("720P");
    expect(config(f.sent.at(-1)!)).toEqual({ ...c.report, ...c.patch });
    privateLogs(f);
  },
);

it.each(cases)("retains snapshot-only $param config across a poll and collection", async (c) => {
  const f = await fixture();
  f.overlay[c.param] = encode(c.report);
  const older = await f.app.getDevice(sn);
  await f.app.getDevice(sn);
  await f.internal.pollOnce();
  const internal = f.app as unknown as { liveDevices: Map<string, WeakRef<Device>> };
  internal.liveDevices.set(sn, { deref: () => undefined } as WeakRef<Device>);
  if (c.param === 1421) await older.light!()!.setLightSchedule!("[]");
  else if (c.param === 1422) await older.light!()!.setMotionLightBrightness!(80);
  else await older.camera!()!.setRecordingQuality!("720P");
  expect(config(f.sent.at(-1)!)).toEqual({ ...c.report, ...c.patch });
  privateLogs(f);
});

it.each(cases)(
  "retains the joined $param config over invalid cloud values after the newest handle is collected",
  async (c) => {
    const f = await fixture({ [c.param]: c.scalar[0]! });
    f.overlay[c.param] = encode(c.report);
    const older = await f.app.getDevice(sn);
    await f.app.getDevice(sn);
    const internal = f.app as unknown as { liveDevices: Map<string, WeakRef<Device>> };
    internal.liveDevices.set(sn, { deref: () => undefined } as WeakRef<Device>);
    f.cloud[c.param] = c.scalar[1]!;
    await f.internal.pollOnce();
    if (c.param === 1421) await older.light!()!.setLightSchedule!("[]");
    else if (c.param === 1422) await older.light!()!.setMotionLightBrightness!(80);
    else await older.camera!()!.setRecordingQuality!("720P");
    expect(config(f.sent.at(-1)!)).toEqual({ ...c.report, ...c.patch });
    privateLogs(f);
  },
);

it.each(cases)(
  "updates the authoritative $param snapshot when the newest handle is collected before a poll",
  async (c) => {
    const f = await fixture({ [c.param]: encode(c.report) });
    const older = await f.app.getDevice(sn);
    await f.app.getDevice(sn);
    const internal = f.app as unknown as { liveDevices: Map<string, WeakRef<Device>> };
    internal.liveDevices.set(sn, { deref: () => undefined } as WeakRef<Device>);
    f.cloud[c.param] = encode(c.cloud);
    await f.internal.pollOnce();
    if (c.param === 1421) await older.light!()!.setLightSchedule!("[]");
    else if (c.param === 1422) await older.light!()!.setMotionLightBrightness!(80);
    else await older.camera!()!.setRecordingQuality!("720P");
    expect(config(f.sent.at(-1)!)).toEqual({ ...c.cloud, ...c.patch });
    privateLogs(f);
  },
);

it.each(
  cases.flatMap((c) =>
    [false, true].flatMap((held) => ["cloud", "realtime"].map((source) => ({ ...c, held, source }))),
  ),
)("uses a newly joined $source $param when held=$held has no raw value", async (c) => {
  const f = await fixture();
  const device = c.held ? await f.app.getDevice(sn) : undefined;
  if (device) expect(device.readRawParameter(c.param)).toBeUndefined();
  f.overlay[c.param] = encode(c.source === "cloud" ? c.report : c.cloud);
  if (c.source === "realtime") f.internal.registry.applyRealtimeParams(sn, { [c.param]: encode(c.report, 2) });
  await f.app.setProperty(sn, c.property, c.value);
  expect(config(f.sent[0]!)).toEqual({ ...c.report, ...c.patch });
  privateLogs(f);
});

it.each(cases.flatMap((c) => [false, true].flatMap((held) => [0, 1, 2].map((wrappers) => ({ ...c, held, wrappers })))))(
  "retains valid realtime $param over invalid cloud diffs with held=$held, wrappers=$wrappers",
  async (c) => {
    const f = await fixture({ [c.param]: c.scalar[0]! });
    const device = c.held ? await f.app.getDevice(sn) : undefined;
    const report = encode(c.report, c.wrappers);
    f.internal.applyRealtimeState(sn, { [c.param]: report });
    for (const invalid of [c.scalar[1]!, encode(c.invalid, c.wrappers)]) {
      f.cloud[c.param] = invalid;
      f.cloud[1400] = f.cloud[1400] === "1" ? "0" : "1";
      await f.internal.pollOnce();
      expect(f.internal.registry.knownParam(sn, c.param)).toBe(report);
      expect((await f.internal.registry.record(sn)).dpParams?.[c.param]).toBe(report);
      if (device) expect(device.readRawParameter(c.param)).toBe(report);
      expect(f.internal.registry.knownParam(sn, 1400)).toBe(f.cloud[1400]);
      if (device) expect(device.readRawParameter(1400)).toBe(f.cloud[1400]);
      await f.app.setProperty(sn, c.property, c.value);
      expect(config(f.sent.at(-1)!)).toEqual({ ...c.report, ...c.patch });
    }
    const valid = encode(c.cloud, c.wrappers);
    f.cloud[c.param] = valid;
    await f.internal.pollOnce();
    expect((await f.internal.registry.record(sn)).dpParams?.[c.param]).toBeUndefined();
    expect(f.internal.registry.knownParam(sn, c.param)).toBe(valid);
    if (device) expect(device.readRawParameter(c.param)).toBe(valid);
    await f.app.setProperty(sn, c.property, c.value);
    expect(config(f.sent.at(-1)!)).toEqual({ ...c.cloud, ...c.patch });
    privateLogs(f);
  },
);

it.each(cases.flatMap((c) => [false, true].map((held) => ({ ...c, held }))))(
  "keeps the revision gate for valid cloud $param configs with held=$held",
  async (c) => {
    const f = await fixture({ [c.param]: encode(c.cloud) });
    const device = c.held ? await f.app.getDevice(sn) : undefined;
    f.cloud[c.param] = encode(c.report);
    let release!: () => void;
    const waiting = new Promise<void>((resolve) => (release = resolve));
    const getDevices = f.internal.registry.getDevices.bind(f.internal.registry);
    vi.spyOn(f.internal.registry, "getDevices").mockImplementationOnce(async () => {
      await waiting;
      return getDevices();
    });
    const poll = f.internal.pollOnce();
    const fresh = encode(c.cloud, 2);
    f.internal.applyRealtimeState(sn, { [c.param]: fresh });
    release();
    await poll;
    if (device) expect(device.readRawParameter(c.param)).toBe(fresh);
    expect((await f.internal.registry.record(sn)).dpParams?.[c.param]).toBe(fresh);
    await f.app.setProperty(sn, c.property, c.value);
    expect(config(f.sent.at(-1)!)).toEqual({ ...c.cloud, ...c.patch });
    privateLogs(f);
  },
);

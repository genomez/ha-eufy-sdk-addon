import { afterEach, describe, expect, it, vi } from "vitest";
import type { Command, CommandReceipt } from "../../core/contracts.js";
import type { EufyDevice } from "../../core/types.js";
import { Device } from "../../model/device.js";
import { EufyMega } from "../../client/eufy-mega.js";
import type { DeviceRecord, DeviceRegistry } from "../../client/device-registry.js";

const motion = { enable: 1, time: 30, brightness: 50, mode: 1, schedule: [], retained: true };
const schedule = { schedule: [{ start: "18:00", end: "20:00" }], retained: true };
const capture = { cur_mode: 1, mode_0: { quality: 3 }, mode_1: { quality: 2 } };
const params: Record<number, string> = {
  1045: "1",
  1400: "1",
  1421: JSON.stringify(schedule),
  1422: JSON.stringify(motion),
  2731: Buffer.from(JSON.stringify(capture)).toString("base64"),
};
type Internal = {
  registry: DeviceRegistry;
  commandSinkFor(sn: string, invocation?: { receipt?: CommandReceipt }): { dispatch(command: Command): Promise<void> };
  applyAndAnnounce(device: Device, params: Record<number, string>, mode?: string): void;
  applyPolledParams(changes: unknown[]): void;
  applyRealtimeState(sn: string, params: Record<number, string>): void;
};
function fixture(opts: { autoRealtime?: boolean } = {}) {
  const app = new EufyMega({
    email: "fixture@example.com",
    password: "synthetic",
    autoRealtime: opts.autoRealtime ?? false,
  });
  const station = { sn: "fx-station", stationSn: "fx-station", model: "T9000", raw: {} } as EufyDevice;
  const mk = (sn: string, ch: number) =>
    ({
      sn,
      stationSn: station.sn,
      model: "T8425",
      category: "eufy_security",
      deviceClass: "camera",
      api: "mega",
      realtime: "p2p",
      params: { ...params },
      raw: { device_type: 47, device_channel: ch },
    }) as unknown as EufyDevice;
  const cams = [mk("fx-cam-a", 2), mk("fx-cam-b", 3)];
  const records: Record<string, DeviceRecord> = Object.fromEntries(
    cams.map((c) => [
      c.sn,
      {
        model: "T8425",
        deviceType: 47,
        parentSn: station.sn,
        params: { ...params },
        paramUpdatedAt: {},
        dpParams: {},
      } as DeviceRecord,
    ]),
  );
  const internal = app as unknown as Internal;
  vi.spyOn(internal.registry, "record").mockImplementation(async (sn: string) => records[sn]!);
  vi.spyOn(internal.registry, "list").mockReturnValue([...cams, station]);
  vi.spyOn(internal.registry, "require").mockImplementation(((sn: string) => cams.find((c) => c.sn === sn)!) as never);
  const sent: { sn: string; c: Command }[] = [];
  vi.spyOn(internal, "commandSinkFor").mockImplementation((sn: string) => ({
    dispatch: async (command) => void sent.push({ sn, c: command }),
  }));
  vi.spyOn(app.api, "post").mockRejectedValue(new Error("Unexpected network request"));
  return { app, cams, sent, records, internal };
}
afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
});
const payload = (f: ReturnType<typeof fixture>, index = -1) => {
  const command = f.sent.at(index)!.c;
  if (command.kind !== "set-payload") throw new Error("Expected composite payload");
  return command.payload;
};
async function ready() {
  for (let i = 0; i < 100; i++) await Promise.resolve();
}

it.each(["generic", "generic-held", "fluent-refresh", "fresh-handle", "getter-refresh"])(
  "preserves realtime-confirmed brightness across stale cloud reads via %s",
  async (route) => {
    const f = fixture({ autoRealtime: route === "getter-refresh" });
    (f.app as unknown as { awaitFirstRealtimeState: () => Promise<void> }).awaitFirstRealtimeState = async () => {};
    const d = route === "generic" ? undefined : await f.app.getDevice("fx-cam-a");
    await f.app.setProperty("fx-cam-a", "motionLightBrightness", 70);
    f.internal.applyRealtimeState("fx-cam-a", { 1422: JSON.stringify({ ...motion, brightness: 70 }) });
    if (route === "fluent-refresh") f.internal.applyAndAnnounce(d!, { ...f.records["fx-cam-a"]!.params });
    if (route === "getter-refresh") {
      const clock = vi.spyOn(Date, "now").mockReturnValue(Date.now() + 60_000);
      d!.getProperties();
      await ready();
      clock.mockRestore();
    }
    if (route === "fresh-handle") await (await f.app.getDevice("fx-cam-a")).light!()!.setMotionLightDuration!(45);
    else if (route === "fluent-refresh" || route === "getter-refresh") await d!.light!()!.setMotionLightDuration!(45);
    else await f.app.setProperty("fx-cam-a", "motionLightDuration", 45);
    expect(payload(f)).toMatchObject({ brightness: 70, time: 45 });
  },
);

it.each([80, 50])("preserves repeated same-field ACK %s after a poll of the first value", async (brightness) => {
  const f = fixture();
  const d = await f.app.getDevice("fx-cam-a");
  await d.light!()!.setMotionLightBrightness!(70);
  await d.light!()!.setMotionLightBrightness!(brightness);
  f.internal.applyPolledParams([
    { deviceSn: "fx-cam-a", paramType: 1422, from: params[1422], to: JSON.stringify({ ...motion, brightness: 70 }) },
  ]);
  await d.light!()!.setMotionLightDuration!(45);
  expect(payload(f)).toMatchObject({ brightness, time: 45 });
});

it.each([false, true])("preserves an ACK across the first fresh getDevice, fluent=%s", async (fluent) => {
  const f = fixture();
  await f.app.setProperty("fx-cam-a", "motionLightBrightness", 70);
  const d = await f.app.getDevice("fx-cam-a");
  if (fluent) await d.light!()!.setMotionLightDuration!(45);
  else await f.app.setProperty("fx-cam-a", "motionLightDuration", 45);
  expect(payload(f)).toMatchObject({ brightness: 70, time: 45 });
});

it.each([5000, 20000])("preserves an ACK across a stale held-device getProperties refresh at %s ms", async (age) => {
  const f = fixture({ autoRealtime: true });
  (f.app as unknown as { awaitFirstRealtimeState: () => Promise<void> }).awaitFirstRealtimeState = async () => {};
  const d = await f.app.getDevice("fx-cam-a");
  await f.app.setProperty("fx-cam-a", "motionLightBrightness", 70);
  const now = Date.now();
  vi.spyOn(Date, "now").mockReturnValue(now + age);
  d.getProperties();
  await ready();
  await f.app.setProperty("fx-cam-a", "motionLightDuration", 45);
  expect(payload(f)).toMatchObject({ brightness: 70, time: 45 });
  expect(d.light!()!.motionLightBrightness).toBe(50);
  expect(f.internal.registry.record).toHaveBeenCalledTimes(age === 20000 ? 4 : 3);
});

it("a lagging poll confirms only write one and preserves write two for write three", async () => {
  const f = fixture();
  const d = await f.app.getDevice("fx-cam-a");
  await d.light!()!.setMotionLightBrightness!(70);
  await d.light!()!.setMotionLightDuration!(45);
  f.internal.applyPolledParams([
    { deviceSn: "fx-cam-a", paramType: 1422, from: params[1422], to: JSON.stringify({ ...motion, brightness: 70 }) },
  ]);
  await d.light!()!.setMotionLightMode!(2);
  expect(payload(f)).toMatchObject({ brightness: 70, time: 45, mode: 2 });
});

it.each([50, 80])(
  "a mid-flight report with brightness %s preserves stale baselines or yields to external edits",
  async (brightness) => {
    const f = fixture();
    const d = await f.app.getDevice("fx-cam-a");
    let first = true;
    const sink = {
      dispatch: async (command: Command) => {
        f.sent.push({ sn: "fx-cam-a", c: command });
        if (first) {
          first = false;
          f.internal.applyAndAnnounce(d, { 1422: JSON.stringify({ ...motion, brightness }) });
        }
      },
    };
    const ctx = (d as unknown as { binding: { ctx: import("../../model/capabilities/types.js").CommandContext } })
      .binding.ctx;
    d.bindActions(ctx, sink);
    await d.light!()!.setMotionLightBrightness!(70);
    await d.light!()!.setMotionLightDuration!(45);
    expect(payload(f)).toMatchObject({ brightness: brightness === 50 ? 70 : 80, time: 45 });
  },
);

it("a per-command cloud read preserves an app duration edit without an observe event", async () => {
  const f = fixture();
  await f.app.setProperty("fx-cam-a", "motionLightDuration", 45);
  f.records["fx-cam-a"]!.params = { ...params, 1422: JSON.stringify({ ...motion, time: 60 }) };
  await f.app.setProperty("fx-cam-a", "motionLightBrightness", 70);
  expect(payload(f)).toMatchObject({ brightness: 70, time: 60 });
});

it("ACK overlays expire even if reports never catch up", async () => {
  const f = fixture();
  const d = await f.app.getDevice("fx-cam-a");
  await d.light!()!.setMotionLightBrightness!(70);
  vi.spyOn(Date, "now").mockReturnValue(Date.now() + 120000);
  await d.light!()!.setMotionLightDuration!(45);
  expect(payload(f)).toMatchObject({ brightness: 50, time: 45 });
});

it("isolates overlays by device and parameter without manufacturing getter state", async () => {
  const f = fixture();
  const a = await f.app.getDevice("fx-cam-a");
  const b = await f.app.getDevice("fx-cam-b");
  await a.light!()!.setMotionLightBrightness!(70);
  await b.light!()!.setMotionLightDuration!(45);
  expect(payload(f)).toMatchObject({ brightness: 50, time: 45 });
  await a.camera!()!.setRecordingQuality!(2);
  await a.light!()!.setMotionLightMode!(2);
  expect(payload(f)).toMatchObject({ brightness: 70, time: 30, mode: 2 });
  expect(a.light!()!.motionLightBrightness).toBe(50);
});

it("initializes the authenticated scope before a generic write and resets on account changes", async () => {
  const f = fixture();
  const auth = vi.spyOn(f.app.api, "auth", "get").mockReturnValue({ userId: "fixture-owner", authToken: "synthetic" });
  await f.app.setProperty("fx-cam-a", "motionLightBrightness", 70);
  await f.app.getDevice("fx-cam-a");
  await f.app.setProperty("fx-cam-a", "motionLightDuration", 45);
  expect(payload(f)).toMatchObject({ brightness: 70, time: 45 });
  auth.mockReturnValue({ userId: "fixture-replacement-owner", authToken: "synthetic" });
  await f.app.setProperty("fx-cam-a", "motionLightMode", 2);
  expect(payload(f)).toMatchObject({ brightness: 50, time: 30, mode: 2 });
});

/** Synthetic full reports, including location-shaped fields and unrecognized extensions. */
const reportedMotion = {
  enable: 1,
  time: 180,
  brightness: 100,
  mode: 1,
  schedule: [{ start: "18:00", end: "23:00", weekdays: [1, 3] }],
  sunset2rise: 0,
  latitude: "0.000000",
  longtitude: "0.000000",
  extension: { retained: [true, 7] },
};
const reportedCapture = {
  cur_mode: 0,
  mode_0: { quality: 2, audio: 1 },
  mode_1: { quality: 3, audio: 0 },
  extension: { retained: true },
};

function encodeReport(value: unknown, wrappers: number): string {
  let raw = JSON.stringify(value);
  for (let i = 0; i < wrappers; i++) raw = Buffer.from(raw).toString("base64");
  return raw;
}

describe("facade composite writes use getter reports", () => {
  it.each([
    { property: "recordingQuality", value: "720P" },
    { property: "motionLightBrightness", value: 80 },
    { property: "lightSchedule", value: "[]" },
  ])("builds $property from realtime-only reports after advertising its write", async ({ property, value }) => {
    const f = fixture();
    const sn = "fx-cam-a";
    f.records[sn]!.params = { 1400: "1" };
    f.records[sn]!.dpParams = {
      2731: encodeReport(reportedCapture, 0),
      1422: encodeReport(reportedMotion, 0),
      1421: encodeReport(reportedMotion, 0),
    };
    const device = await f.app.getDevice(sn);
    expect(
      device
        .describe()
        .details.flatMap((detail) => detail.reads)
        .find((read) => read.property === property),
    ).toMatchObject({ writable: true });
    await f.app.setProperty(sn, property, value);
    expect(f.sent).toHaveLength(1);
    expect(f.app.getPropertyPreparationDiagnostics().recent[0]?.phase).toBe("dispatch_preparation");
  });

  it.each(
    [0, 1, 2].flatMap((wrappers) =>
      [false, true].flatMap((held) => ["missing", "malformed", "stale"].map((cloud) => ({ wrappers, held, cloud }))),
    ),
  )("preserves $wrappers wrappers, held=$held, cloud=$cloud", async ({ wrappers, held, cloud }) => {
    const f = fixture();
    const sn = "fx-cam-a";
    const record = f.records[sn]!;
    record.params =
      cloud === "missing"
        ? { 1045: "1", 1400: "1" }
        : cloud === "malformed"
          ? { ...params, 2731: "2", 1422: "100", 1421: "[]" }
          : { ...params };
    f.cams[0]!.params = record.params;
    record.dpParams = {
      2731: encodeReport(reportedCapture, wrappers),
      1422: encodeReport(reportedMotion, wrappers),
      1421: encodeReport(reportedMotion, wrappers),
    };
    f.internal.applyRealtimeState(sn, record.dpParams);
    const device = held ? await f.app.getDevice(sn) : undefined;
    if (device) {
      expect(device.camera!()!.recordingQuality).toBe(2);
      expect(device.light!()!.motionLightBrightness).toBe(100);
      expect(device.light!()!.motionLightDuration).toBe(180);
      expect(device.light!()!.motionLightMode).toBe(1);
      expect(device.light!()!.lightSchedule).toBe(JSON.stringify(reportedMotion.schedule));
      expect(
        device
          .describe()
          .details.flatMap((detail) => detail.reads)
          .find((read) => read.property === "recordingQuality"),
      ).toMatchObject({ writable: true });
    }
    await f.app.setProperty(sn, "recordingQuality", "720P");
    await f.app.setProperty(sn, "motionLightBrightness", 80);
    await f.app.setProperty(sn, "lightSchedule", "[]");
    expect(f.sent.map(({ c }) => c)).toEqual([
      {
        kind: "raw-text",
        cmd: 2731,
        channel: 2,
        text: encodeReport({ ...reportedCapture, mode_0: { ...reportedCapture.mode_0, quality: 1 } }, 1),
      },
      {
        kind: "set-payload",
        cmd: 1422,
        channel: 2,
        mValue3: 0,
        form: undefined,
        payload: { ...reportedMotion, brightness: 80 },
      },
      {
        kind: "set-payload",
        cmd: 1421,
        channel: 2,
        mValue3: 0,
        form: undefined,
        payload: { ...reportedMotion, schedule: [] },
      },
    ]);
    if (device) {
      expect(device.camera!()!.recordingQuality).toBe(2);
      expect(device.light!()!.motionLightBrightness).toBe(100);
      expect(device.light!()!.lightSchedule).toBe(JSON.stringify(reportedMotion.schedule));
    }
    expect(f.app.api.post).not.toHaveBeenCalled();
  });

  it("uses newer live reports over both halves of an older command record", async () => {
    const f = fixture();
    const sn = "fx-cam-a";
    const device = await f.app.getDevice(sn);
    f.records[sn]!.dpParams = { ...params };
    f.internal.applyRealtimeState(sn, {
      2731: encodeReport(reportedCapture, 2),
      1422: encodeReport(reportedMotion, 1),
      1421: encodeReport(reportedMotion, 0),
    });
    await f.app.setProperty(sn, "recordingQuality", "720P");
    await f.app.setProperty(sn, "motionLightBrightness", 80);
    await f.app.setProperty(sn, "lightSchedule", "[]");
    expect(f.sent[0]!.c).toMatchObject({
      text: encodeReport({ ...reportedCapture, mode_0: { ...reportedCapture.mode_0, quality: 1 } }, 1),
    });
    expect(payload(f, 1)).toEqual({ ...reportedMotion, brightness: 80 });
    expect(payload(f, 2)).toEqual({ ...reportedMotion, schedule: [] });
    expect(device.light!()!.motionLightBrightness).toBe(100);
  });

  it("reads a newer report when a queued facade write dispatches, retaining ACKed fields", async () => {
    const f = fixture();
    const sn = "fx-cam-a";
    const device = await f.app.getDevice(sn);
    let release!: () => void;
    vi.mocked(f.internal.commandSinkFor).mockImplementation(() => ({
      dispatch: async (c) => {
        f.sent.push({ sn, c });
        if (f.sent.length === 1) await new Promise<void>((resolve) => (release = resolve));
      },
    }));
    const first = f.app.setProperty(sn, "motionLightBrightness", 80);
    await ready();
    expect(f.sent).toHaveLength(1);
    const second = f.app.setProperty(sn, "motionLightDuration", 45);
    await ready();
    const newer = { ...reportedMotion, brightness: motion.brightness };
    f.internal.applyRealtimeState(sn, { 1422: encodeReport(newer, 2) });
    release();
    await Promise.all([first, second]);
    expect(payload(f)).toEqual({ ...newer, brightness: 80, time: 45 });
    expect(device.light!()!.motionLightBrightness).toBe(motion.brightness);
  });

  it("uses a cloud transition accepted by the existing poll ordering", async () => {
    const f = fixture();
    const sn = "fx-cam-a";
    const device = await f.app.getDevice(sn);
    f.internal.applyRealtimeState(sn, { 1422: encodeReport(reportedMotion, 0) });
    const cloud = { ...reportedMotion, enable: 0, mode: 2 };
    f.internal.applyPolledParams([
      { deviceSn: sn, paramType: 1422, from: encodeReport(reportedMotion, 0), to: encodeReport(cloud, 0) },
    ]);
    await f.app.setProperty(sn, "motionLightBrightness", 80);
    expect(payload(f)).toEqual({ ...cloud, brightness: 80 });
    expect(device.light!()!.motionLightEnabled).toBe(false);
  });

  it("refuses an invalid live report instead of resurrecting valid cloud data", async () => {
    const f = fixture();
    const device = await f.app.getDevice("fx-cam-a");
    f.internal.applyRealtimeState("fx-cam-a", { 2731: "bad", 1422: "bad", 1421: "bad" });
    expect(device.camera!()!.setRecordingQuality).toBeUndefined();
    await expect(f.app.setProperty("fx-cam-a", "recordingQuality", "720P")).rejects.toThrow();
    await expect(f.app.setProperty("fx-cam-a", "motionLightBrightness", 80)).rejects.toThrow(/valid reported/);
    await expect(f.app.setProperty("fx-cam-a", "lightSchedule", "[]")).rejects.toThrow(/valid reported/);
    expect(f.sent).toEqual([]);
  });
});

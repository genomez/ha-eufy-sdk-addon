import { EventEmitter } from "node:events";
import { afterEach, describe, expect, it, vi } from "vitest";
import { EufyMega } from "../eufy-mega.js";
import type { DeviceRegistry } from "../device-registry.js";
import type { EufyDevice } from "../../core/types.js";
import { noopLogger } from "../../core/logger.js";
import { RtcCommandRouter } from "../../transport/rtc/command-router.js";
import type { RtcSession, RtcSessionOptions } from "../../transport/rtc/session.js";
import { buildPortalHeader, parsePortalHeader, PORTAL_HEADER_LENGTH } from "../../transport/rtc/portal-packet.js";

const HUB = "synthetic-station-private";
const CAMERA = "synthetic-camera-private";
const ACCOUNT = "synthetic-account-private";
const TOKEN = "synthetic-token-private";

function fixture() {
  const logger = { ...noopLogger, debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() };
  const client = new EufyMega({
    email: "test@example.com",
    password: "synthetic",
    autoRealtime: false,
    pollMs: 0,
    storedSnapshotCache: false,
    logger,
  });
  const internals = client as unknown as {
    registry: Pick<DeviceRegistry, "applyRealtimeParams"> & { devices: EufyDevice[] };
    rtc: RtcCommandRouter;
    onRtcFrame: NonNullable<ConstructorParameters<typeof RtcCommandRouter>[0]["onFrame"]>;
  };
  const devices = [
    { sn: HUB, model: "T9000", raw: { member: { admin_user_id: ACCOUNT } } },
    { sn: CAMERA, model: "T8170", stationSn: HUB, raw: { device_channel: 3 } },
  ] as EufyDevice[];
  internals.registry.devices = devices;
  const packets: Buffer[] = [];
  const session = Object.assign(new EventEmitter(), {
    isConnected: false,
    connect: vi.fn(async () => {
      session.isConnected = true;
      session.emit("connected");
    }),
    sendCommand: vi.fn((packet: Buffer) => {
      packets.push(packet);
      return true;
    }),
    close() {
      session.isConnected = false;
      session.emit("close");
    },
  });
  const createSession = vi.fn((_opts: RtcSessionOptions) => session as unknown as RtcSession);
  internals.rtc = new RtcCommandRouter({
    identity: () => ({ userId: ACCOUNT, authToken: TOKEN }),
    shard: () => "fixture",
    accountName: () => "fixture",
    findDevice: (sn) => devices.find((device) => device.sn === sn),
    createSession,
    onFrame: (...args) => internals.onRtcFrame(...args),
    logger,
  });
  const emit = vi.spyOn(client, "emit");
  const apply = vi.spyOn(internals.registry, "applyRealtimeParams");
  const preempt = vi.spyOn(internals.rtc, "preemptRecordingReads");
  function notify(payload: unknown, channel = 3, cmd = 6482) {
    const request = parsePortalHeader(packets.at(-1)!)!;
    const body = Buffer.from(JSON.stringify({ cmd, payload }));
    session.emit(
      "commandData",
      Buffer.concat([buildPortalHeader(1351, body.length, channel, request.segment, 0), body]),
      3,
    );
  }
  return { client, internals, devices, logger, session, createSession, packets, notify, emit, apply, preempt };
}

async function ready() {
  for (let i = 0; i < 50; i++) await Promise.resolve();
}

afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe("on-demand diagnostic query", () => {
  it.each([6237, 0, -1, 6483, NaN, Infinity, "6482", null, undefined])("refuses command %s", async (cmd) => {
    const f = fixture();
    expect(await f.client.diagnosticQuery(CAMERA, cmd as number)).toEqual({
      ok: false,
      error: "Diagnostic command is not allowed",
    });
    expect(f.createSession).not.toHaveBeenCalled();
  });

  it.each(["other-station", "standalone", "station-target", "unknown", "missing-station"])(
    "refuses unsupported topology: %s",
    async (issue) => {
      const f = fixture();
      if (issue === "other-station") f.devices[0]!.model = "T8030";
      if (issue === "standalone") f.devices[1]!.stationSn = CAMERA;
      if (issue === "missing-station") f.devices.shift();
      const sn = issue === "station-target" ? HUB : issue === "unknown" ? "unknown" : CAMERA;
      expect((await f.client.diagnosticQuery(sn, 6482)).ok).toBe(false);
      expect(f.createSession).not.toHaveBeenCalled();
    },
  );

  it.each([undefined, null, "3", -1, 255, 256, 1.5, NaN])("refuses unresolved channel %s", async (channel) => {
    const f = fixture();
    f.devices[1]!.raw = { device_channel: channel };
    expect(await f.client.diagnosticQuery(CAMERA, 6482)).toEqual({
      ok: false,
      error: "Diagnostic query requires a resolved camera channel",
    });
    expect(f.createSession).not.toHaveBeenCalled();
  });

  it("refuses duplicate channel ownership", async () => {
    const f = fixture();
    f.devices.push({ ...f.devices[1]!, sn: "synthetic-second-camera" });
    expect((await f.client.diagnosticQuery(CAMERA, 6482)).ok).toBe(false);
    expect(f.createSession).not.toHaveBeenCalled();
  });

  it.each([0, 3])(
    "sends the empty query on reported channel %s and returns the uninterpreted reply",
    async (channel) => {
      const f = fixture();
      f.devices[1]!.raw = { device_channel: channel };
      const before = JSON.stringify(f.devices);
      const raw = { unknown: [null, false, 7, { value: "opaque" }], params: [{ param_type: 6482, param_value: 1 }] };
      try {
        const result = f.client.diagnosticQuery(CAMERA, 6482);
        await ready();
        expect(f.packets).toHaveLength(1);
        expect(parsePortalHeader(f.packets[0]!)).toMatchObject({ commandId: 1350, channel });
        expect(JSON.parse(f.packets[0]!.subarray(PORTAL_HEADER_LENGTH).toString())).toEqual({
          account_id: ACCOUNT,
          cmd: 6482,
          mValue3: 0,
          payload: {},
        });
        // Opening the shared station session keeps its normal call retries for later commands.
        expect(f.createSession.mock.calls[0]?.[0]?.maxCallRetries).not.toBe(0);
        f.notify(raw, channel);
        expect(await result).toEqual({ ok: true, reply: { data: { cmd: 6482, payload: raw } } });
        expect(f.emit).not.toHaveBeenCalled();
        expect(f.apply).not.toHaveBeenCalled();
        expect(f.preempt).not.toHaveBeenCalled();
        expect(JSON.stringify(f.devices)).toBe(before);
        const logs = JSON.stringify([
          f.logger.debug.mock.calls,
          f.logger.info.mock.calls,
          f.logger.warn.mock.calls,
          f.logger.error.mock.calls,
        ]);
        for (const secret of [HUB, CAMERA, ACCOUNT, TOKEN]) expect(logs).not.toContain(secret);
      } finally {
        f.internals.rtc.close();
      }
    },
  );

  it("returns the exact payload object supplied by the router", async () => {
    const f = fixture();
    const payload = { opaque: { flags: [1, 2] } };
    vi.spyOn(f.internals.rtc, "payloadQuery").mockResolvedValue(payload);
    expect((await f.client.diagnosticQuery(CAMERA, 6482)).reply).toBe(payload);
  });

  it.each([[1], [[0, 1]], ["on"], [null]])(
    "returns a non-object reply payload %j instead of timing out",
    async (payload) => {
      const f = fixture();
      try {
        const result = f.client.diagnosticQuery(CAMERA, 6482);
        await ready();
        f.notify(payload);
        expect(await result).toEqual({ ok: true, reply: { data: { cmd: 6482, payload } } });
      } finally {
        f.internals.rtc.close();
      }
    },
  );

  it("returns a reply carrying a nonzero code as data", async () => {
    const f = fixture();
    try {
      const result = f.client.diagnosticQuery(CAMERA, 6482);
      await ready();
      const request = parsePortalHeader(f.packets.at(-1)!)!;
      const body = Buffer.from(JSON.stringify({ cmd: 6482, code: -1 }));
      f.session.emit(
        "commandData",
        Buffer.concat([buildPortalHeader(1351, body.length, 3, request.segment, 0), body]),
        3,
      );
      expect(await result).toEqual({ ok: true, reply: { data: { cmd: 6482, code: -1 } } });
    } finally {
      f.internals.rtc.close();
    }
  });

  it("rejects a concurrent query to another camera on the same station", async () => {
    const f = fixture();
    f.devices.push({ ...f.devices[1]!, sn: "synthetic-second-camera", raw: { device_channel: 4 } });
    try {
      const first = f.client.diagnosticQuery(CAMERA, 6482);
      expect(await f.client.diagnosticQuery("synthetic-second-camera", 6482)).toEqual({
        ok: false,
        error: "A diagnostic query is already pending for this station",
      });
      await ready();
      expect(f.packets).toHaveLength(1);
      f.notify({ value: 7 });
      await first;
      const next = f.client.diagnosticQuery(CAMERA, 6482);
      await ready();
      f.notify({ value: 8 });
      expect(await next).toEqual({ ok: true, reply: { data: { cmd: 6482, payload: { value: 8 } } } });
    } finally {
      f.internals.rtc.close();
    }
  });

  it("times out after 15 seconds without retrying, and releases the outstanding-query guard", async () => {
    vi.useFakeTimers();
    const f = fixture();
    try {
      const result = f.client.diagnosticQuery(CAMERA, 6482);
      await ready();
      await vi.advanceTimersByTimeAsync(15_000);
      expect(await result).toEqual({ ok: false, error: "Diagnostic query timed out" });
      expect(f.packets).toHaveLength(1);
      expect(f.emit).not.toHaveBeenCalled();
      f.notify({ late: true });
      const next = f.client.diagnosticQuery(CAMERA, 6482);
      await ready();
      f.notify({ fresh: true });
      expect(await next).toEqual({ ok: true, reply: { data: { cmd: 6482, payload: { fresh: true } } } });
      expect(f.packets).toHaveLength(2);
    } finally {
      f.internals.rtc.close();
    }
  });

  it("fails a connection attempt without relay fallback or leaking its error", async () => {
    const f = fixture();
    f.session.connect.mockRejectedValue(new Error(`${HUB} ${ACCOUNT} ${TOKEN}`));
    expect(await f.client.diagnosticQuery(CAMERA, 6482)).toEqual({ ok: false, error: "Diagnostic query failed" });
    expect(f.createSession).toHaveBeenCalledTimes(1);
    expect(f.packets).toHaveLength(0);
    f.internals.rtc.close();
  });
});

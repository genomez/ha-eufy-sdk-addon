import { EufyMega } from "../eufy-mega.js";

afterEach(() => vi.restoreAllMocks());

it("refreshes battery readings from device-list params without relying on the per-device overlay", async () => {
  const eufy = new EufyMega({ email: "synthetic", password: "synthetic", autoRealtime: false });
  const internal = eufy as any;
  let params: Record<number, string> = { 1101: "100", 1313: "86400", 1314: "97" };
  vi.spyOn(internal.mega, "post").mockImplementation(async (...args: any[]) =>
    args[1].endsWith("get_house_list")
      ? { house_infos: [] }
      : {
          devices: [
            {
              device_sn: "synthetic-station",
              device_model: "T9000",
              device_type: 27,
              category: "eufy_security",
              params: Object.entries(params).map(([id, value]) => ({ param_type: Number(id), param_value: value })),
            },
          ],
        },
  );
  const overlay = vi.spyOn(internal.mega, "getDeviceParamList").mockResolvedValue({ params: [] });
  vi.spyOn(internal.mega, "rtcIdentity").mockReturnValue({ authToken: "synthetic", userId: "synthetic" });
  const events: unknown[] = [];
  eufy.on("propertyChanged", ({ evidence: _evidence, ...event }) => events.push(event));
  try {
    await eufy.getDevices();
    await internal.registry.pollChanges();
    const held = await eufy.getDevice("synthetic-station");
    expect(held.battery?.()?.health).toBe(97);
    expect(held.battery?.()?.lifeEstimate).toBe(86400);
    params = { 1101: "100", 1313: "43200", 1314: "96" };
    await internal.pollOnce();
    expect(held.battery?.()?.health).toBe(96);
    expect(held.battery?.()?.lifeEstimate).toBe(43200);
    expect(events).toEqual(
      expect.arrayContaining([
        { deviceSn: "synthetic-station", property: "batteryHealth", value: 96 },
        { deviceSn: "synthetic-station", property: "batteryLifeEstimate", value: 43200 },
      ]),
    );
    params = { 1101: "100", 1313: "0", 1314: "0" };
    await eufy.getDevices();
    const latest = await eufy.getDevice("synthetic-station");
    expect(latest.battery?.()?.health).toBe(0);
    expect(latest.battery?.()?.lifeEstimate).toBe(0);
    params = { 1101: "100", 1198: "88" };
    await eufy.getDevices();
    const missing = await eufy.getDevice("synthetic-station");
    expect(missing.getPropertyValue("batteryHealth")).toBeUndefined();
    expect(missing.getPropertyValue("batteryLifeEstimate")).toBeUndefined();
    expect(overlay).toHaveBeenCalledTimes(3);
  } finally {
    internal.cameraHealthIngress.store.close();
  }
});

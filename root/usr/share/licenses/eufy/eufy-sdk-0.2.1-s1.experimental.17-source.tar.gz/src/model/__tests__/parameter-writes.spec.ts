import { afterEach, expect, it, vi } from "vitest";
import type { Command, CommandSink } from "../../core/contracts.js";
import { CompositeWriteSupersededError } from "../../core/contracts.js";
import { ParameterWrites, dispatchParameterCommand } from "../parameter-writes.js";
import { configObject } from "../capabilities/config-value.js";

function fixture() {
  const writes = new ParameterWrites();
  let report: Record<string, unknown> = {
    brightness: 50,
    time: 30,
    enable: 1,
    mode: 1,
    schedule: [],
    mode_0: { quality: 3, other: true },
  };
  const sent: Command[] = [];
  let release!: () => void;
  const sink: CommandSink = {
    dispatch: vi.fn(async (command) => {
      sent.push(command);
    }),
  };
  const send = (patch: Record<string, unknown>, param = 1422, acknowledged = () => true) => {
    const command = writes.command(
      param,
      () => report,
      (raw) => ({ kind: "set-payload", cmd: param, channel: 2, payload: { ...configObject(raw), ...patch } }),
      Object.keys(patch),
    );
    return dispatchParameterCommand(command, sink, acknowledged);
  };
  const block = () => {
    vi.mocked(sink.dispatch).mockImplementationOnce(async (command) => {
      sent.push(command);
      await new Promise<void>((resolve) => {
        release = resolve;
      });
    });
  };
  return {
    writes,
    sent,
    send,
    block,
    release: () => release(),
    sink,
    observeOnly: (patch: Record<string, unknown>) => writes.observe(1422, { ...report, ...patch }),
    observe: (patch: Record<string, unknown>) => {
      report = { ...report, ...patch };
      writes.observe(1422, report);
    },
  };
}
afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});

it("coalesces a slider burst behind one in-flight write to the latest field value", async () => {
  const f = fixture();
  f.block();
  const first = f.send({ brightness: 60 });
  const outcomes = Array.from({ length: 100 }, (_, i) => f.send({ brightness: i + 1 }).catch((e: unknown) => e));
  const duration = f.send({ time: 45 });
  expect(f.sent).toHaveLength(1);
  f.release();
  await first;
  const results = await Promise.all(outcomes);
  await duration;
  expect(results.filter((value) => value instanceof Error)).toHaveLength(99);
  for (const result of results.slice(0, -1)) {
    expect(result).toBeInstanceOf(CompositeWriteSupersededError);
    expect(result).toMatchObject({ status: "superseded_before_send", sendAttempted: false });
  }
  expect(f.sent).toHaveLength(3);
  expect(f.sent[1]).toMatchObject({ payload: { brightness: 100 } });
  expect(f.sent[2]).toMatchObject({ payload: { brightness: 100, time: 45 } });
});

it("removes only overlapping fields from an unsent multi-field intent", async () => {
  const f = fixture();
  f.block();
  const first = f.send({ brightness: 60 });
  const older = f.send({ brightness: 70, time: 45 });
  const latest = f.send({ brightness: 80 });
  f.release();
  await Promise.all([first, older, latest]);
  expect(f.sent[1]).toMatchObject({ payload: { brightness: 60, time: 45 } });
  expect(f.sent[2]).toMatchObject({ payload: { brightness: 80, time: 45 } });
});

it("bounds unsent depth and expires queued work without sending it", async () => {
  vi.useFakeTimers();
  const f = fixture();
  f.block();
  const first = f.send({ brightness: 60 });
  const queued = Array.from({ length: 32 }, (_, i) => f.send({ [`field${i}`]: i }).catch((e: unknown) => e));
  await expect(f.send({ overflow: true })).rejects.toThrow(/queue is full/);
  await f.send({ schedule: [] }, 1421);
  await vi.advanceTimersByTimeAsync(60000);
  for (const result of await Promise.all(queued))
    expect(result).toMatchObject({ message: "Composite write expired before send" });
  f.release();
  await first;
  expect(f.sent).toHaveLength(2);
});

it("a blocked parameter leaves other parameters usable and reset rejects its queued work", async () => {
  const f = fixture();
  f.block();
  const first = f.send({ brightness: 60 });
  const queued = f.send({ time: 45 }).catch((e: unknown) => e);
  await f.send({ schedule: [{ start: "20:00" }] }, 1421);
  f.writes.reset();
  expect(await queued).toMatchObject({ message: "Composite write owner changed" });
  f.release();
  await first;
  await f.send({ time: 50 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 50, time: 50 } });
});

it("retains confirmed fields across later stale reports while preserving other pending fields", async () => {
  const f = fixture();
  await f.send({ brightness: 70 });
  await f.send({ time: 45 });
  f.observe({ brightness: 70 });
  f.observe({ brightness: 50 });
  await f.send({ mode: 2 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 70, time: 45, mode: 2 } });
});

it("retains realtime confirmation when the command read still returns the original baseline", async () => {
  const f = fixture();
  await f.send({ brightness: 70 });
  f.observeOnly({ brightness: 70 });
  await f.send({ time: 45 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 70, time: 45 } });
});

it.each([80, 50])("retains the latest ACK %s across a lagging report of the first ACK", async (latest) => {
  const f = fixture();
  await f.send({ brightness: 70 });
  await f.send({ brightness: latest });
  f.observe({ brightness: 70 });
  await f.send({ time: 45 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: latest, time: 45 } });
});

it("a third value retires only its field and a later baseline cannot resurrect the patch", async () => {
  const f = fixture();
  await f.send({ brightness: 70, time: 45 });
  f.observe({ brightness: 90 });
  await f.send({ mode: 2 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 90, time: 45 } });
  f.observe({ brightness: 50 });
  await f.send({ enable: 0 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 50, time: 45 } });
});

it.each([119_000, 120_000, 121_000])("keeps ACKs only before the TTL boundary at %s ms", async (age) => {
  vi.useFakeTimers();
  const f = fixture();
  await f.send({ brightness: 70 });
  f.observeOnly({ brightness: 70 });
  vi.setSystemTime(Date.now() + age);
  await f.send({ time: 45 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: age < 120_000 ? 70 : 50, time: 45 } });
});

it("expires individual ACK values while keeping the latest ACK and original baseline", async () => {
  vi.useFakeTimers();
  const f = fixture();
  await f.send({ brightness: 70 });
  vi.setSystemTime(Date.now() + 60_000);
  await f.send({ brightness: 80 });
  vi.setSystemTime(Date.now() + 61_000);
  await f.send({ time: 45 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 80 } });
  f.observe({ brightness: 70 });
  await f.send({ mode: 2 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 70 } });
});

it("A to B followed by the app setting A keeps B until expiry because A is indistinguishable from lag", async () => {
  vi.useFakeTimers();
  const f = fixture();
  await f.send({ brightness: 70 });
  await f.send({ brightness: 80 });
  f.observe({ brightness: 70 });
  await f.send({ time: 45 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 80 } });
  vi.setSystemTime(Date.now() + 121_000);
  await f.send({ mode: 2 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 70 } });
});

it.each([50, 70, 90])("handles a mid-flight baseline, confirmation or external report of %s", async (brightness) => {
  const f = fixture();
  f.block();
  const first = f.send({ brightness: 70 });
  f.observe({ brightness });
  f.release();
  await first;
  await f.send({ time: 45 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: brightness === 90 ? 90 : 70 } });
});

it("failed and unacknowledged replacements preserve the previous ACK", async () => {
  const f = fixture();
  await f.send({ brightness: 70 });
  vi.mocked(f.sink.dispatch).mockRejectedValueOnce(new Error("Synthetic rejection"));
  await expect(f.send({ brightness: 80 })).rejects.toThrow("Synthetic rejection");
  await f.send({ brightness: 90 }, 1422, () => false);
  await f.send({ time: 45 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 70, time: 45 } });
});

it("reset releases a hung owner and its later completion cannot release the new owner's slot", async () => {
  const f = fixture();
  f.block();
  const old = f.send({ brightness: 70 });
  const releaseOld = f.release;
  f.writes.reset();
  let releaseNew!: () => void;
  vi.mocked(f.sink.dispatch).mockImplementationOnce(async (command) => {
    f.sent.push(command);
    await new Promise<void>((resolve) => {
      releaseNew = resolve;
    });
  });
  const current = f.send({ time: 45 });
  const queued = f.send({ mode: 2 });
  expect(f.sent).toHaveLength(2);
  releaseOld();
  await old;
  await Promise.resolve();
  expect(f.sent).toHaveLength(2);
  releaseNew();
  await Promise.all([current, queued]);
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 50, time: 45, mode: 2 } });
});

it("does not keep the process alive for the enqueue deadline", async () => {
  const timer = vi.spyOn(globalThis, "setTimeout");
  const f = fixture();
  f.block();
  const first = f.send({ brightness: 70 });
  const queued = f.send({ time: 45 });
  expect(timer.mock.results.at(-1)!.value.hasRef()).toBe(false);
  f.release();
  await Promise.all([first, queued]);
});

it("failed acknowledgements do not advance overlays", async () => {
  const f = fixture();
  await f.send({ brightness: 70 }, 1422, () => false);
  await f.send({ time: 45 });
  expect(f.sent.at(-1)).toMatchObject({ payload: { brightness: 50, time: 45 } });
});

it("nested quality and schedule arrays use independent atomic baselines", async () => {
  const writes = new ParameterWrites();
  let report = { mode_0: { quality: 3, other: true }, schedule: [{ start: "18:00" }] };
  const sent: Command[] = [];
  const sink = {
    dispatch: async (command: Command) => {
      sent.push(command);
    },
  };
  const send = (quality: number) =>
    dispatchParameterCommand(
      writes.command(
        2731,
        () => report,
        (raw) => {
          const cfg = configObject(raw)!;
          return {
            kind: "raw-text",
            cmd: 2731,
            channel: 2,
            text: Buffer.from(JSON.stringify({ ...cfg, mode_0: { ...(cfg.mode_0 as object), quality } })).toString(
              "base64",
            ),
          };
        },
        ["mode_0.quality"],
      ),
      sink,
    );
  await send(2);
  report = { mode_0: { quality: 3, other: false }, schedule: [{ start: "20:00" }] };
  await send(1);
  expect(
    configObject(
      sent.at(-1)!.kind === "raw-text" ? (sent.at(-1) as Extract<Command, { kind: "raw-text" }>).text : undefined,
    ),
  ).toEqual({ mode_0: { quality: 1, other: false }, schedule: [{ start: "20:00" }] });
});

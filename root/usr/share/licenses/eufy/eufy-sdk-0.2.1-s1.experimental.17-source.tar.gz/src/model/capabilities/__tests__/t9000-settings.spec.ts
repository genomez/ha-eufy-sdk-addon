import { describe, expect, it } from "vitest";
import { buildCommand, describeCapabilities } from "../index.js";
import { bind } from "./bind.js";
import type { CommandContext } from "../types.js";
import type { CameraActions } from "../camera.js";
import type { LightActions } from "../light.js";
import { Device } from "../../device.js";
import { memberWrite } from "../members.js";
import { BATTERY_MEMBERS } from "../battery.js";

const ctx: CommandContext = {
  codec: "camera",
  deviceType: 47,
  model: "T8425",
  stationModel: "T9000",
  channel: 2,
  homeBaseAttached: true,
  paramIds: new Set([1045, 2731, 1421, 1422, 1401, 1403]),
};
const encode = (value: unknown) => Buffer.from(JSON.stringify(value)).toString("base64");
const config = { cur_mode: 1, mode_0: { quality: 3, retained: true }, mode_1: { quality: 2 }, extra: [1, 2] };
const motion = {
  enable: 1,
  time: 30,
  brightness: 50,
  mode: 1,
  schedule: [],
  sunset2rise: 0,
  latitude: "private-latitude",
  longtitude: "private-longitude",
  unknown: { preserved: true },
};

describe("T9000 capture settings", () => {
  it.each([config, JSON.stringify(config), encode(config), Buffer.from(encode(config)).toString("base64")])(
    "merges only mode_0.quality in each supported report encoding",
    (raw) => {
      const command = buildCommand("recordingQuality", 2, { ...ctx, readParameter: () => raw });
      expect(command?.kind).toBe("raw-text");
      if (command?.kind !== "raw-text") throw new Error("Missing raw-text route");
      expect(command.cmd).toBe(2731);
      expect(JSON.parse(Buffer.from(command.text, "base64").toString())).toEqual({
        ...config,
        mode_0: { ...config.mode_0, quality: 2 },
      });
      expect(config.mode_0.quality).toBe(3);
    },
  );
  it.each([undefined, "bad", {}, [], { cur_mode: 0, mode_0: { quality: 2 } }, { ...config, mode_1: [] }])(
    "refuses a missing or malformed capture config",
    (raw) => {
      expect(buildCommand("recordingQuality", 2, { ...ctx, readParameter: () => raw })).toBeUndefined();
    },
  );
  it("publishes resolution labels while retaining the active-mode read", () => {
    const { acts } = bind<CameraActions>("camera", ctx, { read: () => ({ value: encode(config) }) });
    expect(acts.recordingQuality).toBe(2);
    const cap = describeCapabilities({ camera: acts }, ctx)[0]!;
    expect(cap.reads.find((r) => r.accessor === "recordingQuality")).toMatchObject({
      kind: "enum",
      values: [1, 2, 3],
      labels: { 1: "720P", 2: "1080P", 3: "3K" },
    });
  });
  it.each(["720P", "1080P", "3K", 1, 2, 3])("accepts tier %s", (value) => {
    expect(buildCommand("recordingQuality", value, { ...ctx, readParameter: () => config })?.kind).toBe("raw-text");
  });
  it.each(["T8416", "t8416", "T8416P00"])("uses verified 2K labels and raw-text writes on %s", (model) => {
    const context = { ...ctx, model, readParameter: () => config };
    const { acts } = bind<CameraActions>("camera", context, { read: () => ({ value: encode(config) }) });
    expect(
      describeCapabilities({ camera: acts }, context)[0]!.reads.find((r) => r.accessor === "recordingQuality")?.labels,
    ).toEqual({ 1: "720P", 2: "1080P", 3: "2K", 4: "4K" });
    const command = buildCommand("recordingQuality", "2K", context);
    expect(command?.kind).toBe("raw-text");
    if (command?.kind !== "raw-text") throw new Error("Missing raw-text route");
    expect(JSON.parse(Buffer.from(command.text, "base64").toString())).toEqual(config);
    for (const value of ["3K", "Auto", 0]) {
      expect(() => buildCommand("recordingQuality", value, context)).toThrow(/valid value/);
    }
  });
  it.each(["T8425", "T8426", "T8171"])("preserves other T9000 model labels on %s", (model) => {
    const context = { ...ctx, model, readParameter: () => config };
    const { acts } = bind<CameraActions>("camera", context, { read: () => ({ value: encode(config) }) });
    expect(
      describeCapabilities({ camera: acts }, context)[0]!.reads.find((r) => r.accessor === "recordingQuality")?.labels,
    ).toEqual({ 1: "720P", 2: "1080P", 3: "3K" });
    expect(() => buildCommand("recordingQuality", "2K", context)).toThrow(/valid value/);
    expect(() => buildCommand("recordingQuality", "Auto", context)).toThrow(/valid value/);
  });
  it.each([
    ["T8416", 4, "4K"],
    ["T8170", 0, "Auto"],
  ] as const)("reads and writes the verified extra tier on %s", async (model, tier, label) => {
    const reported = { ...config, cur_mode: 0, mode_0: { ...config.mode_0, quality: tier } };
    const context = { ...ctx, model, readParameter: () => encode(config) };
    const { acts, sent } = bind<CameraActions>("camera", context, { read: () => ({ value: encode(reported) }) });
    expect(acts.recordingQuality).toBe(tier);
    const read = describeCapabilities({ camera: acts }, context)[0]!.reads.find(
      (r) => r.accessor === "recordingQuality",
    )!;
    expect(read.values).toEqual(model === "T8416" ? [1, 2, 3, 4] : [0, 1, 2, 3]);
    expect(read.labels).toEqual(
      model === "T8416" ? { 1: "720P", 2: "1080P", 3: "2K", 4: "4K" } : { 0: "Auto", 1: "720P", 2: "1080P", 3: "3K" },
    );
    for (const value of [tier, String(tier), label]) {
      const command = buildCommand("recordingQuality", value, context);
      if (command?.kind !== "raw-text") throw new Error("Missing raw-text route");
      expect(JSON.parse(Buffer.from(command.text, "base64").toString())).toEqual({
        ...config,
        mode_0: { ...config.mode_0, quality: tier },
      });
    }
    for (const value of [tier, label]) {
      await acts.setRecordingQuality!(value);
      expect(sent.at(-1)).toEqual(buildCommand("recordingQuality", value, context));
    }
    const inactive = { ...reported, cur_mode: 1 };
    const active = bind<CameraActions>("camera", context, { read: () => ({ value: encode(inactive) }) }).acts;
    expect(active.recordingQuality).toBe(2);
    const unknown = { ...reported, mode_0: { quality: 99 } };
    expect(
      bind<CameraActions>("camera", context, { read: () => ({ value: encode(unknown) }) }).acts.recordingQuality,
    ).toBeUndefined();
  });
  it.each([
    ["T8416", 3],
    ["T8170", 3],
    ["T8425", 3],
  ] as const)("keeps accepting the base rank name Max on %s", (model, tier) => {
    const context = { ...ctx, model, readParameter: () => encode(config) };
    const command = buildCommand("recordingQuality", "Max", context);
    if (command?.kind !== "raw-text") throw new Error("Missing raw-text route");
    expect(JSON.parse(Buffer.from(command.text, "base64").toString()).mode_0.quality).toBe(tier);
  });
  it("leaves dynamic members without decodedValues on their existing write checks", () => {
    // workingMode publishes a per-model set but never narrowed writes; any index >= 0 is still sent.
    for (const model of ["T8170", "T8114"]) {
      expect(() => memberWrite("workingMode", BATTERY_MEMBERS.workingMode, 3, { ...ctx, model })).not.toThrow();
    }
  });
  it("publishes and writes the T8416 night-vision modes seen in the app", () => {
    const context = { ...ctx, model: "T8416", channelIsUnambiguous: true, paramIds: new Set([...ctx.paramIds!, 1277]) };
    const { acts } = bind<CameraActions>("camera", context, { read: () => ({ value: 3 }) });
    const read = describeCapabilities({ camera: acts }, context)[0]!.reads.find((r) => r.accessor === "nightVision")!;
    expect(read.labels).toEqual({ 0: "Off", 1: "Infrared", 3: "Infrared On" });
    expect(read.values).toEqual([0, 1, 3]);
    for (const mode of [0, 1, 3, "3"]) {
      expect(buildCommand("nightVision", mode, context)).toEqual(
        buildCommand("nightVision", Number(mode), { ...context, model: "T8416P00" }),
      );
      expect(buildCommand("nightVision", mode, context)).toBeDefined();
    }
    expect(() => buildCommand("nightVision", 2, context)).toThrow(/valid value/);
  });
  it.each([
    ["T8425", "T9000"],
    ["T8416", "T8030"],
  ])("keeps the base night-vision modes on %s with %s", (model, stationModel) => {
    const context = {
      ...ctx,
      model,
      stationModel,
      channelIsUnambiguous: true,
      paramIds: new Set([...ctx.paramIds!, 1277]),
    };
    const { acts } = bind<CameraActions>("camera", context, { read: () => ({ value: 1 }) });
    expect(
      describeCapabilities({ camera: acts }, context)[0]!.reads.find((r) => r.accessor === "nightVision")?.labels,
    ).toEqual({ 0: "Off", 1: "Infrared", 2: "Full Color" });
    expect(buildCommand("nightVision", 2, context)).toBeDefined();
    expect(() => buildCommand("nightVision", 3, context)).toThrow(/valid value/);
  });
  it.each(["T8425", "T8426", "T8171", "T8134", "T9999"])("does not extend the recording domain on %s", (model) => {
    const context = { ...ctx, model, readParameter: () => config };
    for (const tier of [0, 4]) {
      const reported = { ...config, cur_mode: 0, mode_0: { quality: tier } };
      expect(
        bind<CameraActions>("camera", context, { read: () => ({ value: encode(reported) }) }).acts.recordingQuality,
      ).toBeUndefined();
      expect(() => buildCommand("recordingQuality", tier, context)).toThrow(/valid value/);
    }
  });
  it("preserves T8416 labels on other station topologies", () => {
    const context = { ...ctx, model: "T8416", stationModel: "T8030" };
    const { acts } = bind<CameraActions>("camera", context, { read: () => ({ value: config }) });
    expect(
      describeCapabilities({ camera: acts }, context)[0]!.reads.find((r) => r.accessor === "recordingQuality")?.labels,
    ).toEqual({ 1: "HD (720P)", 2: "Full HD (1080P)", 3: "Max" });
    expect(() => buildCommand("recordingQuality", "2K", context)).toThrow(/valid value/);
  });
  it.each([0, 4, "nonsense"])("refuses invalid recording tier %s", (value) => {
    expect(() => buildCommand("recordingQuality", value, { ...ctx, readParameter: () => config })).toThrow(
      /valid value/,
    );
  });
  it("reads the latest bound device value on every merge", async () => {
    const dev = Device.fromRecord("fixture-camera", {
      deviceType: 47,
      model: "T8425",
      params: { 2731: encode(config) },
    });
    const sent: unknown[] = [];
    dev.bindActions(ctx, {
      dispatch: async (command) => {
        sent.push(command);
      },
    });
    dev.applyParams({ 2731: encode({ ...config, cur_mode: 0, mode_1: { quality: 1 } }) });
    await dev.camera!()!.setRecordingQuality!(2);
    const command = sent[0] as { text: string };
    expect(JSON.parse(Buffer.from(command.text, "base64").toString()).mode_1).toEqual({ quality: 1 });
  });
  it("preserves the P2P decoder's refusal of an unparsed wrapped string", () => {
    const raw = Buffer.from(encode(config)).toString("base64");
    const p2p = bind<CameraActions>("camera", { ...ctx, stationModel: "T8030" }, { read: () => ({ value: raw }) }).acts;
    const rtc = bind<CameraActions>("camera", ctx, { read: () => ({ value: raw }) }).acts;
    expect(p2p.recordingQuality).toBeUndefined();
    expect(rtc.recordingQuality).toBe(2);
  });

  it("keeps the published P2P recording wire and LED wire unchanged", () => {
    const p2p = { ...ctx, stationModel: "T8030" };
    expect(buildCommand("recordingQuality", 2, p2p)).toEqual({
      kind: "set-payload",
      cmd: 2731,
      payload: { channel: 0, mode: 0, primary_view: 0, quality: 2 },
      channel: 2,
      mValue3: 0,
      form: "auto",
    });
    expect(buildCommand("statusLed", true, p2p)).toMatchObject({
      kind: "set-param",
      param: 1045,
      value: 1,
      form: "int-string",
    });
    expect(buildCommand("statusLed", true, ctx)).toMatchObject({
      kind: "set-param",
      param: 1045,
      value: 1,
      form: "direct-binary",
    });
  });
});

describe("T9000 full floodlight configs", () => {
  it.each([30, 60, 180, 300, 900])("writes verified timer choice %s through the composite config", (time) => {
    expect(buildCommand("motionLightDuration", time, { ...ctx, readParameter: () => encode(motion) })).toMatchObject({
      kind: "set-payload",
      cmd: 1422,
      mValue3: 0,
      channel: 2,
      payload: { ...motion, time },
    });
  });
  it.each([
    ["motionLightEnabled", false, { enable: 0 }],
    ["motionLightDuration", 45, { time: 45 }],
    ["motionLightBrightness", 70, { brightness: 70 }],
    ["motionLightMode", 2, { mode: 2 }],
  ] as const)("%s preserves all unrelated fields", (name, value, patch) => {
    const command = buildCommand(name, value, { ...ctx, readParameter: () => encode(motion) });
    expect(command).toMatchObject({
      kind: "set-payload",
      cmd: 1422,
      mValue3: 0,
      channel: 2,
      payload: { ...motion, ...patch },
    });
  });
  it("merges schedule entries without replacing location or vendor fields", () => {
    const current = { ...motion, schedule: [{ start: "18:00", end: "20:00", weekdays: [1] }] };
    const schedule = [{ ...current.schedule[0], start: "19:00" }];
    expect(
      buildCommand("lightSchedule", JSON.stringify(schedule), { ...ctx, readParameter: () => current }),
    ).toMatchObject({ kind: "set-payload", cmd: 1421, payload: { ...current, schedule } });
  });
  it.each([undefined, "bad", {}, { enable: 1 }])("refuses unavailable or partial light configs", (raw) => {
    expect(() => buildCommand("motionLightEnabled", true, { ...ctx, readParameter: () => raw })).toThrow(
      /valid reported/,
    );
    expect(() => buildCommand("lightSchedule", "[]", { ...ctx, readParameter: () => raw })).toThrow(/valid reported/);
  });
  it.each(["{}", "bad", "null", "[null]", "[1]", "[true]", '["entry"]', "[[]]"])(
    "refuses invalid schedule %s",
    (value) => {
      expect(() => buildCommand("lightSchedule", value, { ...ctx, readParameter: () => motion })).toThrow(/JSON array/);
    },
  );
  it.each([-1, 1.5, NaN, Infinity, 256, 1e10])("refuses invalid motion mode %s", (value) => {
    expect(() => buildCommand("motionLightMode", value, { ...ctx, readParameter: () => motion })).toThrow();
  });
  it("reads typed members from their single owner payload", () => {
    const { acts } = bind<LightActions>("light", ctx, { read: () => ({ value: motion }) });
    expect([
      acts.motionLightEnabled,
      acts.motionLightDuration,
      acts.motionLightBrightness,
      acts.motionLightMode,
    ]).toEqual([true, 30, 50, 1]);
  });
  it("makes the existing composite method preserve the reported config", async () => {
    const { acts, sent } = bind<LightActions>("light", { ...ctx, readParameter: () => motion });
    await acts.setAutoSpotlight(false, { time: 45 });
    expect(sent[0]).toMatchObject({ payload: { ...motion, enable: 0, time: 45 } });
  });
  it("withholds the new RTC-specific members from P2P cameras", () => {
    const { acts } = bind<LightActions>("light", { ...ctx, stationModel: "T8030" });
    expect(acts.motionLightEnabled).toBeUndefined();
    expect(acts.setMotionLightDuration).toBeUndefined();
  });
});

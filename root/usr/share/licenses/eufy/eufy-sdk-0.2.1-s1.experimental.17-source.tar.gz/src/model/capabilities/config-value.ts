import type { Command } from "../../core/contracts.js";
import type { CommandContext } from "./types.js";

/** Compose against the current report or acknowledged predecessor, serialized at dispatch. */
export function parameterCommand(
  param: number,
  ctx: CommandContext,
  build: (raw: unknown) => Command,
  fields: readonly string[],
): Command {
  const read = () => ctx.readParameter?.(param);
  return ctx.parameterWrites?.command(param, read, build, fields) ?? build(read());
}

/** Parse a reported object, JSON text, or at most two base64 wrappers, without retaining malformed input. */
export function configObject(raw: unknown): Record<string, unknown> | undefined {
  let value = raw;
  for (let depth = 0; depth < 4; depth++) {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      try {
        return JSON.parse(JSON.stringify(value)) as Record<string, unknown>;
      } catch {
        return undefined;
      }
    }
    if (typeof value !== "string" || value.length > 65536) return undefined;
    const text = value;
    try {
      value = JSON.parse(text);
    } catch {
      if (depth >= 2 || !/^[A-Za-z0-9+/]+={0,2}$/.test(text) || text.length % 4 !== 0) return undefined;
      value = Buffer.from(text, "base64").toString("utf8");
    }
  }
  return undefined;
}

/** Full reported capture configuration required for a safe primary-quality edit. */
export function captureConfig(raw: unknown): Record<string, unknown> | undefined {
  const cfg = configObject(raw);
  const primary = cfg?.mode_0;
  const secondary = cfg?.mode_1;
  return cfg &&
    Number.isInteger(cfg.cur_mode) &&
    primary &&
    typeof primary === "object" &&
    !Array.isArray(primary) &&
    secondary &&
    typeof secondary === "object" &&
    !Array.isArray(secondary) &&
    Number.isInteger((primary as Record<string, unknown>).quality) &&
    Number.isInteger((secondary as Record<string, unknown>).quality)
    ? cfg
    : undefined;
}

/** Full scheduling configuration, with numeric motion fields when required. */
function lightConfig(raw: unknown, motion: boolean): Record<string, unknown> | undefined {
  const cfg = configObject(raw);
  return cfg &&
    Array.isArray(cfg.schedule) &&
    (!motion || ["enable", "brightness", "mode", "time"].every((key) => typeof cfg[key] === "number"))
    ? cfg
    : undefined;
}

/** Composite parameter validators shared by write builders and cloud-report replacement. */
export const compositeConfigs: ReadonlyMap<number, (raw: unknown) => Record<string, unknown> | undefined> = new Map([
  [2731, captureConfig],
  [1421, (raw) => lightConfig(raw, false)],
  [1422, (raw) => lightConfig(raw, true)],
]);

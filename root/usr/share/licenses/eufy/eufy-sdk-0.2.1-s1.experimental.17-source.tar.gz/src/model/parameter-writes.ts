import { isDeepStrictEqual } from "node:util";
import type { Command, CommandSink } from "../core/contracts.js";
import { CompositeWriteSupersededError } from "../core/contracts.js";
import { configObject } from "./capabilities/config-value.js";

/** Deferred composite builders retain their parameter owner without adding wire fields. */
const prepared = new WeakMap<Command, (sink: CommandSink, acknowledged: () => boolean) => Promise<void>>();

/** Dispatch a composite inside its parameter queue, or an ordinary command directly. */
export function dispatchParameterCommand(
  command: Command,
  sink: CommandSink,
  acknowledged: () => boolean = () => true,
): Promise<void> {
  return prepared.get(command)?.(sink, acknowledged) ?? sink.dispatch(command);
}

/** A field retains its original baseline and ordered acknowledgements until external replacement or expiry. */
type Patch = { baseline: unknown; values: { value: unknown; acknowledgedAt: number }[] };

/** Prune expired acknowledgements and recognize baseline or retained values as lagging reports. */
function lagging(patch: Patch, value: unknown): boolean {
  patch.values = patch.values.filter((entry) => Date.now() - entry.acknowledgedAt < 120_000);
  return (
    patch.values.length > 0 &&
    (isDeepStrictEqual(value, patch.baseline) || patch.values.some((entry) => isDeepStrictEqual(value, entry.value)))
  );
}
/** A queued intent contains only explicitly requested fields; superseded fields are removed before send. */
type Pending = {
  param: number;
  fields: Map<string, unknown>;
  run: () => Promise<void>;
  resolve: () => void;
  reject: (error: Error) => void;
  timer: ReturnType<typeof setTimeout>;
};

/** Read a declared config field; arrays remain atomic values. */
function field(config: Record<string, unknown> | undefined, path: string): unknown {
  return path
    .split(".")
    .reduce<unknown>(
      (value, key) => (value && typeof value === "object" ? (value as Record<string, unknown>)[key] : undefined),
      config,
    );
}

/** Replace an existing declared config field in an independently cloned config. */
function put(config: Record<string, unknown>, path: string, value: unknown): void {
  const keys = path.split(".");
  let owner = config;
  for (const key of keys.slice(0, -1)) owner = owner[key] as Record<string, unknown>;
  owner[keys.at(-1)!] = structuredClone(value);
}

/** Per-device field overlays expire after 120 seconds; at most 32 intents per parameter wait up to 60 seconds. */
export class ParameterWrites {
  private readonly tracked = new Set<number>();
  private readonly observed = new Map<number, unknown>();
  private readonly patches = new Map<number, Map<string, Patch>>();
  private readonly flights = new Map<number, Map<string, Patch>>();
  private readonly active = new Set<number>();
  private readonly queue: Pending[] = [];
  private generation = 0;

  /** Baselines and retained acknowledgements preserve patches; third values retire only their own field. */
  observe(param: number, value: unknown): void {
    if (!this.tracked.has(param)) return;
    this.observed.set(param, structuredClone(value));
    const config = configObject(value);
    for (const patches of [this.patches.get(param), this.flights.get(param)]) {
      if (!patches) continue;
      for (const [path, patch] of patches) {
        if (!lagging(patch, field(config, path))) patches.delete(path);
      }
    }
  }

  /** Discard composition state and unsent work across an identity or connection lifecycle boundary. */
  reset(): void {
    this.generation++;
    this.tracked.clear();
    this.observed.clear();
    this.patches.clear();
    this.flights.clear();
    this.active.clear();
    for (const pending of [...this.queue]) this.remove(pending, new Error("Composite write owner changed"));
  }

  /** Compose the latest acknowledgement over lagging reports; expired or externally edited fields retire. */
  private current(param: number, raw = this.observed.get(param)): unknown {
    const config = configObject(raw);
    if (!config) return raw;
    for (const [path, patch] of this.patches.get(param) ?? []) {
      if (lagging(patch, field(config, path))) put(config, path, patch.values.at(-1)!.value);
      else this.patches.get(param)!.delete(path);
    }
    return config;
  }

  /** Remove queued work and settle its caller without claiming a dispatch or acknowledgement. */
  private remove(pending: Pending, error: Error): void {
    const index = this.queue.indexOf(pending);
    if (index < 0) return;
    this.queue.splice(index, 1);
    clearTimeout(pending.timer);
    pending.reject(error);
  }

  /** Drain each parameter independently; completions from older owners cannot release a new owner's slot. */
  private drain(param: number): void {
    if (this.active.has(param)) return;
    const index = this.queue.findIndex((pending) => pending.param === param);
    if (index < 0) return;
    const pending = this.queue.splice(index, 1)[0]!;
    clearTimeout(pending.timer);
    this.active.add(param);
    const generation = this.generation;
    void pending
      .run()
      .then(pending.resolve, pending.reject)
      .finally(() => {
        if (generation !== this.generation) return;
        this.active.delete(param);
        this.drain(param);
      });
  }

  /** Validate now, coalesce explicit fields before send, and rebuild against the latest report. */
  command(param: number, read: () => unknown, build: (raw: unknown) => Command, paths: readonly string[]): Command {
    const initial = structuredClone(read());
    const command = build(this.current(param, initial));
    const desired = configObject(
      command.kind === "set-payload" ? command.payload : command.kind === "raw-text" ? command.text : undefined,
    );
    const requested = new Map(paths.map((path) => [path, structuredClone(field(desired, path))]));
    prepared.set(
      command,
      (sink, acknowledged) =>
        new Promise<void>((resolve, reject) => {
          if (paths.length === 0 || paths.length > 32) return reject(new Error("Invalid composite write fields"));
          const remaining = this.queue.filter(
            (pending) => pending.param === param && [...pending.fields.keys()].some((path) => !requested.has(path)),
          );
          if (remaining.length >= 32) return reject(new Error("Composite write queue is full"));
          for (const pending of [...this.queue]) {
            if (pending.param !== param) continue;
            for (const path of requested.keys()) pending.fields.delete(path);
            if (pending.fields.size === 0) this.remove(pending, new CompositeWriteSupersededError());
          }
          this.tracked.add(param);
          this.observe(param, initial);
          const generation = this.generation;
          const pending: Pending = {
            param,
            fields: new Map(requested),
            resolve,
            reject,
            timer: setTimeout(() => this.remove(pending, new Error("Composite write expired before send")), 60_000),
            run: async () => {
              const latest = read();
              if (!isDeepStrictEqual(latest, initial) || !this.observed.has(param)) this.observe(param, latest);
              const base = configObject(this.current(param));
              const template = build(base);
              if (!base) throw new Error("Composite write requires a reported config");
              const report = configObject(this.observed.get(param));
              const flight = new Map<string, Patch>();
              for (const [path, value] of pending.fields) {
                put(base, path, value);
                const previous = this.patches.get(param)?.get(path);
                flight.set(path, {
                  baseline: structuredClone(previous ? previous.baseline : field(report, path)),
                  values: [...structuredClone(previous?.values ?? []), { value, acknowledgedAt: Infinity }],
                });
              }
              const next =
                template.kind === "set-payload"
                  ? { ...template, payload: base }
                  : template.kind === "raw-text"
                    ? { ...template, text: Buffer.from(JSON.stringify(base)).toString("base64") }
                    : template;
              this.flights.set(param, flight);
              try {
                await sink.dispatch(next);
                if (!acknowledged() || generation !== this.generation) return;
                let patches = this.patches.get(param);
                if (!patches) this.patches.set(param, (patches = new Map()));
                for (const [path, patch] of flight) {
                  for (const entry of patch.values)
                    if (entry.acknowledgedAt === Infinity) entry.acknowledgedAt = Date.now();
                  patches.set(path, patch);
                }
              } finally {
                if (this.flights.get(param) === flight) this.flights.delete(param);
              }
            },
          };
          pending.timer.unref?.();
          this.queue.push(pending);
          this.drain(param);
        }),
    );
    return command;
  }
}

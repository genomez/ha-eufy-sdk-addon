import { EventEmitter } from "node:events";
import { afterEach, describe, expect, it, vi } from "vitest";
import { bind } from "./bind.js";
import type { DoorbellActions } from "../doorbell.js";
import type { CommandContext } from "../types.js";
import type { LiveStreamConsumer, MediaProvider } from "../../../core/contracts.js";

const ctx: CommandContext = {
  codec: "camera",
  model: "T8214",
  deviceType: 94,
  stationModel: "T9000",
  channel: 2,
  paramIds: new Set(),
};
function fixture() {
  const stream = Object.assign(new EventEmitter(), { stop: vi.fn() });
  const media = { live: vi.fn(async () => stream as unknown as LiveStreamConsumer) } as unknown as MediaProvider;
  const bound = bind<DoorbellActions>("doorbell", ctx, { media });
  return { ...bound, stream, media };
}
afterEach(() => vi.useRealTimers());

describe("RTC quick-response playback timing", () => {
  it("waits through battery wake and 2.5 seconds after the first video frame", async () => {
    vi.useFakeTimers();
    const { acts, sent, stream } = fixture();
    const work = acts.playQuickResponse(3);
    await vi.advanceTimersByTimeAsync(4000);
    expect(sent).toEqual([]);
    stream.emit("video", { data: Buffer.from([1]) });
    await vi.advanceTimersByTimeAsync(2499);
    expect(sent).toEqual([]);
    await vi.advanceTimersByTimeAsync(1);
    expect(sent).toEqual([{ kind: "set-param", param: 1706, value: 3, form: "direct-binary", channel: 2 }]);
    await vi.advanceTimersByTimeAsync(1500);
    await work;
    expect(stream.stop).toHaveBeenCalledOnce();
    expect(stream.listenerCount("video") + stream.listenerCount("stop") + stream.listenerCount("error")).toBe(0);
  });
  it.each(["stop", "error", "timeout"])("refuses playback when video fails: %s", async (event) => {
    vi.useFakeTimers();
    const { acts, sent, stream } = fixture();
    const result = acts.playQuickResponse(1).catch((error: unknown) => error);
    await vi.advanceTimersByTimeAsync(0);
    if (event === "timeout") await vi.advanceTimersByTimeAsync(25000);
    else stream.emit(event, new Error("synthetic failure"));
    expect(await result).toBeInstanceOf(Error);
    expect(sent).toEqual([]);
    expect(stream.stop).toHaveBeenCalledOnce();
    expect(stream.eventNames()).toEqual([]);
  });
  it("refuses if the stream stops during the settle window", async () => {
    vi.useFakeTimers();
    const { acts, sent, stream } = fixture();
    const result = acts.playQuickResponse(1).catch((error: unknown) => error);
    await vi.advanceTimersByTimeAsync(0);
    stream.emit("video", {});
    await vi.advanceTimersByTimeAsync(1000);
    stream.emit("stop");
    expect(await result).toBeInstanceOf(Error);
    expect(sent).toEqual([]);
  });
  it("does not let engage:false bypass the RTC frame gate", async () => {
    vi.useFakeTimers();
    const { acts, sent, stream, media } = fixture();
    const result = acts.playQuickResponse(2, { engage: false }).catch((error: unknown) => error);
    await vi.advanceTimersByTimeAsync(0);
    expect(media.live).toHaveBeenCalledOnce();
    stream.emit("stop");
    await result;
    expect(sent).toEqual([]);
  });
  it.each([-1, 1.5, NaN, Infinity, 0x100000000])("refuses invalid voice id %s without media work", async (voice) => {
    const { acts, sent, media } = fixture();
    await expect(acts.playQuickResponse(voice)).rejects.toThrow(/unsigned integer/);
    expect(media.live).not.toHaveBeenCalled();
    expect(sent).toEqual([]);
  });
});

it("allows first video near the deadline to complete its full wake window", async () => {
  vi.useFakeTimers();
  const { acts, sent, stream } = fixture();
  const work = acts.playQuickResponse(3);
  await vi.advanceTimersByTimeAsync(24900);
  stream.emit("video", {});
  await vi.advanceTimersByTimeAsync(2500);
  expect(sent).toHaveLength(1);
  await vi.advanceTimersByTimeAsync(1500);
  await work;
  expect(stream.eventNames()).toEqual([]);
});
it("checks liveness again between the settle timer and command dispatch", async () => {
  vi.useFakeTimers();
  const { acts, sent, stream } = fixture();
  const off = stream.off.bind(stream);
  vi.spyOn(stream, "off").mockImplementation((event, listener) => {
    const result = off(event, listener);
    if (event === "video") queueMicrotask(() => stream.emit("stop"));
    return result;
  });
  const result = acts.playQuickResponse(1).catch((error: unknown) => error);
  await vi.advanceTimersByTimeAsync(0);
  stream.emit("video", {});
  await vi.advanceTimersByTimeAsync(2500);
  expect(await result).toBeInstanceOf(Error);
  expect(sent).toEqual([]);
  expect(stream.eventNames()).toEqual([]);
});

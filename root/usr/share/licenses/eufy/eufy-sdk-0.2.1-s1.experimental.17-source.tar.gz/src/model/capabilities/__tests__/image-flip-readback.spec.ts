import { Device } from "../../device.js";
import { type CameraActions } from "../camera.js";
import { describeCapabilities, describeWriteOnlySettings, mergeProperties } from "../index.js";
import { unobservableMembers } from "../members.js";
import type { CommandContext } from "../types.js";
import { bind } from "./bind.js";

const context = (model = "T8171", stationModel = "T9000", reported = true): CommandContext => ({
  model,
  stationModel,
  homeBaseAttached: true,
  codec: "camera",
  channel: 2,
  capabilities: new Set(["camera"]),
  paramIds: new Set(reported ? [1207] : []),
});

describe("image flip readback on T8171 with T9000", () => {
  it.each([true, false])("keeps a write-only control with reported parameter=%s", async (reported) => {
    const ctx = context("T8171", "T9000", reported);
    const { acts, sent } = bind<CameraActions>("camera", ctx, { read: () => ({ value: false }) });
    expect(acts).not.toHaveProperty("imageFlipped");
    expect(unobservableMembers(acts)).toContain("imageFlipped");
    expect(mergeProperties(["camera"], ctx).map((p) => p.name)).not.toContain("imageFlipped");
    const manifest = describeCapabilities({ camera: acts }, ctx)[0]!;
    expect(manifest.reads.map((p) => p.property)).not.toContain("imageFlipped");
    expect(manifest.actions.find((a) => a.name === "setImageFlipped")).toMatchObject({
      writeOnly: true,
      form: "momentary",
      args: [{ name: "imageFlipped", kind: "boolean" }],
    });
    expect(manifest.actions.find((a) => a.name === "setImageFlipped")?.reflects).toBeUndefined();
    expect(describeWriteOnlySettings({ camera: acts }, ctx)).toContainEqual(
      expect.objectContaining({
        name: "imageFlipped",
        paramType: 1207,
        type: "bool",
        kind: "boolean",
        writable: true,
        writeOnly: true,
      }),
    );
    await acts.setImageFlipped(true);
    await acts.setImageFlipped(false);
    expect(sent).toEqual([
      { kind: "set-param", param: 1207, value: 1, channel: 2, form: "auto" },
      { kind: "set-param", param: 1207, value: 0, channel: 2, form: "auto" },
    ]);
  });

  it.each([
    ["T8170", "T9000"],
    ["T8416", "T9000"],
    ["T8171", "T8030"],
    ["T8171", undefined],
  ])("preserves reported readback on %s with station %s", (model, stationModel) => {
    const ctx = { ...context(model), stationModel };
    const { acts } = bind<CameraActions>("camera", ctx, { read: () => ({ value: false }) });
    expect(acts.imageFlipped).toBe(false);
    expect(mergeProperties(["camera"], ctx).find((p) => p.name === "imageFlipped")?.writable).toBe(true);
    const manifest = describeCapabilities({ camera: acts }, ctx)[0]!;
    expect(manifest.reads.find((p) => p.property === "imageFlipped")?.writable).toBe(true);
    expect(manifest.actions.find((a) => a.name === "setImageFlipped")).toMatchObject({
      form: "stateful",
      reflects: "imageFlipped",
    });
    expect(manifest.actions.find((a) => a.name === "setImageFlipped")?.writeOnly).toBeUndefined();
  });

  it("withholds stale named state after learning the station topology", () => {
    const dev = Device.fromRecord("fixture-camera", { model: "T8171", params: { 1207: "0" } });
    expect(dev.getProperty("imageFlipped")?.value).toBe(false);
    dev.setStationContext({ stationModel: "T9000" });
    dev.bindActions(context(), { dispatch: async () => {} });
    expect(dev.getProperty("imageFlipped")).toBeUndefined();
    expect(dev.getPropertyValue("imageFlipped")).toBeUndefined();
    expect(dev.getProperties()).not.toHaveProperty("imageFlipped");
    expect(dev.getProperties()).not.toHaveProperty("indoorRotateImage");
    expect(dev.getPropertySpecs().map((p) => p.name)).not.toContain("imageFlipped");
    dev.applyParams({ 1207: "1" });
    expect(dev.getProperty("imageFlipped")).toBeUndefined();
    expect(dev.camera!()).not.toHaveProperty("imageFlipped");
  });
});

import { describe, expect, it } from "vitest";
import { Device } from "../../device.js";
import { buildActions, buildCommand, mergeProperties, describeWriteOnlySettings } from "../index.js";
import type { CommandContext } from "../types.js";
import type { Command } from "../../../core/contracts.js";

function context(model = "T8134", stationModel = "T9000", doorbell = false): CommandContext {
  return {
    codec: "camera",
    model,
    deviceType: model === "T8134" ? 19 : 93,
    channel: 2,
    stationModel,
    paramIds: new Set([1400, 1708, 1718, 2706, 2731]),
    capabilities: new Set(["camera", "light", "motion", "audio", ...(doorbell ? ["doorbell" as const] : [])]),
  };
}

describe("reviewed topology gates", () => {
  it("retains light reads while withholding unwritable T9000 switches", () => {
    for (const model of ["T8134", "T8214"]) {
      const ctx = context(model);
      const spec = mergeProperties(["light"], ctx).find((p) => p.name === "light");
      expect(spec?.writable).toBe(false);
      const actions = buildActions(["light"], { ctx, sink: { dispatch: async () => {} }, read: () => undefined });
      expect(actions.light?.on).toBeUndefined();
      expect(actions.light?.off).toBeUndefined();
      expect(actions.light?.set).toBeUndefined();
      expect(buildCommand("light", true, ctx)).toBeUndefined();
    }
    expect(mergeProperties(["light"], context("T8134", "T8030")).find((p) => p.name === "light")?.writable).toBe(true);
  });
  it("offers loitering only on T9000 doorbells while retaining other topologies", () => {
    expect(mergeProperties(["motion"], context()).some((p) => p.name === "loiteringDetection")).toBe(false);
    expect(buildCommand("loiteringDetection", true, context())).toBeUndefined();
    expect(buildCommand("loiteringDetection", true, context("T8214", "T9000", true))).toBeDefined();
    expect(buildCommand("loiteringDetection", true, context("T8134", "T8030"))).toBeDefined();
  });
  it("withholds accessory tones and doorbell recording quality only on T9000", () => {
    for (const station of ["T9000", "T8030"]) {
      const ctx = context("T8214", station, true);
      const names = mergeProperties(["camera", "doorbell"], ctx).map((p) => p.name);
      expect(names.includes("dingdongRingtone")).toBe(station !== "T9000");
      expect(mergeProperties(["camera"], ctx).find((p) => p.name === "recordingQuality")?.writable).toBe(
        station !== "T9000",
      );
      expect(names).toContain("videoQuality");
    }
  });
  it("describes only installed write-only controls and preserves the prompt wire", async () => {
    const ctx: CommandContext = {
      codec: "station",
      model: "T9000",
      deviceType: 27,
      channel: 0,
      paramIds: new Set(),
      capabilities: new Set(["audio"]),
    };
    const sent: Command[] = [];
    const actions = buildActions(["audio"], {
      ctx,
      sink: {
        dispatch: async (cmd) => {
          sent.push(cmd);
        },
      },
      read: () => undefined,
    });
    const specs = describeWriteOnlySettings(actions, ctx);
    expect(specs.find((p) => p.name === "promptVolume")).toMatchObject({
      min: 0,
      max: 100,
      kind: "percent",
      writable: true,
    });
    await actions.audio?.setPromptVolume?.(50);
    expect(sent).toEqual([{ kind: "set-payload", cmd: 1292, payload: { value: 50 }, channel: 0, mValue3: 0 }]);
    expect(describeWriteOnlySettings({}, ctx)).toEqual([]);
  });
  it("reports cross-capability ringtone writes alongside their existing read", () => {
    const device = Device.fromRecord("fixture-camera", {
      model: "T8214",
      deviceType: 93,
      params: { 1708: "50", 1240: "1" },
    });
    device.bindActions(context("T8214", "T9000", true), { dispatch: async () => {} });
    const read = device
      .describe()
      .details.flatMap((d) => d.reads)
      .find((r) => r.property === "ringtoneVolume");
    expect(read).toMatchObject({ writable: false, min: 0, max: 100 });
    expect(device.writeOnlySettings.find((p) => p.name === "ringtoneVolume")).toBeDefined();
  });
});

describe("reviewed write-only discovery boundaries", () => {
  it.each(["T9000", "T9000-family"])("discovers and validates model-only prompt volume on %s", async (model) => {
    const device = Device.fromRecord("fixture-station", { model, params: {} });
    const sent: Command[] = [];
    device.bindActions(
      { codec: "station", model, channel: 0, paramIds: new Set() },
      {
        dispatch: async (command) => {
          sent.push(command);
        },
      },
    );
    expect(device.writeOnlySettings).toEqual([
      expect.objectContaining({ name: "promptVolume", paramType: 1292, step: 1 }),
    ]);
    for (const value of [-1, 0.5, 50.5, 101, NaN, Infinity]) {
      await expect(device.audio!()!.setPromptVolume!(value)).rejects.toThrow();
    }
    expect(sent).toEqual([]);
    await device.audio!()!.setPromptVolume!(50);
    expect(sent).toEqual([expect.objectContaining({ cmd: 1292, payload: { value: 50 }, mValue3: 0 })]);
  });
  it.each(["T8030", "T9000"])("does not discover unrelated controls on %s", (stationModel) => {
    for (const model of ["T8214", "T8425"]) {
      const ctx = context(model, stationModel, model === "T8214");
      const actions = buildActions(["audio", "light", "siren"], {
        ctx,
        sink: { dispatch: async () => {} },
        read: () => undefined,
      });
      expect(describeWriteOnlySettings(actions, ctx).map((s) => [s.name, s.paramType])).toEqual(
        stationModel === "T9000" && model === "T8214" ? [["ringtoneVolume", 1708]] : [],
      );
    }
    const ctx: CommandContext = {
      codec: "station",
      model: stationModel,
      deviceType: 18,
      channel: 0,
      paramIds: new Set(),
      capabilities: new Set(["audio", "siren"]),
    };
    const actions = buildActions(["audio", "siren"], {
      ctx,
      sink: { dispatch: async () => {} },
      read: () => undefined,
    });
    expect(describeWriteOnlySettings(actions, ctx).map((s) => s.name)).toEqual(
      stationModel === "T9000" ? ["promptVolume"] : [],
    );
  });
});

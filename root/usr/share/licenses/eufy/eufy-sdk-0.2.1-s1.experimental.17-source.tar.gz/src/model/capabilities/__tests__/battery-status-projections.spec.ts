import { Device } from "../../device.js";
import { BATTERY, BATTERY_PARAM, type BatteryActions } from "../battery.js";
import { buildCommand, describeCapabilities } from "../index.js";
import type { CommandContext } from "../types.js";
import { bind } from "./bind.js";

const device = (status?: string | number | boolean) => {
  const params: Record<number, string> = { 1101: "50" };
  if (status !== undefined) params[2111] = String(status);
  const dev = Device.fromRecord("fixture-camera", {
    model: "T8171",
    params,
  });
  if (status !== undefined) dev.applyParams({ 2111: status });
  return dev;
};

const context = (reported: boolean): CommandContext => ({
  model: "T8171",
  codec: "camera",
  channel: 1,
  capabilities: new Set(["battery"]),
  paramIds: new Set(reported ? [1101, 2111] : [1101]),
});

describe("battery status scalar projections", () => {
  it.each([
    [4, true],
    [5, true],
    [12, true],
    [20, true],
    [0, false],
    [1, false],
    [2, false],
    [3, false],
    [6, false],
  ])("decodes status %s as solarPanelConnected=%s independently of charging", (status, connected) => {
    for (const raw of [status, String(status)]) {
      const dev = device(raw);
      const ctx = context(true);
      dev.bindActions(ctx, { dispatch: async () => {} });
      expect(dev.battery!()!.solarPanelConnected).toBe(connected);
      expect(dev.getProperty("solarPanelConnected")?.value).toBe(connected);
      expect(dev.getPropertyValue("solarPanelConnected")).toBe(connected);
      expect(dev.getPropertyValue("charging")).toBe(status !== 0 && status !== 2);
      expect(dev.getPropertySpecs().find((spec) => spec.name === "solarPanelConnected")).toMatchObject({
        paramType: 2111,
        type: "bool",
        kind: "boolean",
        provenance: "apk",
        writable: false,
      });
      expect(dev.describe().details.find((cap) => cap.capability === "battery")?.reads).toContainEqual(
        expect.objectContaining({
          accessor: "solarPanelConnected",
          property: "solarPanelConnected",
          type: "bool",
          kind: "boolean",
          writable: false,
        }),
      );
      expect(buildCommand("solarPanelConnected", true, ctx)).toBeUndefined();
    }
  });

  it.each([undefined, "", "   ", NaN, Infinity, "not-numeric", true, false])(
    "answers undefined for absent or malformed status %s",
    (raw) => {
      const dev = device(raw);
      dev.bindActions(context(raw !== undefined), { dispatch: async () => {} });
      expect(dev.battery!()!.solarPanelConnected).toBeUndefined();
      expect(dev.getPropertyValue("solarPanelConnected")).toBeUndefined();
      expect(dev.getPropertyValues().solarPanelConnected).toBeUndefined();
      expect(dev.getProperty("solarPanelConnected")).toBeUndefined();
      expect(dev.getProperties()).not.toHaveProperty("solarPanelConnected");
    },
  );

  it("requires reported 2111 for both schema and manifest discovery", () => {
    const dev = device();
    const ctx = context(false);
    const { acts } = bind<BatteryActions>("battery", ctx);
    expect(dev.properties.map((p) => p.name)).not.toContain("solarPanelConnected");
    expect(acts).not.toHaveProperty("solarPanelConnected");
    expect(describeCapabilities({ battery: acts }, ctx)[0]?.reads.map((p) => p.property)).not.toContain(
      "solarPanelConnected",
    );
  });

  it("updates both interpretations and announces the derived connection when 2111 changes", () => {
    const dev = device(4);
    expect(dev.announcements(dev.applyParams({ 2111: "1" }))).toContainEqual({
      property: "solarPanelConnected",
      value: false,
    });
    expect(dev.getPropertyValue("charging")).toBe(true);
    expect(dev.getPropertyValue("solarPanelConnected")).toBe(false);
    expect(dev.announcements(dev.applyParams({ 2111: "" }))).toContainEqual({ property: "solarPanelConnected" });
    expect(dev.getProperty("solarPanelConnected")).toBeUndefined();
  });

  it("backfills solarPanelConnected when 2111 first arrives after resolve", () => {
    const dev = Device.fromRecord("fixture-camera", { model: "T8171", params: { 1101: "50" } });
    expect(dev.properties.map((p) => p.name)).not.toContain("solarPanelConnected");
    dev.applyParams({ 2111: "4" }, 1234);
    expect(dev.getPropertyValue("charging")).toBe(true);
    dev.reresolve({ params: { 2111: "4" } });
    expect(dev.properties.map((p) => p.name)).toContain("solarPanelConnected");
    expect(dev.getProperty("solarPanelConnected")).toMatchObject({ value: true, paramType: 2111, ts: 1234 });
  });

  it("keeps the query-only 6482 schema unexposed and out of typed reads", () => {
    const dev = Device.fromRecord("fixture-camera", { model: "T8171", params: { 1101: "50", 6482: "1" } });
    const ctx = { ...context(false), paramIds: new Set([1101, 6482]) };
    dev.bindActions(ctx, { dispatch: async () => {} });
    expect(BATTERY.properties.find((p) => p.paramType === BATTERY_PARAM.SOLAR_CONNECT_24H)).toMatchObject({
      name: "solarConnected24h",
      unexposed: true,
    });
    expect(dev.getPropertySpecs().find((p) => p.name === "solarConnected24h")?.unexposed).toBe(true);
    expect(dev.battery!()).not.toHaveProperty("solarConnected24h");
    expect(dev.getPropertyValue("solarConnected24h")).toBeUndefined();
    expect(
      dev
        .describe()
        .details.find((cap) => cap.capability === "battery")
        ?.reads.map((p) => p.property),
    ).not.toContain("solarConnected24h");
  });
});

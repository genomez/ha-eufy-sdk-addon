import { describe, expect, it } from "vitest";
import type { Command, CommandSink } from "../../core/contracts.js";
import { Device } from "../device.js";
import { ParameterWrites } from "../parameter-writes.js";

const capture = {
  cur_mode: 0,
  mode_0: { quality: 2, audio: 1 },
  mode_1: { quality: 3, audio: 0 },
  extension: { retained: true },
};
const motion = {
  brightness: 100,
  enable: 1,
  time: 180,
  mode: 1,
  schedule: [{ start: "18:00", end: "23:00" }],
  sunset2rise: 0,
  latitude: "",
  longtitude: "",
  extension: { retained: true },
};

function encode(value: unknown, wrappers: number): string {
  let text = JSON.stringify(value);
  for (let index = 0; index < wrappers; index++) text = Buffer.from(text).toString("base64");
  return text;
}

function fixture(params: Record<number, string>, parameterWrites?: ParameterWrites) {
  const device = Device.fromRecord("T8000P0000000000", {
    model: "T8425",
    deviceType: 47,
    category: "eufy_security",
    parentSn: "T9000P0000000000",
    params: { 1400: "0", ...params },
  });
  const sent: Command[] = [];
  const sink: CommandSink = { dispatch: async (command) => void sent.push(command) };
  device.bindActions(
    {
      channel: 2,
      codec: "camera",
      model: "T8425",
      deviceType: 47,
      stationModel: "T9000",
      homeBaseAttached: true,
      paramIds: new Set([1400, ...Object.keys(params).map(Number)]),
      parameterWrites,
    },
    sink,
  );
  return { device, sent, sink };
}

describe("Device composite parameter binding", () => {
  it.each([1, 2])("preserves a capture config reported with %i base64 wrappers", async (wrappers) => {
    const { device, sent } = fixture({ 2731: encode(capture, wrappers) });
    expect(device.camera?.()?.recordingQuality).toBe(2);
    await device.camera?.()!.setRecordingQuality("3K");
    expect(sent).toEqual([
      {
        kind: "raw-text",
        cmd: 2731,
        channel: 2,
        text: encode({ ...capture, mode_0: { ...capture.mode_0, quality: 3 } }, 1),
      },
    ]);
    expect(device.camera?.()?.recordingQuality).toBe(2);
  });

  it.each([0, 1, 2])("preserves the full motion config with %i base64 wrappers", async (wrappers) => {
    const { device, sent } = fixture({ 1422: encode(motion, wrappers) });
    expect(device.light?.()?.motionLightBrightness).toBe(100);
    expect(device.light?.()?.motionLightDuration).toBe(180);
    expect(device.light?.()?.motionLightMode).toBe(1);
    await device.light?.()!.setMotionLightBrightness!(65);
    expect(sent).toEqual([
      {
        kind: "set-payload",
        cmd: 1422,
        channel: 2,
        mValue3: 0,
        form: undefined,
        payload: { ...motion, brightness: 65 },
      },
    ]);
    expect(device.light?.()?.motionLightBrightness).toBe(100);
  });

  it("preserves outer schedule fields across station context changes", async () => {
    const { device, sent } = fixture({ 1421: encode(motion, 0) });
    device.setStationContext({ stationModel: "T8030" });
    device.setStationContext({ stationModel: "T9000" });
    const schedule = [{ start: "20:00", end: "22:00", weekdays: [1, 3] }];
    await device.light?.()!.setLightSchedule!(JSON.stringify(schedule));
    expect(sent).toEqual([
      {
        kind: "set-payload",
        cmd: 1421,
        channel: 2,
        mValue3: 0,
        form: undefined,
        payload: { ...motion, schedule },
      },
    ]);
  });

  it.each([false, true])("composes acknowledged fields over fresh raw reports (shared owner: %s)", async (shared) => {
    const { device, sent, sink } = fixture({ 1422: encode(motion, 0) }, shared ? new ParameterWrites() : undefined);
    let release!: () => void;
    sink.dispatch = async (command) => {
      sent.push(command);
      if (sent.length === 1) await new Promise<void>((resolve) => (release = resolve));
    };
    const light = device.light?.()!;
    const brightness = light.setMotionLightBrightness!(65);
    const duration = light.setMotionLightDuration!(45);
    const report = { ...motion, enable: 0, extension: { retained: false } };
    device.applyParams({ 1422: encode(report, 0) });
    release();
    await Promise.all([brightness, duration]);
    expect(sent[1]).toMatchObject({ payload: { ...report, brightness: 65, time: 45 } });
    await light.setMotionLightMode!(2);
    expect(sent[2]).toMatchObject({ payload: { ...report, brightness: 65, time: 45, mode: 2 } });
    expect(light.motionLightBrightness).toBe(100);
    expect(light.motionLightDuration).toBe(180);
  });

  it("updates the recording write gate when valid raw reports arrive and disappear", async () => {
    const { device, sent } = fixture({ 2731: "invalid" });
    expect(device.camera?.()?.setRecordingQuality).toBeUndefined();
    device.applyParams({ 2731: encode(capture, 2) });
    const camera = device.camera?.()!;
    expect(camera.setRecordingQuality).toBeTypeOf("function");
    await camera.setRecordingQuality(3);
    device.applyParams({ 2731: encode({ cur_mode: 0, mode_0: { quality: 2 } }, 1) });
    expect(device.camera?.()?.setRecordingQuality).toBeUndefined();
    await expect(camera.setRecordingQuality(1)).rejects.toThrow("valid reported capture config");
    expect(sent).toHaveLength(1);
  });

  it("keeps reported capture data independent of the exposed property cache", async () => {
    const { device, sent } = fixture({ 2731: encode(capture, 1) });
    expect(device.camera?.()?.recordingQuality).toBe(2);
    device.getProperty("recordingQuality")!.value = 2;
    await device.camera?.()!.setRecordingQuality(3);
    expect(sent).toEqual([
      {
        kind: "raw-text",
        cmd: 2731,
        channel: 2,
        text: encode({ ...capture, mode_0: { ...capture.mode_0, quality: 3 } }, 1),
      },
    ]);
  });

  it("keeps reported motion data independent of the exposed property cache", async () => {
    const { device, sent } = fixture({ 1422: encode(motion, 0) });
    expect(device.light?.()?.motionLightBrightness).toBe(100);
    device.getProperty("motionLightEnabled")!.value = true;
    await device.light?.()!.setMotionLightBrightness!(65);
    expect(sent[0]).toMatchObject({ payload: { ...motion, brightness: 65 } });
  });

  it("keeps the full report when a schedule property holds only its decoded entries", async () => {
    const { device, sent } = fixture({ 1421: encode(motion, 0) });
    device.getProperty("lightSchedule")!.value = JSON.stringify(motion.schedule);
    await device.light?.()!.setLightSchedule!("[]");
    expect(sent[0]).toMatchObject({ payload: { ...motion, schedule: [] } });
  });

  it("preserves capture acknowledgements and sibling updates across lagging raw reports", async () => {
    const { device, sent } = fixture({ 2731: encode(capture, 2) });
    const camera = device.camera?.()!;
    await camera.setRecordingQuality(3);
    const report = { ...capture, mode_1: { quality: 1, audio: 1 }, extension: { retained: false } };
    device.applyParams({ 2731: encode(report, 1) });
    await camera.setRecordingQuality(1);
    expect(sent[1]).toEqual({
      kind: "raw-text",
      cmd: 2731,
      channel: 2,
      text: encode({ ...report, mode_0: { ...report.mode_0, quality: 1 } }, 1),
    });
    expect(camera.recordingQuality).toBe(2);
  });
});

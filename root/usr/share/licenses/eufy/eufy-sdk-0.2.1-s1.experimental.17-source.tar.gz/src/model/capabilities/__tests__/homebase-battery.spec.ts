import { Device, type RawParams } from "../../device.js";
import type { BatteryActions } from "../battery.js";

function battery(model: string, params: Record<number, string> = {}) {
  const dev = Device.fromRecord("synthetic-device", { model, params: { 1101: "100", ...params } });
  dev.bindActions(
    { model, codec: dev.codec, channel: 0, paramIds: new Set([1101, ...Object.keys(params).map(Number)]) },
    {
      dispatch: async () => {
        throw new Error("Command I/O forbidden");
      },
    },
  );
  return dev;
}

describe("HomeBase battery cloud parameters", () => {
  it.each(["T9000", "T9000A", "t9000"])("selects read-only station parameters on %s", (model) => {
    const dev = battery(model, { 1198: "12", 1314: "97", 1313: "86400" });
    expect(dev.getProperty("batteryHealth")).toMatchObject({ value: 97, paramType: 1314 });
    expect(dev.getProperty("batteryLifeEstimate")).toMatchObject({ value: 86400, paramType: 1313 });
    expect(dev.battery?.()?.health).toBe(97);
    expect(dev.battery?.()?.lifeEstimate).toBe(86400);
    expect(dev.properties.find((p) => p.name === "batteryLifeEstimate")).toMatchObject({
      type: "number",
      kind: "seconds",
      unit: "s",
      min: 0,
      step: 1,
      writable: false,
    });
    expect(dev.battery?.()).not.toHaveProperty("setLifeEstimate");
    expect(
      dev
        .describe()
        .details.flatMap((d) => d.reads)
        .find((r) => r.property === "batteryLifeEstimate"),
    ).toMatchObject({ writable: false });
  });

  it.each([{}, { 1198: "97" }] as Record<number, string>[])(
    "does not invent station values without 1313/1314: %j",
    (params) => {
      const dev = battery("T9000", params);
      expect(dev.getPropertyValue("batteryHealth")).toBeUndefined();
      expect(dev.getPropertyValue("batteryLifeEstimate")).toBeUndefined();
      expect(dev.battery?.()).not.toHaveProperty("health");
      expect(dev.battery?.()).not.toHaveProperty("lifeEstimate");
    },
  );

  it.each(["T8134", "T8170"])("keeps camera health on 1198 and excludes station life on %s", (model) => {
    const dev = battery(model, { 1198: "89", 1314: "97", 1313: "86400" });
    expect(dev.getProperty("batteryHealth")).toMatchObject({ value: 89, paramType: 1198 });
    expect(dev.properties.map((p) => p.name)).not.toContain("batteryLifeEstimate");
    expect(dev.battery?.()).not.toHaveProperty("lifeEstimate");
  });

  it.each(["T8214", "T8217", " t8214 ", "\tt8217 "])("preserves doorbell health exclusion on %s", (model) => {
    const dev = battery(model, { 1198: "0", 1314: "97", 1313: "86400" });
    expect(dev.getPropertyValue("batteryHealth")).toBeUndefined();
    expect(dev.battery?.()).not.toHaveProperty("health");
    expect(dev.battery?.()).not.toHaveProperty("lifeEstimate");
  });

  it.each(["0", "86400"])("decodes reported duration %s without losing zero", (raw) => {
    expect(battery("T9000", { 1313: raw }).battery?.()?.lifeEstimate).toBe(Number(raw));
  });

  it.each(["", " ", "-1", "1.5", "NaN", "Infinity", "invalid", "9007199254740992"])(
    "clears malformed duration %j instead of inventing a value",
    (raw) => {
      const dev = battery("T9000", { 1313: "86400" });
      dev.applyParams({ 1313: raw });
      expect(dev.getPropertyValue("batteryLifeEstimate")).toBeUndefined();
      expect(dev.battery?.()?.lifeEstimate).toBeUndefined();
    },
  );

  it.each(["", " ", "-1", "101", "NaN", "Infinity", "invalid"])("withholds invalid health %j", (raw) => {
    expect(battery("T9000", { 1314: raw }).getPropertyValue("batteryHealth")).toBeUndefined();
  });

  it("withholds out-of-range camera parameter 1198", () => {
    const dev = battery("T8134", { 1198: "101" });
    expect(dev.getPropertyValue("batteryHealth")).toBeUndefined();
    expect(dev.battery?.()?.health).toBeUndefined();
  });

  it.each([null, undefined])("clears battery readings on nullish input %j", (raw) => {
    const dev = battery("T9000", { 1313: "86400", 1314: "97" });
    dev.applyParams({ 1313: raw, 1314: raw } as unknown as RawParams);
    expect(dev.battery?.()?.health).toBeUndefined();
    expect(dev.battery?.()?.lifeEstimate).toBeUndefined();
  });

  it.each(["0", "100"])("retains boundary health %s", (raw) => {
    expect(battery("T9000", { 1314: raw }).battery?.()?.health).toBe(Number(raw));
  });
});

const _lifeEstimate: BatteryActions["lifeEstimate"] = 86400;
const _readOnly: "setLifeEstimate" extends keyof BatteryActions ? never : true = true;
export const _surface = [_lifeEstimate, _readOnly];

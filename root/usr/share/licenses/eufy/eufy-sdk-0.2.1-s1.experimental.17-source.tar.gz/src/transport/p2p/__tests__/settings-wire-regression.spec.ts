import { describe, expect, it, vi } from "vitest";
import { ACCOUNT_ID, DEVICE_SN, connectedSession, routerWithSession } from "./session-fixtures.js";

describe("unchanged P2P control bytes", () => {
  it.each([1401, 1403, 1035, 1207, 1214, 1230])("preserves direct body %i", async (param) => {
    const session = connectedSession();
    const send = vi.fn(() => true);
    Object.assign(session, { sendRawLevel2Bytes: send });
    const router = routerWithSession(session);
    await router.dispatchCommand(DEVICE_SN, { kind: "set-param", param, value: 1, form: "direct-binary", channel: 1 });
    const expected = Buffer.alloc(136);
    expected.writeUInt32LE(1, 0);
    expected.writeUInt32LE(1, 4);
    expected.write(ACCOUNT_ID, 8, "ascii");
    expect(send.mock.calls).toEqual(Array(5).fill([expected, 1, param, 8]));
  });
  it.each([1249, 1250, 1251])("preserves station body %i", async (cmd) => {
    const session = connectedSession();
    const send = vi.fn(() => true);
    Object.assign(session, { sendRawLevel2Bytes: send });
    const router = routerWithSession(session);
    await router.dispatchCommand(DEVICE_SN, { kind: "p2p-station-scalar", cmd, value: 75, channel: 1 });
    const expected = Buffer.alloc(132);
    expected.writeUInt32LE(75);
    expected.write(ACCOUNT_ID, 4, "ascii");
    expect(send.mock.calls).toEqual(Array(5).fill([expected, 1, cmd, 8]));
  });
  it("preserves the int-string LED and 1350 quality writes", async () => {
    const session = connectedSession();
    const led = vi.fn(() => true);
    const payload = vi.fn(() => true);
    Object.assign(session, { sendIntStringCommand: led, sendControlLevel2: payload });
    const router = routerWithSession(session);
    await router.dispatchCommand(DEVICE_SN, {
      kind: "set-param",
      param: 1045,
      value: 1,
      form: "int-string",
      channel: 1,
    });
    await router.dispatchCommand(DEVICE_SN, {
      kind: "set-payload",
      cmd: 2731,
      payload: { channel: 0, mode: 0, primary_view: 0, quality: 2 },
      channel: 1,
      mValue3: 0,
      form: "auto",
    });
    expect(led.mock.calls).toEqual(Array(5).fill([1045, 1, 1, ACCOUNT_ID, 1]));
    expect(payload.mock.calls).toEqual(
      Array(5).fill([2731, 1, ACCOUNT_ID, { channel: 0, mode: 0, primary_view: 0, quality: 2 }, 0]),
    );
  });
});

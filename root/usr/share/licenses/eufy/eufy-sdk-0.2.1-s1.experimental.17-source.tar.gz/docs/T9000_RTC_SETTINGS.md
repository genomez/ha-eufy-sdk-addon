# T9000 RTC settings in experimental.16

These changes apply to HomeBase S1 (T9000) control sessions and their attached devices. Other stations retain their existing P2P command bodies, encryption selection, and replay behavior. This is local SDK implementation; no device acceptance was performed for this revision.

## Public settings surface

Use `Device.describe().details` to discover installed reads, actions, kinds, labels, and `writable` flags. A missing setter means the selected transport cannot carry the routed intent or the required evidence is absent. Retained reads remain available. The fluent getters remain the source for fields borrowed from a composite parameter; those fields do not each allocate a separate stored property.

| Capability member             | Setter                             | Kind / values                     | T9000 behavior                                                                                                             |
| ----------------------------- | ---------------------------------- | --------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `camera.statusLed`            | `setStatusLed(boolean)`            | boolean                           | Direct-binary 1045, 1 = on. Doorbells retain 1350/1716.                                                                    |
| `camera.recordingQuality`     | `setRecordingQuality(tierOrName)`  | enum: 1 = 720P, 2 = 1080P, 3 = 3K | Exact raw-text 2731 containing base64 JSON. Numeric tiers and the three labels are accepted. 720P is untested on hardware. |
| `light.brightness`            | `setBrightness(number)`            | percent, 1–100                    | Direct-binary 1401.                                                                                                        |
| `light.spotlightEnabled`      | `setEnabled(boolean)`              | boolean                           | Direct-binary 1403.                                                                                                        |
| `light.motionLightEnabled`    | `setMotionLightEnabled(boolean)`   | boolean                           | Full 1350/1422 config, updates `enable`.                                                                                   |
| `light.motionLightDuration`   | `setMotionLightDuration(number)`   | seconds, positive integer         | Full 1350/1422 config, updates `time`.                                                                                     |
| `light.motionLightBrightness` | `setMotionLightBrightness(number)` | percent, integer 1–100            | Full 1350/1422 config, updates `brightness`.                                                                               |
| `light.motionLightMode`       | `setMotionLightMode(number)`       | integer, 0–255                    | Full 1350/1422 config, updates the existing `mode`; no unevidenced mode labels.                                            |
| `light.lightSchedule`         | `setLightSchedule(string)`         | text: JSON array of plain objects | Full 1350/1421 config, replaces only the existing `schedule` array. No inferred schedule-entry schema.                     |

The motion-light and schedule members require a T9000-attached floodlight and reported backing parameters. Writes refuse absent, malformed, or unsupported config shapes. Configs may be reported as objects, JSON, or up to two base64 wrappers. Motion-light writes require the reported `enable`, `time`, `brightness`, `mode`, and `schedule` fields. The existing `setAutoSpotlight(on, options)` also merges on T9000, changing only explicitly supplied options. Its P2P behavior remains unchanged.

Station-context resolution promotes retained unknown parameters into their resolved property names, preserving their original observation timestamps. Cold construction and every fresh `getDevice()` therefore populate the reported 1421/1422 getters and permit composite writes without waiting for another report. Binding a model with station context performs the same resolution. `Device.describe()` uses station context for read labels, including the T9000 recording-quality enum. Recording-quality setters are absent unless a parseable full 2731 config is reported; malformed reports remain read-only.

Recording quality reads retain the existing **active-mode** semantics. Writes change only `mode_0.quality`; `cur_mode`, `mode_1`, extra mode fields, and unknown config fields are preserved. Thus if `cur_mode` selects mode 1, the active quality read can remain unchanged after editing mode 0. Missing or malformed current capture configs refuse the write. Parameter 1286 is never used for this setting.

Composite writes serialize per device and parameter (1421, 1422, 2731), including `setAutoSpotlight` on 1422 and the generic property API. Fresh handles from the same facade share that ownership. Composition starts from the latest observed configuration and applies ACKed patches per explicit field, including atomic schedule arrays and `mode_0.quality`. Each field retains its original pre-write baseline and ordered ACKed values, each for 120 seconds. Reports matching that baseline or any unexpired ACKed value are treated as lagging and composition uses the latest ACKed value. Confirmation does not retire a patch; a third value retires only that field. A→B followed by an app edit back to A is indistinguishable from a lagging report, so B wins until its TTL expires. Expired history values no longer count as lagging; the original baseline remains while any ACK is unexpired. Failed or unacknowledged writes never create patches. Reports arriving mid-flight use the same per-field precedence. Getters and observation timestamps continue to describe reported state.

Queued unsent intents coalesce by device, parameter, and explicit field; the last value wins. Superseded callers reject with `CompositeWriteSupersededError` (`superseded_before_send`, `sendAttempted: false`). Each device and parameter admits at most 32 queued intents, each with a 60-second enqueue deadline; the in-flight intent is preserved and other parameters remain independent. Lifecycle changes clear patches and reject unsent work. No network read or compare-and-swap isolation from another client's writes is provided. Obtain a current report before editing an old retained configuration.

Overlay regression validation: `npm test -- parameter-writes t9000-composition-regression` passed 40 tests. Full `npm test` passed 7,674 tests with 8 skipped. Typecheck, build, ESM import and all five architecture guards passed. Coverage includes confirmation followed by stale cloud reads, repeated same-field writes and return-to-baseline writes, third-value retirement, 119/120/121-second TTL boundaries, per-value history expiry, failed replacements, queue isolation, reset ownership and unreferenced enqueue timers. No hardware acceptance was performed.

## Doorbell quick responses

- `doorbell.quickResponses({ timeoutMs? })` now works with the RTC media provider. It returns the existing `QuickResponse[]` (`voiceId`, `name`, optional `path`, and `custom`) from 1350/6237 → 1351/6237 `voice_list`.
- `doorbell.playQuickResponse(voiceId, { engage? })` joins the existing media provider, waits up to 25 seconds for actual video delivery, then waits at least 2.5 seconds before direct-binary 1706. It retains the stream for another 1.5 seconds and detaches its own consumer. RTC always joins a consumer, including with `engage: false`; P2P retains its existing override.
- Query replies require the current station session, notification link/envelope, device channel, and matching inner command. Nonzero segments must match; unsegmented notifications are temporally attributed within one serialized exchange. A timed-out query is retired without closing the station session, disrupting live streams, or dropping other queued commands. The same channel/subcommand query is quarantined for at most 45 seconds; a matching late reply drains the quarantine early. Replies delayed beyond that bound remain ambiguous because unsegmented notifications have no transaction identity. Other queries remain usable. Rejections include the numeric device code. Acknowledgement alone does not answer a query.

## Transport gate and read-only members

RTC carries the existing `set-json` / `set-payload` routes (1700 / 1350), including full 1421/1422 configs. New scalar and text routes are admitted by parameter **and layout**, for attached devices and the station itself. `set-json-raw` remains refused. The single `T9000_VERIFIED_CONTROL_LAYOUTS` constant records the live-test allowlist, grounded in `diagnostics/t9000-command-encodings-20261114/COMMAND_STATUS.md`:

| Layout                                          | Live-verified parameters                                                                       |
| ----------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| direct-binary (`set-param`, auto/direct-binary) | 1011, 1035, 1045, 1207, 1214, 1230, 1240, 1241, 1401, 1403, 1702, 1703, 1704, 1705, 1706, 1708 |
| station-132 (`p2p-station-scalar`)              | 1249, 1250, 1251                                                                               |
| raw-text (`cmd`, `text`, `channel`)             | 2731                                                                                           |

Unlisted new scalar/text routes have no setter: this includes anti-theft 1015, RTSP publication 1145 (including publish/withdraw aliases), alarm volume 1235, working mode 1246, and color temperature 1410. No siren/alarm parameter is admitted by this new allowlist. Existing JSON alarm/prompt routes retain their prior behavior. Admission applies only to RTC portal kinds; ff09, MQTT-DP, and AIOT-DP commands retain their independent routing. Raw text is rejected by P2P. Direct-binary bodies are 136 bytes; station-scalar bodies are 132 bytes. Attached scalar bodies use the reported device channel, while station commands use 255.

The gate runs after capability routing, applies to described setters and generic write intents, and preserves getter evidence. It removes `camera.setPrivacy` (the unsupported privacy burst). It makes `light.isOn` read-only on families whose switch builder requires int-string: the indoor/outdoor 1080p/2K families, outdoor PT, Cam2/Cam2C/Pro, and Cam3/Cam3C. Their `light.set` setter and `on`/`off` aliases are absent. T8425's 1700 light switch remains writable. Explicit `p2p-int-string` intents remain unsupported. Value-dependent setters are withheld if either emitted branch is uncarryable. Unprobeable builders retain their explicit runtime refusal; transport admission still runs before send.

`motion.setTestMode` remains unsupported for T9000 sensor types; no additional write wire is admitted.

`rtsp.published` remains a retained read on T9000; publication setters and aliases are withheld.

Known string parameters, including 1286, 1718, and 2731, cannot take binary scalar writes. The facade also checks the complete security parameter dictionary for string-valued slots. Dingdong ringtone selection (1718) is withheld on T9000; other stations retain their existing envelope. HomeBase alarm tone 1281 and prompt volume 1292 retain their existing 1350/0 routes. Motion sensitivity 1276 retains the device channel in its JSON body.

Receipts and command diagnostics contain numeric headers and finite outcomes, without parameter payloads or identities. RTC connection logs omit station identifiers and candidate exception text. Location fields are preserved in config bodies and are never included in settings diagnostics.

Known retained-state item: `Device.toJSON()` and `getProperties()` can expose the complete reported 1422 configuration, including location fields. This predates these settings changes and is unchanged. The generic composite-write context also retains its existing cloud-only parameter read; realtime-only `dpParams` composition is outside this revision. Settings diagnostics and logs do not include these fields. Non-T9000 devices retain the published .15 state names and decoded values (`motionActivateLight` for 1422; `unknown_1421` for 1421).

No probe HTTP entry points, experimental portal-spec types, or frame recorder were imported into this release branch. This SDK revision changes no external runtime.

## Implementation file map

Shared files occur in more than one item because the gate, serializers, and composite reads meet at the same boundary. `model/parameter-writes.ts` owns deferred composition, per-parameter serialization, ACK overlays, and report precedence.

| Item                    | Source files (relative to `src/`)                                                                                                                                | Focused or updated specs (relative to `src/`)                                                                                                      |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1. Production routing   | `core/contracts.ts`; `transport/rtc/{control-command,command-router,command-diagnostics,connection-deadline,session,peer}.ts`; `transport/p2p/command-router.ts` | `transport/rtc/__tests__/{control-command,command-router,connection-deadline}.spec.ts`; `transport/p2p/__tests__/settings-wire-regression.spec.ts` |
| 2. Wire constraints     | `transport/rtc/control-command.ts`; `client/eufy-mega.ts`                                                                                                        | `transport/rtc/__tests__/control-command.spec.ts`; `client/__tests__/t9000-write-gate.spec.ts`                                                     |
| 3. Capability gate      | `client/eufy-mega.ts`; `model/device.ts`; `model/capabilities/{members,index,types,rtsp}.ts`                                                                     | `client/__tests__/t9000-write-gate.spec.ts`; `model/capabilities/__tests__/rtsp.spec.ts`                                                           |
| 4. Camera LED           | `model/capabilities/camera.ts`                                                                                                                                   | `model/capabilities/__tests__/t9000-settings.spec.ts`                                                                                              |
| 5. Recording quality    | `model/capabilities/{camera,config-value,index}.ts`; `model/device.ts`                                                                                           | `model/capabilities/__tests__/{camera,t9000-settings}.spec.ts`; `model/__tests__/cached-evidence.spec.ts`                                          |
| 6. Quick responses      | `model/capabilities/doorbell.ts`; `transport/rtc/command-router.ts`; `core/contracts.ts`                                                                         | `model/capabilities/__tests__/rtc-quick-response.spec.ts`; `client/__tests__/t9000-rtc-query.spec.ts`                                              |
| 7. Floodlight extras    | `model/capabilities/{light,config-value,members}.ts`; `model/param-dictionary.ts`                                                                                | `client/__tests__/t9000-light-settings.spec.ts`; `model/capabilities/__tests__/{light,t9000-settings,property-id-integrity}.spec.ts`               |
| 8. Cold station context | `model/device.ts`                                                                                                                                                | `client/__tests__/t9000-cold-context.spec.ts`                                                                                                      |

Package metadata: `package.json` and `package-lock.json` now identify experimental.16. This document is the added public-surface guide.

## Local validation

- `npm test -- t9000 parameter-writes signaling control-command rtc-quick-response settings-wire-regression src/transport/rtc/__tests__/command-router.spec.ts src/model/capabilities/__tests__/rtsp.spec.ts src/model/capabilities/__tests__/property-id-integrity.spec.ts`: 329 passed, 15 files. Field-baseline precedence, stale refreshes, lagging polls, in-flight reports, TTL expiry, account scope, bounded/coalesced queues, signaling privacy, and bounded query recovery are covered. Cold construction, fresh facade reads, delayed station context, observation timestamps, recording-quality labels, missing capture config, and unchanged non-T9000 state/command bodies are covered.
- `npm test`: 7,652 passed, 8 skipped, all 332 files passed. No timing flakes were observed in this run. The test matrix starts from the published .15 tree and excludes the probe branch's feature tests.
- `npm run typecheck`: passed, zero diagnostics.
- `npm run build`: passed.
- `npm run check:esm`: passed, 374 exports.
- All five repository architecture/documentation guards passed. Changed files passed formatting and whitespace checks. Guard scripts ran with the installed Git Bash on PATH; the default Windows bash route requires an unavailable WSL distribution.

## Reviewed control applicability

T9000 non-doorbell cameras no longer advertise loitering detection. Doorbells retain it.
Accessory chime ringtone selection is withheld on T9000; other stations retain support.
Doorbells attached to T9000 have no recording-quality setter for 2731; their video-quality
control remains on 1705. Light/1400 reads remain available, but T9000 setters are installed
only for the supported JSON-wire families. Int-string and unknown-wire families have no setter.
No reboot route for 1034 is established on RTC.

`Device.writeOnlySettings` projects only installed, declared write-only value setters from
bound capability descriptors. It never invokes a getter or setter. Reported ringtone volume
1708 retains its read and has a separately owned audio setter. Prompt volume 1292 on T9000
uses 1350 with `{value}` and explicit `mValue3: 0`; it has no confirmed cloud readback.

Floodlight motion-light duration uses the metadata envelope 30–900 seconds with the existing
integer step. The upstream declaration `DeviceFloodlightLightSettingsMotionTriggeredTimerT8425Property`
in eufy-security-client `src/http/types.ts` at revision
`4faba498a9ebd3889fdf2b9aabaaf97e169e5b6e` inherits named values 30, 60, 180, 300 and 900,
and is assigned to both T8425 and T8426. This establishes metadata bounds, not acceptance of
every intermediate second. The audited reported duration, 180 seconds, is within those bounds.
No model-specific clip or interval domain was added for T8425, T8426 or T8416: their applicable
upstream entries do not establish it, and unrelated floodlight/battery defaults are insufficient.

Night vision (1277) uses the uniquely resolved attached-device channel in both the T9000 portal header and payload. Missing, invalid or duplicate channel evidence withholds its setter. Other stations retain outer channel zero. The payload-setter audit found no other remaining attached-device outer-channel-zero override; AI detection (1298) already uses the resolved channel. Reboot (1034) is unsupported on T9000 and is rejected before context preparation or transport use. `Device.canReboot` reports this limitation.

Residual: a previously bound device handle can retain stale channel evidence after roster changes. This revision does not rebind held handles; dispatch preparation remains the final target check. No hardware acceptance was performed.
